# =====================================================================
# engine/spec_generator.py
# ---------------------------------------------------------------------
# قابلیت جدید: «سورس‌کد → Spec»
# agent سورس‌های پروژه وب را می‌خواند (engine/source_scanner.py)،
# ویژگی‌ها/فرم‌ها/جریان‌ها را تحلیل می‌کند و برای هر flow یک Spec
# YAML قابل‌اجرا (بدون selector!) تولید می‌کند — مطابق
# .skills/spec-generation/SKILL.md و .agents/planner.md
# =====================================================================

import json
import os

import yaml

import config

from engine.ai_client import AIClient, parse_json_loose
from engine.source_scanner import SourceScanner


# ---------------------------------------------------------------------
# پرامپت تحلیل هر chunk
# ---------------------------------------------------------------------

EXTRACT_SYSTEM = """You are the Planner agent (see .agents/planner.md) —
a senior QA architect who reads SOURCE CODE and extracts testable,
user-visible behavior.

Rules (binding):
- Only report behavior you can actually SEE in the code — never invent
  constraints, limits, or flows (Constitution #6).
- Ignore styling, internal state, and dead code.
- Detect the UI language of labels/texts; describe features in THAT
  language (Persian labels → Persian descriptions).
- Fields without visible labels: describe by placeholder/role.
- Mark anything uncertain with "confidence": "low".

Reply ONLY with JSON:
{
  "features": [
    {
      "name": "short-kebab-name",
      "title": "Human-readable feature title",
      "entry": "/route-or-file-hint",
      "summary": "one paragraph of what this feature does",
      "forms": [
        {
          "label": "form/section label",
          "fields": [
            {"name": "field name/label", "type": "text|password|...",
             "placeholder": "...", "required": true, "constraints":
             "min/max/format ONLY if visible in code"}
          ],
          "submit": "submit button text (if visible)"
        }
      ],
      "actions": ["visible button/link texts"],
      "api_calls": ["/api/..."],
      "auth_flow": true|false,
      "risks": ["otp|captcha|upload|auth|payment if present"],
      "confidence": "high|medium|low"
    }
  ]
}"""


PLAN_SYSTEM = """You are the Planner agent. You merge extracted features
into final executable QA Specs.

For EACH feature that deserves a spec, output a YAML document.
Rules (binding):
- Step descriptions must be natural human sentences (same language as the
  UI) — the agent will resolve elements semantically at runtime.
- ABSOLUTELY NO CSS/XPath selectors anywhere (Constitution #14).
- Steps schema:
    id: REQ-001
    description: "..."
    action: type|click|select|upload|prompt_user|wait|verify
    target_hint: "semantic hint (label/button text)"
    value: "value if any"
    wait_for: "text=acceptance text"   (optional)
    policy: must_complete_before_submit|must_complete|
            requires_all_inputs_filled|optional
- auth_flow=true → include login steps first, with prompt_user for OTP
  (never a hard-coded code) — credentials via {secret:...} placeholders.
- Fields with explicit constraints → add negative_cases (from the code
  only!).
- Uncertain behavior → add review: needs-verification on that step.
- One output document per feature, separated by a line containing ONLY:
  ---SPEC---

Reply with the YAML documents only — no prose, no markdown fences."""


class SpecGenerator:

    def __init__(self, source_path, out_dir=None, max_files=None,
                 base_url=None, model=None):
        self.source_path = source_path
        self.out_dir = out_dir or os.path.join(
            config.GENERATED_DIR, "specs")
        self.base_url = base_url
        self.model = model

        self.ai = AIClient(model=model) if model else AIClient()
        self.scanner = SourceScanner(
            source_path, max_files=max_files or 120)

    # -----------------------------------------------------------------
    # خط لوله کامل: اسکن → تحلیل chunk ها → ادغام → نوشتن فایل‌ها
    # -----------------------------------------------------------------

    def generate(self):
        print("=" * 62)
        print("🧬 GEN-SPEC — source code → executable Specs")
        print(f"📂 Source : {self.source_path}")
        print(f"📤 Output : {self.out_dir}")
        print("=" * 62)

        result = self.scanner.scan()
        print(f"🧩 framework: {result.framework}  "
              f"files: {len(result.files)}  "
              f"routes: {len(result.routes)}  "
              f"ui-language: {result.detected_language}")

        chunks = self.scanner.build_chunks()
        if not chunks:
            print("⚠️ no analyzable source files found")
            return []
        print(f"📦 {len(chunks)} analysis chunk(s)")

        # 1) تحلیل هر chunk
        features = []
        for i, chunk in enumerate(chunks, 1):
            print(f"  🧠 analyzing chunk {i}/{len(chunks)} ...")
            extracted = self._extract_chunk(chunk)
            features.extend(extracted)

        if not features:
            print("⚠️ no features extracted")
            return []

        # 2) ادغام و تولید spec ها
        specs = self._plan_specs(features)
        if not specs:
            print("⚠️ no specs produced")
            return []

        # 3) نوشتن فایل‌ها
        os.makedirs(self.out_dir, exist_ok=True)
        written = []
        for spec in specs:
            path = self._write_spec(spec)
            if path:
                written.append(path)

        # 4) ایندکس
        self._write_index(written)
        return written

    # -----------------------------------------------------------------

    def _extract_chunk(self, chunk):
        user = (
            f"SOURCE ANALYSIS (project framework: "
            f"{self.scanner.result.framework}):\n\n{chunk}\n\n"
            "Extract testable user-visible features. Reply ONLY the JSON."
        )
        try:
            data = self.ai.chat_json([
                {"role": "system", "content": EXTRACT_SYSTEM},
                {"role": "user", "content": user},
            ], retries=1)
            features = data.get("features", []) if isinstance(data, dict) \
                else []
            return [f for f in features if isinstance(f, dict)]
        except Exception as e:                              # noqa: BLE001
            print(f"    ⚠️ chunk analysis failed: {e}")
            return []

    # -----------------------------------------------------------------

    def _plan_specs(self, features):
        summary = json.dumps(
            {
                "features": features,
                "base_url": self.base_url,
                "ui_language": self.scanner.result.detected_language,
                "known_routes": [r["route"]
                                 for r in self.scanner.result.routes][:30],
            },
            ensure_ascii=False, indent=1,
        )

        user = (
            f"EXTRACTED FEATURES (JSON):\n{summary}\n\n"
            f"Base URL for all specs: "
            f"{self.base_url or '(infer from routes, e.g. http://localhost:3000)'}"
            "\n\n"
            "Produce one YAML spec document per meaningful feature/flow "
            "(max 8 specs, prioritize auth + main flows). Use ---SPEC--- "
            "separator."
        )

        try:
            raw = self.ai.chat([
                {"role": "system", "content": PLAN_SYSTEM},
                {"role": "user", "content": user},
            ], temperature=0.2)
        except Exception as e:                              # noqa: BLE001
            print(f"⚠️ planning failed: {e}")
            return []

        # جداسازی اسناد
        documents = []
        if "---SPEC---" in raw:
            parts = raw.split("---SPEC---")
        else:
            # شاید مدل fence زده باشد
            cleaned = raw.replace("```yaml", "```")
            parts = [
                p for p in cleaned.split("```") if p.strip()
            ] if "```" in cleaned else [raw]

        for part in parts:
            part = part.strip()
            if not part or "steps" not in part:
                continue
            try:
                spec = yaml.safe_load(part)
                if isinstance(spec, dict) and spec.get("steps"):
                    documents.append(spec)
            except yaml.YAMLError:
                continue

        # اعتبارسنجی + پاک‌سازی (selector ممنوع!)
        cleaned_specs = []
        for spec in documents:
            spec = self._sanitize_spec(spec)
            if spec:
                cleaned_specs.append(spec)
        return cleaned_specs

    # -----------------------------------------------------------------
    # پاک‌سازی — selector ها حذف می‌شوند (Constitution #14)
    # -----------------------------------------------------------------

    def _sanitize_spec(self, spec):
        try:
            steps = spec.get("steps") or []
            if not steps:
                return None
            clean_steps = []
            for i, step in enumerate(steps, 1):
                if not isinstance(step, dict):
                    continue
                step.pop("selector", None)          # 🔒 ممنوع
                step.setdefault("id", f"REQ-{i:03d}")
                step.setdefault("description", f"step {i}")
                clean_steps.append(step)
            spec["steps"] = clean_steps

            if self.base_url:
                # آدرس صریح کاربر بر تخمین LLM اولویت دارد
                spec["target_url"] = self.base_url

            feature = spec.get("feature") or spec.get("title") \
                or f"generated-{_next_index()}"
            spec["feature"] = _slug(feature)
            spec["generated"] = True
            return spec
        except Exception:                                    # noqa: BLE001
            return None

    # -----------------------------------------------------------------

    def _write_spec(self, spec):
        path = os.path.join(self.out_dir, f"{spec['feature']}.yaml")
        try:
            with open(path, "w", encoding="utf-8") as f:
                yaml.safe_dump(spec, f, allow_unicode=True,
                               sort_keys=False, width=100)
            print(f"  📝 {path}  ({len(spec.get('steps', []))} steps)")
            return path
        except OSError as e:
            print(f"  ⚠️ write failed: {e}")
            return None

    def _write_index(self, paths):
        index_path = os.path.join(self.out_dir, "INDEX.md")
        lines = [
            "# Generated Specs",
            "",
            f"Source: `{self.source_path}`",
            f"Framework: {self.scanner.result.framework}",
            "",
            "| Spec | Steps | Target |",
            "|------|-------|--------|",
        ]
        for p in paths:
            try:
                with open(p, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f) or {}
                steps = len(data.get("steps") or [])
                url = data.get("target_url", "")
                name = os.path.basename(p)
                lines.append(f"| `{name}` | {steps} | {url} |")
            except Exception:                              # noqa: BLE001
                continue
        lines += [
            "",
            "بازبینی انسانی توصیه می‌شود (اصل #6: چیز نامطمئن را علامت "
            "بزنید). برای اجرا:",
            "",
            "```bash",
            "python main.py run " + (paths[0] if paths else "<spec>.yaml"),
            "```",
        ]
        try:
            with open(index_path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
        except OSError:
            pass


def _slug(text):
    import re
    text = str(text or "spec")
    text = re.sub(r"[^a-zA-Z0-9\u0600-\u06FF]+", "-", text).strip("-")
    return text[:60].lower() or "generated-spec"


_SPEC_COUNTER = {"n": 0}


def _next_index():
    _SPEC_COUNTER["n"] += 1
    return _SPEC_COUNTER["n"]
