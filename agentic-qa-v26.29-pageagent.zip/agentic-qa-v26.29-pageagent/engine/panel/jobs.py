# =====================================================================
# engine/panel/jobs.py
# ---------------------------------------------------------------------
# مدیر job های پنل — اجرای run/explore در thread جدا +:
#
#   LogRouter : sys.stdout را per-thread به لاگ job مسیر می‌دهد
#               (خروجی console سرور دست‌نخورده می‌ماند)
#   AskRelay  : ask_human از agent به UI پنل می‌رسد و منتظر پاسخ
#               کاربر از مرورگر می‌ماند (کپچا/OTP از UI وارد می‌شود)
#   cancel    : بستن مرورگر + پاسخ خالی به ask → اجرا زودتر تمام می‌شود
#
# یک job فعال در هر لحظه (یک مرورگر MCP در هر اجرا — ساده و قابل پیش‌بینی).
# =====================================================================

import json
import os
import threading
import time
import uuid

import config

MAX_LOG_CHUNKS = 6000        # سقف قطعات لاگ در حافظه


# =====================================================================
# مسیردهی خروجی stdout بر اساس thread
# =====================================================================

class LogRouter:
    """پروکسی sys.stdout — نوشته‌های threadِ job به لاگ همان job می‌روند."""

    def __init__(self, original):
        self._original = original
        self._routes = {}
        self._lock = threading.Lock()

    def attach(self, job):
        with self._lock:
            self._routes[threading.get_ident()] = job

    def detach(self):
        with self._lock:
            self._routes.pop(threading.get_ident(), None)

    # --- file-like API ---
    def write(self, text):
        job = self._routes.get(threading.get_ident())
        if job is not None:
            try:
                job._write_log(text)
            except Exception:                            # noqa: BLE001
                pass
            return len(text)
        return self._original.write(text)

    def flush(self):
        try:
            self._original.flush()
        except Exception:                                # noqa: BLE001
            pass

    @property
    def encoding(self):
        return getattr(self._original, "encoding", "utf-8")


# =====================================================================
# رله‌ی ask_human → پنل
# =====================================================================

class AskRelay:
    """human_input_fn که پرسش را به UI پنل می‌فرستد و منتظر جواب می‌ماند."""

    def __init__(self, job):
        self.job = job

    def __call__(self, question):
        job = self.job
        if job.cancel_requested:
            return ""
        ask = {
            "id": uuid.uuid4().hex[:8],
            "question": str(question),
            "answer": None,
            "event": threading.Event(),
        }
        job.pending_ask = ask
        job.touch()
        print(f"👤 [panel] درخواست ورودی انسانی: {question}")
        print("   → از پنل، در کادر «پرسش از کاربر» پاسخ دهید...")

        answered = ask["event"].wait(timeout=config.PANEL_ASK_TIMEOUT)
        job.pending_ask = None
        job.touch()

        if not answered:
            print(f"⏱ [panel] پاسخی در {config.PANEL_ASK_TIMEOUT}s "
                  f"دریافت نشد — ادامه با مقدار خالی")
            return ""
        if job.cancel_requested:
            return ""
        return str(ask.get("answer") or "")


# =====================================================================
# Job
# =====================================================================

class Job:
    FINISHED = {"done", "error", "cancelled"}

    def __init__(self, jtype, title, params=None):
        self.id = uuid.uuid4().hex[:10]
        self.type = jtype                  # "run" | "explore"
        self.title = title
        self.params = params or {}

        self.status = "queued"             # queued|running|done|error|cancelled
        self.logs = []                     # قطعات خام خروجی stdout
        self.log_count = 0                 # کل قطعات (حتی بعد از trim)
        self.pending_ask = None
        self.result = None
        self.error = None
        self.run_dir = None
        self.created_at = time.time()
        self.started_at = None
        self.finished_at = None

        self.version = 0                   # bump برای SSE
        self.cancel_requested = False
        self._runner = None
        self._thread = None

    # --- داخلی ---
    def _write_log(self, text):
        self.logs.append(text)
        if len(self.logs) > MAX_LOG_CHUNKS:
            self.logs = self.logs[-MAX_LOG_CHUNKS:]
        self.log_count += 1

    def touch(self):
        self.version += 1

    @property
    def finished(self):
        return self.status in self.FINISHED

    def log_text(self, tail=None):
        parts = self.logs[-tail:] if tail else self.logs
        return "".join(parts)

    # --- نمایش ---
    def to_dict(self, log_tail=400, include_logs=True):
        d = {
            "id": self.id,
            "type": self.type,
            "title": self.title,
            "status": self.status,
            "cancel_requested": self.cancel_requested,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "version": self.version,
            "run_dir": self.run_dir,
            "result": self.result,
            "error": self.error,
            "ask": ({
                "id": self.pending_ask["id"],
                "question": self.pending_ask["question"],
            } if self.pending_ask else None),
            "log_count": self.log_count,
        }
        if include_logs:
            d["logs"] = self.log_text(tail=log_tail)
        return d

    def answer_ask(self, answer):
        ask = self.pending_ask
        if not ask:
            return False
        ask["answer"] = str(answer)
        ask["event"].set()
        return True

    def cancel(self):
        """لغو نرم: پاسخ ask را آزاد می‌کند + مرورگر را می‌بندد."""
        if self.finished:
            return False
        self.cancel_requested = True
        self.touch()
        if self.pending_ask:
            self.pending_ask["event"].set()
        runner = self._runner
        if runner is not None:
            try:
                if getattr(runner, "agent", None) is not None:
                    runner.agent.max_steps = 1
                if getattr(runner, "policy", None) is not None:
                    runner.policy.max_actions = 0
                if getattr(runner, "browser", None) is not None:
                    runner.browser.close()
            except Exception:                            # noqa: BLE001
                pass
        return True


# =====================================================================
# مدیر job ها
# =====================================================================

class JobManager:

    def __init__(self):
        self.jobs = {}                     # id → Job (به‌ترتیب درج)
        self._router = None
        self._lock = threading.Lock()
        self._active_id = None

    # -----------------------------------------------------------------
    # شروع
    # -----------------------------------------------------------------

    def start(self, jtype, params, title):
        """شروع job جدید — اگر job فعالی هست خطا می‌دهد."""
        with self._lock:
            active = self.jobs.get(self._active_id)
            if active and not active.finished:
                raise RuntimeError(
                    "یک اجرا در حال انجام است — تا پایان آن صبر کنید "
                    f"(job {self._active_id}) یا لغوش کنید"
                )
            self._install_router()

            job = Job(jtype, title, params)
            self.jobs[job.id] = job
            self._active_id = job.id

        job._thread = threading.Thread(
            target=self._run_job, args=(job,), daemon=True,
            name=f"panel-job-{job.id}")
        job._thread.start()
        return job

    def get(self, job_id):
        return self.jobs.get(job_id)

    def list_jobs(self):
        return list(self.jobs.values())

    @property
    def active_job(self):
        with self._lock:
            j = self.jobs.get(self._active_id)
            return j if (j and not j.finished) else None

    # -----------------------------------------------------------------
    # نصب router (یک بار)
    # -----------------------------------------------------------------

    def _install_router(self):
        import sys
        if isinstance(sys.stdout, LogRouter):
            self._router = sys.stdout
            return
        self._router = LogRouter(sys.stdout)
        sys.stdout = self._router

    # -----------------------------------------------------------------
    # بدنه‌ی اجرا
    # -----------------------------------------------------------------

    def _run_job(self, job):
        self._router.attach(job)
        job.status = "running"
        job.started_at = time.time()
        job.touch()
        try:
            if job.type == "run":
                result = self._execute_run(job)
            elif job.type == "explore":
                result = self._execute_explore(job)
            else:
                raise ValueError(f"unknown job type: {job.type}")
            job.result = result
            job.status = "cancelled" if job.cancel_requested else "done"
        except Exception as e:                             # noqa: BLE001
            job.error = f"{type(e).__name__}: {e}"
            job.status = "cancelled" if job.cancel_requested else "error"
            print(f"\n💥 [panel] job error: {job.error}")
        finally:
            self._router.detach()
            job.finished_at = time.time()
            # مسیر شواهد — از خود runner (اطمینان‌پذیرتر از mtime)
            runner = job._runner
            store = getattr(runner, "store", None) if runner else None
            if store is not None and getattr(store, "run_dir", None):
                job.run_dir = store.run_dir
            else:
                job.run_dir = self._last_run_dir(job)
            self._tag_run(job)
            job.touch()
            print(f"\n🏁 [panel] job {job.status} "
                  f"({int(job.finished_at - (job.started_at or time.time()))}s)")

    def _execute_run(self, job):
        from engine.spec_runner import SpecDrivenRunner
        from engine.reporter import print_terminal_report, write_html_report

        p = job.params
        spec_path = p["spec_path"]
        print("=" * 62)
        print(f"🚀 [panel] SPEC-DRIVEN RUN — {spec_path}")
        if p.get("budget"):
            print(f"   budget={p['budget']}")
        print("=" * 62)

        runner = SpecDrivenRunner(
            spec_path,
            allow_destructive=bool(p.get("allow_destructive")),
            max_actions=p.get("budget") or None,
            human_input_fn=AskRelay(job),
        )
        job._runner = runner
        verdict = runner.run()

        try:
            print_terminal_report(runner.store, runner.results,
                                  runner.feature)
            write_html_report(
                runner.store, runner.results, runner.feature,
                title=f"گزارش تست Spec-Driven — {runner.feature}",
            )
        except Exception as e:                             # noqa: BLE001
            print(f"⚠️ report: {e}")

        return {
            "kind": "run",
            "verdict": verdict,
            "feature": runner.feature,
            "spec_path": spec_path,
            "steps": [
                {"id": r.get("id"), "verdict": r.get("verdict"),
                 "reason": (r.get("reason") or "")[:200]}
                for r in runner.results
            ],
        }

    def _execute_explore(self, job):
        from engine.explorer import ExploratoryRunner
        from engine.reporter import write_html_report

        p = job.params
        print("=" * 62)
        print(f"🧭 [panel] EXPLORATORY RUN — {p['url']}")
        print(f"   intent: {p.get('intent', '')[:100]}")
        print("=" * 62)

        runner = ExploratoryRunner(
            base_url=p["url"],
            intent=p.get("intent", ""),
            budget=p.get("budget") or 60,
            allow_destructive=bool(p.get("allow_destructive")),
            human_input_fn=AskRelay(job),
        )
        job._runner = runner
        result = runner.run()

        findings = result.get("findings") or []
        fake_results = [
            {"id": f.get("id", "?"), "verdict": "INCONCLUSIVE",
             "description": f.get("description", ""),
             "reason": f"finding [{f.get('severity')}]"}
            for f in findings
        ]
        try:
            write_html_report(
                runner.store, fake_results, runner.mission_id,
                title=f"گزارش اکتشاف — {runner.mission_id}",
            )
        except Exception as e:                             # noqa: BLE001
            print(f"⚠️ report: {e}")

        return {
            "kind": "explore",
            "status": result.get("status"),
            "actions": result.get("actions"),
            "findings": [
                {"severity": f.get("severity"),
                 "description": f.get("description")}
                for f in findings
            ],
            "generated_spec": result.get("generated_spec"),
        }

    # -----------------------------------------------------------------
    # شواهد
    # -----------------------------------------------------------------

    def _last_run_dir(self, job):
        """آخرین پوشه‌ی run ساخته‌شده در طول این job."""
        try:
            ev = config.EVIDENCE_DIR
            if not os.path.isdir(ev):
                return None
            names = [n for n in os.listdir(ev)
                     if os.path.isdir(os.path.join(ev, n))]
            if not names:
                return None
            latest = max(
                names, key=lambda n: os.path.getmtime(os.path.join(ev, n)))
            mtime = os.path.getmtime(os.path.join(ev, latest))
            # فقط اگر در بازه‌ی اجرای job ساخته شده باشد
            if job.started_at and mtime >= job.started_at - 2:
                return os.path.join(ev, latest)
        except Exception:                                  # noqa: BLE001
            pass
        return job.run_dir

    @staticmethod
    def _tag_run(job):
        """run.json اجرای پنل را با اطلاعات پروژه برچسب می‌زند."""
        if not job.run_dir:
            return
        try:
            path = os.path.join(job.run_dir, "run.json")
            if not os.path.exists(path):
                return
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            data["panel_job"] = job.id
            data["panel_status"] = job.status
            if job.params.get("project_id"):
                data["project"] = job.params["project_id"]
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:                                  # noqa: BLE001
            pass


# یک نمونه‌ی مشترک برای سرور
MANAGER = JobManager()
