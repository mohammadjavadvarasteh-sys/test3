# =====================================================================
# engine/panel/server.py
# ---------------------------------------------------------------------
# پنل وب agentic-qa — فقط با کتابخانه‌ی استاندارد پایتون (بدون وابستگی
# جدید؛ مناسب محیط‌های آفلاین).
#
#   python main.py panel                → http://127.0.0.1:8787
#   python main.py panel --port 9000 --no-open
#
# امکانات API:
#   /api/state                       وضعیت کلی + پروژه‌ها + اجراهای اخیر
#   /api/projects        GET/POST    لیست / افزودن پروژه
#   /api/projects/<id>/specs GET/POST  لیست spec ها / ساخت خودکار spec
#   /api/spec             GET/PUT/DELETE  دیدن/ویرایش/حذف فایل spec
#   /api/jobs/run         POST       اجرای یک spec (در پس‌زمینه)
#   /api/jobs/explore     POST       اجرای اکتشاف (در پس‌زمینه)
#   /api/jobs/<id>        GET        وضعیت job + لاگ
#   /api/jobs/<id>/stream GET        استریم زنده (SSE)
#   /api/jobs/<id>/answer POST       پاسخ به ask_human (کپچا/OTP از UI)
#   /api/jobs/<id>/cancel POST       لغو اجرا
#   /api/runs             GET        اجراهای گذشته
#   /api/runs/<id>        GET        جزئیات اجرا + شواهد
#   /api/runs/<id>/report GET        گزارش HTML
#   /api/to-spec          POST       ساخت spec از اجرای گذشته
#   /api/doctor | /api/skills        سلامت سیستم / لیست skill ها
# =====================================================================

import json
import os
import re
import shutil
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

import yaml

import config
from engine.panel.jobs import MANAGER

PANEL_VERSION = "1.0"
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "static")
PROJECTS_DIR = os.path.join(config.PROJECT_ROOT, "projects")

CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".json": "application/json; charset=utf-8",
    ".yaml": "text/plain; charset=utf-8",
}

MAX_BODY = 5 * 1024 * 1024


# =====================================================================
# کمک‌تابع‌ها — پروژه‌ها و مسیرها
# =====================================================================

def _safe_child(base, rel):
    """مسیر rel باید داخل base بماند (ضد path traversal)."""
    base = os.path.realpath(base)
    full = os.path.realpath(os.path.join(base, rel))
    if full == base or not full.startswith(base + os.sep):
        return None
    return full


def _read_json(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:                                     # noqa: BLE001
        return default


def _list_spec_files(spec_dir):
    if not os.path.isdir(spec_dir):
        return []
    out = []
    for fn in sorted(os.listdir(spec_dir)):
        if os.path.splitext(fn)[1].lower() in (".yaml", ".yml", ".json"):
            out.append(os.path.join(spec_dir, fn))
    return out


def _parse_spec(path):
    """خلاصه‌ی معرفی spec برای UI."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            if os.path.splitext(path)[1].lower() == ".json":
                data = json.load(f)
            else:
                data = yaml.safe_load(f) or {}
        steps = data.get("steps") or data.get("requirements") or []
        return {
            "feature": data.get("feature") or data.get("title")
            or os.path.splitext(os.path.basename(path))[0],
            "target_url": data.get("target_url", ""),
            "intent": (data.get("intent") or "")[:160],
            "steps": len(steps) if isinstance(steps, list) else 0,
            "mission_type": data.get("mission_type", "spec"),
        }
    except Exception as e:                                # noqa: BLE001
        return {"feature": os.path.basename(path), "target_url": "",
                "intent": f"⚠ parse error: {e}", "steps": 0,
                "mission_type": "?"}


def _builtin_project():
    return {
        "id": "general",
        "name": "عمومی",
        "subtitle": "پوشه‌ی specs/ اصلی",
        "base_url": "",
        "dir": os.path.join(config.PROJECT_ROOT, "specs"),
        "spec_dir": os.path.join(config.PROJECT_ROOT, "specs"),
        "builtin": True,
        "created_at": "",
    }


def list_projects():
    """پروژه‌ی عمومی (specs/) + پوشه‌های projects/<slug>."""
    projects = [_builtin_project()]
    if os.path.isdir(PROJECTS_DIR):
        for name in sorted(os.listdir(PROJECTS_DIR)):
            pdir = os.path.join(PROJECTS_DIR, name)
            meta = _read_json(os.path.join(pdir, "project.json"))
            if meta is None:
                meta = {"name": name, "base_url": ""}
            projects.append({
                "id": name,
                "name": meta.get("name") or name,
                "subtitle": meta.get("subtitle", ""),
                "base_url": meta.get("base_url", ""),
                "dir": pdir,
                "spec_dir": os.path.join(pdir, "specs"),
                "builtin": False,
                "created_at": meta.get("created_at", ""),
            })
    for p in projects:
        p["spec_count"] = len(_list_spec_files(p["spec_dir"]))
    return projects


def get_project(pid):
    for p in list_projects():
        if p["id"] == pid:
            return p
    return None


def add_project(name, base_url="", subtitle=""):
    name = str(name or "").strip()
    if not name:
        raise ValueError("نام پروژه لازم است")
    base_url = str(base_url or "").strip()

    slug = re.sub(r"[^a-zA-Z0-9]+", "-", name).strip("-").lower() \
        or "project"
    # یکتا کردن slug
    final, i = slug, 2
    while os.path.exists(os.path.join(PROJECTS_DIR, final)):
        final = f"{slug}-{i}"
        i += 1

    pdir = os.path.join(PROJECTS_DIR, final)
    os.makedirs(os.path.join(pdir, "specs"), exist_ok=True)
    meta = {
        "name": name,
        "base_url": base_url,
        "subtitle": str(subtitle or "").strip(),
        "created_at": time.strftime("%Y-%m-%d %H:%M"),
    }
    with open(os.path.join(pdir, "project.json"), "w",
              encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    return final


# =====================================================================
# Handler
# =====================================================================

class PanelHandler(BaseHTTPRequestHandler):
    server_version = f"agentic-qa-panel/{PANEL_VERSION}"
    protocol_version = "HTTP/1.1"

    # ---------------- ابزارهای پاسخ ----------------

    def log_message(self, fmt, *args):      # لاگ کم‌تر
        if config.VERBOSE:
            sys.stderr.write("[panel] " + (fmt % args) + "\n")

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _err(self, msg, code=400):
        self._json({"error": str(msg)}, code=code)

    def _body(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > MAX_BODY:
            return {}
        try:
            return json.loads(
                self.rfile.read(length).decode("utf-8") or "{}")
        except Exception:                                 # noqa: BLE001
            return {}

    def _file(self, path, code=200):
        try:
            with open(path, "rb") as f:
                body = f.read()
        except OSError:
            return self._err("not found", 404)
        ctype = CONTENT_TYPES.get(
            os.path.splitext(path)[1].lower(),
            "application/octet-stream")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _sse(self, name, payload):
        data = json.dumps(payload, ensure_ascii=False)
        self.wfile.write(f"event: {name}\ndata: {data}\n\n".encode("utf-8"))
        self.wfile.flush()

    # ---------------- مسیریابی ----------------

    def do_GET(self):
        try:
            self._route("GET")
        except BrokenPipeError:
            pass
        except Exception as e:                             # noqa: BLE001
            try:
                self._err(f"server error: {e}", 500)
            except Exception:                             # noqa: BLE001
                pass

    def do_POST(self):
        try:
            self._route("POST")
        except BrokenPipeError:
            pass
        except Exception as e:                             # noqa: BLE001
            try:
                self._err(f"server error: {e}", 500)
            except Exception:                             # noqa: BLE001
                pass

    def do_PUT(self):
        try:
            self._route("PUT")
        except BrokenPipeError:
            pass
        except Exception as e:                             # noqa: BLE001
            try:
                self._err(f"server error: {e}", 500)
            except Exception:                             # noqa: BLE001
                pass

    def do_DELETE(self):
        try:
            self._route("DELETE")
        except BrokenPipeError:
            pass
        except Exception as e:                             # noqa: BLE001
            try:
                self._err(f"server error: {e}", 500)
            except Exception:                             # noqa: BLE001
                pass

    def _route(self, method):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        qs = {k: v[0] for k, v in parse_qs(parsed.query).items()}
        parts = [p for p in path.split("/") if p]

        # ---------- استاتیک ----------
        if method == "GET" and path == "/":
            return self._file(os.path.join(STATIC_DIR, "index.html"))
        if method == "GET" and len(parts) == 2 and parts[0] == "static":
            fp = _safe_child(STATIC_DIR, parts[1])
            if not fp or not os.path.isfile(fp):
                return self._err("not found", 404)
            return self._file(fp)
        if method == "GET" and path == "/favicon.svg":
            svg = ('<svg xmlns="http://www.w3.org/2000/svg" '
                   'viewBox="0 0 32 32"><rect width="32" height="32" '
                   'rx="7" fill="#6c8cff"/><text x="16" y="22" '
                   'font-size="16" text-anchor="middle" fill="#fff" '
                   'font-family="monospace">Q</text></svg>')
            body = svg.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "image/svg+xml")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            return self.wfile.write(body)

        if not parts or parts[0] != "api":
            return self._err("not found", 404)

        # ---------- API ----------
        api = parts[1:]

        if api == ["state"] and method == "GET":
            return self._api_state()
        if api == ["projects"]:
            if method == "GET":
                return self._json({"projects": list_projects()})
            if method == "POST":
                return self._api_add_project()
        if len(api) == 3 and api[0] == "projects" and api[2] == "specs":
            if method == "GET":
                return self._api_project_specs(api[1])
            if method == "POST":
                return self._api_create_spec(api[1])
        if api == ["spec"]:
            if method == "GET":
                return self._api_get_spec(qs.get("path", ""))
            if method == "PUT":
                return self._api_put_spec()
            if method == "DELETE":
                return self._api_delete_spec(qs.get("path", ""))
        if api == ["jobs", "run"] and method == "POST":
            return self._api_start_job("run")
        if api == ["jobs", "explore"] and method == "POST":
            return self._api_start_job("explore")
        if api == ["jobs"]:
            if method == "GET":
                return self._json({"jobs": [
                    j.to_dict(include_logs=False, log_tail=0)
                    for j in MANAGER.list_jobs()[::-1]]})
        if len(api) == 2 and api[0] == "jobs":
            job = MANAGER.get(api[1])
            if not job:
                return self._err("job not found", 404)
            return self._json(job.to_dict(log_tail=800))
        if len(api) == 3 and api[0] == "jobs" and api[2] == "stream":
            job = MANAGER.get(api[1])
            if not job:
                return self._err("job not found", 404)
            return self._sse_loop(job)
        if len(api) == 3 and api[0] == "jobs" and api[2] == "answer":
            if method != "POST":
                return self._err("POST only", 405)
            job = MANAGER.get(api[1])
            if not job:
                return self._err("job not found", 404)
            if job.answer_ask(self._body().get("answer", "")):
                return self._json({"ok": True})
            return self._err("no pending question", 409)
        if len(api) == 3 and api[0] == "jobs" and api[2] == "cancel":
            if method != "POST":
                return self._err("POST only", 405)
            job = MANAGER.get(api[1])
            if not job:
                return self._err("job not found", 404)
            return self._json({"ok": job.cancel()})

        if api == ["runs"] and method == "GET":
            return self._api_runs()
        if len(api) == 2 and api[0] == "runs" and method == "GET":
            return self._api_run_detail(api[1])
        if len(api) == 3 and api[0] == "runs" and api[2] == "report" \
                and method == "GET":
            rd = _safe_child(config.EVIDENCE_DIR, api[1])
            if not rd:
                return self._err("bad path", 400)
            return self._file(os.path.join(rd, "report.html"))
        if len(api) == 4 and api[0] == "runs" and api[2] == "evidence" \
                and method == "GET":
            rd = _safe_child(config.EVIDENCE_DIR, os.path.join(api[1],
                                                               "evidence"))
            if not rd:
                return self._err("bad path", 400)
            fp = _safe_child(rd, api[3])
            if not fp or not os.path.isfile(fp):
                return self._err("not found", 404)
            return self._file(fp)

        if api == ["to-spec"] and method == "POST":
            return self._api_to_spec()
        if api == ["doctor"] and method == "GET":
            return self._api_doctor()
        if api == ["skills"] and method == "GET":
            from engine.skill_loader import SkillLoader
            return self._json({"skills": SkillLoader().describe_all()})

        return self._err("not found", 404)

    # =================================================================
    # پیاده‌سازی endpoint ها
    # =================================================================

    def _api_state(self):
        from engine.spec_extractor import list_runs
        active = MANAGER.active_job
        runs = list_runs()[:6]
        # برچسب پروژه برای اجراهای پنل
        for r in runs:
            data = _read_json(os.path.join(r["dir"], "run.json")) or {}
            r["project"] = data.get("project") or ""
            r["panel_job"] = data.get("panel_job") or ""
        return self._json({
            "version": PANEL_VERSION,
            "config": {
                "ai_model": config.AI_MODEL,
                "ai_base_url": config.AI_BASE_URL,
                "typing": "human-paced" if config.REALISTIC_TYPING
                else "instant",
                "typing_delays": [config.TYPE_DELAY_MIN_MS,
                                  config.TYPE_DELAY_MAX_MS],
                "default_budget": 60,
            },
            "projects": list_projects(),
            "runs": runs,
            "active_job": active.id if active else None,
            "jobs_total": len(MANAGER.jobs),
        })

    def _api_add_project(self):
        body = self._body()
        try:
            pid = add_project(
                body.get("name", ""), base_url=body.get("base_url", ""),
                subtitle=body.get("subtitle", ""))
        except ValueError as e:
            return self._err(e)
        return self._json({"ok": True, "id": pid,
                           "projects": list_projects()})

    def _api_project_specs(self, pid):
        project = get_project(pid)
        if not project:
            return self._err("project not found", 404)
        specs = []
        for path in _list_spec_files(project["spec_dir"]):
            info = _parse_spec(path)
            info["path"] = os.path.relpath(path, config.PROJECT_ROOT)
            specs.append(info)
        return self._json({"project": _pub_project(project),
                           "specs": specs})

    def _api_create_spec(self, pid):
        project = get_project(pid)
        if not project:
            return self._err("project not found", 404)
        body = self._body()
        goal = str(body.get("goal", "")).strip()
        url = str(body.get("url", "")).strip() or project.get("base_url",
                                                              "")
        name = str(body.get("name", "")).strip()
        if not goal:
            return self._err("هدف تست (goal) لازم است")
        if not url:
            return self._err("آدرس سایت لازم است (یا base_url پروژه)")

        from engine.spec_writer import draft_spec, save_spec, slugify
        spec, source = draft_spec(url, goal, name=name)
        base = slugify(name or goal, "spec")
        out = os.path.join(project["spec_dir"], f"{base}.yaml")
        i = 2
        while os.path.exists(out):
            out = os.path.join(project["spec_dir"], f"{base}-{i}.yaml")
            i += 1
        save_spec(spec, out)
        return self._json({
            "ok": True,
            "source": source,
            "path": os.path.relpath(out, config.PROJECT_ROOT),
            "steps": len(spec.get("steps") or []),
        })

    def _api_get_spec(self, rel):
        fp = _safe_child(config.PROJECT_ROOT, rel)
        if not fp or not os.path.isfile(fp):
            return self._err("spec not found", 404)
        if os.path.splitext(fp)[1].lower() not in (".yaml", ".yml", ".json"):
            return self._err("not a spec file", 400)
        try:
            with open(fp, "r", encoding="utf-8") as f:
                content = f.read()
        except OSError as e:
            return self._err(e)
        return self._json({
            "path": rel,
            "content": content,
            "info": _parse_spec(fp),
        })

    def _api_put_spec(self):
        body = self._body()
        fp = _safe_child(config.PROJECT_ROOT, str(body.get("path", "")))
        if not fp or not os.path.isfile(fp):
            return self._err("spec not found", 404)
        content = str(body.get("content", ""))
        # اعتبارسنجی YAML/JSON قبل از ذخیره
        try:
            if os.path.splitext(fp)[1].lower() == ".json":
                json.loads(content)
            else:
                yaml.safe_load(content)
        except Exception as e:                             # noqa: BLE001
            return self._err(f"invalid syntax: {e}")
        with open(fp, "w", encoding="utf-8") as f:
            f.write(content)
        return self._json({"ok": True})

    def _api_delete_spec(self, rel):
        fp = _safe_child(config.PROJECT_ROOT, rel)
        if not fp or not os.path.isfile(fp):
            return self._err("spec not found", 404)
        os.remove(fp)
        return self._json({"ok": True})

    def _api_start_job(self, jtype):
        body = self._body()
        project_id = body.get("project_id") or None
        try:
            if jtype == "run":
                rel = str(body.get("path", ""))
                fp = _safe_child(config.PROJECT_ROOT, rel)
                if not fp or not os.path.isfile(fp):
                    return self._err("spec not found", 404)
                if os.path.splitext(fp)[1].lower() not in (
                        ".yaml", ".yml", ".json"):
                    return self._err("not a spec file", 400)
                job = MANAGER.start("run", {
                    "spec_path": fp,
                    "budget": int(body.get("budget") or 0) or None,
                    "allow_destructive": bool(body.get("allow_destructive")),
                    "project_id": project_id,
                }, title=os.path.basename(rel))
            else:
                url = str(body.get("url", "")).strip()
                if not url:
                    return self._err("url لازم است")
                job = MANAGER.start("explore", {
                    "url": url,
                    "intent": str(body.get("intent", "")).strip(),
                    "budget": int(body.get("budget") or 60),
                    "allow_destructive": bool(body.get("allow_destructive")),
                    "project_id": project_id,
                }, title=url)
        except RuntimeError as e:
            return self._err(e, 409)
        except ValueError as e:
            return self._err(e)
        return self._json({"ok": True, "job_id": job.id})

    def _api_runs(self):
        from engine.spec_extractor import list_runs
        rows = []
        for r in list_runs():
            data = _read_json(os.path.join(r["dir"], "run.json")) or {}
            r["project"] = data.get("project") or ""
            r["panel_job"] = data.get("panel_job") or ""
            r["report"] = os.path.exists(
                os.path.join(r["dir"], "report.html"))
            rows.append(r)
        return self._json({"runs": rows})

    def _api_run_detail(self, rid):
        rd = _safe_child(config.EVIDENCE_DIR, rid)
        if not rd or not os.path.isdir(rd):
            return self._err("run not found", 404)
        data = _read_json(os.path.join(rd, "run.json")) or {}
        verdicts = _read_json(os.path.join(rd, "verdicts.json")) or []
        findings = _read_json(os.path.join(rd, "findings.json")) or []
        ev_dir = os.path.join(rd, "evidence")
        shots = [f for f in sorted(os.listdir(ev_dir))
                 if f.endswith(".png")] if os.path.isdir(ev_dir) else []
        return self._json({
            "run_id": rid,
            "run": data,
            "verdicts": verdicts,
            "findings": findings,
            "screenshots": shots,
            "report": os.path.exists(os.path.join(rd, "report.html")),
            "actions_count": data.get("counts", {}).get("actions", 0),
        })

    def _api_to_spec(self):
        from engine.spec_extractor import resolve_run, spec_from_run
        body = self._body()
        rid = body.get("run_id", "")
        try:
            run_dir = resolve_run(rid or None,
                                  last=bool(body.get("last")) or rid == "last")
        except ValueError as e:
            return self._err(e)

        out_path = None
        pid = body.get("project_id")
        if pid:
            project = get_project(pid)
            if project:
                out_path = os.path.join(
                    project["spec_dir"],
                    f"from-run-{os.path.basename(run_dir)}.yaml")
        try:
            path = spec_from_run(run_dir, out_path=out_path)
        except Exception as e:                             # noqa: BLE001
            return self._err(f"extraction failed: {e}")
        if not path:
            return self._err(
                "این اجرا مسیر قابل استخراجی ندارد "
                "(فقط مشاهده/اکشن ناموفق ثبت شده است)", 422)
        return self._json({
            "ok": True,
            "path": os.path.relpath(path, config.PROJECT_ROOT),
        })

    def _api_doctor(self):
        ok = True
        env_path = os.path.join(config.PROJECT_ROOT, ".env")
        node = shutil.which("node")
        items = [
            {"label": "پایتون", "value": sys.version.split()[0],
             "ok": True},
            {"label": "فایل .env",
             "value": "found" if os.path.exists(env_path)
             else "not found — copy .env.example → .env",
             "ok": os.path.exists(env_path)},
            {"label": "مدل هوش مصنوعی",
             "value": f"{config.AI_MODEL} @ {config.AI_BASE_URL}",
             "ok": True},
            {"label": "Node.js",
             "value": node or "NOT FOUND — install Node.js",
             "ok": bool(node)},
        ]
        try:
            from engine.ai_client import AIClient
            reply = AIClient(timeout=8).ping()
            items.append({"label": "اتصال هوش مصنوعی",
                          "value": (reply or "")[:60], "ok": True})
        except Exception as e:                             # noqa: BLE001
            ok = False
            items.append({"label": "اتصال هوش مصنوعی",
                          "value": str(e)[:120], "ok": False})

        from engine.skill_loader import SkillLoader
        n_skills = len(SkillLoader().available())
        items.append({"label": "Skill ها", "value": f"{n_skills} loaded",
                      "ok": n_skills >= 5})

        active = MANAGER.active_job
        items.append({"label": "job فعال",
                      "value": active.id if active else "—",
                      "ok": True})
        for it in items:
            if not it["ok"]:
                ok = False
        return self._json({"ok": ok, "items": items})

    # =================================================================
    # SSE — استریم زنده‌ی job
    # =================================================================

    def _sse_loop(self, job):
        self.send_response(200)
        self.send_header("Content-Type",
                         "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()

        cursor = 0                    # اندیس مطلق در جریان لاگ
        last_version = -1
        sent_ask_id = None
        last_beat = time.time()

        try:
            while True:
                # --- لاگ‌های جدید ---
                base = job.log_count - len(job.logs)
                if cursor < base:
                    cursor = base           # بخش trim شده را رد کن
                if job.log_count > cursor:
                    idx = cursor - base
                    new_text = "".join(job.logs[idx:])
                    cursor = job.log_count
                    self._sse("log", {"text": new_text})
                # --- تغییر وضعیت ---
                if job.version != last_version:
                    last_version = job.version
                    self._sse("status", job.to_dict(include_logs=False,
                                                     log_tail=0))
                # --- پرسش ask_human ---
                if job.pending_ask and \
                        job.pending_ask["id"] != sent_ask_id:
                    sent_ask_id = job.pending_ask["id"]
                    self._sse("ask", {
                        "id": sent_ask_id,
                        "question": job.pending_ask["question"],
                    })
                # --- پایان ---
                if job.finished:
                    self._sse("done", job.to_dict(include_logs=False,
                                                   log_tail=0))
                    break
                # --- heartbeat ---
                if time.time() - last_beat > 10:
                    last_beat = time.time()
                    self.wfile.write(b": hb\n\n")
                    self.wfile.flush()
                time.sleep(0.25)
        except (BrokenPipeError, ConnectionResetError,
                ConnectionAbortedError):
            pass
        finally:
            self.close_connection = True


def _pub_project(project):
    """نسخه‌ی سبک project برای پاسخ‌ها."""
    return {
        "id": project["id"],
        "name": project["name"],
        "subtitle": project.get("subtitle", ""),
        "base_url": project.get("base_url", ""),
        "builtin": project.get("builtin", False),
        "spec_count": project.get("spec_count", 0),
    }


# =====================================================================
# اجرای سرور
# =====================================================================

def run_panel(host="127.0.0.1", port=8787, open_browser=True):
    os.makedirs(PROJECTS_DIR, exist_ok=True)
    server = ThreadingHTTPServer((host, port), PanelHandler)
    server.daemon_threads = True
    url = f"http://{host}:{port}"
    print("=" * 62)
    print("🖥  AGENTIC-QA PANEL")
    print(f"   URL      : {url}")
    print(f"   projects : {config.PROJECT_ROOT}/projects + specs/")
    print(f"   evidence : {config.EVIDENCE_DIR}")
    print("   توقف     : Ctrl+C")
    print("=" * 62)
    print("ℹ️  پنل اختیاری است — CLI (run/explore/to-spec) مثل قبل کار می‌کند")

    if open_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n⛔ panel stopped")
    finally:
        server.server_close()
    return 0
