/* =====================================================================
   agentic-qa panel — app.js (vanilla, no CDN — offline friendly)
   ===================================================================== */

"use strict";

const $ = (sel) => document.querySelector(sel);
const main = () => $("#main");

/* ---------------- helpers ---------------- */

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

async function api(path, method = "GET", body = null) {
  const opts = { method, headers: {} };
  if (body !== null) {
    opts.headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(path, opts);
  let data = {};
  try { data = await res.json(); } catch (_) { /* empty */ }
  if (!res.ok) throw new Error(data.error || res.statusText || "error");
  return data;
}

let toastTimer = null;
function toast(msg, kind = "") {
  const el = $("#toast");
  el.textContent = msg;
  el.className = "toast " + kind;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add("hidden"), 3600);
}

function fmtTime(ts) {
  if (!ts) return "—";
  try {
    return new Date(ts * 1000).toLocaleString("fa-IR", {
      hour: "2-digit", minute: "2-digit", second: "2-digit",
      year: "numeric", month: "2-digit", day: "2-digit",
    });
  } catch (_) { return String(ts); }
}

function badge(text, cls) {
  return `<span class="badge ${cls || "b-" + esc(text)}">${esc(text)}</span>`;
}

function verdictBadge(v) {
  const map = {
    PASSED: "b-PASSED", FAILED: "b-FAILED", BLOCKED: "b-BLOCKED",
    PARTIAL: "b-PARTIAL", INCONCLUSIVE: "b-INCONCLUSIVE",
  };
  return badge(v, map[v] || "b-muted");
}

async function refreshActiveChip() {
  try {
    const st = await api("/api/state");
    const chip = $("#active-job-chip");
    if (st.active_job) {
      chip.innerHTML = `⚡ اجرای فعال — <code>${esc(st.active_job)}</code>`;
      chip.className = "chip";
      chip.href = `#/job/${esc(st.active_job)}`;
    } else {
      chip.classList.add("hidden");
    }
  } catch (_) { /* panel gone */ }
}

/* ---------------- ask_human modal ---------------- */

let askJobId = null;

function showAsk(jobId, question) {
  askJobId = jobId;
  $("#ask-question").textContent = question;
  $("#ask-input").value = "";
  $("#ask-overlay").classList.remove("hidden");
  setTimeout(() => $("#ask-input").focus(), 60);
}

async function submitAsk() {
  const val = $("#ask-input").value;
  if (!val.trim()) { $("#ask-input").focus(); return; }
  try {
    await api(`/api/jobs/${askJobId}/answer`, "POST", { answer: val });
    $("#ask-overlay").classList.add("hidden");
    toast("مقدار به agent ارسال شد ✓", "ok");
  } catch (e) { toast(e.message, "err"); }
}

$("#ask-submit").addEventListener("click", submitAsk);
$("#ask-input").addEventListener("keydown", (ev) => {
  if (ev.key === "Enter") submitAsk();
});

/* ---------------- router ---------------- */

const routes = [
  [/^#\/dashboard$/, viewDashboard],
  [/^#\/projects$/, viewProjects],
  [/^#\/project\/([\w\-]+)$/, viewProject],
  [/^#\/spec\?path=(.+)$/, viewSpec],
  [/^#\/explore$/, viewExplore],
  [/^#\/runs$/, viewRuns],
  [/^#\/run\/([^\/]+)$/, viewRunDetail],
  [/^#\/job\/(\w+)$/, viewJob],
  [/^#\/status$/, viewStatus],
];

async function route() {
  const hash = decodeURIComponent(location.hash || "#/dashboard");
  document.querySelectorAll("#nav a").forEach((a) => {
    a.classList.toggle("active",
      a.getAttribute("href") === (hash.startsWith("#/") ? hash.split("?")[0] : hash));
  });
  let es = window._es;
  if (es) { es.close(); window._es = null; }

  main().innerHTML = '<div class="loading">در حال بارگذاری…</div>';
  for (const [re, fn] of routes) {
    const m = hash.match(re);
    if (m) {
      try { await fn(...m.slice(1)); }
      catch (e) {
        main().innerHTML =
          `<div class="empty">⚠️ ${esc(e.message)}</div>`;
      }
      refreshActiveChip();
      return;
    }
  }
  location.hash = "#/dashboard";
}

window.addEventListener("hashchange", route);

/* =====================================================================
   VIEW: داشبورد
   ===================================================================== */

async function viewDashboard() {
  const st = await api("/api/state");
  const totalSpecs = st.projects.reduce((a, p) => a + p.spec_count, 0);

  const rows = (st.runs || []).map((r) => `
    <tr>
      <td><a class="mono" style="color:var(--info);text-decoration:none"
             href="#/run/${esc(r.run_id)}">${esc(r.run_id)}</a></td>
      <td>${badge(r.type, r.type === "spec" ? "b-ok" : "b-PARTIAL")}</td>
      <td>${badge(r.status)}</td>
      <td>${esc(r.actions)}</td>
      <td class="mono">${esc((r.started_at || "").slice(0, 19))}</td>
      <td style="max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
        ${esc(r.intent || r.base_url || "")}</td>
    </tr>`).join("");

  main().innerHTML = `
    <h1 class="page-title">داشبورد</h1>
    <div class="page-sub">نمای کلی سیستم تست agentic-qa</div>

    ${st.active_job ? `
      <a class="banner" href="#/job/${esc(st.active_job)}">
        ⚡ اجرایی در حال انجام است — مشاهده‌ی زنده
        <code style="direction:ltr">${esc(st.active_job)}</code>
      </a>` : ""}

    <div class="cards">
      <div class="card"><div class="num">${st.projects.length}</div>
        <div class="lbl">پروژه</div>
        <div class="foot">projects/ + specs/</div></div>
      <div class="card"><div class="num">${totalSpecs}</div>
        <div class="lbl">فایل Spec</div>
        <div class="foot">قابل اجرا از پنل</div></div>
      <div class="card"><div class="num">${(st.runs || []).length}</div>
        <div class="lbl">اجرای ثبت‌شده (اخیر)</div>
        <div class="foot">.evidence/runs</div></div>
      <div class="card"><div class="num" style="font-size:15px;padding-top:6px">
        ${st.config.typing === "human-paced"
          ? "⌨️ انسانی (" + st.config.typing_delays[0] + "-" +
            st.config.typing_delays[1] + "ms)"
          : "فوری"}</div>
        <div class="lbl">سرعت تایپ agent</div>
        <div class="foot">مدل: ${esc(st.config.ai_model)}</div></div>
    </div>

    <section class="block">
      <h2 class="block-title">اجراهای اخیر</h2>
      ${rows ? `<div class="table-wrap"><table>
        <tr><th>شناسه</th><th>نوع</th><th>وضعیت</th><th>اکشن‌ها</th>
        <th>زمان</th><th>هدف</th></tr>${rows}</table></div>`
      : `<div class="empty">هنوز اجرایی ثبت نشده — از «اکتشاف» یا اجرای یک Spec شروع کنید</div>`}
    </section>

    <section class="block">
      <h2 class="block-title">میان‌برها</h2>
      <div class="row">
        <a class="btn btn-primary" href="#/projects">📁 مدیریت پروژه‌ها و Spec ها</a>
        <a class="btn" href="#/explore">🧭 اجرای اکتشاف جدید</a>
        <a class="btn" href="#/runs">📜 تاریخچه و ساخت Spec از اجراها</a>
        <a class="btn" href="#/status">🩺 سلامت سیستم</a>
      </div>
    </section>`;
}

/* =====================================================================
   VIEW: پروژه‌ها
   ===================================================================== */

async function viewProjects() {
  const { projects } = await api("/api/projects");

  const cards = projects.map((p) => `
    <a class="project-card" href="#/project/${esc(p.id)}">
      <div class="p-name">${esc(p.name)} ${p.builtin ? badge("built-in", "b-muted") : ""}</div>
      <div class="p-url">${esc(p.base_url || "—")}</div>
      ${p.subtitle ? `<div style="font-size:12px;color:var(--muted)">${esc(p.subtitle)}</div>` : ""}
      <div class="p-meta">${p.spec_count} فایل Spec${p.created_at ? " · " + esc(p.created_at) : ""}</div>
    </a>`).join("");

  main().innerHTML = `
    <h1 class="page-title">پروژه‌ها</h1>
    <div class="page-sub">هر پروژه یک مجموعه Spec برای یک سایت/اپ است</div>

    <div class="form">
      <h2 class="block-title">افزودن پروژه‌ی جدید</h2>
      <div class="form-grid">
        <div class="field"><label>نام پروژه *</label>
          <input id="np-name" placeholder="مثلاً: پکی سامانه"></div>
        <div class="field"><label>آدرس سایت (Base URL)</label>
          <input id="np-url" dir="ltr" placeholder="https://example.ir"></div>
        <div class="field"><label>توضیح (اختیاری)</label>
          <input id="np-sub" placeholder="مثلاً: تست‌های ورود و قرارداد"></div>
      </div>
      <div class="form-actions">
        <button class="btn btn-primary" id="np-add">➕ افزودن پروژه</button>
      </div>
    </div>

    ${cards ? `<div class="project-grid">${cards}</div>`
      : `<div class="empty">هنوز پروژه‌ای نیست — بالا یکی بسازید</div>`}`;

  $("#np-add").addEventListener("click", async () => {
    const name = $("#np-name").value.trim();
    if (!name) { toast("نام پروژه لازم است", "err"); return; }
    try {
      const r = await api("/api/projects", "POST", {
        name, base_url: $("#np-url").value.trim(),
        subtitle: $("#np-sub").value.trim(),
      });
      toast(`پروژه «${name}» ساخته شد ✓`, "ok");
      location.hash = `#/project/${r.id}`;
    } catch (e) { toast(e.message, "err"); }
  });
}

/* =====================================================================
   VIEW: پروژه — لیست Spec ها + ساخت خودکار
   ===================================================================== */

async function viewProject(pid) {
  const { project, specs } = await api(`/api/projects/${esc(pid)}/specs`);

  const rows = specs.map((s) => `
    <tr>
      <td><a href="#/spec?path=${encodeURIComponent(s.path)}"
             style="color:var(--accent);text-decoration:none">${esc(s.feature)}</a></td>
      <td>${esc(s.steps)}</td>
      <td class="mono" style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
        ${esc(s.target_url || "—")}</td>
      <td style="max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
        ${esc(s.intent || "")}</td>
      <td><div class="cell-actions">
        <a class="btn btn-sm btn-primary" href="#/spec?path=${encodeURIComponent(s.path)}">▶ اجرا</a>
        <a class="btn btn-sm" href="#/spec?path=${encodeURIComponent(s.path)}">✏️ مشاهده</a>
        <button class="btn btn-sm btn-danger" data-del="${esc(s.path)}">🗑</button>
      </div></td>
    </tr>`).join("");

  main().innerHTML = `
    <h1 class="page-title">📁 ${esc(project.name)}</h1>
    <div class="page-sub">
      ${esc(project.subtitle || "")} ${project.base_url
        ? `· <span class="mono" style="color:var(--info)">${esc(project.base_url)}</span>` : ""}
    </div>

    <div class="form">
      <h2 class="block-title">🪄 ساخت خودکار Spec جدید</h2>
      <div class="form-grid">
        <div class="field"><label>هدف تست * (به فارسی یا انگلیسی)</label>
          <input id="ns-goal" placeholder="مثلاً: ورود با کدملی و کپچا، سپس ساخت قرارداد"></div>
        <div class="field"><label>آدرس صفحه‌ی شروع</label>
          <input id="ns-url" dir="ltr" value="${esc(project.base_url || "")}"
                 placeholder="https://…"></div>
        <div class="field"><label>نام فایل (اختیاری)</label>
          <input id="ns-name" dir="ltr" placeholder="login-flow"></div>
      </div>
      <div class="form-actions">
        <button class="btn btn-primary" id="ns-create">🪄 تولید Spec</button>
        <span class="progress-note" id="ns-note">
          قدم‌ها با هوش مصنوعی پیش‌نویس می‌شوند؛ کپچا/OTP خودکار prompt_user می‌شود
        </span>
      </div>
    </div>

    <section class="block">
      <h2 class="block-title">Spec های این پروژه (${specs.length})</h2>
      ${rows ? `<div class="table-wrap"><table>
        <tr><th>Feature</th><th>قدم‌ها</th><th>Target URL</th><th>هدف</th><th>عملیات</th></tr>
        ${rows}</table></div>`
      : `<div class="empty">Specی نیست — بالا با «تولید Spec» یکی بسازید</div>`}
    </section>`;

  $("#ns-create").addEventListener("click", async () => {
    const goal = $("#ns-goal").value.trim();
    const url = $("#ns-url").value.trim();
    if (!goal) { toast("هدف تست لازم است", "err"); return; }
    if (!url) { toast("آدرس صفحه شروع لازم است", "err"); return; }
    const btn = $("#ns-create");
    btn.disabled = true;
    $("#ns-note").textContent = "در حال تولید…";
    try {
      const r = await api(`/api/projects/${esc(pid)}/specs`, "POST",
        { goal, url, name: $("#ns-name").value.trim() });
      toast(`Spec ساخته شد (${r.steps} قدم${r.source === "ai" ? "، پیش‌نویس هوشمند" : "، قالب حداقلی"}) ✓`, "ok");
      location.hash = `#/spec?path=${encodeURIComponent(r.path)}`;
    } catch (e) {
      toast(e.message, "err");
      $("#ns-create").disabled = false;
      $("#ns-note").textContent = "";
    }
  });

  document.querySelectorAll("[data-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("این فایل Spec حذف شود؟")) return;
      try {
        await api(`/api/spec?path=${encodeURIComponent(btn.dataset.del)}`,
          "DELETE");
        viewProject(pid);
      } catch (e) { toast(e.message, "err"); }
    });
  });
}

/* =====================================================================
   VIEW: فایل Spec — نمایش/ویرایش/اجرا
   ===================================================================== */

async function viewSpec(relPath) {
  const { path, content, info } =
    await api(`/api/spec?path=${encodeURIComponent(relPath)}`);

  main().innerHTML = `
    <h1 class="page-title">📄 ${esc(info.feature)}</h1>
    <div class="page-sub">
      <code style="direction:ltr">${esc(path)}</code>
      · ${info.steps} قدم
      · <span class="mono">${esc(info.target_url || "بدون target_url")}</span>
    </div>

    <div class="form">
      <h2 class="block-title">▶ اجرای این Spec</h2>
      <div class="form-grid">
        <div class="field"><label>بودجه اکشن‌ها (خالی = پیش‌فرض)</label>
          <input id="sp-budget" type="number" min="1" placeholder="60"></div>
        <div class="field"><label>گزینه‌ها</label>
          <label class="check"><input id="sp-destructive" type="checkbox">
            اجازه اکشن‌های مخرب (--allow-destructive)</label></div>
      </div>
      <div class="form-actions">
        <button class="btn btn-primary" id="sp-run">🚀 اجرا (پس‌زمینه + مشاهده زنده)</button>
      </div>
    </div>

    <section class="block">
      <h2 class="block-title">متن Spec (YAML — قابل ویرایش)</h2>
      <textarea class="spec-editor" id="sp-content" spellcheck="false">${esc(content)}</textarea>
      <div class="form-actions">
        <button class="btn" id="sp-save">💾 ذخیره تغییرات</button>
        <span class="progress-note">selector ممنوع است — فقط توصیف معنایی (اصل #14)</span>
      </div>
    </section>`;

  $("#sp-run").addEventListener("click", async () => {
    const budget = parseInt($("#sp-budget").value, 10) || null;
    try {
      const r = await api("/api/jobs/run", "POST", {
        path: relPath, budget,
        allow_destructive: $("#sp-destructive").checked,
      });
      location.hash = `#/job/${r.job_id}`;
    } catch (e) { toast(e.message, "err"); }
  });

  $("#sp-save").addEventListener("click", async () => {
    try {
      await api("/api/spec", "PUT", {
        path: relPath, content: $("#sp-content").value,
      });
      toast("ذخیره شد ✓", "ok");
    } catch (e) { toast(e.message, "err"); }
  });
}

/* =====================================================================
   VIEW: اکتشاف
   ===================================================================== */

async function viewExplore() {
  let defUrl = "";
  try {
    const st = await api("/api/state");
    const withUrl = st.projects.find((p) => p.base_url);
    if (withUrl) defUrl = withUrl.base_url;
  } catch (_) { /* ignore */ }

  main().innerHTML = `
    <h1 class="page-title">🧭 اجرای اکتشاف (Explorer)</h1>
    <div class="page-sub">مرورگر باز می‌شود و agent صفحه را کشف می‌کند؛ در پایان
      Spec کشف‌شده ساخته می‌شود (قابل بازاجرای قطعی)</div>

    <div class="form">
      <div class="form-grid">
        <div class="field"><label>آدرس شروع *</label>
          <input id="ex-url" dir="ltr" value="${esc(defUrl)}"
                 placeholder="https://sandbox.example.ir/"></div>
        <div class="field"><label>مأموریت / اینتنت</label>
          <input id="ex-intent" placeholder="مثلاً: فرم ورود را با کدملی و کپچا تست کن"></div>
        <div class="field"><label>بودجه اکشن‌ها</label>
          <input id="ex-budget" type="number" value="60" min="5"></div>
        <div class="field"><label>پروژه (اختیاری — spec کشف‌شده آنجا ثبت می‌شود؟ نه، در generated/)</label>
          <select id="ex-project"><option value="">— بدون پروژه —</option></select></div>
      </div>
      <div class="form-actions">
        <button class="btn btn-primary" id="ex-start">🧭 شروع اکتشاف</button>
      </div>
      <div class="progress-note" style="margin-top:10px">
        ⚠️ کپچا/OTP حین اجرا از همین پنل پرسیده می‌شود (کادر «پرسش از کاربر»)
      </div>
    </div>`;

  try {
    const st = await api("/api/state");
    st.projects.forEach((p) => {
      const opt = document.createElement("option");
      opt.value = p.id; opt.textContent = p.name;
      $("#ex-project").appendChild(opt);
    });
  } catch (_) { /* ignore */ }

  $("#ex-start").addEventListener("click", async () => {
    const url = $("#ex-url").value.trim();
    if (!url) { toast("آدرس شروع لازم است", "err"); return; }
    try {
      const r = await api("/api/jobs/explore", "POST", {
        url,
        intent: $("#ex-intent").value.trim(),
        budget: parseInt($("#ex-budget").value, 10) || 60,
        project_id: $("#ex-project").value || null,
      });
      location.hash = `#/job/${r.job_id}`;
    } catch (e) { toast(e.message, "err"); }
  });
}

/* =====================================================================
   VIEW: اجراها (تاریخچه)
   ===================================================================== */

async function viewRuns() {
  const { runs } = await api("/api/runs");

  const rows = runs.map((r) => `
    <tr>
      <td><a class="mono" style="color:var(--info);text-decoration:none"
             href="#/run/${esc(r.run_id)}">${esc(r.run_id)}</a></td>
      <td>${badge(r.type, r.type === "spec" ? "b-ok" : "b-PARTIAL")}</td>
      <td>${badge(r.status)}</td>
      <td>${esc(r.actions)}</td>
      <td class="mono">${esc((r.started_at || "").slice(0, 19))}</td>
      <td style="max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
        ${esc(r.intent || r.base_url || "")}</td>
      <td><div class="cell-actions">
        <a class="btn btn-sm" href="#/run/${esc(r.run_id)}">جزئیات</a>
        ${r.report ? `<a class="btn btn-sm" target="_blank"
            href="/api/runs/${esc(r.run_id)}/report">📄 گزارش</a>` : ""}
        <button class="btn btn-sm" data-tospec="${esc(r.run_id)}">🪄 to-spec</button>
      </div></td>
    </tr>`).join("");

  main().innerHTML = `
    <h1 class="page-title">📜 اجراها</h1>
    <div class="page-sub">همه‌ی اجراهای ثبت‌شده در .evidence/runs — از جدید به قدیم</div>
    ${rows ? `<div class="table-wrap"><table>
      <tr><th>شناسه</th><th>نوع</th><th>وضعیت</th><th>اکشن‌ها</th>
      <th>شروع</th><th>هدف</th><th>عملیات</th></tr>${rows}</table></div>`
    : `<div class="empty">هنوز اجرایی ثبت نشده است</div>`}`;

  document.querySelectorAll("[data-tospec]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        const r = await api("/api/to-spec", "POST",
          { run_id: btn.dataset.tospec });
        toast(`Spec ساخته شد: ${r.path} ✓`, "ok");
        location.hash = `#/spec?path=${encodeURIComponent(r.path)}`;
      } catch (e) {
        toast(e.message, "err");
        btn.disabled = false;
      }
    });
  });
}

/* =====================================================================
   VIEW: جزئیات اجرا
   ===================================================================== */

async function viewRunDetail(rid) {
  const d = await api(`/api/runs/${encodeURIComponent(rid)}`);
  const mission = (d.run && d.run.mission) || {};

  const vrows = (d.verdicts || []).map((v) => `
    <tr>
      <td>${verdictBadge(v.verdict)}</td>
      <td><code>${esc(v.requirement_id || "?")}</code></td>
      <td style="max-width:320px">${esc((v.expected || "").slice(0, 220))}</td>
      <td style="max-width:320px">${esc((v.failure_reason || v.actual || "").slice(0, 220))}</td>
    </tr>`).join("");

  const findings = (d.findings || []).map((f) => `
    <div class="banner" style="background:rgba(251,191,36,.08);border-color:rgba(251,191,36,.3);color:var(--warn)">
      [${esc(f.severity)}] ${esc(f.description || "")}
      ${f.note ? `<div style="font-size:12px;opacity:.8">${esc(f.note)}</div>` : ""}
    </div>`).join("");

  const shots = (d.screenshots || []).slice(0, 40).map((fn) => `
    <div class="shot">
      <img loading="lazy" src="/api/runs/${encodeURIComponent(rid)}/evidence/${encodeURIComponent(fn)}"
           onclick="window.open(this.src)" alt="${esc(fn)}">
      <div class="cap">${esc(fn)}</div>
    </div>`).join("");

  main().innerHTML = `
    <h1 class="page-title">🧾 اجرا: <span class="mono">${esc(rid)}</span></h1>
    <div class="page-sub">
      نوع: ${esc(d.run && d.run.mission && d.run.mission.type || d.run.type || "?")}
      · وضعیت: ${badge(d.run.status || "?")}
      · اکشن‌ها: ${esc(d.actions_count)}
      ${mission.base_url ? `· <span class="mono">${esc(mission.base_url)}</span>` : ""}
    </div>

    <div class="row" style="margin-bottom:18px">
      ${d.report ? `<a class="btn" target="_blank"
        href="/api/runs/${encodeURIComponent(rid)}/report">📄 گزارش کامل HTML</a>` : ""}
      <button class="btn" id="rd-tospec">🪄 ساخت Spec از این اجرا</button>
      ${d.run.panel_job ? `<a class="btn" href="#/job/${esc(d.run.panel_job)}">⚡ مشاهده‌ی job پنل</a>` : ""}
    </div>

    ${vrows ? `<section class="block">
      <h2 class="block-title">احکام (${(d.verdicts || []).length})</h2>
      <div class="table-wrap"><table>
        <tr><th>حکم</th><th>قدم</th><th>انتظار</th><th>نتیجه/علت</th></tr>
        ${vrows}</table></div>
    </section>` : ""}

    ${findings ? `<section class="block">
      <h2 class="block-title">یافته‌های اکتشافی</h2>${findings}
    </section>` : ""}

    ${shots ? `<section class="block">
      <h2 class="block-title">شواهد تصویری (${(d.screenshots || []).length})</h2>
      <div class="shots">${shots}</div>
    </section>` : ""}`;

  $("#rd-tospec").addEventListener("click", async () => {
    try {
      const r = await api("/api/to-spec", "POST", { run_id: rid });
      toast(`Spec ساخته شد: ${r.path} ✓`, "ok");
      location.hash = `#/spec?path=${encodeURIComponent(r.path)}`;
    } catch (e) { toast(e.message, "err"); }
  });
}

/* =====================================================================
   VIEW: job زنده (اجرای پس‌زمینه)
   ===================================================================== */

let logBuf = [];

async function viewJob(jobId) {
  const j = await api(`/api/jobs/${esc(jobId)}`);
  logBuf = [j.logs || ""];

  main().innerHTML = `
    <h1 class="page-title">${j.type === "run" ? "🚀 اجرای Spec" : "🧭 اکتشاف"}
      — <span class="mono">${esc(j.title)}</span></h1>
    <div class="page-sub">
      job <code style="direction:ltr">${esc(j.id)}</code>
      · وضعیت: <span id="jb-status">${badge(j.status)}</span>
      ${j.run_dir ? `· شواهد: <span class="mono">${esc(j.run_dir.split("/").pop())}</span>` : ""}
    </div>

    <div class="row" style="margin-bottom:14px">
      <button class="btn btn-danger" id="jb-cancel">⛔ لغو اجرا</button>
      <span class="progress-note" id="jb-note"></span>
      <span id="jb-report"></span>
    </div>

    <div class="console" id="jb-console"></div>

    ${j.ask ? "" : ""}
  `;
  renderLog();

  if (j.ask) showAsk(jobId, j.ask.question);

  $("#jb-cancel").addEventListener("click", async () => {
    try {
      await api(`/api/jobs/${esc(jobId)}/cancel`, "POST");
      toast("درخواست لغو ارسال شد", "ok");
    } catch (e) { toast(e.message, "err"); }
  });

  // ---- استریم زنده ----
  const es = new EventSource(`/api/jobs/${esc(jobId)}/stream`);
  window._es = es;

  es.addEventListener("log", (ev) => {
    const d = JSON.parse(ev.data);
    logBuf.push(d.text);
    renderLog();
  });
  es.addEventListener("status", (ev) => {
    const d = JSON.parse(ev.data);
    $("#jb-status").innerHTML = badge(d.status);
    if (d.run_dir) {
      $("#jb-note").textContent = "شواهد: " + d.run_dir.split("/").pop();
    }
    if (d.status === "running") {
      $("#jb-cancel").disabled = false;
    }
  });
  es.addEventListener("ask", (ev) => {
    const d = JSON.parse(ev.data);
    showAsk(jobId, d.question);
  });
  es.addEventListener("done", (ev) => {
    const d = JSON.parse(ev.data);
    $("#jb-status").innerHTML = badge(d.status);
    $("#jb-cancel").disabled = true;
    renderResult(d);
    es.close(); window._es = null;
    refreshActiveChip();
  });
  es.onerror = () => { /* پایان استریم */ };

  if (j.status && j.status !== "running" && j.status !== "queued") {
    renderResult(j);
    $("#jb-cancel").disabled = true;
  }
}

function renderLog() {
  const el = $("#jb-console");
  if (!el) return;
  const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 60;
  el.textContent = logBuf.join("");
  if (atBottom) el.scrollTop = el.scrollHeight;
}

function renderResult(d) {
  const r = d.result;
  const note = $("#jb-note");
  const rep = $("#jb-report");
  if (!note || !rep) return;
  if (!r) {
    if (d.error) note.textContent = "خطا: " + d.error;
    return;
  }
  if (r.kind === "run") {
    note.innerHTML = `نتیجه: ${verdictBadge(r.verdict)}` +
      (r.steps || []).filter((s) => s.verdict !== "PASS").length
        ? ` · ${r.steps.length} قدم` : "";
    const bad = (r.steps || []).filter((s) => s.verdict !== "PASS");
    if (bad.length) {
      note.innerHTML += `<div style="margin-top:6px;font-size:12px;color:var(--muted)">`
        + bad.map((s) => `${esc(s.id)}: ${verdictBadge(s.verdict)} ${esc(s.reason || "")}`)
          .join("<br>") + `</div>`;
    }
  } else {
    note.innerHTML =
      `${badge(r.status || "?")} · ${r.actions ?? "؟"} اکشن · ` +
      `${(r.findings || []).length} یافته`;
    if (r.generated_spec) {
      note.innerHTML += ` · <a style="color:var(--accent)"
        href="#/spec?path=${encodeURIComponent(r.generated_spec)}">Spec کشف‌شده</a>`;
    }
  }
  if (d.run_dir) {
    const rid = d.run_dir.split("/").pop();
    rep.innerHTML = `<a class="btn btn-sm" target="_blank"
      href="/api/runs/${encodeURIComponent(rid)}/report">📄 گزارش HTML</a>
      <a class="btn btn-sm" href="#/run/${encodeURIComponent(rid)}">جزئیات اجرا</a>`;
  }
}

/* =====================================================================
   VIEW: وضعیت سیستم
   ===================================================================== */

async function viewStatus() {
  main().innerHTML = '<div class="loading">در حال بررسی…</div>';
  const [doc, sk] = await Promise.all([
    api("/api/doctor"), api("/api/skills").catch(() => ({ skills: [] })),
  ]);

  const items = doc.items.map((it) => `
    <tr>
      <td>${esc(it.label)}</td>
      <td class="mono">${esc(it.value)}</td>
      <td>${it.ok ? "✅" : "❌"}</td>
    </tr>`).join("");

  const skills = (sk.skills || []).map((s) => `
    <tr><td><code>${esc(s.skill)}</code></td>
    <td>${esc(s.activates)}</td></tr>`).join("");

  main().innerHTML = `
    <h1 class="page-title">🩺 وضعیت سیستم</h1>
    <div class="page-sub">چک سلامت اجزای agentic-qa</div>

    <section class="block">
      <h2 class="block-title">سلامت (${doc.ok ? "همه‌چیز آماده ✅" : "برخی موارد نیازمند اصلاح ⚠️"})</h2>
      <div class="table-wrap"><table>
        <tr><th>مورد</th><th>مقدار</th><th>وضعیت</th></tr>${items}
      </table></div>
    </section>

    <section class="block">
      <h2 class="block-title">Skill ها (${(sk.skills || []).length})</h2>
      ${skills ? `<div class="table-wrap"><table>
        <tr><th>نام</th><th>شرایط فعال‌سازی</th></tr>${skills}</table></div>`
      : `<div class="empty">skillی بارگذاری نشده</div>`}
    </section>`;
}

/* ---------------- boot ---------------- */

route();
setInterval(() => {
  if (!window._es) refreshActiveChip();
}, 8000);
