# =====================================================================
# engine/spec_extractor.py
# ---------------------------------------------------------------------
# «to-spec» — ساخت یک Spec قابل اجرای مجدد از شواهدِ یک اجرای واقعی.
#
# چرا این ماژول؟
#   اجرای explorer هوشمند ولی «پرانرژی» است: هر بار ممکن است مسیر
#   کمی متفاوت برود، کپچا/OTP دوباره از کاربر بگیرد و بودجه مصرف
#   کند. وقتی یک مسیر خوب کشف شد، می‌خواهیم همان مسیر «قطعی» و
#   ارزان دوباره اجرا شود — یعنی Spec-Driven (اصل #۱۱).
#
#   python main.py to-spec exploratory-1789165500
#   python main.py to-spec --last
#   → generated/from-run-<id>.yaml
#   → python main.py run generated/from-run-<id>.yaml
#
# منبع داده: دیتای شواهدِ خود اجرا (.evidence/runs/<id>/actions.jsonl)
#   - هیچ selector ی هارد کد نمی‌شود (Constitution #14) — فقط
#     «توصیف معنایی» المنت‌ها همان‌طور که agent در لحظه دیده
#   - مقادیر واقعی تایپ‌شده حفظ می‌شوند تا بازاجرا همان رفتار بدهد
#   - مقداری که از ask_human آمده (کپچا/OTP) → placeholder {var}
#     می‌شود تا بازاجرا دوباره از کاربر بپرسد
#   - اکشن‌های ناموفق (خطا/پالیسی) و ابزارهای مشاهده‌ای (اسکرین‌شات،
#     snapshot، کنسول، شبکه) حذف می‌شوند — فقط «مسیر موفق» می‌ماند
#   - تایپ مکرر روی یک فیلد (مثلاً کپچای دوبار تایپ‌شده) → آخرین
#     مقدار موفق، در جای اولین تلاش
# =====================================================================

import json
import os
import re
import time

import yaml

import config

# ---------------------------------------------------------------------
# دسته‌بندی ابزارها از دید استخراج
# ---------------------------------------------------------------------

# ابزارهای «مشاهده‌ای» — در Spec جایی ندارند (spec خودش snapshot می‌گیرد)
NOISE_TOOLS = {
    "browser_snapshot", "browser_screenshot", "browser_take_screenshot",
    "browser_console_messages", "browser_network_requests",
    "browser_network_request", "browser_evaluate", "browser_pdf_save",
    "browser_tab_list", "browser_press_key", "browser_hover",
    "browser_drag", "browser_handle_dialog", "browser_close",
    "browser_navigate_back", "browser_navigate_forward",
    "report_finding",
}

TEXT_FIELD_TYPES = {"textbox", "text", "textarea"}

# فیلدهایی که مقدارشان نباید در spec ذخیره شود — از کاربر پرسیده می‌شود
SECRET_HINT_RE = re.compile(
    r"(password|passwd|\bpass\b|رمز|گذرواژه|کلمه‌?ی?\s?عبور|"
    r"\bsecret\b|\btoken\b|\bpin\b|credential|confidential)",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------
# کمک‌تابع‌ها
# ---------------------------------------------------------------------

def _norm(text):
    """نرمال‌سازی متن برای کلید یکسان‌سازی (فاصله‌ها/حروف)."""
    return " ".join(str(text or "").lower().split())[:120]


def _mask_value(value):
    """آیا این مقدار در شواهد ماسک شده؟ (REDACTED)"""
    return "***REDACTED***" in str(value)


def _shorten(text, limit=90):
    text = str(text or "")
    return text if len(text) <= limit else text[:limit - 1] + "…"


def _slug(text, fallback="run"):
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", str(text)).strip("-").lower()
    return (slug or fallback)[:60]


# ---------------------------------------------------------------------
# پیدا کردن اجراها
# ---------------------------------------------------------------------

def list_runs(runs_dir=None):
    """
    لیست اجراهای ثبت‌شده در .evidence/runs — مرتب از جدید به قدیم.
    خروجی: list[dict] با کلیدهای run_id / dir / type / status /
    actions / started_at / base_url / intent
    """
    runs_dir = runs_dir or config.EVIDENCE_DIR
    if not os.path.isdir(runs_dir):
        return []

    rows = []
    for name in os.listdir(runs_dir):
        run_dir = os.path.join(runs_dir, name)
        if not os.path.isdir(run_dir):
            continue

        # فقط پوشه‌هایی که واقعاً «اجرای» ثبت‌شده‌اند — پوشه‌های
        # دیگر (مثل generated/) که اتفاقاً کنارشان باشند، نه
        if not (os.path.exists(os.path.join(run_dir, "actions.jsonl"))
                or os.path.exists(os.path.join(run_dir, "run.json"))):
            continue

        row = {
            "run_id": name,
            "dir": run_dir,
            "type": "?",
            "status": "?",
            "actions": 0,
            "started_at": "",
            "base_url": "",
            "intent": "",
            "mtime": os.path.getmtime(run_dir),
        }

        run_json = os.path.join(run_dir, "run.json")
        if os.path.exists(run_json):
            try:
                with open(run_json, "r", encoding="utf-8") as f:
                    data = json.load(f)
                mission = data.get("mission") or {}
                row["type"] = mission.get("type", data.get("type", "?"))
                row["status"] = data.get("status", "?")
                row["started_at"] = data.get("started_at", "")
                row["base_url"] = mission.get("base_url", "") or ""
                row["intent"] = (mission.get("intent", "") or "")[:80]
                counts = data.get("counts") or {}
                row["actions"] = counts.get("actions", 0)
            except Exception:                          # noqa: BLE001
                pass

        if row["actions"] == 0:
            # شمارش از خود jsonl (اجرای ناتمام که run.json ندارد)
            jsonl = os.path.join(run_dir, "actions.jsonl")
            if os.path.exists(jsonl):
                try:
                    with open(jsonl, "r", encoding="utf-8") as f:
                        row["actions"] = sum(
                            1 for line in f if line.strip())
                except Exception:                      # noqa: BLE001
                    pass

        rows.append(row)

    rows.sort(key=lambda r: r["mtime"], reverse=True)
    return rows


def resolve_run(query=None, last=False, runs_dir=None):
    """
    run id یا مسیر پوشه → مسیر کامل پوشه اجرا.
    - last=True  → جدیدترین اجرا
    - query      → نام پوشه (run_id) یا مسیر مستقیم
    خطا → ValueError با لیست اجراهای موجود.
    """
    runs_dir = runs_dir or config.EVIDENCE_DIR

    if query:
        candidate = query
        if not os.path.isdir(candidate):
            candidate = os.path.join(runs_dir, query)
        if os.path.isdir(candidate):
            return candidate
        available = ", ".join(r["run_id"] for r in list_runs(runs_dir)[:15])
        raise ValueError(
            f"run '{query}' not found in {runs_dir}. "
            f"Available: {available or '(none)'}"
        )

    runs = list_runs(runs_dir)
    if not runs:
        raise ValueError(f"no runs found in {runs_dir}")

    if last:
        return runs[0]["dir"]

    # بدون آرگومان → اگر فقط یکی هست همان، وگرنه خطا با لیست
    if len(runs) == 1:
        return runs[0]["dir"]
    listing = "\n".join(
        f"  {r['run_id']:34s} {r['type']:12s} "
        f"{str(r['actions']):>4s} actions  {r['intent']}"
        for r in runs[:15]
    )
    raise ValueError(
        "several runs found — pass a run id or --last:\n" + listing
    )


# ---------------------------------------------------------------------
# استخراجگر Spec
# ---------------------------------------------------------------------

class SpecExtractor:

    def __init__(self, run_dir, ai=None):
        self.run_dir = run_dir
        self.ai = ai
        self.run_id = os.path.basename(os.path.normpath(run_dir))
        self.mission = {}
        self.actions = []
        self._load()

    # -----------------------------------------------------------------

    def _load(self):
        run_json = os.path.join(self.run_dir, "run.json")
        if os.path.exists(run_json):
            try:
                with open(run_json, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.mission = data.get("mission") or {}
                self.status = data.get("status", "?")
            except Exception:                          # noqa: BLE001
                self.status = "?"

        jsonl = os.path.join(self.run_dir, "actions.jsonl")
        if os.path.exists(jsonl):
            try:
                with open(jsonl, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            self.actions.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue
            except Exception:                          # noqa: BLE001
                pass

    # -----------------------------------------------------------------
    # ساخت Spec
    # -----------------------------------------------------------------

    def build_spec(self):
        """
        خروجی: dict مطابق schema specs/*.yaml یا None اگر مسیر
        قابل استخراجی وجود نداشت.
        """
        steps = []
        index_by_key = {}          # کلید یکسان‌سازی → اندیس در steps
        current_url = self.mission.get("base_url") or ""
        pending_var = None         # (save_to) از آخرین ask_human
        seq = 0

        def _next_id():
            nonlocal seq
            seq += 1
            return f"REQ-{seq:03d}"

        def _emit(step, key=None):
            """افزودن قدم جدید (بدون یکسان‌سازی)."""
            step.setdefault("id", _next_id())
            steps.append(step)
            if key is not None:
                index_by_key[key] = len(steps) - 1
            return step

        def _upsert(step, key):
            """قدم موجود با همان کلید → به‌روزرسانی درجا؛ وگرنه افزودن."""
            if key in index_by_key:
                existing = steps[index_by_key[key]]
                for k, v in step.items():
                    if k not in ("id",):
                        existing[k] = v
                return existing, True
            return _emit(step, key), False

        def _link_pending_var(step):
            """اگر قدم بلافاصله بعد از ask_human است → مقدار {var}."""
            nonlocal pending_var
            if pending_var and step.get("action") in ("type",):
                step["value"] = f"{{{pending_var}}}"
                pending_var = None

        def _emit_secret_prompt(step, hint):
            """
            فیلد حساس (رمز/توکن/…): قبل از قدم تایپ، یک prompt_user
            ساخته می‌شود و مقدار {var} می‌شود تا بازاجرا از کاربر
            بپرسد و رمز هرگز در فایل spec ذخیره نشود.
            ⚠ قبل از _upsert قدم تایپ صدا زده شود (ترتیب درست).
            """
            value = str(step.get("value", ""))
            if "{" in value:
                return                  # قبلاً به var وصل شده است
            if not SECRET_HINT_RE.search(str(hint)):
                return
            if _mask_value(value):
                var = "redacted_secret"
            else:
                var = f"secret_{_slug(hint, 'value')}"
            _upsert({
                "description": f"دریافت مقدار حساس از کاربر: "
                               f"{_shorten(hint, 80)}",
                "action": "prompt_user",
                "message": f"مقدار {_shorten(hint, 80)} را وارد کنید",
                "save_to": var,
                "policy": "optional",
            }, ("prompt", _norm(hint)))
            step["value"] = f"{{{var}}}"

        for entry in self.actions:
            tool = entry.get("tool") or ""
            args = entry.get("arguments") or {}
            obs = str(entry.get("observation") or "")

            # اکشن ناموفق یا مسدود — در مسیر بازاجرا جایی نیست
            if entry.get("error") or obs.startswith("BLOCKED BY POLICY"):
                continue

            # ابزارهای مشاهده‌ای — حذف
            if tool in NOISE_TOOLS:
                continue

            # --------- ناوبری ---------
            if tool in ("browser_navigate", "browser_tab_new"):
                url = args.get("url") or ""
                if url and url != current_url \
                        and not url.startswith("about:"):
                    _emit({
                        "description": f"رفتن به آدرس {_shorten(url, 70)}",
                        "action": "navigate",
                        "value": url,
                        "policy": "must_complete",
                    })
                    current_url = url
                continue

            # --------- پرسش از کاربر (کپچا/OTP) ---------
            if tool == "ask_human":
                question = str(args.get("question", ""))[:200]
                # نام متغیر عیناً حفظ می‌شود — این همان اسمی است که
                # در {var} بازاجرا حل می‌شود
                save_to = str(
                    args.get("save_to") or f"human_value_{len(steps) + 1}"
                ).strip() or f"human_value_{len(steps) + 1}"
                _emit({
                    "description": f"دریافت مقدار از کاربر: "
                                   f"{_shorten(question, 90)}",
                    "action": "prompt_user",
                    "message": question,
                    "save_to": save_to,
                    "policy": "optional",
                })
                pending_var = save_to
                continue

            # --------- تایپ تک‌فیلد ---------
            if tool == "browser_type":
                text = args.get("text")
                if text is None or text == "":
                    continue                # پاک‌کردن فیلد — در spec لازم نیست
                text = str(text)
                hint = str(args.get("element") or "فیلد")[:140]
                key = ("type", _norm(hint))
                step = {
                    "description": f"وارد کردن مقدار در {hint}",
                    "action": "type",
                    "target_hint": hint,
                    "value": text,
                    "policy": "must_complete_before_submit",
                }
                if _mask_value(text):
                    step["value"] = "{secret:redacted_value}"
                elif not pending_var:
                    _emit_secret_prompt(step, hint)
                step, _ = _upsert(step, key)
                if pending_var:
                    _link_pending_var(step)
                continue

            # --------- فرم چندفیلدی ---------
            if tool == "browser_fill_form":
                fields = args.get("fields") or []
                if not isinstance(fields, list) or not fields:
                    continue

                text_fields = [
                    f for f in fields
                    if isinstance(f, dict)
                    and str(f.get("type", "textbox")).lower()
                    in TEXT_FIELD_TYPES
                ]

                # حالت «چندخانه‌ای» (کپچا/OTP): همه مقدارهای ۱-۲ کاراکتری
                if len(text_fields) >= 2 and all(
                        len(str(f.get("value", ""))) <= 2
                        for f in text_fields):
                    joined = "".join(
                        str(f.get("value", "")) for f in text_fields)
                    first = text_fields[0]
                    hint = str(
                        first.get("element") or first.get("name")
                        or "سلول‌های ورودی")[:140]
                    key = ("multi", _norm(hint))
                    step = {
                        "description": f"وارد کردن {len(joined)} کاراکتر "
                                       f"در {hint} (هر کاراکتر در خانه جدا)",
                        "action": "type",
                        "target_hint": hint,
                        "value": joined,
                        "multi_input": True,
                        "policy": "must_complete_before_submit",
                    }
                    if _mask_value(joined):
                        step["value"] = "{secret:redacted_value}"
                    step, _ = _upsert(step, key)
                    _link_pending_var(step)
                    continue

                # حالت عادی: هر فیلد یک قدم
                for f in fields:
                    if not isinstance(f, dict):
                        continue
                    ftype = str(f.get("type", "textbox")).lower()
                    value = str(f.get("value", ""))
                    name = str(f.get("element") or f.get("name")
                               or "فیلد")[:140]
                    if ftype in TEXT_FIELD_TYPES:
                        if value == "":
                            continue
                        key = ("type", _norm(name))
                        step = {
                            "description": f"وارد کردن مقدار در {name}",
                            "action": "type",
                            "target_hint": name,
                            "value": value,
                            "policy": "must_complete_before_submit",
                        }
                        if _mask_value(value):
                            step["value"] = "{secret:redacted_value}"
                        elif not pending_var:
                            _emit_secret_prompt(step, name)
                        step, _ = _upsert(step, key)
                        if pending_var:
                            _link_pending_var(step)
                    elif ftype == "combobox":
                        _emit({
                            "description": f"انتخاب «{_shorten(value)}» "
                                           f"در {name}",
                            "action": "select",
                            "target_hint": name,
                            "value": value,
                            "policy": "must_complete_before_submit",
                        })
                    elif ftype in ("checkbox", "radio"):
                        _emit({
                            "description": (
                                f"{'فعال‌سازی' if value == 'true' else 'غیرفعال‌سازی'} {name}"),
                            "action": "click",
                            "target_hint": name,
                            "policy": "must_complete_before_submit",
                        })
                continue

            # --------- کلیک ---------
            if tool == "browser_click":
                hint = str(args.get("element") or "عنصر")[:140]
                key = ("click", _norm(hint))
                # کلیک پشت‌سرهم روی همان عنصر = تلاش مجدد → یکی کافی
                if key in index_by_key and \
                        index_by_key[key] == len(steps) - 1:
                    continue
                pending_var = None      # کلیک پیوند ask_human را می‌شکند
                _emit({
                    "description": f"کلیک روی {hint}",
                    "action": "click",
                    "target_hint": hint,
                    "policy": "requires_all_inputs_filled",
                }, key)
                continue

            # --------- انتخاب از لیست ---------
            if tool == "browser_select_option":
                values = args.get("values") or []
                value = str(values[0]) if values else ""
                hint = str(args.get("element") or "لیست")[:140]
                _emit({
                    "description": f"انتخاب «{_shorten(value)}» در {hint}",
                    "action": "select",
                    "target_hint": hint,
                    "value": value,
                    "policy": "must_complete_before_submit",
                })
                continue

            # --------- آپلود فایل ---------
            if tool == "browser_file_upload":
                paths = args.get("paths") or []
                value = str(paths[0]) if paths else ""
                _emit({
                    "description": f"آپلود فایل {_shorten(value, 70)}",
                    "action": "upload",
                    "target_hint": "دکمه انتخاب فایل / محل آپلود",
                    "value": value,
                    "policy": "must_complete_before_submit",
                })
                continue

            # --------- انتظار ---------
            if tool == "browser_wait_for":
                text = args.get("text")
                if text and steps and not steps[-1].get("wait_for"):
                    # معیار پذیرش برای قدم قبلی (کلیک/تایپ)
                    steps[-1]["wait_for"] = str(text)[:160]
                elif args.get("time"):
                    _emit({
                        "description": "چند لحظه صبر کردن",
                        "action": "wait",
                        "value": str(args.get("time")),
                        "policy": "optional",
                    })
                continue

        if len(steps) < 1:
            return None

        base_url = self.mission.get("base_url") or current_url
        intent = self.mission.get("intent") or ""
        started = self.mission.get("id", self.run_id)

        spec = {
            "feature": f"replay-{_slug(self.run_id, 'run')}",
            "target_url": base_url,
            "mission_type": "spec",
            "intent": (
                f"بازاجرای قطعی مسیری که در اجرای اکتشافی "
                f"'{started}' کشف شد. {intent}".strip()
            ),
            "source_run": self.run_id,
            "steps": steps,
        }
        return spec

    # -----------------------------------------------------------------
    # بازنویسی توصیف‌ها با LLM (اختیاری)
    # -----------------------------------------------------------------

    def polish(self, spec):
        """
        توصیف قدم‌ها را طبیعی‌تر می‌کند (با LLM). ساختار/مقدارها
        دست نمی‌خورد — فقط description و intent.
        هر خطایی → همان spec خام برگردد (silent fallback).
        """
        if not self.ai:
            return spec
        try:
            payload = {
                "intent": spec.get("intent", ""),
                "descriptions": [
                    s.get("description", "") for s in spec["steps"]
                ],
            }
            prompt = (
                "You rewrite QA spec step descriptions in the SAME "
                "language as they are written (likely Persian/Farsi).\n"
                "Keep them short, human, precise. Do NOT add or remove "
                "steps. Do NOT change meaning. Return STRICT JSON:\n"
                '{"intent": "...", "descriptions": ["...", "..."]}\n\n'
                "INPUT:\n"
                + json.dumps(payload, ensure_ascii=False, indent=1)
            )
            raw = self.ai.chat(
                [{"role": "user", "content": prompt}], temperature=0.2)
            data = json.loads(re.sub(
                r"^```(?:json)?|```$", "", str(raw).strip(),
                flags=re.MULTILINE).strip())
            if isinstance(data, dict):
                descs = data.get("descriptions")
                if isinstance(descs, list) and \
                        len(descs) == len(spec["steps"]):
                    for s, d in zip(spec["steps"], descs):
                        if str(d).strip():
                            s["description"] = str(d).strip()[:200]
                if str(data.get("intent", "")).strip():
                    spec["intent"] = str(data["intent"]).strip()[:600]
        except Exception:                              # noqa: BLE001
            pass
        return spec

    # -----------------------------------------------------------------

    def save(self, spec, out_path=None):
        if not spec:
            return None
        out_dir = os.path.dirname(out_path) if out_path \
            else config.GENERATED_DIR
        os.makedirs(out_dir, exist_ok=True)
        path = out_path or os.path.join(
            config.GENERATED_DIR, f"from-run-{_slug(self.run_id)}.yaml")
        with open(path, "w", encoding="utf-8") as f:
            yaml.safe_dump(spec, f, allow_unicode=True,
                           sort_keys=False, width=100)
        return path


# ---------------------------------------------------------------------
# تابع یک‌خطی برای CLI/explorer
# ---------------------------------------------------------------------

def spec_from_run(run_dir, out_path=None, polish=False, ai=None):
    """run_dir → مسیر فایل spec ذخیره‌شده (یا None)."""
    extractor = SpecExtractor(run_dir, ai=None if not polish else ai)
    spec = extractor.build_spec()
    if not spec:
        return None
    if polish:
        spec = extractor.polish(spec)
    return extractor.save(spec, out_path)
