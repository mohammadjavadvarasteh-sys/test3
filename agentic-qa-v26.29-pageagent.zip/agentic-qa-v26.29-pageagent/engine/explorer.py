# =====================================================================
# engine/explorer.py
# ---------------------------------------------------------------------
# حالت تست ۲: «Explorer Test»
# مرورگر باز می‌شود و agent (مطابق .skills/explatory-testing/SKILL.md)
# صفحه را اکتشاف می‌کند:
#   - پیمایش first-breadth از حالت‌های قابل‌دسترس، محدود به action budget
#   - ثبت هر state hash جدید (LoopDetector در کد جلوی چرخه را می‌گیرد)
#   - هر چیز شبیه edge case (خطا، حالت خالی، مجوز غیرعادی) → Finding
#     (نه Verdict — اصل #8)
#   - در پایان، یک «Spec کشف‌شده» هم تولید می‌شود تا بعداً بتوان همان
#     مسیر را به‌صورت spec-driven و قطعی اجرا کرد (اصل #11)
# =====================================================================

import os
import time

import yaml

import config

from engine.agent import QAReActAgent
from engine.ai_client import AIClient, parse_json_loose
from engine.evidence_store import EvidenceStore
from engine.mcp_client import PlaywrightMCPBrowser
from engine.policy_engine import PolicyEngine
from engine.skill_loader import SkillLoader
from engine.snapshot import SnapshotIndex


class ExploratoryRunner:

    def __init__(self, base_url, intent="", budget=60,
                 mission_id=None, allow_destructive=False,
                 human_input_fn=None):
        self.base_url = base_url
        self.intent = intent or "Explore the application, discover " \
                                "features, states and edge cases."
        self.mission_id = mission_id or _slugify(
            f"exploratory-{int(time.time())}")

        self.policy = PolicyEngine(allow_destructive=allow_destructive)
        self.policy.max_actions = int(budget)

        self.browser = PlaywrightMCPBrowser()
        self.ai = AIClient()
        self.store = EvidenceStore(run_id=self.mission_id)
        self.skills = SkillLoader()

        self.agent = QAReActAgent(
            browser=self.browser,
            ai=self.ai,
            policy=self.policy,
            evidence=self.store,
            skill_loader=self.skills,
            mission_type="exploratory",
            mode="explore",
            max_steps=int(budget) + 8,
            human_input_fn=human_input_fn,
        )

        self.discovered_states = []
        self.generated_spec_path = None

    # -----------------------------------------------------------------

    def run(self):
        print("=" * 62)
        print("🧭 EXPLORATORY RUN")
        print(f"🌐 URL     : {self.base_url}")
        print(f"🎯 Intent  : {self.intent[:100]}")
        print(f"⚙️ Budget  : {self.policy.max_actions} actions")
        if config.REALISTIC_TYPING:
            print(f"⌨️  Typing : HUMAN-PACED "
                  f"({config.TYPE_DELAY_MIN_MS}-{config.TYPE_DELAY_MAX_MS}"
                  f"ms per key)")
        else:
            print("⌨️  Typing : instant (AGENTIC_QA_REALISTIC_TYPING=0)")
        print("=" * 62)

        # The explicit user-supplied URL defines this run's navigation
        # boundary; it is not hard-coded to a project-specific host.
        mission = self.policy.set_mission_url(self.base_url)
        if not mission["ok"] and self.policy.allow_requested_domain:
            raise ValueError(f"Invalid mission URL: {mission['reason']}")

        check = self.policy.check_domain(self.base_url)
        if not check["ok"]:
            raise ValueError(
                f"URL not allowed by safety policy: {check['reason']}"
            )

        self.browser.start()

        self.store.start_run({
            "id": self.mission_id,
            "command": f"agentic-qa explore --url {self.base_url}",
            "type": "exploratory",
            "target_spec": None,
            "base_url": self.base_url,
            "intent": self.intent,
            "allow_destructive": self.policy.allow_destructive,
            "budget": {
                "max_actions": self.policy.max_actions,
                "max_retries": self.policy.max_retries,
            },
        })

        status = "COMPLETED"
        try:
            print(f"[nav] {self.base_url}")
            self.browser.navigate(self.base_url)
            # Give the page a moment to settle after navigation before the
            # first Page-Agent state extraction. SPA routes may still be
            # rendering.
            time.sleep(0.5)
            # Page-Agent architecture: the agent observes the live DOM itself.
            try:
                pa = self.agent.browser.page_agent.state()
                self.agent._recent_page_agent_state = pa.get("content", "")
                self.agent._page_agent_url = pa.get("url", "")
            except Exception as state_err:
                # Don't crash — run_goal has its own retry. Just log it.
                print(f"[nav] ⚠️ initial page-agent state failed: {state_err}")

            goal = self._goal_message()

            outcome = self.agent.run_goal(
                goal, context={"base_url": self.base_url},
                requirement_id="EXPLORE",
            )

            self.agent.screenshot("explore-final")

            status = "COMPLETED" if outcome.finished_normally else \
                "BUDGET_EXHAUSTED"

            # If the outcome has a failure_reason, print it so the user can
            # see why the mission ended early.
            if outcome.failure_reason and outcome.actions_count == 0:
                print(f"\n⚠️ failure_reason: {outcome.failure_reason}")

            print(f"\n🧭 exploration outcome: {outcome.verdict} "
                  f"({outcome.actions_count} actions)")
        finally:
            self.browser.close()
            media = self.store.build_run_media()
            run_dir = self.store.finish_run(status, extra={
                "verdict": None,
                "media": {k: os.path.relpath(v, self.store.run_dir) for k, v in media.items()},
            })
            print(f"📁 Evidence: {run_dir}")
            for kind, path in media.items():
                print(f"🎬 {kind.upper()} recording → {path}")

        # تولید Spec کشف‌شده — تا مسیر دوباره قابل اجرا باشد
        self.generated_spec_path = self._generate_discovered_spec()

        return {
            "status": status,
            "run_dir": self.store.run_dir,
            "findings": self.store.findings,
            "generated_spec": self.generated_spec_path,
        }

    # -----------------------------------------------------------------

    def _goal_message(self):
        return (
            f"MISSION (exploratory): {self.intent}\n\n"
            "STRATEGY (from the exploratory-testing skill — binding):\n"
            "- First inspect the actual page and its live element inventory. "
            "Never assume a login form, labels, language, selectors, or "
            "layout from another website.\n"
            "- Breadth-first: cover reachable areas before deep-diving one.\n"
            "- For form/input missions, create a representative matrix "
            "from the observed controls: empty, invalid type/format, "
            "length boundaries, whitespace, special characters, and other "
            "relevant edge partitions. Do not search randomly for a valid "
            "credential when the mission is negative testing.\n"
            "- Track tested values/categories and never repeat the same "
            "invalid value or alternate between the same few values. "
            "If one partition is blocked, move to an independent partition.\n"
            "- CAPTCHA/OTP are never guessed. Ask the human only when the "
            "real value is required. Human-supplied text is not proof that "
            "the CAPTCHA/OTP is correct.\n"
            "- Interact NON-destructively only (safety rules are enforced "
            "in code and will block violations).\n"
            "- Flag anything resembling an edge case — error states, empty "
            "states, broken layouts, unexpected tabs/redirects, unusual "
            "permission states — using report_finding with a severity.\n"
            "- When the action budget warning appears, wrap up and finish "
            "with verdict BLOCKED and failure_reason "
            "'budget_exhausted' (exploration does not produce PASS/FAIL "
            "verdicts — it produces findings).\n\n"
            "Finish when the mission intent is fulfilled or the reachable "
            "state space is genuinely saturated."
        )

    # -----------------------------------------------------------------
    # Spec کشف‌شده — خروجی مکمل (اصل #11: بعداً قطعی اجرا شود)
    # -----------------------------------------------------------------

    def _generate_discovered_spec(self):
        """
        از «شواهد همین اجرا» (actions.jsonl) یک Spec قابل بازاجرایی
        می‌سازد — قطعی و بدون LLM (نگاهی به engine/spec_extractor.py).
        بعداً به‌جای explorer همین spec با 'run' اجرا می‌شود.
        """
        if not self.store.actions:
            return None

        try:
            from engine.spec_extractor import spec_from_run
            path = spec_from_run(self.store.run_dir)
            if path:
                print(f"📝 discovered spec → {path}")
                return path
            return None
        except Exception as e:                              # noqa: BLE001
            print(f"⚠️ could not generate discovered spec: {e}")
            return None


def _slugify(text):
    import re
    text = re.sub(r"[^a-zA-Z0-9]+", "-", str(text)).strip("-")
    return (text or "mission")[:60].lower()
