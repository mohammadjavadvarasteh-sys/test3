# =====================================================================
# engine/oracle.py
# ---------------------------------------------------------------------
# «Oracle Agent» — منطق حکم (Verdict) اینجا متمرکز است، همان‌طور که
# .skills/oracle-verdict/SKILL.md دستور می‌دهد:
#
#   Verdict ها:
#     PASS          — نیاز تأیید شد (باید screenshot + observation داشته باشد)
#     FAIL          — رفتار واقعی با Spec مغایرت دارد (screenshot +
#                     observation + expected + actual لازم است)
#     BLOCKED       — مانع خارجی (captcha، otp بدون کانال دریافت، ...)
#     INCONCLUSIVE  — شواهد کافی برای قضاوت نیست
#
# دو لایه:
#   1) قضاوت معنایی توسط LLM (با متن قدم + مشاهدات agent)
#   2) بررسی کد «کامل بودن شواهد» طبق .rules/evidence.yaml —
#      اگر شواهد الزامی نباشد حکم به INCONCLUSIVE تنزل می‌یابد
#      (دقیقاً طبق .skills/evidence-collection/SKILL.md)
# =====================================================================

import re

import config

from engine.ai_client import AIClient

VERDICTS = ("PASS", "FAIL", "BLOCKED", "INCONCLUSIVE")

# عنصری با این نام در لاگ fill_form نباید مقدارش دیده شود
SENSITIVE_ELEMENT_RE = re.compile(
    r"(password|passwd|secret|token|credential|\bpin\b|cvv|"
    r"رمز|گذرواژه|پسورد)",
    re.IGNORECASE,
)

# نتیجه‌ی تایپ انسانی (browser_type/fill_form) خودش snapshot تازه است؛
# برای قاضی متنِ snapshot نویز است — ولی URL اش شاهد ناوبری است
# (باگ REQ-004: کلیک «تایید» به /panel/certificates رفت ولی فشرده‌سازی
# URL را هم حذف می‌کرد → قاضی موفقیت submit را نمی‌دید → INCONCLUSIVE)
SNAPSHOT_PREFIX = "- Page URL:"

# اولین خط snapshot واقعی MCP: «- Page URL: <url>»
PAGE_URL_RE = re.compile(r"^\s*-\s*Page URL:\s*(\S+)", re.MULTILINE)


def _short(value, maxlen=24):
    text = str(value)
    return text if len(text) <= maxlen else text[:maxlen - 3] + "..."


def _snapshot_note(observation):
    """snapshot → «(page snapshot after action — now at URL)».

    متنِ snapshot نویز است ولی URL را نگه می‌داریم: تغییر URL بین
    خطوط لاگ تنها شاهدِ قطعیِ ناوبری است (مثلاً submit موفق OTP).
    """
    m = PAGE_URL_RE.search(observation)
    if m:
        return (f"(page snapshot after action — now at "
                f"{_short(m.group(1), 110)})")
    return "(page snapshot after action)"


def _field_note(field):
    """ یک فیلد fill_form به‌صورت `ref label -> "value"` (با ماسک رمز). """
    if not isinstance(field, dict):
        return None
    label = (field.get("element") or field.get("name") or "")
    ref = field.get("ref") or field.get("target") or ""
    value = field.get("value")
    if value is None or isinstance(value, bool):
        return None
    value = str(value)
    if SENSITIVE_ELEMENT_RE.search(f"{label} {ref}"):
        value = "***"
    where = f"{ref} {label}".strip() if (ref or label) else "?"
    return f'{where} -> "{_short(value)}"'


def format_observation_lines(observations, limit=25):
    """
    ساخت لاگ مشاهده‌ها برای قاضی.

    باگ واقعی کاربر (REQ-003 کپچا): browser_fill_form اجرا شد ولی نتیجه‌اش
    snapshot است و note ای برای fill_form ساخته نمی‌شد → قاضی فقط
    «یک page snapshot» می‌دید و حکم INCONCLUSIVE می‌داد → policy جلوی
    کلیک ورود را می‌گرفت. حالا هر خط نشان می‌دهد چه اکشنی با چه
    مقداری روی کدام عنصر اجرا شد.
    """
    lines = []
    for obs in (observations or [])[-limit:]:
        tool = obs.get("tool", "?")
        args = obs.get("arguments", {}) or {}
        observation = str(obs.get("observation", ""))
        note = ""
        if tool == "browser_click":
            note = args.get("element", "")
        elif tool == "browser_type":
            note = f'{args.get("element", "")} -> ' \
                   f'"{_short(args.get("text", ""))}"'
        elif tool == "browser_fill_form":
            parts = [n for n in (_field_note(f)
                                 for f in args.get("fields", [])) if n]
            note = f"[{len(parts)} fields] " + "; ".join(parts) \
                if parts else ""
        elif tool == "browser_select_option":
            note = f'{args.get("element", "")} = ' \
                   f'"{_short(args.get("value", ""))}"'
        elif tool == "browser_press_key":
            note = f'key "{args.get("key", "")}"'
        elif tool == "browser_navigate":
            note = args.get("url", "")
        elif tool == "browser_snapshot":
            note = "(page snapshot refreshed)"
        elif tool == "browser_wait_for":
            note = args.get("text", "")
        elif tool == "ask_human":
            # سؤال + نام متغیر ذخیره؛ خود مقدار هرگز وارد evidence نمی‌شود
            # (redaction) — ولی «رسیدِ پاسخ» باید برای قاضی بدیهی باشد:
            # باگ REQ-004: قاضی نمی‌توانست ثابت کند کاربر اصلاً کد داده!
            question = _short(
                args.get("question", args.get("message", "")), 80)
            save_to = args.get("save_to", "")
            note = f'"{question}"' \
                   + (f" (save_to: {save_to})" if save_to else "")
            if "human input received" in observation:
                observation = (
                    "HUMAN REPLIED — value redacted by security policy; "
                    "the receipt is proven"
                )
        elif tool == "browser_file_upload":
            paths = args.get("paths") or []
            note = f"{len(paths)} file(s)"

        if obs.get("error"):
            observation = f"ERROR: {str(obs['error'])[:160]}"
        elif observation.lstrip().startswith(SNAPSHOT_PREFIX):
            observation = _snapshot_note(observation)
        elif "FRESH SNAPSHOT AFTER" in observation:
            # نتیجه‌ی متنی اکشن + snapshot خودکارِ بعدش — فقط متن خودِ
            # اکشن نگه داشته می‌شود و از snapshot تنها URL تازه
            head = observation.split("===")[0].strip()[:160]
            m = PAGE_URL_RE.search(observation)
            observation = (head + " — " if head else "") + (
                f"[fresh snapshot — now at {_short(m.group(1), 110)}]"
                if m else "[fresh snapshot after action]")
        else:
            observation = observation[:220]

        lines.append(
            f"- {tool} {note} :: {observation}" if observation
            else f"- {tool} {note}"
        )
    return lines

JUDGE_SYSTEM = """You are the Oracle — a strict, evidence-based QA verdict judge.
You receive: a requirement (from a Spec), the agent's final claim, and the
action/observation log. Decide ONE verdict:

- PASS: the requirement is demonstrably fulfilled by the evidence shown.
- FAIL: the app demonstrably violates the requirement (expected != actual).
- BLOCKED: an external blocker makes completion impossible
  (CAPTCHA present, OTP channel unavailable, element genuinely absent).
- INCONCLUSIVE: evidence is too weak to say PASS or FAIL. When unsure,
  choose INCONCLUSIVE — never guess (Constitution #6).

Rules:
- "agent claims success" is NOT evidence; only recorded observations count.
- The spec's `action` field (type/click/select/...) is only a HINT. The
  agent may fulfill a "type" step with browser_type OR with ONE
  browser_fill_form call that fills several fields (captcha/OTP cells).
  Both count as the typing action — the log lines show element -> "value".
- A line ending with ":: (page snapshot after action)" means that action
  succeeded and the page state was captured right after it — that IS
  recorded execution evidence, not a missing action.
- "(page snapshot after action — now at URL)" additionally records the
  page URL right after that action. A URL CHANGE between consecutive
  log lines proves navigation really happened (e.g. submit accepted →
  panel/next page URL).
- `- ask_human "..." (save_to: var) :: HUMAN REPLIED ...` PROVES the
  human operator answered; the value itself is redacted from evidence
  ON PURPOSE (secrets never enter logs). For a requirement with
  action=prompt_user ("receive a value from the user") that reply IS
  the deliverable — the receipt line (plus the type/fill_form lines
  showing the value was entered) justifies PASS.
- One-time values (captcha/OTP) vanish from the page once submitted:
  their ABSENCE in a later snapshot is expected and is NOT evidence of
  failure.
- If acceptance criteria (wait_for / expected) are declared but no
  observation shows them met, do NOT return PASS.
- Never invent constraints or behaviors you cannot see in the log.

Reply ONLY with this JSON:
{
  "verdict": "PASS | FAIL | BLOCKED | INCONCLUSIVE",
  "expected": "one short sentence of what the spec required",
  "actual": "one short sentence of what was observed",
  "failure_reason": "short reason when not PASS (else empty string)",
  "reasoning": "2-3 sentences referencing the log"
}"""


class Oracle:

    def __init__(self, ai=None, evidence_store=None):
        self.ai = ai or AIClient()
        self.store = evidence_store
        self.required = self._required_map()

    # -----------------------------------------------------------------

    def _required_map(self):
        """{verdict: [required evidence fields]} از .rules/evidence.yaml"""
        from engine.evidence_store import load_evidence_rules
        rules = load_evidence_rules()
        raw = rules.get("required_on_verdict", {}) or {}
        return {k.upper(): v for k, v in raw.items()}

    # -----------------------------------------------------------------
    # قضاوت
    # -----------------------------------------------------------------

    def judge(self, requirement, agent_final, observations):
        """
        requirement : dict — قدم spec (id, description, wait_for, ...)
        agent_final : dict — خروجی نهایی agent (verdict خودش + دلیل)
        observations: list[dict] — اکشن‌های ثبت‌شده این requirement
        خروجی: verdict استاندارد (dict)
        """
        req_id = requirement.get("id", "?")
        llm_verdict = self._llm_judge(requirement, agent_final, observations)
        verdict = self._enforce_evidence(req_id, llm_verdict)
        verdict["requirement_id"] = req_id
        if self.store:
            self.store.add_verdict(verdict)
        return verdict

    # -----------------------------------------------------------------
    # لایه ۱ — قضاوت معنایی
    # -----------------------------------------------------------------

    def _llm_judge(self, requirement, agent_final, observations):
        obs_lines = format_observation_lines(observations)

        user_prompt = (
            f"REQUIREMENT:\n{_dump(requirement)}\n\n"
            f"AGENT FINAL CLAIM:\n{_dump(agent_final)}\n\n"
            f"OBSERVATION LOG (chronological):\n"
            + "\n".join(obs_lines)
            + "\n\nDecide the verdict. Reply ONLY the JSON object."
        )

        try:
            result = self.ai.chat_json([
                {"role": "system", "content": JUDGE_SYSTEM},
                {"role": "user", "content": user_prompt},
            ], retries=1)
        except Exception as e:                        # noqa: BLE001
            return {
                "verdict": "INCONCLUSIVE",
                "expected": requirement.get("description", ""),
                "actual": "",
                "failure_reason": f"oracle LLM error: {e}",
                "reasoning": "judge call failed; evidence not assessed",
            }

        verdict = str(result.get("verdict", "INCONCLUSIVE")).upper().strip()
        if verdict not in VERDICTS:
            verdict = "INCONCLUSIVE"

        return {
            "verdict": verdict,
            "expected": str(result.get("expected", ""))[:300],
            "actual": str(result.get("actual", ""))[:300],
            "failure_reason": str(result.get("failure_reason", ""))[:300],
            "reasoning": str(result.get("reasoning", ""))[:500],
        }

    # -----------------------------------------------------------------
    # لایه ۲ — اجرای الزامات شواهد در کد
    # -----------------------------------------------------------------

    def _enforce_evidence(self, req_id, verdict):
        v = verdict.get("verdict")
        required = self.required.get(v, []) or []
        missing = []

        for field in required:
            if field == "screenshot":
                if self.store and not self.store.has_screenshot_for(req_id):
                    missing.append("screenshot")
            elif field == "observation":
                if not self._has_observation(req_id):
                    missing.append("observation")
            elif field == "expected":
                if not verdict.get("expected"):
                    missing.append("expected")
            elif field == "actual":
                if not verdict.get("actual"):
                    missing.append("actual")
            elif field == "failure_reason":
                if not verdict.get("failure_reason"):
                    missing.append("failure_reason")

        if missing and v in ("PASS", "FAIL"):
            verdict = dict(verdict)
            verdict["verdict"] = "INCONCLUSIVE"
            verdict["failure_reason"] = (
                f"downgraded to INCONCLUSIVE: missing required evidence "
                f"{missing} for {v} per .rules/evidence.yaml"
            )
            verdict["downgraded_from"] = v
        return verdict

    def _has_observation(self, req_id):
        if self.store is None:
            return True
        return len(self.store.observations_for(req_id)) > 0


def _dump(obj):
    import json
    try:
        return json.dumps(obj, ensure_ascii=False, indent=1)
    except Exception:                                  # noqa: BLE001
        return str(obj)
