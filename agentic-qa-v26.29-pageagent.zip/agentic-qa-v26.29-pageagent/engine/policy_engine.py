# =====================================================================
# engine/policy_engine.py
# ---------------------------------------------------------------------
# موتور سیاست — همان engine/policy_engine.py که فایل‌های skill شما
# به آن ارجاع می‌دهند. همه‌چیز «در کد» اعمال می‌شود، نه در پرامپت
# (اصل #13 قانون اساسی).
#
# وظایف:
#   1) Level-1 Safety:
#      - allowed_domains: هر ناوبری خارج از allow-list بلاک می‌شود
#      - destructive_actions: الگوهای مخرب (delete_* و ...) deny
#      - ابزارهای ممنوع (پیش‌فرض browser_evaluate)
#   2) Budget: max_actions / max_retries / max_recovery_attempts
#   3) LoopDetector (کلاس هم‌نام با ارجاع skill ها):
#      - تکرار (action,target) بیش از حد
#      - تکرار state hash بیش از حد
#      - چرخه A→B→C→A→B→C در پنجره cycle_window
#      - الگوی متناوب click→refresh→click→refresh
#   4) Gating قدم‌های Spec (must_complete_before_submit /
#      requires_all_inputs_filled) — سازگار با spec های فعلی شما
# =====================================================================

import fnmatch
import json
import os
import re
import time
from collections import Counter, deque
import hashlib
from urllib.parse import urlparse

import yaml

import config
from engine.navigation import is_trusted
from engine.semantic import SemanticResolver
from engine.snapshot import SnapshotIndex


def _load_yaml(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        return data if isinstance(data, dict) else default
    except Exception:                              # noqa: BLE001
        return default


# ابزارهایی که URL می‌برند و باید دامنه‌شان چک شود
NAV_TOOLS = {"browser_navigate", "browser_navigate_back", "browser_navigate_forward"}

# ابزارهای تغییردهنده (بعد از این‌ها snapshot وضعیت عوض می‌شود)
MUTATING_TOOLS = {
    "browser_click", "browser_type", "browser_fill_form",
    "browser_select_option", "browser_press_key", "browser_file_upload",
    "browser_handle_file_chooser", "browser_drag", "browser_hover",
    "browser_navigate", "browser_navigate_back", "browser_navigate_forward",
    "browser_evaluate",
}

# ابزارهای مشاهده/جمع‌آوری شواهد — وضعیت صفحه را تغییر نمی‌دهند.
# ⚠ این‌ها در LoopDetector شمرده نمی‌شوند: گرفتن چند اسکرین‌شات/
# snapshot در یک مأموریت اکتشافی «جمع‌آوری شواهد» است، نه گیر کردن
# در حلقه (رفع false-positive در explore). عدم پیشرفت واقعی را
# قانون state-hash (که فقط اکشن‌های تغییردهنده را می‌شمارد) می‌گیرد.
OBSERVATION_TOOLS = {
    "browser_snapshot",
    "browser_find",
    "browser_take_screenshot",
    "browser_console_messages",
    "browser_network_requests",
    "browser_network_request",
    "browser_console_messages",
    "browser_tabs",
    "browser_wait",
    "browser_close",
    "browser_pdf_save",
}


# =====================================================================
# LoopDetector — دقیقاً همان قراردادی که .skills/loop-detection/SKILL.md
# توصیف کرده است
# =====================================================================

class LoopDetector:
    """State-aware no-progress detector.

    A loop is only a repeated *same action on the same target while the
    relevant browser state is unchanged*. Action type alone, element text
    alone, or a previously visited state is never sufficient. This keeps
    valid progressions such as OPEN -> OBSERVE -> SELECT out of the loop
    detector.
    """

    def __init__(self, loop_cfg=None):
        cfg = loop_cfg or {}
        self.max_same_action_repeat = max(2, int(cfg.get("max_same_action_repeat", 2)))
        self.enabled = cfg.get("enabled", True)
        self._actions = deque(maxlen=max(20, int(cfg.get("cycle_window", 12)) * 4))
        self.flagged_reason = None
        self._no_progress_counts = Counter()

    def record(self, tool, target_key, before_state_hash=None, after_state_hash=None,
               evidence_hash=None, is_mutating=True):
        if not self.enabled or tool in OBSERVATION_TOOLS:
            return None

        before = str(before_state_hash or "")
        after = str(after_state_hash or "")
        evidence = str(evidence_hash or after or before)
        record = {
            "tool": str(tool),
            "target": str(target_key or ""),
            "before": before,
            "after": after,
            "evidence": evidence,
            "mutating": bool(is_mutating),
        }
        self._actions.append(record)

        # A wait is itself a progress opportunity: time, timers and in-flight
        # requests may change even when the DOM hash is identical. Do not treat
        # repeated waits as an immediate no-progress loop. The agent has a
        # separate budget/mission timeout to prevent unbounded waiting.
        if record["tool"] == "wait":
            return None

        # Only an unchanged before/after state is a no-progress candidate.
        # A changed state is a valid transition, even when the action type is
        # the same as an earlier action.
        if before and after and before == after:
            fingerprint = (
                record["tool"], record["target"], before, after, evidence
            )
            self._no_progress_counts[fingerprint] += 1
            count = self._no_progress_counts[fingerprint]
            if count >= self.max_same_action_repeat:
                self.flagged_reason = (
                    "loop_detected: identical action target and unchanged "
                    f"state repeated {count} times "
                    f"(tool={record['tool']}, target={record['target']}, "
                    f"state={after})"
                )
                return self.flagged_reason
        return None

    def reset(self):
        self._actions.clear()
        self._no_progress_counts.clear()
        self.flagged_reason = None

    def check(self):
        return self.flagged_reason

    @property
    def actions_taken(self):
        return len(self._actions)


# =====================================================================
# PolicyEngine — اعمال Level 1 Safety + Budget + Loop
# =====================================================================

class PolicyEngine:

    def __init__(self, rules_dir=None, allow_destructive=False):
        self.rules_dir = rules_dir or config.RULES_DIR

        self.safety = _load_yaml(
            os.path.join(self.rules_dir, "safety.yaml"), {}
        )
        self.execution = _load_yaml(
            os.path.join(self.rules_dir, "execution.yaml"), {}
        )
        self.validation = _load_yaml(
            os.path.join(self.rules_dir, "validation.yaml"), {}
        )

        exec_cfg = self.execution.get("execution", {})
        loop_cfg = self.execution.get("loop_detection", {})

        self.allowed_domains = []
        self.allow_requested_domain = bool(
            self.safety.get("allow_requested_domain", False)
        )
        self.mission_domains = []
        self.destructive = self.safety.get("destructive_actions", {}) or {}
        self.destructive_patterns = [
            p.lower() for p in self.destructive.get("patterns", [])
        ]
        self.allow_destructive = allow_destructive

        self.max_actions = exec_cfg.get("max_actions", 100)
        self.max_retries = exec_cfg.get("max_retries", 3)
        self.max_recovery_attempts = exec_cfg.get(
            "max_recovery_attempts", 5
        )
        self.action_timeout = exec_cfg.get("action_timeout_seconds", 30)
        self.mission_timeout = exec_cfg.get("mission_timeout_seconds", 900)

        self.loop_detector = LoopDetector(
            {**loop_cfg,
             "max_same_action_repeat": exec_cfg.get(
                 "max_same_action_repeat", 2),
             "max_state_repetition": exec_cfg.get(
                 "max_state_repetition", 3)}
        )

        self.deny_tools = set(config.DENY_TOOLS)
        self.actions_done = 0
        self.started_at = time.time()
        self.denied = deque(maxlen=20)
        self._observed_snapshot = ""
        self._observed_navigation_targets = set()
        self._navigation_evidence = {}
        self.semantic_resolver = SemanticResolver()
        self.mission_intent = ""
        self._observation_epoch = 0
        self._last_no_effect = None

    def set_mission_url(self, url):
        """
        Make the URL explicitly supplied for this run the navigation
        boundary. This removes the old project-specific hard-code where
        only a few internal domains could be explored.

        Security rule:
        - exact target host is allowed;
        - its subdomains are allowed when the host is a normal DNS name;
        - unrelated domains are NOT added and remain subject to drift guard.
        """
        if not self.allow_requested_domain:
            return {"ok": False, "reason": "dynamic mission domains disabled"}

        try:
            parsed = urlparse(str(url))
        except ValueError:
            return {"ok": False, "reason": f"unparseable URL: {url!r}"}

        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            return {
                "ok": False,
                "reason": "mission URL must be an absolute http/https URL",
            }

        host = (parsed.hostname or "").lower().rstrip(".")
        if not host:
            return {"ok": False, "reason": "mission URL has no hostname"}

        patterns = [host]
        if not re.match(r"^\\d+(?:\\.\\d+){3}$", host) and ":" not in host:
            patterns.append(f"*.{host}")

        for pattern in patterns:
            if pattern not in self.mission_domains:
                self.mission_domains.append(pattern)

        return {
            "ok": True,
            "reason": f"mission boundary set to {host}",
            "patterns": patterns,
        }

    # -----------------------------------------------------------------
    # اعتبارسنجی «قبل» از اجرای هر اکشن
    # -----------------------------------------------------------------

    def set_mission_intent(self, intent):
        """Set the unmodified user/spec goal used to ground semantic requests."""
        self.mission_intent = str(intent or "")

    def consume_internal_action(self):
        """Count an executed internal agent action against the shared budget."""
        if self.actions_done >= self.max_actions:
            return False
        self.actions_done += 1
        return True

    def set_observed_snapshot(self, snapshot_text):
        snapshot_text = snapshot_text or ""
        if snapshot_text != self._observed_snapshot:
            self._observation_epoch += 1
        self._observed_snapshot = snapshot_text
        try:
            snapshot_index = SnapshotIndex(snapshot_text)
            self._observed_navigation_targets = set(
                snapshot_index.observed_navigation_targets()
            )
            if (self._last_no_effect and
                    snapshot_index.state_hash != self._last_no_effect.get("state_hash")):
                # New state evidence means a strategy retry may be valid.
                self._last_no_effect = None
        except Exception:
            self._observed_navigation_targets = set()

    def note_no_effect(self, tool, arguments, before_state_hash, after_state_hash):
        if before_state_hash and after_state_hash and before_state_hash == after_state_hash:
            self._last_no_effect = {
                "tool": str(tool),
                "target": self._action_target(arguments),
                "state_hash": after_state_hash,
            }
        else:
            self._last_no_effect = None

    def clear_no_effect(self):
        self._last_no_effect = None

    @staticmethod
    def _action_target(arguments):
        args = arguments or {}
        return str(
            args.get("target", "")
            or args.get("ref", "")
            or args.get("element", "")
        )[:160]

    def register_navigation_evidence(self, evidence):
        if isinstance(evidence, dict) and evidence.get("navigation_target"):
            self._navigation_evidence = dict(evidence)

    def semantic_option_evidence(self, requested_concept=None):
        """Discover semantic option matches across every observed form control.

        This is runtime evidence only: controls and options come from the
        current accessibility snapshot. No control name, option label, or
        selector is encoded here.
        """
        requested = str(
            requested_concept or self.mission_intent or ""
        ).strip()
        if not requested or not self._observed_snapshot:
            return []

        # A model-authored concept must still be grounded in the mission.
        from engine.semantic import concept_is_in_intent
        if requested_concept and not concept_is_in_intent(requested, self.mission_intent):
            return []

        index = SnapshotIndex(self._observed_snapshot)
        results = []
        for control in index.elements:
            if control.role not in {"combobox", "listbox"}:
                continue
            options = index.options_for(control.ref)
            if not options:
                continue
            match = self.semantic_resolver.match_options(requested, options)
            if match["status"] == "MATCH":
                results.append({
                    "target": control.ref,
                    "control": control.describe(),
                    "options": options,
                    "matches": match["matches"],
                    "status": "MATCH",
                })
            elif match["status"] == "AMBIGUOUS":
                results.append({
                    "target": control.ref,
                    "control": control.describe(),
                    "options": options,
                    "matches": match["matches"],
                    "status": "AMBIGUOUS",
                })
        return results

    def _validate_select_option_evidence(self, arguments):
        target = arguments.get("target") or arguments.get("ref") or arguments.get("element")
        values = arguments.get("values") or arguments.get("value") or []
        if isinstance(values, str):
            values = [values]
        requested = arguments.get("requested_concept") or arguments.get("semantic_concept")

        if not target or not self._observed_snapshot or not values:
            return {"ok": False, "reason": "selection requires current field evidence"}

        index = SnapshotIndex(self._observed_snapshot)
        observed = index.options_for(str(target))
        if not observed:
            return {
                "ok": False,
                "reason": "no options observed for the targeted control; semantic selection cannot be proven",
            }

        if not requested:
            return {
                "ok": False,
                "reason": "selection requires a requested semantic concept; arbitrary/default option selection is forbidden",
            }

        result = self.semantic_resolver.validate_selected_options(
            requested, values, observed, mission_intent=self.mission_intent
        )
        if result["status"] != "MATCH":
            alternatives = []
            if result["status"] in {"NO_MATCH", "AMBIGUOUS"}:
                for item in self.semantic_option_evidence(requested):
                    if item["target"] != str(target):
                        alternatives.append(
                            f"{item['control']} [ref={item['target']}] "
                            f"matches={item['matches']}"
                        )
            suffix = (
                " Other observed controls with a semantic match: "
                + "; ".join(alternatives[:8])
                if alternatives else ""
            )
            return {
                "ok": False,
                "reason": (
                    "semantic selection rejected: status="
                    f"{result['status']}; requested={requested!r}; "
                    f"selected={values!r}; observed={observed!r}; "
                    f"mission_intent_grounded={result['status'] != 'UNANCHORED_REQUEST'}"
                    + suffix
                ),
            }
        return {"ok": True, "reason": "exact semantic match observed in targeted control"}

    def validate_action(self, tool, arguments):
        """
        {approved: bool, reason: str} — قبل از اجرا صدا زده می‌شود.
        این همان دروازه‌ای است که هیچ پرامپتی نمی‌تواند دورش بزند.
        """
        arguments = arguments or {}

        # 1) ابزار ممنوع؟
        if tool in self.deny_tools:
            reason = (
                f"tool '{tool}' is denied by policy "
                f"(set AGENTIC_QA_ALLOW_EVALUATE=1 to enable evaluation)"
                if tool == "browser_evaluate"
                else f"tool '{tool}' is denied by policy"
            )
            return self._deny(tool, arguments, reason)

        # 2) بودجه اکشن‌ها
        if self.actions_done >= self.max_actions:
            return self._deny(
                tool, arguments,
                f"action budget exhausted (max_actions="
                f"{self.max_actions}) — wind down and finish",
            )

        # 3) تایم‌اوت مأموریت
        elapsed = time.time() - self.started_at
        if elapsed > self.mission_timeout:
            return self._deny(
                tool, arguments,
                f"mission timeout reached "
                f"({int(elapsed)}s > {self.mission_timeout}s)",
            )

        # 4) Navigation is allowed by mission boundary or runtime provenance.
        if tool == "browser_navigate":
            url = str(arguments.get("url", ""))
            evidence = arguments.get("navigation_evidence") or {}
            check = self.check_navigation(url, evidence)
            if not check["ok"]:
                return self._deny(tool, arguments, check["reason"])

        if tool == "browser_select_option":
            selection = self._validate_select_option_evidence(arguments)
            if not selection["ok"]:
                return self._deny(tool, arguments, selection["reason"])

        # A mutating action that just produced no state change cannot be
        # repeated blindly. A fresh observation is required before retrying
        # the same target/action, which forces a strategy change or new evidence.
        if tool in MUTATING_TOOLS and self._last_no_effect:
            previous = self._last_no_effect
            current_target = self._action_target(arguments)
            if (previous["tool"] == tool
                    and previous["target"] == current_target):
                return self._deny(
                    tool, arguments,
                    "previous action had no observable effect; obtain new evidence "
                    "or change strategy before repeating the identical action",
                )

        # 5) اکشن مخرب؟ (متن هدف + مقدار تایپ‌شده چک می‌شود)
        if not self.allow_destructive:
            target_text = " ".join([
                str(arguments.get("element", "")),
                str(arguments.get("text", "")),
                str(arguments.get("value", "")),
                str(arguments.get("filename", "")),
                tool,
            ]).lower()
            for pattern in self.destructive_patterns:
                if self._pattern_match(pattern, target_text):
                    return self._deny(
                        tool, arguments,
                        f"destructive action pattern matched: "
                        f"'{pattern}' — mission flag allow_destructive "
                        f"is not set",
                    )

        return {"approved": True, "reason": "action complies with policy"}

    # -----------------------------------------------------------------

    @staticmethod
    def _pattern_match(pattern, text):
        if "*" in pattern:
            return fnmatch.fnmatch(text, pattern)
        return pattern in text

    def check_navigation(self, url, evidence=None):
        """Deterministic navigation decision based on observed evidence.

        Trusted provenance (clipboard_from_application, application_generated,
        observed_href, etc.) is checked FIRST and approves both same-host
        and external navigation. This is critical for 'copy link' flows where
        the share link is on the same host as the mission but was never
        rendered as an observable href in the page.

        Without this, same-host share links like
        ``https://app.example.test/contract/sign?token=abc`` would be
        rejected as 'guessed routes' even when the runtime just read them
        from the trusted clipboard.

        Same-origin is trusted only for the current mission URL or an exact
        navigation target observed in the live snapshot. Being on the same
        host is NOT evidence for an invented route such as ``/some-path``.
        """
        requested = str(url or "").strip()
        evidence = dict(evidence or {})
        target = str(evidence.get("navigation_target", "")).strip()
        if target and target != requested:
            return {
                "ok": False,
                "reason": "navigation evidence target does not match requested URL",
                "external": True,
            }

        observed = {str(x).strip() for x in self._observed_navigation_targets}
        current_url = ""
        try:
            current_url = SnapshotIndex(self._observed_snapshot).url or ""
        except Exception:
            pass

        if requested == current_url:
            return {
                "ok": True,
                "reason": "navigation target is the currently observed page URL",
                "external": False,
                "provenance": "same_origin",
            }

        if requested in observed:
            return {
                "ok": True,
                "reason": "navigation target was explicitly observed in the live page",
                "external": not self.check_domain(requested)["ok"],
                "provenance": "observed_href",
            }

        # Trusted provenance approves navigation for BOTH same-host and
        # external URLs. This must come BEFORE the same-host restriction
        # so that clipboard-copied / application-generated share links on
        # the mission host are not rejected as 'guessed routes'.
        if is_trusted(evidence):
            provenance = str(evidence.get("provenance", "")).strip().lower()
            domain = self.check_domain(requested)
            return {
                "ok": True,
                "reason": f"navigation allowed by trusted provenance: {provenance}",
                "external": not domain["ok"],
                "provenance": provenance,
            }

        domain = self.check_domain(requested)
        if domain["ok"]:
            provenance = str(evidence.get("provenance", "")).strip().lower()
            if provenance == "same_origin" and evidence.get("was_inferred") is not True:
                return {
                    "ok": False,
                    "reason": "same-origin navigation is not enough to authorize an unobserved route; observe the target href/link or application artifact first",
                    "external": False,
                    "provenance": provenance,
                }
            return {
                "ok": False,
                "reason": "navigation target is inside the mission host but was not observed; guessed or constructed routes are forbidden",
                "external": False,
                "provenance": provenance or "unknown",
            }

        provenance = str(evidence.get("provenance", "unknown")).strip().lower()
        return {
            "ok": False,
            "reason": (
                "external navigation blocked: untrusted provenance "
                f"{provenance!r}; runtime/application evidence or an explicitly "
                "scoped human-confirmed artifact is required"
            ),
            "external": True,
            "provenance": provenance,
        }

    def check_domain(self, url):
        """مجاز بودن host طبق allow-list (با پشتیبانی wildcard *)."""
        try:
            parsed = urlparse(url)
        except ValueError:
            return {"ok": False, "reason": f"unparseable URL: {url!r}"}

        if parsed.scheme not in ("http", "https", ""):
            return {
                "ok": False,
                "reason": f"scheme '{parsed.scheme}' not allowed "
                          f"(only http/https)",
            }

        if not parsed.netloc:
            return {"ok": True, "reason": "relative/no host"}

        host = (parsed.hostname or "").lower()
        if host in ("localhost", "127.0.0.1", "::1"):
            return {"ok": True, "reason": "local development host"}

        # Static project rules + the explicit target boundary for this run.
        all_domains = list(self.mission_domains)
        for domain in all_domains:
            domain = str(domain).lower()
            if fnmatch.fnmatch(host, domain):
                source = (
                    "mission boundary" if domain in self.mission_domains
                    else "static allow-list"
                )
                return {"ok": True, "reason": f"matched {domain} ({source})"}

        return {
            "ok": False,
            "reason": f"host '{host}' not matched by the mission boundary",
        }

    def _deny(self, tool, arguments, reason):
        self.denied.append({
            "tool": tool,
            "element": str(arguments.get("element", ""))[:80],
            "reason": reason,
        })
        return {"approved": False, "reason": reason}

    # -----------------------------------------------------------------
    # بعد از اجرای اکشن
    # -----------------------------------------------------------------

    def note_action(self, tool, arguments, before_state_hash=None, after_state_hash=None):
        """Record a completed action using a state-aware fingerprint.

        The target identity always prefers the live MCP ref (`target`/`ref`)
        over the human-readable description (`element`). Two different refs
        are therefore different actions even when their descriptions match.
        """
        self.actions_done += 1
        args = arguments or {}

        # MCP ref/target is the authoritative identity. `element` is only a
        # semantic description and must never hide a different live ref.
        target_key = str(
            args.get("target", "")
            or args.get("ref", "")
            or args.get("element", "")
        )[:160]

        # fill_form: include every live field ref and a non-reversible digest
        # of values so distinct test partitions are not collapsed together.
        if tool == "browser_fill_form" and isinstance(args.get("fields"), list):
            refs = ";".join(
                str(f.get("target") or f.get("ref") or f.get("element") or "")
                for f in args["fields"] if isinstance(f, dict)
            )[:160]
            value_parts = []
            for f in args["fields"]:
                if not isinstance(f, dict):
                    continue
                value = f.get("value", f.get("text", ""))
                value = "" if value is None else str(value)
                value_parts.append(
                    f"{len(value)}:{hashlib.sha256(value.encode('utf-8')).hexdigest()[:12]}"
                )
            value_digest = hashlib.sha256(
                "|".join(value_parts).encode("utf-8")
            ).hexdigest()[:16]
            target_key = (
                (target_key + "|" + refs if refs else target_key)
                + f"|values:{value_digest}"
            )[:320]

        evidence_hash = str(after_state_hash or before_state_hash or "")
        return self.loop_detector.record(
            tool, target_key,
            before_state_hash=before_state_hash,
            after_state_hash=after_state_hash,
            evidence_hash=evidence_hash,
            is_mutating=tool in MUTATING_TOOLS,
        )

    # -----------------------------------------------------------------
    # Gating قدم‌های Spec — همان semantics پروژه قبلی شما
    # -----------------------------------------------------------------

    def step_gate(self, step, steps, completed_ids):
        """
        steps: لیست کامل قدم‌های spec
        completed_ids: set از id های کامل‌شده
        """
        policy = step.get("policy", "")
        step_id = step.get("id")

        if policy == "requires_all_inputs_filled":
            target_index = -1
            for i, s in enumerate(steps):
                if s.get("id") == step_id:
                    target_index = i
                    break
            if target_index == -1:
                return {"approved": True, "reason": "step not in list"}

            for prev in steps[:target_index]:
                prev_policy = prev.get("policy", "")
                if prev_policy == "must_complete_before_submit":
                    if prev.get("id") not in completed_ids:
                        return {
                            "approved": False,
                            "reason": (
                                f"Policy violation: cannot run "
                                f"{step_id} because "
                                f"{prev.get('id')} "
                                f"({prev.get('description', '')}) "
                                f"is not completed yet"
                            ),
                        }
        return {"approved": True, "reason": "step complies"}

    # -----------------------------------------------------------------

    def budget_report(self):
        elapsed = int(time.time() - self.started_at)
        return {
            "actions_done": self.actions_done,
            "max_actions": self.max_actions,
            "elapsed_seconds": elapsed,
            "mission_timeout": self.mission_timeout,
            "loop_flagged": self.loop_detector.flagged_reason,
            "denied_count": len(self.denied),
        }

    # -----------------------------------------------------------------
    # کامپایل قوانین برای تزریق در پرامپت (فقط برای آگاهی agent)
    # -----------------------------------------------------------------

    def compile_prompt_rules(self):
        lines = [
            f"- Static allowed domains: {', '.join(self.allowed_domains) or '(none)'}",
            f"- Mission target domains: "
            f"{', '.join(self.mission_domains) or '(set from the explicit target URL before navigation)'} "
            f"— unrelated domains remain blocked",
            f"- Max actions per run: {self.max_actions}",
            f"- Max retries per action: {self.max_retries}",
            f"- Max recovery attempts: {self.max_recovery_attempts}",
            f"- Mission timeout: {self.mission_timeout}s",
            f"- Destructive actions (delete_*, cancel_subscription, ...): "
            f"{'ALLOWED this mission' if self.allow_destructive else 'DENIED'}",
            f"- Denied tools: {', '.join(sorted(self.deny_tools)) or '(none)'}",
            f"- Loop detection: ON — same action/state repetition or "
            f"cycles are stopped in code (Constitution #13)",
        ]
        cred = self.safety.get("credential_protection", {}) or {}
        if cred.get("never_log_plaintext"):
            lines.append(
                "- Credentials/OTP/tokens are never logged in plaintext "
                "(redacted automatically in evidence)"
            )
        return "\n".join(lines)
