# =====================================================================
# engine/spec_runner.py
# ---------------------------------------------------------------------
# حالت تست ۱: «Spec-Driven Test»
# یک فایل Spec (YAML/JSON — همان schema فعلی شما، ولی بدون selector)
# خوانده می‌شود؛ برای هر requirement، agent با مرورگر واقعی (MCP)
# هدف را اجرا می‌کند و Oracle حکم می‌دهد.
#
# ویژگی‌های حفظ‌شده از پروژه قبلی شما:
#   - placeholder ها: {var} از ask_human، به‌علاوه {secret:NAME} و
#     {env:NAME|default} از .steering/secrets.yaml و محیط
#   - policy gating قدم‌ها (must_complete_before_submit / ...)
#   - wait_for به‌عنوان «معیار پذیرش» (متنی و انسانی، نه CSS)
#   - negative_cases اختیاری → requirement های فرعی N1, N2, ...
# =====================================================================

import hashlib
import json
import os
import re

import yaml

import config

from engine.agent import QAReActAgent, AgentOutcome
from engine.ai_client import AIClient
from engine.evidence_store import EvidenceStore
from engine.mcp_client import PlaywrightMCPBrowser
from engine.oracle import Oracle
from engine.policy_engine import PolicyEngine
from engine.skill_loader import SkillLoader

VAR_RE = re.compile(r"\{([a-zA-Z0-9_.\-]+)\}")
SECRET_RE = re.compile(r"\{secret:([a-zA-Z0-9_.\-]+)\}")
ENV_RE = re.compile(r"\{env:([A-Za-z0-9_]+)(?:\|([^}]*))?\}")

# وقتی Oracle حکم INCONCLUSIVE بدهد (شواهد کافی نبود)، همان قدم یک
# بار دوباره اجرا می‌شود — placeholder ها الان resolve می‌شوند (مثل
# {captcha_text} که agent در تلاش اول با ask_human گرفت) و agent
# به‌جای تکرار اکشن، وضعیت صفحه را verify می‌کند و finish می‌زند.
INCONCLUSIVE_RETRY_HINT = """

RETRY NOTE (final attempt): the previous attempt of THIS requirement was
judged INCONCLUSIVE — the recorded evidence was too weak.
- Look at CURRENT PAGE STATE: if the requirement is already fulfilled
  (fields already contain the expected values), do NOT repeat the action;
  finish immediately with verdict PASS and state exactly what you verified.
- Otherwise perform the action now.
- If the human already provided the value for this step, do NOT ask again
  — reuse it."""


def load_spec(path):
    """Spec را YAML/JSON می‌خواند — steps یا requirements."""
    with open(path, "r", encoding="utf-8") as f:
        ext = os.path.splitext(path)[1].lower()
        if ext in (".yaml", ".yml"):
            spec = yaml.safe_load(f)
        elif ext == ".json":
            spec = json.load(f)
        else:
            raise ValueError(
                f"Unsupported spec format '{ext}' — use .yaml/.yml/.json"
            )
    if not isinstance(spec, dict):
        raise ValueError("Spec file must contain a mapping/object.")
    return spec


def spec_hash(spec):
    return hashlib.md5(
        json.dumps(spec, ensure_ascii=False, sort_keys=True)
        .encode("utf-8")
    ).hexdigest()[:12]


def load_secrets():
    """Secret store: .steering/secrets.yaml — هرگز commit نمی‌شود."""
    path = os.path.join(config.STEERING_DIR, "secrets.yaml")
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        return data.get("credentials", data)
    except Exception:                                    # noqa: BLE001
        return {}


class SpecDrivenRunner:

    def __init__(self, spec_path, allow_destructive=False,
                 max_actions=None, human_input_fn=None):
        self.spec_path = spec_path
        self.spec = load_spec(spec_path)
        self.steps = (
            self.spec.get("steps")
            or self.spec.get("requirements")
            or []
        )
        self.feature = self.spec.get(
            "feature", self.spec.get("title", "unnamed-feature")
        )
        self.target_url = self.spec.get("target_url")

        self.policy = PolicyEngine(allow_destructive=allow_destructive)
        if max_actions:
            self.policy.max_actions = int(max_actions)

        self.secrets = load_secrets()
        self.context_vars = {}

        self.browser = PlaywrightMCPBrowser()
        self.ai = AIClient()
        self.store = EvidenceStore()
        self.skills = SkillLoader()
        self.oracle = Oracle(ai=self.ai, evidence_store=self.store)

        self.agent = QAReActAgent(
            browser=self.browser,
            ai=self.ai,
            policy=self.policy,
            evidence=self.store,
            skill_loader=self.skills,
            mission_type=self.spec.get("mission_type", "spec"),
            mode="run",
            human_input_fn=human_input_fn,
        )

        self.results = []          # خلاصه‌ی per-step
        self.completed_ids = set()

    # -----------------------------------------------------------------
    # Placeholder ها
    # -----------------------------------------------------------------

    def resolve_placeholders(self, value):
        if not isinstance(value, str):
            return value

        # {secret:NAME} — پشتیبانی از مسیر نقطه‌ای مثل a.b
        def _secret(m):
            name = m.group(1)
            val = _dotted_get(self.secrets, name)
            if val is not None:
                self.context_vars[f"__secret_{name}"] = "***"
                return str(val)
            return m.group(0)     # حل نشد — همین‌طور بماند

        value = SECRET_RE.sub(_secret, value)

        # {env:NAME|default}
        def _env(m):
            name, default = m.group(1), m.group(2)
            return os.environ.get(name, default if default is not None
                                  else m.group(0))

        value = ENV_RE.sub(_env, value)

        # {var}
        def _var(m):
            name = m.group(1)
            return str(self.context_vars[name]) \
                if name in self.context_vars else m.group(0)

        value = VAR_RE.sub(_var, value)
        return value

    # -----------------------------------------------------------------
    # اجرای کل Spec
    # -----------------------------------------------------------------

    def run(self):
        print("=" * 62)
        print(f"🚀 SPEC-DRIVEN RUN — {self.feature}")
        print(f"📄 Spec   : {self.spec_path}")
        print(f"🌐 Target : {self.target_url}")
        print(f"🧩 Steps  : {len(self.steps)}")
        print(f"🔧 Model  : {config.AI_MODEL} @ {config.AI_BASE_URL}")
        if config.REALISTIC_TYPING:
            print(f"⌨️  Typing : HUMAN-PACED "
                  f"({config.TYPE_DELAY_MIN_MS}-{config.TYPE_DELAY_MAX_MS}"
                  f"ms per key)")
        print("=" * 62)

        # The spec target URL is the explicit navigation boundary.
        if self.target_url:
            mission = self.policy.set_mission_url(self.target_url)
            if not mission["ok"] and self.policy.allow_requested_domain:
                raise ValueError(
                    f"Invalid target_url: {mission['reason']}"
                )

        self.browser.start()

        self.store.start_run({
            "id": self.feature,
            "command": f"agentic-qa run {self.spec_path}",
            "type": "spec",
            "target_spec": os.path.relpath(
                self.spec_path, config.PROJECT_ROOT),
            "base_url": self.target_url,
            "allow_destructive": self.policy.allow_destructive,
            "budget": {
                "max_actions": self.policy.max_actions,
                "max_retries": self.policy.max_retries,
            },
            "spec_hash": spec_hash(self.spec),
        })

        exit_verdict = "PASS"
        try:
            # ناوبری اولیه
            if self.target_url:
                check = self.policy.check_domain(self.target_url)
                if not check["ok"]:
                    raise ValueError(
                        f"target_url not allowed by safety.yaml: "
                        f"{check['reason']}"
                    )
                print(f"[nav] {self.target_url}")
                self.browser.navigate(self.target_url)
                agent = self.agent
                pa = agent.browser.page_agent.state()
                agent._recent_page_agent_state = pa.get("content", "")
                agent._page_agent_url = pa.get("url", "")

            # قدم به قدم — اگر قدمی «به‌دلیل policy» بلاک شد (پیش‌نیازش
            # کامل نشده)، ادامه‌ی زنجیره بی‌معنی است: مثلاً اگر ورود
            # کلیک نشده، پرسیدن OTP از کاربر فقط OTP او را هدر می‌دهد.
            # بقیه‌ی قدم‌ها skip و BLOCKED ثبت می‌شوند.
            plan = self._expanded_plan()

            gate_aborted = False
            for step in plan:
                if gate_aborted:
                    self._record_skipped_step(step)
                    continue
                if self._run_step(step):
                    gate_aborted = True

            # جمع‌بندی
            exit_verdict = self._summary()
        finally:
            self.browser.close()
            media = self.store.build_run_media()
            self.store.finish_run(exit_verdict, extra={
                "feature": self.feature,
                "verdicts": [r["verdict"] for r in self.results],
                "media": {k: os.path.relpath(v, self.store.run_dir) for k, v in media.items()},
            })
            print(f"\n📁 Evidence: {self.store.run_dir}")
            for kind, path in media.items():
                print(f"🎬 {kind.upper()} recording → {path}")

        return exit_verdict

    # -----------------------------------------------------------------
    # گسترش negative cases به requirement های فرعی
    # -----------------------------------------------------------------

    def _expanded_plan(self):
        plan = []
        for step in self.steps:
            plan.append(step)
            for i, neg in enumerate(step.get("negative_cases") or [], 1):
                plan.append({
                    "id": f"{step.get('id', 'STEP')}-N{i}",
                    "description": (
                        f"[negative] {neg.get('description', '')}"
                    ),
                    "action": neg.get("action", step.get("action")),
                    "target_hint": neg.get(
                        "target_hint", step.get("target_hint")),
                    "value": neg.get("value", ""),
                    "expect": neg.get(
                        "expect", "graceful error, no corrupted state"),
                    "policy": "optional",
                    "parent": step.get("id"),
                })
        return plan

    # -----------------------------------------------------------------
    # ثبت قدمِ ردشده (بعد از یک gate-block)
    # -----------------------------------------------------------------

    def _record_skipped_step(self, step):
        step_id = step.get("id", f"STEP-{len(self.results) + 1}")
        print()
        print("-" * 62)
        print(f"[{step_id}] {step.get('description', '')}")
        print("    ⏭️ BLOCKED (skipped) — a previous step was "
              "blocked by the policy gate; running this step is not "
              "meaningful now")
        reason = "skipped: previous step blocked by policy gate"
        self.results.append({
            "id": step_id,
            "verdict": "BLOCKED",
            "reason": reason,
        })
        self.store.add_verdict({
            "requirement_id": step_id,
            "verdict": "BLOCKED",
            "expected": step.get("description", ""),
            "actual": "",
            "failure_reason": reason,
        })

    # -----------------------------------------------------------------
    # اجرای یک قدم
    # -----------------------------------------------------------------

    def _run_step(self, step):
        """
        خروجی True یعنی این قدم «به‌دلیل policy gate» اجرا نشد —
        (باقی قدم‌ها باید skip شوند). حکم BLOCKED بعد از اجرای واقعی
        خروجی False می‌دهد؛ چون قدم اجرا شده و قضاوت نهایی گرفته است.
        """
        step_id = step.get("id", f"STEP-{len(self.results) + 1}")
        description = step.get("description", "")
        action = step.get("action", "")
        wait_for = step.get("wait_for", "")

        print()
        print("-" * 62)
        print(f"[{step_id}] {description}")
        print(f"    action={action or '(agent decides)'}"
              + (f"  wait_for={wait_for}" if wait_for else ""))

        # 1) Constitution #14 — selector در spec ممنوع
        if step.get("selector"):
            print("    ⚠️ step carries a `selector` field — IGNORED "
                  "per Constitution #14 (semantic addressing only)")
            step = {k: v for k, v in step.items() if k != "selector"}

        # 2) Gating قدم‌ها (همان semantics قبلی)
        gate = self.policy.step_gate(step, self.steps, self.completed_ids)
        if not gate["approved"]:
            print(f"    🛑 {gate['reason']}")
            print("       → remaining steps will be SKIPPED (broken "
                  "dependency chain)")
            self.results.append({
                "id": step_id,
                "verdict": "BLOCKED",
                "reason": gate["reason"],
            })
            self.store.add_verdict({
                "requirement_id": step_id,
                "verdict": "BLOCKED",
                "expected": description,
                "actual": "",
                "failure_reason": gate["reason"],
            })
            return True          # زنجیره شکست — ادامه‌ی قدم‌ها بی‌معنی است

        # 3) placeholder ها
        value = self.resolve_placeholders(step.get("value", ""))
        if isinstance(value, str) and value != str(step.get("value", "")):
            print(f"    🔄 placeholders resolved")

        # 4) پیام هدف برای agent
        goal = self._goal_text(step, value)
        context = self._step_context(step, value)

        # skill ها: اگر spec سیگنال دارد، بروزرسانی prompt
        signals = set()
        if any(s.get("negative_cases") for s in self.steps):
            signals.add("negative_cases")
        if self.spec.get("constraints"):
            signals.add("constraints")
        self.agent.refresh_skills()

        # 5) اجرا + ۷) حکم — با یک تلاش مجدد وقتی شواهد برای قاضی کافی
        #    نبود (باگ کاربر: کپچا پر شد ولی حکم INCONCLUSIVE آمد و
        #    policy جلوی کلیک «ورود» را گرفت). تلاش دوم: placeholder ها
        #    resolve شده‌اند و agent به‌جای تکرار، verify می‌کند.
        #    loop detection per-path: با هر requirement جدید شمارنده‌های
        #    مسیر ریست می‌شوند (budget تجمعی می‌ماند)
        attempt = 0
        while True:
            attempt += 1
            self.policy.loop_detector.reset()
            try:
                outcome = self.agent.run_goal(
                    goal, context=context, requirement_id=step_id)
            except Exception as e:                          # noqa: BLE001
                outcome = AgentOutcome(
                    verdict="INCONCLUSIVE",
                    expected=description,
                    failure_reason=f"runner error: {e}",
                    finished_normally=False,
                )

            # 6) همگام‌سازی {var} ها — مقدارهایی که agent با ask_human
            #    گرفت (کپچا/OTP) باید در تلاش مجدد و قدم‌های بعدی
            #    resolve شوند
            if self.agent.context_vars:
                self.context_vars.update(self.agent.context_vars)

            # اسکرین‌شات پایان قدم (Constitution #3) — deterministic
            self.agent.screenshot(
                f"req-{step_id}" + ("-retry" if attempt > 1 else ""))

            # 7) حکم Oracle
            verdict = self.oracle.judge(
                requirement=step,
                agent_final=outcome.to_dict(),
                observations=self.store.observations_for(step_id),
            )

            if verdict["verdict"] != "INCONCLUSIVE" or attempt >= 2:
                break
            if self.policy.actions_done >= self.policy.max_actions:
                print("    ⚠️ no retry for INCONCLUSIVE — action "
                      "budget exhausted")
                break

            print("    🔁 INCONCLUSIVE (evidence too weak) — one retry "
                  "with a fresh goal")
            if verdict.get("failure_reason"):
                print(f"       judge note: "
                      f"{verdict['failure_reason'][:140]}")
            # مقدارهایی که agent در تلاش اول گرفت حالا resolve می‌شوند
            value = self.resolve_placeholders(step.get("value", ""))
            goal = self._retry_goal(step, value)
            context = self._step_context(step, value)

        if verdict["verdict"] in ("PASS", "FAIL", "BLOCKED"):
            self.completed_ids.add(step_id)

        icon = {"PASS": "✅", "FAIL": "❌",
                "BLOCKED": "⛔", "INCONCLUSIVE": "❓"}.get(
                    verdict["verdict"], "•")
        print(f"    {icon} {verdict['verdict']}"
              + (f" — {verdict.get('failure_reason', '')[:120]}"
                 if verdict.get("failure_reason") else ""))

        self.results.append({
            "id": step_id,
            "verdict": verdict["verdict"],
            "reason": verdict.get("failure_reason", ""),
            "expected": verdict.get("expected", ""),
            "actual": verdict.get("actual", ""),
        })
        return False

    # -----------------------------------------------------------------

    def _step_context(self, step, value):
        """context goal برای agent (target_hint/action/value/wait_for)."""
        action = step.get("action", "")
        context = {
            "target_hint": step.get("target_hint", ""),
            "action": action,
        }
        if value and action != "prompt_user":
            context["value_to_use"] = _mask_if_secret(step, value)
        if step.get("wait_for"):
            context["acceptance_criteria (wait_for)"] = step["wait_for"]
        if step.get("expect"):
            context["expected_outcome"] = step["expect"]
        return context

    def _goal_text(self, step, value):
        parts = [step.get("description") or
                 f"Perform step {step.get('id', '')}"]

        action = step.get("action", "")
        if action == "prompt_user":
            parts.append(
                f"This step REQUIRES asking the human operator: "
                f"\"{step.get('message', 'please provide the value')}\" "
                f"— use the ask_human tool with save_to="
                f"\"{step.get('save_to', 'step_value')}\", then type the "
                f"received value into the correct field(s) on the page."
            )
        elif action and action not in ("verify",):
            parts.append(f"Intended action type: {action}.")

        if value and action not in ("prompt_user",):
            parts.append(f"Value to use: \"{value}\".")

        if step.get("multi_input"):
            parts.append(
                "The runtime evidence indicates multiple coordinated input "
                "cells. Fill the supplied value across those observed cells "
                "without changing its characters or inventing a format."
            )

        wait_for = step.get("wait_for", "")
        if wait_for:
            parts.append(
                f"Acceptance criteria: after the action, the page should "
                f"show {wait_for} — verify with browser_wait_for or by "
                f"reading the snapshot before finishing."
            )
        if step.get("expect"):
            parts.append(f"Expected outcome: {step['expect']}")

        parts.append(
            "Finish with the proper verdict when the step is done or "
            "provably blocked."
        )
        return "\n".join(parts)

    # -----------------------------------------------------------------

    def _retry_goal(self, step, value):
        """
        goal تلاش دوم.

        باگ واقعی کاربر (REQ-004): OTP از کاربر گرفته شد، وارد فیلدها شد،
        «تایید» کلیک شد و صفحه به /panel/certificates رفت — یعنی مرحله
        واقعاً موفق بود. ولی قاضی INCONCLUSIVE داد و goal تازهِ قدمِ
        prompt_user دوباره می‌گفت «این قدم الزاماً از اپراتور بپرس…» →
        agent دوباره ask_human زد و کاربر بی‌دلیل برای بار دوم OTP را
        وارد کرد (OTP یک‌بارمصرف است و صفحه هم دیگر فیلد OTP ندارد).

        برای قدم‌های prompt_user که مقدارشان را همان تلاش اول گرفتیم:
        goal تلاش دوم «فقط verify» است — مقدار دریافتی را می‌گوییم،
        ask را ممنوع می‌کنیم و فقط وضعیت فعلی صفحه چک می‌شود.
        """
        if step.get("action") == "prompt_user":
            save_to = step.get("save_to", "")
            saved = str(self.context_vars.get(save_to, "") or "")
            if saved:
                parts = [
                    step.get("description")
                    or f"Perform step {step.get('id', '')}",
                    "RETRY (final attempt): the previous attempt of THIS "
                    "step was judged INCONCLUSIVE — its recorded evidence "
                    "was too weak, but the actions may have actually "
                    "succeeded.",
                    f"The human operator ALREADY provided this value in "
                    f"that attempt: \"{saved}\" "
                    f"(saved as {save_to or 'step_value'}).",
                    "ask_human is FORBIDDEN in this attempt — never ask "
                    "the user for this value again.",
                    "STEP 1 — inspect the CURRENT PAGE STATE first: if "
                    "the flow has already moved past this stage (the "
                    "value was accepted, login/submit completed, the "
                    "next page loaded), the requirement is fulfilled: "
                    "finish immediately with verdict PASS and state "
                    "exactly what you verified.",
                    "STEP 2 — only if the page still shows the input "
                    "field(s) for this value AND they are empty, re-enter "
                    "the saved value above (browser_type / "
                    "browser_fill_form), then finish.",
                ]
                if step.get("wait_for"):
                    parts.append(
                        f"Acceptance criteria: the page should show "
                        f"{step['wait_for']}."
                    )
                parts.append(
                    "Finish with the proper verdict when the step is done "
                    "or provably blocked."
                )
                return "\n".join(parts)
        return self._goal_text(step, value) + INCONCLUSIVE_RETRY_HINT

    # -----------------------------------------------------------------

    def _summary(self):
        counts = {"PASS": 0, "FAIL": 0, "BLOCKED": 0, "INCONCLUSIVE": 0}
        for r in self.results:
            counts[r["verdict"]] = counts.get(r["verdict"], 0) + 1

        print()
        print("=" * 62)
        print(f"📊 SUMMARY — {self.feature}")
        print(f"   PASS={counts['PASS']}  FAIL={counts['FAIL']}  "
              f"BLOCKED={counts['BLOCKED']}  "
              f"INCONCLUSIVE={counts['INCONCLUSIVE']}")
        print(f"   actions: {self.policy.actions_done}"
              f"/{self.policy.max_actions}"
              f"   elapsed: "
              f"{int(self.policy.budget_report()['elapsed_seconds'])}s")
        print("=" * 62)

        if counts["FAIL"] > 0:
            return "FAILED"
        if counts["PASS"] == 0:
            return "INCONCLUSIVE"
        if counts["BLOCKED"] or counts["INCONCLUSIVE"]:
            return "PARTIAL"
        return "PASSED"


def _mask_if_secret(step, value):
    """مقدار را در لاگ ترمینال ماسک نکن — فقط در evidence ماسک می‌شود."""
    return value


def _dotted_get(obj, dotted):
    """دسترسی نقطه‌ای به dict های تودرتو — internet_demo.username"""
    current = obj
    for part in str(dotted).split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current
