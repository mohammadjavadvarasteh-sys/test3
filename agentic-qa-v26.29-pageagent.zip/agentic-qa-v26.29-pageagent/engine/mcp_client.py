# =====================================================================
# engine/mcp_client.py
# ---------------------------------------------------------------------
# کلاینت MCP روی stdio — پیاده‌سازی JSON-RPC 2.0 بدون هیچ وابستگی
# خارجی (فقط stdlib). این لایه «ابزار جداگانه‌ای» است که به
# Playwright وصل می‌شود: سرور رسمی @playwright/mcp.
#
# چرا این معماری مشکل selector را حل می‌کند؟
#   - Page-Agent state لایه‌ی اصلی تعامل است: DOM زنده در صفحه استخراج و
#     به عناصر index شده تبدیل می‌شود؛ LLM فقط index می‌فرستد.
#   - browser_snapshot/refهای Playwright MCP فقط surface کمکی برای evidence،
#     diagnostics و قابلیت‌های مرورگر خارج از controller هستند.
#   - هیچ CSS/XPath selector ی در هیچ لایه‌ای هاردکد نمی‌شود.
# =====================================================================

import base64
import json
import os
from pathlib import Path
import random
import shlex
import shutil
import subprocess
import threading
import time
from collections import deque

import config

try:
    # برای تشخیص «مقدار فعلی فیلد» قبل از تایپ انسانی (پاک‌سازی
    # محتوا با سمنتیک replace مثل fill — نه append)
    from engine.snapshot import SnapshotIndex
except Exception:                                          # noqa: BLE001
    SnapshotIndex = None


class MCPError(Exception):
    """خطای سطح پروتکل/انتقال MCP."""


class ToolExecutionError(Exception):
    """سرور ابزار را اجرا کرد ولی خود ابزار خطا داد (isError)."""

    def __init__(self, message, raw_text=""):
        super().__init__(message)
        self.raw_text = raw_text


class ToolResult:
    """نتیجه نرمال‌شده‌ی یک tools/call."""

    def __init__(self, text="", images=None, structured=None):
        self.text = text or ""
        self.images = images or []          # list[str] — base64 PNG
        self.structured = structured

    @property
    def is_snapshot(self):
        """آیا این نتیجه خودش snapshot درخت دسترس‌پذیری است؟"""
        return "[ref=" in self.text


# =====================================================================
# انتقال stdio — پیام‌های JSON خط‌به‌خط (newline-delimited)
# =====================================================================

class MCPStdioTransport:

    def __init__(self, command, cwd=None):
        self.command = command
        self.cwd = cwd
        self.proc = None
        self._id = 0
        self._pending = {}                    # id -> dict(event, result, error)
        self._lock = threading.Lock()
        self.notifications = deque(maxlen=64) # پیام‌های یک‌طرفه سرور
        self._stderr_tail = deque(maxlen=80)  # برای عیب‌یابی
        self._closed = False

    # -----------------------------------------------------------------

    def start(self):
        try:
            self.proc = subprocess.Popen(
                self.command,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=self.cwd,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
        except FileNotFoundError as e:
            raise MCPError(
                f"Cannot start MCP server command {self.command!r}: {e}. "
                f"Is Node.js installed and on PATH?"
            )

        threading.Thread(target=self._read_loop, daemon=True).start()
        threading.Thread(target=self._stderr_loop, daemon=True).start()

    def _read_loop(self):
        try:
            for line in self.proc.stdout:
                if self._closed:
                    return
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    # خطوط غیر JSON را نادیده بگیر (some servers print banners)
                    continue
                self._route(msg)
        except Exception:                      # noqa: BLE001
            pass

    def _route(self, msg):
        has_method = "method" in msg

        if not has_method:
            # پاسخ یک request ما
            rid = msg.get("id")
            with self._lock:
                entry = self._pending.pop(rid, None)
            if entry is not None:
                if "error" in msg:
                    entry["error"] = msg["error"]
                else:
                    entry["result"] = msg.get("result")
                entry["event"].set()
            return

        if "id" in msg:
            # request از سمت سرور (مثل roots/list) — ما قابلیتی اعلام
            # نکرده‌ایم؛ طبق پروتکل با method-not-found پاسخ می‌دهیم.
            self._send({
                "jsonrpc": "2.0",
                "id": msg["id"],
                "error": {"code": -32601, "message": "Method not found"},
            })
        else:
            # notification (مثل notifications/tools/list_changed)
            self.notifications.append(msg)

    def _stderr_loop(self):
        try:
            for line in self.proc.stderr:
                self._stderr_tail.append(line.rstrip())
        except Exception:                      # noqa: BLE001
            pass

    # -----------------------------------------------------------------

    def _send(self, msg):
        if self.proc is None or self.proc.stdin is None:
            raise MCPError("MCP transport not started")
        try:
            self.proc.stdin.write(json.dumps(msg) + "\n")
            self.proc.stdin.flush()
        except (BrokenPipeError, OSError) as e:
            raise MCPError(
                f"MCP server pipe broken: {e}\nstderr tail:\n"
                + "\n".join(list(self._stderr_tail)[-15:])
            )

    def notify(self, method, params=None):
        msg = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            msg["params"] = params
        self._send(msg)

    def request(self, method, params=None, timeout=120):
        with self._lock:
            self._id += 1
            rid = self._id
            entry = {"event": threading.Event()}
            self._pending[rid] = entry

        try:
            self._send({
                "jsonrpc": "2.0",
                "id": rid,
                "method": method,
                "params": params if params is not None else {},
            })
        except MCPError:
            with self._lock:
                self._pending.pop(rid, None)
            raise

        if not entry["event"].wait(timeout):
            with self._lock:
                self._pending.pop(rid, None)
            raise MCPError(
                f"MCP request '{method}' timed out after {timeout}s. "
                f"stderr tail:\n" + "\n".join(list(self._stderr_tail)[-15:])
            )

        if "error" in entry:
            err = entry["error"] or {}
            raise MCPError(
                f"MCP request '{method}' failed: "
                f"{err.get('message', err)} (code {err.get('code')})"
            )
        return entry.get("result")

    # -----------------------------------------------------------------

    def close(self):
        self._closed = True
        try:
            if self.proc and self.proc.stdin:
                self.proc.stdin.close()
        except Exception:                      # noqa: BLE001
            pass
        try:
            if self.proc:
                self.proc.terminate()
                self.proc.wait(timeout=5)
        except Exception:                      # noqa: BLE001
            try:
                self.proc.kill()
            except Exception:                  # noqa: BLE001
                pass

    @property
    def stderr_tail(self):
        return list(self._stderr_tail)


# =====================================================================
# مرورگر Playwright MCP — لایه‌ی سطح بالا که agent با آن کار می‌کند
# =====================================================================

class PageAgentController:
    """In-page Page-Agent-style controller: DOM -> indexed state -> actions."""

    KEY = "__AGENTIC_QA_PAGE_AGENT__"

    def __init__(self, browser):
        self.browser = browser
        self.script = (Path(__file__).with_name("page_agent_controller.js")).read_text(encoding="utf-8")
        # Installation is page-local. Avoid shipping/executing the full
        # controller script on every state/action call; after navigation the
        # first state probe will automatically reinstall it.
        self._installed = False

    def _eval(self, expr, timeout=30):
        return self.browser._execute_tool("browser_evaluate", {"function": expr}, timeout)

    def _ensure(self):
        if self._installed:
            return None
        result = self._eval(self.script, 30)
        self._installed = True
        return result

    def mark_page_changed(self):
        """Invalidate the page-local controller installation after navigation."""
        self._installed = False

    @staticmethod
    def _decode_mcp_json(raw, default=None):
        """Decode Playwright MCP browser_evaluate output robustly.

        MCP versions may return one or more text envelopes around the JSON
        result, and the result itself may be JSON-encoded as a string.
        Never feed trailing MCP text directly to json.loads().
        """
        raw = (raw or "").strip()
        if not raw:
            return default

        # Strip the common textual envelope. Keep everything after it because
        # the actual JSON may be followed by another MCP diagnostic block.
        if raw.startswith("### Result"):
            raw = raw[len("### Result"):].lstrip("\r\n \t")

        def parse_prefix(value):
            decoder = json.JSONDecoder()
            value = value.lstrip("\r\n \t")
            try:
                obj, _end = decoder.raw_decode(value)
                return obj
            except json.JSONDecodeError:
                # Locate the first plausible JSON token and decode only the
                # complete value. raw_decode deliberately ignores trailing
                # MCP text, unlike json.loads().
                starts = [i for i in (value.find("{"), value.find("["), value.find('"')) if i >= 0]
                if not starts:
                    raise
                last_error = None
                for start_idx in sorted(starts):
                    try:
                        obj, _end = decoder.raw_decode(value[start_idx:])
                        return obj
                    except json.JSONDecodeError as exc:
                        last_error = exc
                raise last_error or json.JSONDecodeError("Invalid JSON", value, 0)

        try:
            value = parse_prefix(raw)
        except Exception:
            return default

        # MCP may return a JSON string whose contents are another JSON object.
        # Decode that layer too, again allowing trailing envelope text.
        for _ in range(3):
            if not isinstance(value, str):
                break
            candidate = value.strip()
            if not candidate:
                break
            try:
                value = parse_prefix(candidate)
            except Exception:
                break
        return value

    def state(self):
        # Fast path: one browser_evaluate call after the controller is
        # installed. If a navigation replaced window, reinstall lazily.
        self._ensure()
        try:
            res = self._eval(f"() => window.{self.KEY}.getState()", 30)
            value = self._decode_mcp_json(res.text, default=None)
            if isinstance(value, dict):
                return value
            raise MCPError(f"Invalid Page-Agent state returned by browser_evaluate: {res.text[:500]}")
        except Exception:
            # The page may have navigated/reloaded and lost the page-local
            # controller between actions. Reinstall once and retry.
            self._installed = False
            self._ensure()
            res = self._eval(f"() => window.{self.KEY}.getState()", 30)
            value = self._decode_mcp_json(res.text, default=None)
            if isinstance(value, dict):
                return value
            raise MCPError(f"Invalid Page-Agent state returned by browser_evaluate: {res.text[:500]}")

    def find(self, query):
        self._ensure()
        res = self._eval(f"() => JSON.stringify(window.{self.KEY}.find({json.dumps(str(query), ensure_ascii=False)}))", 30)
        value = self._decode_mcp_json(res.text, default=[])
        return value if isinstance(value, list) else []

    def click(self, index):
        self._ensure()
        res = self._eval(f"() => window.{self.KEY}.click({int(index)})", 30)
        return res

    def input_text(self, index, value):
        self._ensure()
        options = {
            "realistic": bool(getattr(config, "PAGE_AGENT_REALISTIC_TYPING", False)),
            "minDelayMs": int(getattr(config, "PAGE_AGENT_TYPE_MIN_MS", 55)),
            "maxDelayMs": int(getattr(config, "PAGE_AGENT_TYPE_MAX_MS", 125)),
            "pauseChance": float(getattr(config, "PAGE_AGENT_TYPE_PAUSE_CHANCE", 0.015)),
            "pauseMinMs": int(getattr(config, "PAGE_AGENT_TYPE_PAUSE_MIN_MS", 140)),
            "pauseMaxMs": int(getattr(config, "PAGE_AGENT_TYPE_PAUSE_MAX_MS", 320)),
            "preDelayMs": int(getattr(config, "PAGE_AGENT_TYPE_PRE_DELAY_MS", 40)),
        }
        js = f"() => window.{self.KEY}.input({int(index)}, {json.dumps(str(value), ensure_ascii=False)}, {json.dumps(options)})"
        return self._eval(js, 90 if options["realistic"] else 30)

    def input_batch(self, items):
        self._ensure()
        payload = []
        for item in items or []:
            payload.append({
                "index": int(item.get("index")),
                "text": str(item.get("text", "")),
            })
        options = {
            "realistic": bool(getattr(config, "PAGE_AGENT_REALISTIC_TYPING", False)),
            "minDelayMs": int(getattr(config, "PAGE_AGENT_TYPE_MIN_MS", 55)),
            "maxDelayMs": int(getattr(config, "PAGE_AGENT_TYPE_MAX_MS", 125)),
            "pauseChance": float(getattr(config, "PAGE_AGENT_TYPE_PAUSE_CHANCE", 0.015)),
            "pauseMinMs": int(getattr(config, "PAGE_AGENT_TYPE_PAUSE_MIN_MS", 140)),
            "pauseMaxMs": int(getattr(config, "PAGE_AGENT_TYPE_PAUSE_MAX_MS", 320)),
            "preDelayMs": int(getattr(config, "PAGE_AGENT_TYPE_PRE_DELAY_MS", 40)),
        }
        js = f"() => window.{self.KEY}.inputBatch({json.dumps(payload, ensure_ascii=False)}, {json.dumps(options)})"
        return self._eval(js, 90 if options["realistic"] else 30)

    def find_input_group(self, value):
        self._ensure()
        js = f"() => JSON.stringify(window.{self.KEY}.findInputGroup({json.dumps(str(value), ensure_ascii=False)}))"
        return self._eval(js, 30)

    def find_input_group_by_length(self, length):
        self._ensure()
        js = f"() => JSON.stringify(window.{self.KEY}.findInputGroupByLength({int(length)}))"
        return self._eval(js, 30)

    def select_option(self, index, text):
        self._ensure()
        js = f"() => window.{self.KEY}.select({int(index)}, {json.dumps(str(text), ensure_ascii=False)})"
        return self._eval(js, 30)

    def scroll_evidence(self, index=None):
        self._ensure()
        if index is None:
            js = f"() => JSON.stringify(window.{self.KEY}.scrollEvidence())"
        else:
            js = f"() => JSON.stringify(window.{self.KEY}.scrollEvidence({int(index)}))"
        res = self._eval(js, 30)
        value = PageAgentController._decode_mcp_json(res.text, default=None)
        if not isinstance(value, dict):
            raise MCPError(f"Invalid scroll evidence: {res.text[:500]}")
        return value

    def scroll(self, down=True, pixels=None, index=None):
        self._ensure()
        payload = {"down": bool(down)}
        if pixels is not None: payload["pixels"] = int(pixels)
        if index is not None: payload["index"] = int(index)
        js = f"() => window.{self.KEY}.scroll({json.dumps(payload)})"
        return self._eval(js, 30)

    def wait(self, seconds=1):
        self._ensure()
        js = f"() => window.{self.KEY}.wait({max(0.0, min(float(seconds), 10.0))})"
        return self._eval(js, 15)


class PlaywrightMCPBrowser:

    PROTOCOL_VERSIONS = ["2025-06-18", "2024-11-05"]

    def __init__(self):
        self.transport = None
        self.tools = {}                 # name -> tool schema
        self.server_info = {}
        self.protocol_version = None
        self.page_agent = PageAgentController(self)

    # -----------------------------------------------------------------
    # کشف نحوه اجرای سرور MCP — اولویت:
    #   1) override دستی AGENTIC_QA_MCP_CMD
    #   2) باینری global (playwright-mcp / mcp-server-playwright)
    #      بعد از npm i -g @playwright/mcp
    #   3) npx -y @playwright/mcp@latest (بار اول دانلود می‌کند)
    # -----------------------------------------------------------------

    def _resolve_command(self):
        if config.MCP_CMD_OVERRIDE:
            return shlex.split(config.MCP_CMD_OVERRIDE) + config.MCP_ARGS

        # باینری global — چند نام پشتیبانی می‌شود چون بین نسخه‌های
        # پکیج تغییر کرده است (playwright-mcp و mcp-server-playwright)
        for bin_name in getattr(config, "MCP_GLOBAL_BINS", []):
            found = shutil.which(bin_name)
            if found:
                return [found] + config.MCP_ARGS

        # npx — روی ویندوز npx.cmd باید با which پیدا شود
        npx = shutil.which("npx")
        if npx:
            print(
                "[mcp] hint: باینری global نصب نیست → با npx اجرا می‌شود.\n"
                "      بار اول پکیج دانلود می‌شود و شاید چند دقیقه طول بکشد.\n"
                "      نصب دائمی و سریع‌تر:  npm install -g @playwright/mcp"
            )
            return [npx, "-y", config.MCP_NPX_PACKAGE] + config.MCP_ARGS

        # آخرین تلاش: شاید PATH در shell فرزند حل شود
        return ["npx", "-y", config.MCP_NPX_PACKAGE] + config.MCP_ARGS

    # -----------------------------------------------------------------

    def start(self):
        cmd = self._resolve_command()
        print(f"[mcp] starting server: {' '.join(cmd)}")
        self.transport = MCPStdioTransport(cmd, cwd=config.PROJECT_ROOT)
        self.transport.start()

        try:
            self._initialize()
        except MCPError:
            self._print_startup_help()
            self.transport.close()
            raise
        self.refresh_tools()
        return self

    # -----------------------------------------------------------------

    @staticmethod
    def _tick(stop_event, max_seconds):
        """هر ۱۵ ثانیه می‌گوید هنوز منتظر سرور هستیم (تا کاربر فکر نکند هنگ است)."""
        start = time.time()
        while not stop_event.wait(15.0):
            elapsed = int(time.time() - start)
            print(
                f"[mcp] … در انتظار بالا آمدن سرور "
                f"({elapsed}s از حداکثر {max_seconds}s)"
            )

    def _print_startup_help(self):
        print("─" * 60)
        print("❌ سرور MCP در زمان مقرر بالا نیامد — راه‌حل‌ها به ترتیب:")
        print()
        print("  ۱) نصب global (پیشنهادی — دیگر npx و دانلود تکراری لازم نیست):")
        print("       npm install -g @playwright/mcp")
        print("     بعد از نصب، agentic-qa خودش باینری را پیدا می‌کند.")
        print()
        print("  ۲) اگر npm به اینترنت وصل نمی‌شود (فیلتر/کندی رجیستری) — میرور:")
        print("       npm config set registry https://registry.npmmirror.com")
        print()
        print("  ۳) اگر پروکسی محلی دارید (مثلاً پورت 7890):")
        print("       npm config set proxy http://127.0.0.1:7890")
        print("       npm config set https-proxy http://127.0.0.1:7890")
        print()
        print("  ۴) تست دستی اینکه سرور اصلاً بالا می‌آید:")
        print("       npx -y @playwright/mcp@latest --help")
        print()
        print("  ۵) اگر بار اول دانلود طولانی است، تایم‌اوت را در .env زیاد کنید:")
        print("       AGENTIC_QA_MCP_STARTUP_TIMEOUT=600")
        print("─" * 60)

    def _initialize(self):
        last_err = None
        for version in self.PROTOCOL_VERSIONS:
            stop = threading.Event()
            watcher = threading.Thread(
                target=self._tick,
                args=(stop, config.MCP_STARTUP_TIMEOUT),
                daemon=True,
            )
            watcher.start()
            try:
                result = self.transport.request("initialize", {
                    "protocolVersion": version,
                    "capabilities": {},
                    "clientInfo": {
                        "name": "agentic-qa",
                        "version": "1.0.0",
                    },
                }, timeout=config.MCP_STARTUP_TIMEOUT)
                self.protocol_version = result.get(
                    "protocolVersion", version
                )
                self.server_info = result.get("serverInfo", {})
                self.transport.notify("notifications/initialized")
                print(
                    f"[mcp] connected: "
                    f"{self.server_info.get('name', '?')} "
                    f"v{self.server_info.get('version', '?')} "
                    f"(protocol {self.protocol_version})"
                )
                return
            except MCPError as e:
                last_err = e
                # شاید سرور با این نسخه پروتکل کار نکرد — نسخه بعدی
            finally:
                stop.set()
                watcher.join(timeout=1)
        raise MCPError(f"MCP initialize failed: {last_err}")

    # -----------------------------------------------------------------

    def refresh_tools(self):
        self.tools = {}
        cursor = None
        while True:
            params = {} if cursor is None else {"cursor": cursor}
            result = self.transport.request(
                "tools/list", params, timeout=60
            )
            for tool in (result or {}).get("tools", []):
                name = tool.get("name")
                if name:
                    self.tools[name] = tool
            cursor = (result or {}).get("nextCursor")
            if not cursor:
                break
        print(f"[mcp] {len(self.tools)} tools available")

    # -----------------------------------------------------------------
    # اجرای یک ابزار — نتیجه نرمال می‌شود
    # -----------------------------------------------------------------

    def _normalize_arguments(self, name, arguments):
        """
        لایه سازگاری با schema سرور:
          - نگاشت خودکار ref ↔ target (نسخه‌های مختلف MCP یکی را
            می‌خواهند؛ هر دو یعنی «ref از آخرین snapshot»)
          - حذف آرگومان‌های ناشناخته وقتی schema سخت‌گیر است
          - نرمال‌سازی فیلدهای browser_fill_form به‌صورت تودرتو
        """
        tool = self.tools.get(name) or {}
        schema = tool.get("inputSchema") or {}
        props = schema.get("properties") or {}
        args = dict(arguments or {})

        def _map_ref(d):
            if "target" in props and "ref" in d and "target" not in d:
                d["target"] = d.pop("ref")
            elif "ref" in props and "target" in d and "ref" not in d:
                d["ref"] = d.pop("target")
            return d

        args = _map_ref(args)

        # فیلدهای تودرتوی fill_form
        if isinstance(args.get("fields"), list) and \
                isinstance(props.get("fields"), dict):
            field_props = (props["fields"].get("items") or {}).get(
                "properties") or {}
            for field in args["fields"]:
                if isinstance(field, dict):
                    if "target" in field_props and "ref" in field:
                        field["target"] = field.pop("ref")
                    elif "ref" in field_props and "target" in field:
                        field["ref"] = field.pop("target")

        if schema.get("additionalProperties") is False and props:
            for k in [k for k in args if k not in props]:
                args.pop(k)

        return args

    def call_tool(self, name, arguments=None, timeout=None):
        if name not in self.tools:
            # شاید لیست ابزار عوض شده باشد
            self.refresh_tools()
            if name not in self.tools:
                raise MCPError(f"Unknown MCP tool: {name}")

        arguments = self._normalize_arguments(name, arguments)

        # --- تایپ انسانی (fan-out در لایه‌ی MCP، بدون اکشن اضافه) ---
        # سورس @playwright/mcp را کاویده‌ایم: slowly=true → pressSequentially
        # با delay=0 — یعنی حتی با slowly، همه‌ی کاراکترها عملاً یک‌جایی
        # ظاهر می‌شوند (حس کپی/پیست). برای همین تایپ واقعی اینجا پیاده شده:
        # یک browser_type/fill_form منطقی → دنباله‌ای از رویدادهای واقعی
        # کیبورد + تأخیر تصادفی انسانی. از دید agent و بودجه، همین یکی
        # «اکشن» است. fallback خودکار: fill یک‌جایی.
        if (config.REALISTIC_TYPING
                and (not getattr(config, "FAST_MODE", False) or getattr(config, "FAST_KEEP_REALISTIC_TYPING", False))
                and "browser_press_key" in self.tools):
            try:
                if name == "browser_type":
                    out = self._human_type(arguments, timeout)
                    if out is not None:
                        return out
                elif name == "browser_fill_form":
                    out = self._human_fill_form(arguments, timeout)
                    if out is not None:
                        return out
            except (ToolExecutionError, MCPError) as e:
                print(f"[mcp] human-typing fallback → single fill: {e}")
                args = {k: v for k, v in (arguments or {}).items()
                        if k != "slowly"}
                return self._execute_tool(name, args, timeout)

        return self._execute_tool(name, arguments, timeout)

    # -----------------------------------------------------------------
    # تایپ انسانی — کمک‌کننده‌ها
    # -----------------------------------------------------------------

    def _press_char(self, ch, element, target, timeout):
        """
        یک کاراکتر با رویداد واقعی تایپ:
        - ASCII (کلیدهای شناخته‌شده‌ی کیبورد) → browser_press_key
          → keydown/keypress/input/keyup کامل
        - غیر ASCII (فارسی/عربی/…) → press_key خطای «Unknown key» می‌دهد؛
          پس browser_type(slowly) تک‌کاراکتری → pressSequentially که
          unicode را درست append می‌کند
        """
        if ch.isascii() and ch.isprintable() and ch not in "\t\n\r\x0b\x0c":
            self._execute_tool(
                "browser_press_key", {"key": ch}, timeout)
        else:
            args = {"text": ch, "slowly": True}
            if element is not None:
                args["element"] = element
            if target is not None:
                args["target"] = target
            self._execute_tool("browser_type", args, timeout)

    def _human_pause(self):
        """مکث انسانی بین دو کلید: ۷۰-۲۴۰ms + گاهی مکثِ «فکر کردن»."""
        delay_ms = random.uniform(
            config.TYPE_DELAY_MIN_MS, config.TYPE_DELAY_MAX_MS)
        if random.random() < config.TYPE_PAUSE_CHANCE:
            delay_ms += random.uniform(
                config.TYPE_PAUSE_MIN_MS, config.TYPE_PAUSE_MAX_MS)
        time.sleep(max(0.0, delay_ms) / 1000.0)

    def _pre_delay(self):
        """زمان واکنش انسانی قبل از شروع تایپ (نگاه به فیلد + شروع)."""
        time.sleep(random.uniform(
            config.TYPE_PRE_DELAY_MIN_MS,
            config.TYPE_PRE_DELAY_MAX_MS,
        ) / 1000.0)

    def _current_field_value(self, target, element):
        """
        مقدار فعلی یک فیلد از snapshot تازه — برای تصمیم پاک‌سازی
        (تایپِ ما append است؛ اگر فیلد پر باشد باید اول پاک شود).
        خروجی None یعنی «نمی‌دانیم».
        """
        if SnapshotIndex is None or "browser_snapshot" not in self.tools:
            return None
        try:
            snap = self._execute_tool("browser_snapshot", {}, 30)
            if not snap.is_snapshot:
                return None
            index = SnapshotIndex(snap.text)
            el = None
            if target:
                el = index.by_ref(str(target))
            if el is None and element:
                # تطبیق معنایی: نام فیلد با توصیف انسانی agent
                cand = [
                    e for e in index.elements
                    if e.role in ("textbox", "searchbox", "spinbutton")
                    and e.name and (
                        e.name in str(element)
                        or str(element) in e.name
                    )
                ]
                if cand:
                    el = cand[0]
            if el is None:
                return None
            val = el.attrs.get("value")
            return val if isinstance(val, str) else None
        except (ToolExecutionError, MCPError):
            return None

    def _clear_field(self, element, target, timeout):
        """
        پاک‌سازی فیلد قبل از تایپ انسانی با سمنتیک خودِ fill:
        browser_type بدون slowly → fill("") → پاک می‌کند + فوکوس.
        """
        try:
            cargs = {"text": ""}
            if element is not None:
                cargs["element"] = element
            if target is not None:
                cargs["target"] = target
            return self._execute_tool("browser_type", cargs, timeout)
        except (ToolExecutionError, MCPError):
            return None

    def _final_snapshot(self, last_result):
        """
        بعد از fan-out یک snapshot تازه برمی‌گرداند تا agent وضعیت
        «نهایی» را ببیند (snapshot وسط راه فقط حرف اول را دارد).
        """
        if "browser_snapshot" in self.tools:
            try:
                snap = self._execute_tool("browser_snapshot", {}, 30)
                if snap.is_snapshot:
                    return snap
            except (ToolExecutionError, MCPError):
                pass
        return last_result or ToolResult(text="(typed)")

    def _human_type(self, arguments, timeout):
        """
        تایپ متن یک فیلد، کاراکتر-به-کاراکتر مثل کاربر واقعی:
          ۱) کاراکتر اول با browser_type(slowly) → فوکوس مطمئن روی
             همین عنصر + رویدادهای کیبورد (کاراکتر نمی‌رود عنصر اشتباه)
          ۲) بقیه‌ی کاراکترها یکی‌یکی با browser_press_key روی عنصرِ
             فوکوس‌شده + تأخیر تصادفی انسانی
          ۳) submit=true → Enter در پایان
        خروجی: ToolResult یا None (وقتی fan-out نمی‌شود؛ مثل متن خیلی
        بلند که paste برایش طبیعی است).
        """
        args = arguments or {}
        # مقدار عددی JSON (مثلاً 927407043) هم مثل رشته تایپ می‌شود
        text = args.get("text", "")
        if isinstance(text, (int, float)) and not isinstance(text, bool):
            text = str(text)
        text = str(text)

        if len(text) > config.TYPE_MAX_CHARS:
            return None

        # متن خالی = پاک‌کردن فیلد — سمنتیک fill("")، بدون fan-out
        # (قبلاً اینجا IndexError می‌افتاد!)
        if text == "":
            clean = {k: v for k, v in args.items() if k != "slowly"}
            return self._execute_tool("browser_type", clean, timeout)

        # یک کاراکتر: press_key واقعی + مکث واکنش انسانی قبلش
        if len(text) == 1:
            self._pre_delay()
            single = {**args, "slowly": True}
            return self._execute_tool("browser_type", single, timeout)

        element = args.get("element")
        target = args.get("target") or args.get("ref")
        submit = bool(args.get("submit"))

        # فیلد از قبل مقدار «دیگری» دارد؟ → اول پاک کن (مثل انسان که
        # همه را انتخاب و Delete می‌زند) چون تایپ ما append است
        existing = self._current_field_value(target, element)
        if existing is not None and existing == text:
            # فیلد از قبل دقیقاً همین مقدار را دارد → تایپ مجدد = تکرار؛
            # مثل کاربری که می‌بیند فیلد درست پر شده و دست نمی‌زند
            return self._final_snapshot(None)
        cleared = False
        if existing and existing != text:
            self._clear_field(element, target, timeout)
            cleared = True

        self._pre_delay()
        t0 = time.time()
        if cleared:
            # فوکوس مطمئن است (fill فوکوس می‌گذارد) → همه با press_key
            self._press_char(text[0], element, target, timeout)
            last = None
        else:
            first = {"text": text[0], "slowly": True}
            if element is not None:
                first["element"] = element
            if target is not None:
                first["target"] = target
            last = self._execute_tool("browser_type", first, timeout)
        for ch in text[1:]:
            self._human_pause()
            self._press_char(ch, element, target, timeout)
        if submit:
            self._human_pause()
            last = self._execute_tool(
                "browser_press_key", {"key": "Enter"}, timeout)

        print(f"[mcp] human-typing: {len(text)} keys in "
              f"{time.time() - t0:.1f}s")
        # Do not spend an MCP round-trip on a snapshot after typing.
        # The agent receives an explicit success hint and keeps the grounded
        # ref unless a real state transition/error requires observation.
        return last or ToolResult(text="(typed)")

    def _human_fill_form(self, arguments, timeout):
        """
        fill_form «همه-متنی» به‌صورت انسانی: هر فیلد با رویدادهای
        کیبورد واقعی تایپ می‌شود + فاصله‌ی انسانی بین فیلدها.
        برای کپچا/OTP چندخانه‌ای: یک اکشن منطقی، تایپ خانه‌به‌خانه
        مثل کاربر — به‌جای ۴-۵ اکشن جداگانه‌ی agent.
        - مقدار عددی JSON (مثل شماره موبایل 927407043) به رشته تبدیل
          و انسانی تایپ می‌شود — قبلاً همین مسیر paste یک‌جایی می‌شد!
        - فیلدی که مقدار «دیگری» دارد اول پاک می‌شود (سمنتیک fill)
        فیلد غیرمتنی یا بدون target → None → همان fill_form عادی.
        """
        args = arguments or {}
        fields = args.get("fields")
        if not isinstance(fields, list) or not fields:
            return None

        for f in fields:
            if not isinstance(f, dict):
                return None
            ftype = str(f.get("type", "textbox")).lower()
            if ftype not in ("textbox", "text", "textarea"):
                return None       # checkbox/radio/combobox/slider → عادی
            if not (f.get("target") or f.get("ref")):
                return None          # بدون ref نمی‌توان فوکوس را مطمئن کرد
            v = f.get("value")
            if v is None or isinstance(v, bool):
                return None
            if not isinstance(v, (str, int, float)):
                return None
            if len(str(v)) > config.TYPE_MAX_CHARS:
                return None

        last = None
        # Read existing values once for the whole batch, not once per field.
        # Multi-cell inputs must never cause N snapshot round-trips.
        existing_values = {}
        if "browser_snapshot" in self.tools and len(fields) > 1:
            try:
                snap = self._execute_tool("browser_snapshot", {}, 30)
                if snap.is_snapshot:
                    idx = SnapshotIndex(snap.text)
                    for f in fields:
                        ref = f.get("target") or f.get("ref")
                        el = idx.by_ref(str(ref)) if ref else None
                        if el is not None and isinstance(el.attrs.get("value"), str):
                            existing_values[str(ref)] = el.attrs.get("value")
            except (ToolExecutionError, MCPError):
                existing_values = {}

        for i, f in enumerate(fields):
            value = str(f["value"])
            element = f.get("element") or f.get("name")
            target = f.get("target") or f.get("ref")
            if i:
                time.sleep(random.uniform(
                    config.TYPE_FIELD_GAP_MIN_MS,
                    config.TYPE_FIELD_GAP_MAX_MS,
                ) / 1000.0)

            if value == "":
                # مقدار خالی = پاک کردن فیلد (سمنتیک fill(""))
                self._execute_tool(
                    "browser_type",
                    {"text": "", "element": element, "target": target},
                    timeout,
                )
                continue

            # پاک‌سازی اگر فیلد مقدار «دیگری» دارد (تایپ ما append است)
            existing = existing_values.get(str(target)) if existing_values else self._current_field_value(target, element)
            if existing is not None and existing == value:
                continue               # از قبل درست پر شده — دست نزن
            cleared = False
            if existing and existing != value:
                self._clear_field(element, target, timeout)
                cleared = True

            self._pre_delay()
            if cleared:
                self._press_char(value[0], element, target, timeout)
            else:
                first = {"text": value[0], "slowly": True,
                         "element": element, "target": target}
                last = self._execute_tool("browser_type", first, timeout)
            for ch in value[1:]:
                self._human_pause()
                self._press_char(ch, element, target, timeout)

        print(f"[mcp] human-typing form: {len(fields)} fields")
        return last or ToolResult(text="(typed form)")

    # -----------------------------------------------------------------

    def _execute_tool(self, name, arguments, timeout=None):
        """اجرای خام tools/call + نرمال‌سازی نتیجه (بدون interception)."""
        arguments = self._normalize_arguments(name, arguments)
        result = self.transport.request(
            "tools/call",
            {"name": name, "arguments": arguments or {}},
            timeout=timeout or config.MCP_TOOL_TIMEOUT,
        )

        content = (result or {}).get("content") or []
        texts, images = [], []
        for item in content:
            item_type = item.get("type")
            if item_type == "text":
                texts.append(item.get("text", ""))
            elif item_type == "image":
                data = item.get("data")
                if data:
                    images.append(data)
            elif item_type == "resource":
                res = item.get("resource", {})
                texts.append(str(res.get("text", "")))

        structured = (result or {}).get("structuredContent")
        text = "\n".join([t for t in texts if t])

        if (result or {}).get("isError"):
            raise ToolExecutionError(
                text or f"Tool '{name}' returned an error", raw_text=text
            )

        return ToolResult(text=text, images=images, structured=structured)

    # -----------------------------------------------------------------
    # shortcut های پرکاربرد — بدون هارد کد selector؛ فقط نام ابزار
    # -----------------------------------------------------------------

    def discover_capabilities(self):
        """Discover optional capabilities from runtime MCP tool metadata."""
        capabilities = {}
        for name, tool in self.tools.items():
            haystack = (str(name) + " " + str(tool.get("description", ""))).lower()
            if "clipboard" in haystack:
                capabilities.setdefault("clipboard", []).append(name)
        return capabilities

    def navigate(self, url, timeout=None):
        return self.call_tool(
            "browser_navigate", {"url": url}, timeout=timeout
        )

    def snapshot(self, timeout=None):
        return self.call_tool("browser_snapshot", {}, timeout=timeout)

    def current_url(self):
        """آخرین URL معلوم از snapshot؛ اگر نبود، از page state tool."""
        for tool_name in ("browser_evaluate",):
            if tool_name in self.tools:
                try:
                    res = self.call_tool(
                        tool_name,
                        {"function": "() => location.href"},
                        timeout=15,
                    )
                    return res.text.strip().splitlines()[-1].strip()
                except Exception:                  # noqa: BLE001
                    continue
        return None

    def take_screenshot_file(self, filename, timeout=None):
        """
        اسکرین‌شات می‌گیرد و آن را در evidence ذخیره می‌کند.
        سرور با cwd=PROJECT_ROOT اجرا شده، پس filename نسبی امن است.
        خروجی: مسیر فایل ذخیره‌شده (یا None)
        """
        try:
            res = self.call_tool(
                "browser_take_screenshot",
                {"filename": filename, "type": "png"},
                timeout=timeout,
            )
            return filename
        except (ToolExecutionError, MCPError):
            # حالت دوم: بدون filename → تصویر base64 برمی‌گردد
            res = self.call_tool(
                "browser_take_screenshot", {"type": "png"}, timeout=timeout
            )
            if res.images:
                return res.images[0]          # base64 — فراخواننده ذخیره می‌کند
            return None

    # -----------------------------------------------------------------

    def close(self):
        # بستن مرورگر در صورت وجود ابزارش — best effort
        try:
            if "browser_close" in self.tools:
                self.call_tool("browser_close", {}, timeout=20)
        except Exception:                          # noqa: BLE001
            pass
        if self.transport:
            self.transport.close()
