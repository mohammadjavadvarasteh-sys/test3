# =====================================================================
# engine/reporter.py
# ---------------------------------------------------------------------
# گزارش‌ساز نهایی: خلاصه‌ی رنگی ترمینال + گزارش HTML راست‌به‌چپ
# (قابل اشتراک با تیم) — داده‌ها را از EvidenceStore می‌خواند.
# =====================================================================

import html
import json
import os

import config

VERDICT_COLORS = {
    "PASS": "\033[92m",       # سبز
    "FAIL": "\033[91m",       # قرمز
    "BLOCKED": "\033[93m",    # زرد
    "INCONCLUSIVE": "\033[95m",  # بنفش
}
RESET = "\033[0m"
BOLD = "\033[1m"


# =====================================================================
# ترمینال
# =====================================================================

def print_terminal_report(store, results, feature):
    print()
    print(BOLD + "=" * 64 + RESET)
    print(BOLD + f"  FINAL REPORT — {feature}" + RESET)
    print(BOLD + "=" * 64 + RESET)

    for r in results:
        v = r.get("verdict", "?")
        color = VERDICT_COLORS.get(v, "")
        reason = (r.get("reason") or r.get("failure_reason") or "")
        print(f"  {color}{v:13s}{RESET} {r.get('id', '?'):14s} "
              f"{(reason[:70])}")

    counts = {}
    for r in results:
        counts[r.get("verdict", "?")] = counts.get(
            r.get("verdict", "?"), 0) + 1

    print()
    print(f"  totals: {json.dumps(counts, ensure_ascii=False)}")
    print(f"  run dir: {store.run_dir}")
    print(BOLD + "=" * 64 + RESET)


# =====================================================================
# HTML — راست‌به‌چپ، فارسی، بدون وابستگی خارجی
# =====================================================================

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<title>{title}</title>
<style>
  * {{ box-sizing: border-box; }}
  body {{ font-family: 'Segoe UI', Tahoma, sans-serif; direction: rtl;
          background: #f6f7f9; color: #1f2430; margin: 0; padding: 24px; }}
  .wrap {{ max-width: 980px; margin: 0 auto; }}
  h1 {{ font-size: 22px; margin: 0 0 4px; }}
  .meta {{ color: #667; font-size: 13px; margin-bottom: 20px; }}
  .meta code {{ direction: ltr; unicode-bidi: embed; }}
  .cards {{ display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 22px; }}
  .card {{ flex: 1 1 140px; background: #fff; border-radius: 12px;
           padding: 14px 18px; box-shadow: 0 1px 3px rgba(20,30,60,.08);
           border-inline-start: 4px solid #ccc; }}
  .card b {{ display: block; font-size: 26px; }}
  .card span {{ color: #667; font-size: 12px; }}
  .pass {{ border-color: #16a34a; }} .pass b {{ color: #16a34a; }}
  .fail {{ border-color: #dc2626; }} .fail b {{ color: #dc2626; }}
  .blocked {{ border-color: #d97706; }} .blocked b {{ color: #d97706; }}
  .inconcl {{ border-color: #7c3aed; }} .inconcl b {{ color: #7c3aed; }}
  table {{ width: 100%; border-collapse: collapse; background: #fff;
           border-radius: 12px; overflow: hidden;
           box-shadow: 0 1px 3px rgba(20,30,60,.08); }}
  th {{ background: #1f2430; color: #fff; padding: 10px 14px;
        text-align: right; font-size: 13px; }}
  td {{ padding: 10px 14px; border-top: 1px solid #eceff3;
        font-size: 13px; vertical-align: top; }}
  .v {{ font-weight: 700; padding: 2px 10px; border-radius: 999px;
        font-size: 12px; display: inline-block; }}
  .v-PASS {{ background: #dcfce7; color: #15803d; }}
  .v-FAIL {{ background: #fee2e2; color: #b91c1c; }}
  .v-BLOCKED {{ background: #fef3c7; color: #b45309; }}
  .v-INCONCLUSIVE {{ background: #ede9fe; color: #6d28d9; }}
  .reason {{ color: #b42318; }}
  section {{ margin-top: 28px; }}
  h2 {{ font-size: 17px; }}
  .shot {{ background:#fff; border-radius:12px; padding:10px;
           box-shadow: 0 1px 3px rgba(20,30,60,.08); margin:10px 0; }}
  .shot img {{ max-width: 100%; border: 1px solid #e5e7eb;
               border-radius: 8px; }}
  .shot .cap {{ font-size: 12px; color: #556; margin-top: 6px; }}
  .finding {{ background:#fff; border-radius:10px; padding:12px 16px;
              border-inline-start: 4px solid #0ea5e9; margin: 10px 0;
              box-shadow: 0 1px 3px rgba(20,30,60,.08); }}
  .finding.sev-critical {{ border-color: #dc2626; }}
  .finding.sev-major {{ border-color: #d97706; }}
  .finding.sev-minor {{ border-color: #0ea5e9; }}
  .finding.sev-info {{ border-color: #94a3b8; }}
  .sev {{ font-size: 11px; font-weight: 700; color: #667;
          unicode-bidi: embed; }}
  .obs {{ background:#fff; border-radius:10px; padding:12px 16px;
           box-shadow: 0 1px 3px rgba(20,30,60,.08); margin:10px 0; }}
  .obs pre {{ direction:ltr; text-align:left; white-space:pre-wrap;
              max-height:320px; overflow:auto; background:#f8fafc;
              padding:10px; border-radius:8px; font-size:11px; }}
  .media {{ background:#fff; border-radius:12px; padding:14px 18px;
             box-shadow:0 1px 3px rgba(20,30,60,.08); margin-top:20px; }}
  .media a {{ display:inline-block; margin:6px 8px 6px 0; padding:8px 12px;
              border-radius:8px; background:#eef2ff; color:#3730a3;
              text-decoration:none; }}
  footer {{ color: #889; font-size: 12px; margin-top: 28px; }}
</style>
</head>
<body>
<div class="wrap">
  <h1>{title}</h1>
  <div class="meta">
    run: <code>{run_id}</code> &nbsp;|&nbsp; شروع: {started} &nbsp;|&nbsp;
    وضعیت: {status} &nbsp;|&nbsp; اقدامات: {actions}
  </div>

  <div class="cards">
    <div class="card pass"><b>{n_pass}</b><span>PASS</span></div>
    <div class="card fail"><b>{n_fail}</b><span>FAIL</span></div>
    <div class="card blocked"><b>{n_blocked}</b><span>BLOCKED</span></div>
    <div class="card inconcl"><b>{n_inconcl}</b><span>INCONCLUSIVE</span></div>
  </div>

  <table>
    <tr><th style="width:110px">حکم</th><th style="width:110px">شناسه</th>
        <th>انتظار</th><th>واقعیت / دلیل</th></tr>
    {rows}
  </table>

  {findings_section}
  {observability_section}
  {media_section}
  {shots_section}

  <footer>
    agentic-qa — گزارش از evidence واقعی تولید شده؛
    فایل‌ها در <code>{run_dir}</code>
  </footer>
</div>
</body>
</html>"""


def write_html_report(store, results, feature, title=None):
    if not config.HTML_REPORT:
        return None

    run_json_path = os.path.join(store.run_dir, "run.json")
    started, status = "", ""
    try:
        with open(run_json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        started = str(data.get("started_at", ""))[:19]
        status = str(data.get("status", ""))
    except Exception:                                  # noqa: BLE001
        pass

    counts = {"PASS": 0, "FAIL": 0, "BLOCKED": 0, "INCONCLUSIVE": 0}
    rows_html = []
    for r in results:
        v = r.get("verdict", "INCONCLUSIVE")
        counts[v] = counts.get(v, 0) + 1
        expected = html.escape(str(r.get("expected")
                                   or r.get("description", ""))[:220])
        actual = html.escape(
            str(r.get("actual") or r.get("reason")
                or r.get("failure_reason") or "")[:220])
        rows_html.append(
            f'<tr><td><span class="v v-{v}">{v}</span></td>'
            f'<td><code>{html.escape(str(r.get("id", "?")))}</code></td>'
            f'<td>{expected}</td>'
            f'<td class="reason">{actual}</td></tr>'
        )

    findings_html = ""
    if store.findings:
        items = []
        for f in store.findings:
            sev = html.escape(str(f.get("severity", "info")))
            items.append(
                f'<div class="finding sev-{sev}">'
                f'<span class="sev">[{sev}]</span> '
                f'{html.escape(str(f.get("description", ""))[:300])}'
                + (f'<div class="cap">'
                   f'{html.escape(str(f.get("note", ""))[:300])}</div>'
                   if f.get("note") else "")
                + '</div>'
            )
        findings_html = (
            "<section><h2>یافته‌های اکتشافی</h2>"
            + "\n".join(items) + "</section>"
        )

    observability_html = ""
    if getattr(store, "observability", None):
        blocks = []
        for item in store.observability[-30:]:
            kind = html.escape(str(item.get("kind", "")))
            trigger = html.escape(str(item.get("trigger", "")))
            content = html.escape(str(item.get("content", ""))[:9000])
            blocks.append(
                f'<div class="obs"><b>{kind}</b> — trigger: {trigger}'
                f'<pre>{content}</pre></div>'
            )
        observability_html = (
            "<section><h2>Network / Console</h2>"
            + "\n".join(blocks) + "</section>"
        )

    media_html = ""
    media = getattr(store, "media", {}) or {}
    if media:
        links = []
        for kind, path in media.items():
            rel = os.path.relpath(path, store.run_dir).replace(os.sep, "/")
            label = html.escape(str(kind).upper())
            links.append(f'<a href="{html.escape(rel)}" download>{label} — اجرای کامل</a>')
        media_html = "<section class=\"media\"><h2>Recording</h2>" + " ".join(links) + "</section>"

    shots_html = ""
    shots = []
    try:
        ev_dir = os.path.join(store.run_dir, "evidence")
        for fn in sorted(os.listdir(ev_dir)):
            if fn.endswith(".png"):
                rel = os.path.relpath(
                    os.path.join(ev_dir, fn), store.run_dir)
                shots.append(
                    f'<div class="shot"><img src="{rel}" '
                    f'loading="lazy"><div class="cap">{fn}</div></div>'
                )
    except Exception:                                  # noqa: BLE001
        pass
    if shots:
        shots_html = ("<section><h2>اسکرین‌شات‌ها (شواهد)</h2>"
                      + "\n".join(shots[:40]) + "</section>")

    doc = HTML_TEMPLATE.format(
        title=html.escape(title or f"گزارش تست — {feature}"),
        run_id=store.run_id,
        started=started,
        status=status,
        actions=len(store.actions),
        n_pass=counts.get("PASS", 0),
        n_fail=counts.get("FAIL", 0),
        n_blocked=counts.get("BLOCKED", 0),
        n_inconcl=counts.get("INCONCLUSIVE", 0),
        rows="\n".join(rows_html) or "<tr><td colspan=4>—</td></tr>",
        findings_section=findings_html,
        observability_section=observability_html,
        media_section=media_html,
        shots_section=shots_html,
        run_dir=store.run_dir,
    )

    path = os.path.join(store.run_dir, "report.html")
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(doc)
        print(f"📄 HTML report → {path}")
        return path
    except OSError:
        return None
