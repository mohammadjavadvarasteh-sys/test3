# =====================================================================
# engine/agent.py
# ---------------------------------------------------------------------
# QAReActAgent — «ایجنت با قدرت تحلیل»:
#
#   System Prompt = قانون اساسی (L0) + قوانین کد-enforced (L1)
#                   + skills فعال (L2) + نقش + کاتالوگ ابزار MCP
#   حلقه = think (LLM, JSON) → validate (PolicyEngine, در کد)
#          → act (MCP tools/call) → observe (+ snapshot خودکار)
#          → loop-check → recovery (طبق .agents/recovery.md)
#
# ابزارهای داخلی (غیر از MCP):
#   finish         — پایان با verdict
#   ask_human      — ورودی انسانی (OTP/کد تایید) → ذخیره در context vars
#   report_finding — ثبت یافته (برای مأموریت exploratory)
#
# هیچ selector ی در هیچ لایه وجود ندارد؛ المنت‌ها فقط با
#   index از Page-Agent state زنده + توصیف معنایی آدرس‌دهی می‌شوند.
# =====================================================================

import hashlib
import json
import os
import time
from urllib.parse import urlparse

import config
from engine.artifacts import (
    checkpoint_requests_application_artifact,
    make_artifact,
    valid_url,
)
from engine.navigation import build_navigation_evidence
from engine.mission_state import MissionState
from engine.mission_inputs import MissionInputLedger

from engine.ai_client import AIClient
from engine.evidence_store import EvidenceStore, redact_text
from engine.mcp_client import (
    PlaywrightMCPBrowser,
    MCPError,
    ToolExecutionError,
)
from engine.policy_engine import PolicyEngine
from engine.skill_loader import SkillLoader
from engine.snapshot import SnapshotIndex
from engine.semantic import normalize_text, tokens

# ---------------------------------------------------------------------
# سقف اندازه‌ی مشاهدات برای فرستادن به LLM
# ---------------------------------------------------------------------

MAX_OBSERVATION_CHARS = 3500
MAX_SNAPSHOT_CHARS = 9000
MAX_PAGE_AGENT_STATE_CHARS = (
    getattr(config, "FAST_PAGE_STATE_CHARS", 9000)
    if getattr(config, "FAST_MODE", False)
    else 10000
)
HISTORY_KEEP_FULL = (
    getattr(config, "FAST_HISTORY_KEEP_FULL", 4)
    if getattr(config, "FAST_MODE", False)
    else 6
)  # keep less history in fast actor mode
COMPACT_PREFIX = "(older result compacted) "

VERDICTS = ("PASS", "FAIL", "BLOCKED", "INCONCLUSIVE")
PAGE_AGENT_TOOLS = {
    "click_element_by_index", "find_elements", "input_text", "input_text_batch",
    "select_dropdown_option", "scroll", "upload_file",
}

# Browser capabilities that are not DOM interactions: navigation, tabs, clipboard.
BROWSER_CAPABILITY_TOOLS = {"open_application_link", "read_clipboard", "open_new_tab", "switch_tab", "navigate"}

if getattr(config, "ALLOW_AGENT_JS", False) and getattr(config, "ALLOW_EVALUATE", False):
    PAGE_AGENT_TOOLS.add("execute_javascript")

# ---------------------------------------------------------------------
# پرامپت پایه — قانون اساسی ۱۵ ماده‌ای (مطابق docs/CONSTITUTION.md)
# ---------------------------------------------------------------------

CONSTITUTION_PROMPT = """# CONSTITUTION (Level 0 — inviolable, highest authority)
1. Every action must be recorded as evidence; no action without a record.
2. Every verdict must rest on captured evidence (screenshot + observation) — unevidenced claims are void.
3. Capture screenshots at decision points (after completing a requirement, on failures, on findings).
4. Observations are structured (URL, timestamp, triggering action, element states) — never vibes.
5. Act only within the current Mission scope; out-of-scope discoveries become Findings, not actions.
6. Never invent constraints or behavior you cannot observe (unknown limits → INCONCLUSIVE).
7. Secrets (passwords/OTP/tokens) never inlined in prompts/logs; values are redacted automatically.
8. Exploratory missions produce Findings; only Spec-linked requirements produce Verdicts.
9. OTP/CAPTCHA require a human or a real retrieval channel — never guess, never brute-force.
10. Never attempt authentication bypass, opportunistic privilege escalation, or brute force.
11. Prefer deterministic Spec missions over re-running exploration for regression.
12. Respect the execution budget (actions, retries, time); wind down cleanly when near limits.
13. Loop protection is enforced in code — when a loop is flagged, stop immediately, never "one more try".
14. Elements are addressed ONLY from the latest live interactive state: role + name + context + runtime ref.
    The primary state is a compact Page-Agent-style interactive DOM representation; a full snapshot is
    fallback evidence, not the default reasoning format. Hard-coded CSS/XPath selectors are FORBIDDEN in any layer, including specs.
15. Every run must be reproducible: run.json records the mission, spec hash, budgets and verdicts."""

ADDRESSING_PROMPT = """# PAGE-AGENT ARCHITECTURE
# COMBINED observation strategy: Page-Agent DOM is primary; MCP evidence is auxiliary.
The browser is controlled through an in-page PageController-style layer.
Pipeline: Live DOM → Flat interactive tree → dehydration/simplified state → LLM → indexed operation.
The LLM never receives CSS/XPath selectors and never chooses browser refs.

- Every decision must use the CURRENT PAGE-AGENT STATE and an observed element index.
- ATOMIC TARGETING: handle only ONE unfinished target per turn. Never attempt to discover all fields/options in advance. The next action is determined from the current state after the previous action.
- FORM DEPENDENCIES: a visible target is NOT automatically actionable. Before interacting with a control, inspect its live `state`: `DISABLED`, `READONLY`, `REQUIRED-EMPTY`, `INVALID`, `blocked_by`, and `countdown` are binding runtime facts. NEVER click, type into, or open a disabled/read-only target. When the requested target is disabled, choose the smallest currently actionable prerequisite that can unlock it; prefer enabled empty required fields over later optional controls. Do not jump ahead simply because a target is explicitly named later in the mission.
- FORM ORDER: when a form exposes dependencies, work left-to-right/top-to-bottom only among CURRENTLY ACTIONABLE unfinished fields, while re-observing after each state-changing action. A later control becoming enabled is the signal to revisit it.
- TIMER/COOLDOWN: if a requested control is disabled with `countdown` or page `TIMER` evidence, do not click it and do not repeatedly ask the user for the same value. Either wait close to the observed cooldown (the `wait` tool supports up to 60 seconds) or handle an explicit user instruction to resend/retry, then re-observe.
- ASYNC WORK: do not infer progress or blocking from generic UI words such as loading/pending. After a mutating action, inspect the action outcome and any correlated network response; decide from the resulting state.
- ONE-TIME CHALLENGE RECOVERY: after an entered one-time/expiring challenge is submitted and the live page shows that challenge was rejected while a resend/retry control exists, DO NOT ask the human for another value yet. Runtime recovery must first wait for the observed cooldown (if any), click the enabled resend/retry control, re-observe, clear the old challenge fields when still populated, and only then ask for the NEW value. Never reuse the rejected value.
- If the target is not visible in the compact state, use find_elements for that ONE target; do not enumerate the whole page.
- Prefer the compact interactive DOM over screenshots and accessibility snapshots.
- INDEX GROUNDING: NEVER invent, estimate, extrapolate, or "try" an index that is not present in the current state or returned by `find_elements`. If the current state is truncated, use `find_elements` with the exact/semantic target text.
- DROPDOWN GROUNDING: NEVER guess an option index from position, DOM order, or a previous state. After a dropdown opens, search the CURRENT live state with `find_elements` for the exact requested option text, then activate only the uniquely observed option. `select_dropdown_option` may also resolve a uniquely observed option from the live DOM.
- If `find_elements` returns zero matches, do NOT click a guessed index and do NOT scroll merely to compensate. Re-observe or use another evidence-backed strategy.
- Use browser_snapshot only as auxiliary QA evidence when the Page-Agent state is insufficient.
- Use screenshot only when a visual property cannot be established from DOM state.
- Use browser_find only as an auxiliary semantic search; it is not the primary addressing mechanism.
- The interactive tree includes native controls plus observed generic/pointer-interactive elements.
- After a mutation, the engine refreshes the indexed DOM once and returns the new state.
- Do not spend turns repeatedly observing an unchanged page.
- If an action fails, use the refreshed state and, when relevant, console/network diagnostics before changing strategy.
- CLICK OUTCOME / NETWORK: after a click that can trigger application work, the engine checks newly emitted network requests. If a request is found, inspect its correlated response and use that response together with the fresh page state to decide what happened.
- The selected index is valid only for the current live state; after a meaningful DOM mutation, use the new state indices.
- No site-specific text, selector, route, field count, or workflow may be hard-coded.
- NEVER invent credential/input values. If the mission says “with this phone/number” but no literal number is present in the mission or already supplied by the human, ask the human for the missing value. Never enter sample, dummy, placeholder, guessed, or remembered values.
- Preserve the exact observed UI label in your reasoning. A generic button named “تأیید”, “Confirm”, or “OK” must not be renamed to “Login” unless the current page state explicitly proves that role.
- STATE-MISMATCH RECOVERY: after an action moves to a different stage than the mission requires, do not repeat the previous action just because its index remains present. Re-observe and find the current semantic target from the live page.
- STUCK DECISION: if the executor blocks the same interaction surface twice in the same live state, stop trying variants of that control. Use the supplied prerequisite candidates and choose a DIFFERENT currently actionable control; do not spend turns repeating blocked clicks/searchboxes. If no actionable prerequisite is evidenced, finish BLOCKED rather than looping.
- TAB & CLIPBOARD: after `open_application_link` or `open_new_tab`, the runtime switches the active browser tab to the NEW tab and refreshes the Page-Agent state. The CURRENT PAGE STATE indices come from the NEW tab — use them to continue the mission. Do NOT call `read_clipboard` afterwards, do NOT click rows in the previous tab, and do NOT call `open_application_link` again. If `open_application_link` fails (e.g. clipboard empty), the runtime has already tried a DOM fallback; either look for the link URL directly in the live DOM (readonly input, textarea, anchor href) or finish BLOCKED — never loop on `read_clipboard`.
"""


ENVIRONMENT_FACTS_PROMPT = """# ENVIRONMENT FACTS (save your action budget — learned from real runs)
- Screenshots in this environment are saved to FILES; the image content is
  usually NOT returned inline, so you cannot visually read pictures. If one
  screenshot attempt does not return readable image content, do NOT retry
  with other options — for any value you must read visually (CAPTCHA),
  call ask_human directly (Constitution #9).
- The ENGINE captures the end-of-requirement screenshot automatically
  (and every finding gets its own screenshot too). So do NOT spend an
  action on browser_take_screenshot merely to prove a completed step —
  finish and let the engine collect the evidence (Constitution #3 is
  satisfied). Take your own screenshot ONLY to document an unexpected
  VISUAL anomaly (broken layout, misrendered element) that the a11y
  snapshot cannot show.
- Typing (browser_type / browser_fill_form) is executed by the engine with
  real key events and human-paced delays — you never need "slowly".
- To fill several fields at once (login forms, multi-cell one-time codes,
  segmented inputs, or any related group of textboxes), ONE browser_fill_form
  call is REQUIRED when the related refs are already observed. Never type
  one character per model turn when the complete related field group is
  visible. The engine may reject isolated single-character actions and ask
  you to batch the observed refs.
- After a successful browser_type/browser_fill_form, DO NOT request a
  browser_snapshot merely to confirm the value. The ref remains grounded
  unless navigation, validation, tool error, focus loss, or another
  meaningful state transition is observed.
- Network/console inspection is a first-class debugging capability. When an
  action fails, has no observable effect, or the UI shows a validation/error
  signal, inspect console errors and network requests before declaring BLOCKED.
- Use browser_network_requests to locate the request correlated with the just-completed action, then
  browser_network_request to inspect its status, response headers, and response body before interpreting any HTTP failure. Never guess a request URL or token source.
- HTTP status codes alone are not semantic proof. A 429 MUST NOT be classified as rate limiting unless the correlated response body/headers explicitly support throttling (for example Retry-After, X-RateLimit-* or clear rate-limit text). An unrelated 429 must remain an unclassified application error and must not trigger OTP resend recovery.
- If the mission explicitly requires reusing an observed request artifact
  (for example a token) in a new request, ground it in the observed network
  evidence. A new request may be sent with browser_evaluate only when that
  tool is explicitly enabled by the runtime safety configuration.
- Stored evidence automatically redacts secrets such as authorization/token/OTP;
  do not copy secret values into findings or reports.
- Run recording is handled by the engine; do not spend an action on screenshots
  merely to create the final GIF/video."""

RESPONSE_PROTOCOL = """# PAGE AGENT ACTION PROTOCOL
Return exactly ONE JSON object per turn. Think about the current page state,
then perform exactly one browser action. Never emit a multi-step plan.

Preferred form:
{
  "evaluation_previous_goal": "brief result of the previous action",
  "memory": "brief useful state, only if needed",
  "next_goal": "the single immediate objective",
  "action": {"click_element_by_index": {"index": 12}}
}

Available Page-Agent browser tools:
- done: {"text":"final response","success":true|false}
- ask_user: {"question":"..."}
- click_element_by_index: {"index": integer}
- find_elements: {"query": "semantic text/label/context"} — search the CURRENT live DOM for one target and return its observed indices. Use only for a single truncated target, never to enumerate the page.
- input_text: {"index": integer, "text": "exact text"}
- input_text_batch: {"items": [{"index": integer, "text": "exact text"}, ...]} — fill several observed independent inputs in ONE action.
- select_dropdown_option: {"index": integer, "text": "exact observed option"}
- upload_file: {"paths": ["absolute local file path"]}
- scroll: {"down": true|false, "num_pages": number, "pixels": integer(optional), "index": integer(optional)}
- open_application_link: {} — read the application-copied URL (clipboard, with DOM fallback) and open it in a NEW browser tab. Use this right after the app copies a shareable link (e.g. after clicking "کپی لینک"). The runtime resolves the URL even on HTTP sites where the clipboard API is blocked.
- read_clipboard: {} — read clipboard text via the trusted runtime. May return <empty or unreadable> on HTTP sites; do NOT loop on this.
- open_new_tab: {"url": "explicitly observed/trusted URL"} — open a known URL in a new tab.
- switch_tab: {"index": integer} — switch the active browser tab by index.
- navigate: {"url": "explicitly observed/trusted URL"} — navigate the current tab to a known URL.
- execute_javascript: {"script":"..."} only when explicitly enabled.
QA-only tools are allowed when needed: ask_human, report_finding, finish.

CORE LOOP:
1. Read CURRENT PAGE STATE.
2. Decide what the smallest useful next action is.
3. Execute ONE action.
4. Read the returned action result and refreshed page state.
5. Reflect on whether the previous goal succeeded.
6. Continue until the user task is complete, blocked, or impossible.

ATOMIC STEP RULE:
- ONE unfinished target at a time. Do not pre-plan a multi-step workflow.
- After every mutating action, re-observe the live state and choose the next single action from the NEW indices.
- Indices are temporary and valid only for the CURRENT PAGE STATE.

GROUNDING:
- Element indices are temporary and valid only for the CURRENT PAGE STATE.
- Never invent or guess an index.
- Never use CSS/XPath selectors in the model output.
- Never reuse an index after a meaningful DOM/state change without re-observing it.
- Do not enumerate the page when one target is enough.
- If the target is not in the current compact DOM, use find_elements only for that target.
- For dropdowns, use the exact option text observed in the live DOM.
- Never invent credentials, OTPs, CAPTCHA values, URLs, labels, or field counts.
- A disabled/read-only element is not actionable; choose an enabled prerequisite instead.
- Prefer one action per turn. Do not batch unrelated fields.
- Scroll only when there is evidence that more page content exists in the requested direction.

TAB & CLIPBOARD RULES (binding):
- After open_application_link or open_new_tab, the CURRENT active tab is the NEW tab. The CURRENT PAGE STATE reflects the new page. Use those NEW indices to continue the mission. Do NOT call read_clipboard afterwards, do NOT go back to the previous tab, do NOT click rows in the previous tab's table.
- After switch_tab, the CURRENT active tab has changed. Use the new CURRENT PAGE STATE indices.
- If open_application_link fails, do NOT retry read_clipboard in a loop. The runtime already tried the clipboard AND a DOM fallback. Either look for the link URL directly in the live DOM (readonly input, textarea, anchor href) or finish BLOCKED with a clear reason.
- Never call read_clipboard more than once per mission step; it returns the same value and wastes the action budget.

REFLECTION:
- Do not assume a click succeeded merely because the tool returned without an exception.
- Use the action result plus the refreshed DOM, URL/title changes, and relevant response evidence.
- If the result contradicts the intended goal, re-plan from the NEW state.
- Never repeat the same failed action in the same state.
- Keep memory short and factual; do not write a long plan.

AUTHENTICATION:
- OTP/CAPTCHA are never guessed or brute-forced.
- Ask the human only when the real value is required.
- Human input is not proof of successful verification; observe the resulting state.
- RESEND command is handled by runtime: a resend/retry countdown is a cooldown, never proof that the OTP inputs are disabled.

OUTPUT:
- `evaluation_previous_goal` <= 120 chars.
- `memory` <= 240 chars.
- `next_goal` <= 140 chars.
- Exactly one `action` object, unless finishing.
- Same language as the user goal.
"""


MICRO_GOAL_PLANNER_PROMPT = """# MICRO-GOAL PLANNER
You are the planning layer of a browser QA agent.
Your ONLY job is to choose the SINGLE next unfinished objective for the actor.
Do NOT execute browser actions. Do NOT enumerate all controls. Do NOT write a
multi-step plan. Return exactly one JSON object:
{"goal":"one small concrete objective","done":false,"reason":"short"}

Rules:
- The objective must be directly supported by the original mission.
- Preserve mission-provided literal values exactly; never invent replacements.
- Choose exactly ONE atomic objective: locate one target, fill one logical
  value, open one control, select one observed option, upload one file, add one
  entity, verify one result, or recover from one failed action.
- Prefer the smallest useful objective that can be completed with one or a few
  tightly related browser actions.
- Never describe future objectives in the goal text.
- If the current objective has not been verified, keep that objective instead
  of jumping ahead.
- If a dropdown was just opened, the next objective must be to resolve/select
  the requested option from the NEW live state; never reuse stale indices.
- If the mission is fully satisfied, set done=true and goal="".
- Never invent selectors, routes, element indices, field counts, site-specific
  behavior, or UI labels that are not grounded in the mission/current state.
"""


# =====================================================================
# خروجی نهایی agent برای یک هدف
# =====================================================================

class AgentOutcome:
    def __init__(self, verdict, expected="", actual="", failure_reason="",
                 reasoning="", findings=None, actions_count=0,
                 finished_normally=True):
        self.verdict = verdict
        self.expected = expected
        self.actual = actual
        self.failure_reason = failure_reason
        self.reasoning = reasoning
        self.findings = findings or []
        self.actions_count = actions_count
        self.finished_normally = finished_normally

    def to_dict(self):
        return {
            "verdict": self.verdict,
            "expected": self.expected,
            "actual": self.actual,
            "failure_reason": self.failure_reason,
            "reasoning": self.reasoning,
            "findings": self.findings,
            "actions_count": self.actions_count,
            "finished_normally": self.finished_normally,
        }

    @classmethod
    def from_dict(cls, d):
        d = d or {}
        return cls(
            verdict=d.get("verdict", "INCONCLUSIVE"),
            expected=d.get("expected", ""),
            actual=d.get("actual", ""),
            failure_reason=d.get("failure_reason", ""),
            reasoning=d.get("reasoning", ""),
            findings=d.get("findings") or [],
            actions_count=d.get("actions_count", 0),
            finished_normally=d.get("finished_normally", True),
        )


# =====================================================================
# خودِ agent
# =====================================================================

class QAReActAgent:

    def __init__(self, browser, ai=None, policy=None, evidence=None,
                 skill_loader=None, mission_type="spec", mode="run",
                 human_input_fn=None, max_steps=None):
        self.browser = browser
        self.ai = ai or AIClient()
        self.policy = policy or PolicyEngine()
        self.store = evidence or EvidenceStore()
        self.skills = skill_loader or SkillLoader()
        self.mission_type = mission_type
        self.mode = mode
        self.human_input_fn = human_input_fn or _default_human_input
        self.max_steps = max_steps

        self.context_vars = {}          # برای {var} و ask_human
        self._findings = []
        self._system_prompt = None
        self._tool_catalog = None
        self._last_navigation_evidence = None
        self._initial_url = None
        self.mission_state = MissionState()
        self.mission_inputs = MissionInputLedger()
        self._micro_goal = ""
        self._micro_goal_completed = []
        self._last_action_summary = ""
        self._last_action_target = {}
        self._agent_memory = ""
        self._human_command_action_count = 0
        self._blocked_surface_attempts = {}
        self._blocked_action_attempts = {}
        self._pending_human_command = ""
        self._active_runtime_challenge = None
        self._runtime_recovery_action_count = 0
        self._active_runtime_challenge = None
        self._runtime_recovery_action_count = 0
        self._mission_goal_text = ""
        self._denied_navigation_targets = set()
        self._last_dom_action = None
        self._last_dom_action_state = None
        # Per-page request cursor used to correlate responses with the most recent action.
        self._network_seen_max = 0
        self._network_seen_page_url = ""
        self._last_action_response_evidence = {}
        self._fast_filled_signatures = set()
        self._async_wait_context = None
        self._wait_no_progress_counts = {}
        self._premature_finish_rejections = 0
        self._blocked_surface_attempts = {}
        self._blocked_action_attempts = {}
        # Tracks whether the application-copied link has been opened in a new
        # tab. Used by _guard_premature_finish to prevent the LLM from giving
        # up with INCONCLUSIVE right after a copy-link click.
        self._clipboard_link_opened = False
        self._copy_link_click_detected = False

    # -----------------------------------------------------------------
    # ساخت system prompt — فقط یک بار در هر run
    # -----------------------------------------------------------------

    def system_prompt(self):
        if self._system_prompt:
            return self._system_prompt

        active = self.skills.select(
            snapshot_text=self._last_snapshot_text(),
            mission_type=self.mission_type,
            mode=self.mode,
        )
        skills_block = self.skills.compose_prompt(active)

        if getattr(config, "FAST_MODE", False):
            fast_rules = (
                "FAST ACTOR MODE: choose the next concrete action immediately. "
                "Do not build a test matrix, narrate alternatives, or pre-plan future steps. "
                "Return no reasoning narrative: `thought` max 12 words and exactly one action. "
                "For simple field filling, do not narrate; emit the action immediately. For safe adjacent text fields, prefer one input_text_batch action instead of separate actions. "
                "Ask the human only when a real external value is required. "
                "A visible countdown is a resend cooldown unless the target input itself is live-disabled. "
            )
            fast_addressing = (
                "Use the CURRENT Page-Agent state only. Never guess indices/selectors. "
                "Prefer batch input, direct dropdown selection, upload_file, and one-step tab/navigation capabilities. "
                "For literal mission values, use the local fast-fill path only when the field identity is high-confidence and unique; do not bypass semantic disambiguation for ambiguous fields. "
                "Do not wait because an OTP resend timer is running; ask for the newly issued OTP immediately. A resend countdown NEVER proves the OTP inputs are disabled. Use the timer only to schedule an explicit resend operation. "
                "For a newly copied application URL, use open_application_link instead of asking the human to open it. After open_application_link the CURRENT tab is the NEW tab; do NOT call read_clipboard and do NOT click rows in the previous tab. "
                "Never fabricate a phone or credential value; when the mission only says ‘this number’ without a literal value, ask the human. "
                "Use the exact observed button label; do not reinterpret ‘تأیید/Confirm’ as ‘login’ without current-state evidence. "
                "After every action, read ACTION OUTCOME/TARGET EFFECTS as authoritative evidence. Do not assume success from a click; verify the target's state, URL/dialog changes, and correlated response before deciding the next action. If the outcome contradicts your expectation, replan from the new state instead of repeating the same action. "
                ""
                "After a click, do not repeat the same control without fresh target evidence. "
            )
            parts = [
                f"You are an in-page Page Agent operating a real web page. Complete the user's task by iteratively observing the live DOM and taking one grounded action at a time.",
                "Your architecture is: Live DOM -> simplified indexed state -> LLM reflection -> one indexed action -> fresh state. Behave like Alibaba Page Agent: do not create a precomputed workflow and do not guess selectors or future indices.",
                CONSTITUTION_PROMPT,
                "# LEVEL-1 RULES\n" + self.policy.compile_prompt_rules(),
                fast_rules,
                fast_addressing,
                self._tools_catalog(),
                RESPONSE_PROTOCOL,
                "# OUTPUT LANGUAGE\nRespond in the same language as the goal description.",
            ]
        else:
            parts = [
                f"You are a Page Agent-style browser agent operating on a real web page. Complete the user's task through an iterative observe -> reflect -> one action -> observe loop.",
                "The live DOM is your primary perception. Use indexed elements from the current simplified page state. Do not pre-plan a workflow, do not guess selectors, and do not reuse stale indices.",
                CONSTITUTION_PROMPT,
                ENVIRONMENT_FACTS_PROMPT,
                "# LEVEL-1 RULES (machine-enforced — violations are blocked "
                "before execution)\n" + self.policy.compile_prompt_rules(),
                "# ACTIVE SKILLS (binding)\n" + skills_block,
                ADDRESSING_PROMPT,
                self._tools_catalog(),
                RESPONSE_PROTOCOL,
                "# OUTPUT LANGUAGE\nRespond in the same language as the goal "
                "description (Persian goals → Persian `thought`; verdict "
                "fields may be in the goal's language).",
            ]
        self._system_prompt = "\n\n".join(parts)
        return self._system_prompt

    def _last_snapshot_text(self):
        return getattr(self, "_recent_snapshot", "")

    def _tools_catalog(self):
        lines = ["# AVAILABLE PAGE-AGENT TOOLS"]
        descriptions = {
            "click_element_by_index": "Click an observed interactive DOM index.",
            "find_elements": "Search the CURRENT live Page-Agent DOM by semantic text/label/context and return observed indices. Use this instead of guessing an index when the current state is truncated or after a dropdown opens.",
            "input_text": "Input exact text into one observed interactive input index.",
            "input_text_batch": "Fill multiple observed interactive inputs in ONE browser action. Use for a segmented challenge and for several independent currently-actionable text fields visible in the same live state.",
            "select_dropdown_option": "Open a currently observed dropdown/combobox if necessary and select the exact observed option in ONE action.",
            "upload_file": "Upload explicit local file path(s) through the official Playwright file-chooser bridge after the chooser is observed.",
            "scroll": "Scroll the page or an observed scrollable index.",
            "open_application_link": "Read the application-copied URL from clipboard and open it in a NEW TAB; use when the app has just copied a link for the mission.",
            "read_clipboard": "Read clipboard text through the trusted runtime (not arbitrary page JS).",
            "open_new_tab": "Open an explicitly observed/trusted URL in a new browser tab.",
            "switch_tab": "Switch to an observed browser tab by index.",
            "navigate": "Navigate to an explicitly observed/trusted application URL in the current tab.",
            "execute_javascript": "Execute page JavaScript when explicitly permitted by runtime policy.",
            "ask_human": "Request runtime human input such as an unseen challenge value.",
            "report_finding": "Record an exploratory finding.",
            "finish": "Finish with a QA verdict."
        }
        for name in ["click_element_by_index", "find_elements", "input_text", "input_text_batch", "select_dropdown_option", "upload_file", "scroll", "open_application_link", "read_clipboard", "open_new_tab", "switch_tab", "navigate", "execute_javascript", "ask_human", "report_finding", "finish"]:
            if name == "execute_javascript" and name not in PAGE_AGENT_TOOLS:
                continue
            lines.append(f"- {name}: {descriptions[name]}")
        lines.append("# RUNTIME DIAGNOSTICS (engine-controlled, NOT model actions)")
        lines.append("The engine collects console/network/screenshot evidence automatically on failures when useful.")
        lines.append("Legacy snapshot/ref tools are not exposed. Navigation/tab/clipboard use the dedicated trusted capability actions in this catalog.")
        return "\n".join(lines)

    # -----------------------------------------------------------------
    # حلقه‌ی اصلی — اجرای یک «هدف»
    # -----------------------------------------------------------------

    def run_goal(self, goal, context=None, requirement_id=None,
                 max_steps=None):
        """
        goal      : متن هدف (مثلاً description یک قدم spec)
        context   : dict اختیاری (مثلاً target_hint، value، wait_for)
        خروجی     : AgentOutcome
        """
        steps_limit = max_steps or self.max_steps or 24
        self._mission_goal_text = str(goal or "")
        self._denied_navigation_targets = set()
        self._last_dom_action = None
        self._last_dom_action_state = None
        self._async_wait_context = None
        self._wait_no_progress_counts = {}
        self._premature_finish_rejections = 0
        if context and context.get("base_url"):
            self._initial_url = str(context.get("base_url"))
        if context and isinstance(context.get("mission_inputs"), dict):
            for key, value in context["mission_inputs"].items():
                self.mission_state.declare(str(key), value)

        # چک انحراف دامنه «قبل» از اولین تصمیم LLM — ریدایرکت باید از
        # همان پیام اول شفاف باشد؛ یافته هم خودِ موتور ثبت می‌کند تا
        # agent دور/اکشنی صرف report_finding نکند (رفع دور دوم هدررفته
        # در لاگ واقعی کاربر: initial-host → runtime-generated-host).
        drift_note = self._check_domain_drift(requirement_id)

        # Semantic requests must be grounded in the original goal, not in a
        # model-authored paraphrase or a validation error.
        self.mission_inputs = MissionInputLedger(str(goal or ""))

        intent_context = {
            key: value for key, value in (context or {}).items()
            if key not in {"base_url"}
        }
        self.policy.set_mission_intent(
            str(goal or "") + "\n" + json.dumps(
                intent_context, ensure_ascii=False, sort_keys=True, default=str
            )
        )
        # Page-Agent observe: one in-page DOM extraction before the first LLM turn.
        # Retry up to 3 times with a short delay — the page may still be loading
        # or the controller may need a re-install after navigation.
        pa = None
        last_err = None
        for attempt in range(3):
            try:
                pa = self.browser.page_agent.state()
                self._recent_page_agent_state = pa.get("content", "")
                self._page_agent_url = pa.get("url", "")
                last_err = None
                break
            except Exception as exc:
                last_err = exc
                try:
                    self.browser.page_agent.mark_page_changed()
                except Exception:
                    pass
                time.sleep(0.5)
        if last_err is not None:
            outcome = AgentOutcome(
                verdict="INCONCLUSIVE", expected=goal,
                failure_reason=f"page_agent_observe_failed (after 3 retries): {last_err}",
                actions_count=0, finished_normally=False)
            return outcome

        # _prime_network_cursor is best-effort; don't let it crash the mission.
        try:
            self._prime_network_cursor()
        except Exception:
            pass

        self._micro_goal_completed = []
        self._last_action_summary = ""
        self._agent_memory = ""
        self._human_command_action_count = 0
        self._pending_human_command = ""
        if getattr(config, "USE_MICRO_GOAL_PLANNER", False):
            self._micro_goal, mission_done = self._plan_next_micro_goal(
                mission_goal=str(goal or ""), context=context or {},
                current_goal="", last_action=""
            )
            if mission_done:
                outcome = AgentOutcome(
                    verdict="INCONCLUSIVE" if self.mission_type == "exploratory" else "PASS",
                    expected=goal, actual="mission already satisfied",
                    actions_count=0, finished_normally=True,
                )
                return outcome
        else:
            # Alibaba Page Agent-style loop: the acting model carries the next
            # atomic goal in its response, so a separate planner call is not
            # required for every browser action. This removes one LLM turn per
            # step and keeps action/observation/reflection together.
            self._micro_goal = str(goal or "").strip()

        if not self._micro_goal:
            self._micro_goal = str(goal or "").strip()

        goal_message = self._compose_goal_message(goal, context,
                                                  requirement_id,
                                                  micro_goal=self._micro_goal)
        if drift_note:
            goal_message += drift_note

        messages = [
            {"role": "system", "content": self.system_prompt()},
            {"role": "user", "content": goal_message},
        ]

        steps = 0
        actions_count = 0
        outcome = None
        loop_warned = False
        self._record_frame(0)

        while steps < steps_limit:
            steps += 1

            # --- Fast-path routine form filling (no LLM round-trip) ---
            if getattr(config, "FAST_MODE", False) and getattr(config, "FAST_DIRECT_FORM_FILL", False):
                try:
                    fast_batch = self._fast_grounded_form_batch()
                except Exception:
                    fast_batch = []
                if fast_batch:
                    try:
                        result = self.browser.page_agent.input_batch(fast_batch)
                        actions_count += 1
                        observation = (getattr(result, "text", "") or "FAST_FORM_FILL: completed")[:MAX_OBSERVATION_CHARS]
                        for item in fast_batch:
                            self._fast_filled_signatures.add((int(item["index"]), str(item["text"])))
                        pa = self.browser.page_agent.state()
                        self._recent_page_agent_state = pa.get("content", "")
                        self._page_agent_url = pa.get("url", "")
                        self.store.record_action(
                            "input_text_batch",
                            {"items": [{"index": x["index"]} for x in fast_batch]},
                            observation=observation,
                            meta={"requirement_id": requirement_id, "architecture": "page-agent-fast-form-fill", "llm_bypass": True},
                        )
                        self._record_frame(actions_count)
                        messages = self._append_turn(
                            messages,
                            {"thought": "Fast-fill grounded fields.", "tool": "input_text_batch", "arguments": {"items": [{"index": x["index"]} for x in fast_batch]}},
                            f"TOOL_RESULT input_text_batch: {observation}\n\nCURRENT PAGE STATE:\n{self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS]}"
                        )
                        self._last_action_summary = f"input_text_batch: filled {len(fast_batch)} grounded fields"
                        continue
                    except Exception:
                        self._fast_filled_signatures = set()

            # --- پاسخ LLM ---
            try:
                max_tokens = (
                    config.FAST_AI_MAX_TOKENS
                    if getattr(config, "FAST_MODE", False)
                    else config.AI_MAX_TOKENS
                )
                try:
                    decision = self.ai.chat_json(
                        messages,
                        max_tokens=max_tokens,
                        retries=(getattr(config, "FAST_AI_RETRIES", 1) if getattr(config, "FAST_MODE", False) else 2),
                    )
                except TypeError as exc:
                    # Preserve compatibility with existing/local AI adapters whose
                    # chat_json signature predates the max_tokens argument.
                    if "max_tokens" not in str(exc):
                        raise
                    decision = self.ai.chat_json(messages)
            except Exception as e:                        # noqa: BLE001
                outcome = AgentOutcome(
                    verdict="INCONCLUSIVE",
                    expected=goal,
                    failure_reason=f"LLM error: {e}",
                    actions_count=actions_count,
                    finished_normally=False,
                )
                break

            decision = self._normalize_page_agent_decision(decision)
            thought = str(decision.get("thought", ""))[:400]
            tool = str(decision.get("tool", "")).strip()
            arguments = decision.get("arguments") or {}
            next_goal = str(decision.get("next_goal", "") or "").strip()
            memory = str(decision.get("memory", "") or "").strip()
            if memory:
                self._agent_memory = memory[:900]

            if not tool:
                messages.append({"role": "assistant",
                                 "content": json.dumps(decision,
                                                       ensure_ascii=False)})
                messages.append({"role": "user", "content":
                                "No tool given. Reply with the JSON object "
                                "choosing a tool or finish."})
                continue

            # Hard budget boundary applies to every executed action, including
            # human checkpoints and findings. A final response is not an action
            # and remains allowed after the budget is consumed.
            if tool != "finish" and self._budget_exhausted(actions_count):
                outcome = AgentOutcome(
                    verdict="INCONCLUSIVE",
                    expected=goal,
                    actual="action budget exhausted before the next action",
                    failure_reason="action_budget_exhausted",
                    actions_count=actions_count,
                    finished_normally=False,
                )
                break

            print(f"    💭 {thought}")

            # --- ابزارهای داخلی ---
            if tool == "finish":
                finish_guard = self._guard_premature_finish(decision)
                if finish_guard:
                    messages = self._append_turn(
                        messages, decision,
                        finish_guard + "\n\nCURRENT PAGE STATE:\n"
                        + self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS]
                    )
                    continue
                outcome = self._outcome_from_final(decision, goal,
                                                   actions_count)
                break

            if tool == "ask_human":
                if self._pending_human_command:
                    observation = (
                        f"HUMAN_COMMAND_PENDING: {self._pending_human_command}. "
                        "A previous operator command has not completed yet. Do NOT ask for the "
                        "OTP/CAPTCHA again. Continue executing the pending UI command, then re-observe."
                    )
                else:
                    observation = self._handle_ask_human(arguments)
                self.store.record_action(
                    "ask_human",
                    {k: v for k, v in arguments.items() if k != "answer"},
                    observation="(human input received — value redacted)",
                    meta={"requirement_id": requirement_id},
                )
                actions_count += 1
                self.policy.consume_internal_action()
                extra = int(getattr(self, "_human_command_action_count", 0) or 0)
                if extra:
                    actions_count += extra
                    self._human_command_action_count = 0
                self._record_frame(actions_count)
                messages = self._append_turn(
                    messages, decision,
                    f"TOOL_RESULT ask_human: {observation}")
                continue

            if tool == "report_finding":
                finding = self._handle_finding(arguments, requirement_id)
                observation = f"Finding recorded: {finding.get('id')} — " \
                              f"{finding.get('description', '')[:150]}"
                actions_count += 1
                self.policy.consume_internal_action()
                self._record_frame(actions_count)
                messages = self._append_turn(
                    messages, decision,
                    f"TOOL_RESULT report_finding: {observation}")
                continue

            # --- Hard boundary: Page-Agent is the ONLY browser interaction path. ---
            # The model may emit an obsolete MCP/browser tool name; never execute it.
            # This prevents the agent from falling back to snapshot/find/navigate loops.
            if tool == "execute_javascript" and tool not in PAGE_AGENT_TOOLS:
                actions_count += 1
                observation = (
                    "BLOCKED: execute_javascript is disabled. Enable both "
                    "AGENTIC_QA_ALLOW_EVALUATE=1 and AGENTIC_QA_ALLOW_AGENT_JS=1 "
                    "only for a trusted test environment."
                )
                self.store.record_action(tool, arguments, observation=observation, meta={"requirement_id": requirement_id, "blocked_by_runtime": True})
                messages = self._append_turn(messages, decision, observation + "\n\nCURRENT PAGE STATE:\n" + self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS])
                continue

            # --- File upload bridge: Page-Agent remains primary, but file
            # upload is a browser capability that the in-page controller cannot
            # implement by itself. Use the official Playwright MCP tool with
            # an explicit local path and keep it as ONE logical action.
            if tool in {"upload_file", "browser_file_upload"}:
                raw_paths = arguments.get("paths") or arguments.get("path") or arguments.get("file") or ""
                if isinstance(raw_paths, str):
                    paths = [raw_paths]
                elif isinstance(raw_paths, list):
                    paths = [str(x) for x in raw_paths if str(x).strip()]
                else:
                    paths = []
                if not paths:
                    observation = "FILE_UPLOAD BLOCKED: provide an explicit absolute local path in `path` or `paths`."
                    actions_count += 1
                    self.store.record_action(tool, {}, observation=observation, meta={"requirement_id": requirement_id, "blocked_by_runtime": True})
                    messages = self._append_turn(messages, decision, observation + "\n\nCURRENT PAGE STATE:\n" + self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS])
                    continue
                missing = [p for p in paths if not os.path.isfile(os.path.expanduser(p))]
                if missing:
                    observation = "FILE_UPLOAD BLOCKED: these local files do not exist: " + ", ".join(missing[:4])
                    actions_count += 1
                    self.store.record_action(tool, {"paths": paths}, observation=observation, meta={"requirement_id": requirement_id, "blocked_by_runtime": True})
                    messages = self._append_turn(messages, decision, observation + "\n\nCURRENT PAGE STATE:\n" + self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS])
                    continue

                self.policy.set_observed_snapshot(getattr(self, "_recent_snapshot", ""))
                policy_check = self.policy.validate_action("browser_file_upload", {"paths": paths})
                if not policy_check["approved"]:
                    observation = f"POLICY DENIED file upload: {policy_check['reason']}"
                    actions_count += 1
                    self.store.record_action(tool, {"paths": paths}, observation=observation, meta={"requirement_id": requirement_id})
                    messages = self._append_turn(messages, decision, observation + "\n\nCURRENT PAGE STATE:\n" + self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS])
                    continue

                try:
                    before_pa = self.browser.page_agent.state()
                    self._recent_page_agent_state = before_pa.get("content", "")
                except Exception:
                    before_pa = {"content": getattr(self, "_recent_page_agent_state", ""), "elements": [], "url": getattr(self, "_page_agent_url", ""), "title": ""}
                before_state_hash = self._page_agent_state_hash()
                try:
                    result = self.browser.call_tool("browser_file_upload", {"paths": paths})
                    actions_count += 1
                    observation = (result.text or "File upload completed")[:MAX_OBSERVATION_CHARS]
                    pa = self.browser.page_agent.state()
                    self._recent_page_agent_state = pa.get("content", "")
                    self._page_agent_url = pa.get("url", "")
                    after_state_hash = self._page_agent_state_hash()
                    self.store.record_action(
                        "upload_file", {"paths": paths}, observation=observation,
                        meta={"requirement_id": requirement_id, "architecture": "page-agent+playwright-upload", "paths_count": len(paths)},
                    )
                    self.policy.note_action("browser_file_upload", {"paths": paths}, before_state_hash=before_state_hash, after_state_hash=after_state_hash)
                    self._record_frame(actions_count)
                    messages = self._append_turn(messages, decision, f"TOOL_RESULT upload_file: {observation}\n\nCURRENT PAGE STATE:\n{self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS]}")
                    self._last_action_summary = f"upload_file: {observation[:900]}"
                    continue
                except (ToolExecutionError, MCPError) as e:
                    actions_count += 1
                    observation = f"FILE_UPLOAD ERROR: {str(e)[:MAX_OBSERVATION_CHARS]}"
                    try:
                        pa = self.browser.page_agent.state()
                        self._recent_page_agent_state = pa.get("content", "")
                        self._page_agent_url = pa.get("url", "")
                    except Exception:
                        pass
                    self.store.record_action(tool, {"paths": paths}, observation=observation, error=str(e), meta={"requirement_id": requirement_id, "architecture": "page-agent+playwright-upload"})
                    messages = self._append_turn(messages, decision, f"TOOL_RESULT upload_file: {observation}\n\nCURRENT PAGE STATE:\n{self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS]}")
                    continue

            # --- Trusted browser capabilities outside the in-page DOM controller. ---
            if tool in BROWSER_CAPABILITY_TOOLS:
                try:
                    if tool == "read_clipboard":
                        # Use the same robust clipboard reader the auto-follow
                        # path uses; on HTTP sites navigator.clipboard.readText()
                        # may be blocked, so the runtime returns empty rather
                        # than throwing.
                        text_value = self._read_application_clipboard()
                        # If the clipboard contains a valid URL, register it as
                        # trusted navigation evidence so the LLM can immediately
                        # use open_new_tab or navigate with it without the policy
                        # rejecting it as an unobserved route.
                        if text_value:
                            clipboard_url = self._extract_url_from_text(text_value)
                            if clipboard_url:
                                clip_evidence = build_navigation_evidence(
                                    clipboard_url,
                                    source="application_clipboard",
                                    provenance="clipboard_from_application",
                                    evidence="trusted runtime read of application clipboard",
                                    was_inferred=False,
                                    initial_url=self._initial_url,
                                    decision="approved",
                                ).as_dict()
                                self._last_navigation_evidence = clip_evidence
                                self.policy.register_navigation_evidence(clip_evidence)
                        observation = "CLIPBOARD_READ: " + (redact_text(text_value)[:600] if text_value else "<empty or unreadable>")
                    elif tool == "open_application_link":
                        observation = self._open_application_clipboard_link()
                    elif tool == "open_new_tab":
                        url = str(arguments.get("url") or "").strip()
                        evidence = arguments.get("navigation_evidence") or getattr(self, "_last_navigation_evidence", None) or {}
                        if not url or not valid_url(url):
                            raise MCPError("open_new_tab requires an explicit valid URL")
                        # If the LLM is trying to open a URL that matches the
                        # last clipboard-read URL, auto-attach the trusted
                        # clipboard evidence so the policy approves it.
                        last_nav = getattr(self, "_last_navigation_evidence", None) or {}
                        if (last_nav.get("navigation_target") == url
                                and last_nav.get("provenance") == "clipboard_from_application"):
                            evidence = last_nav
                        self.policy.set_observed_snapshot(getattr(self, "_recent_snapshot", ""))
                        check = self.policy.validate_action("browser_navigate", {"url": url, "navigation_evidence": evidence})
                        if not check["approved"]:
                            raise MCPError(check["reason"])
                        result = self.browser.call_tool("browser_tabs", {"action": "new", "url": url})
                        # The active tab has changed; the page-local controller
                        # must be re-installed on the NEW tab before state().
                        try:
                            self.browser.page_agent.mark_page_changed()
                            time.sleep(0.2)
                        except Exception:
                            pass
                        # If this URL came from the clipboard, mark the link as opened.
                        if getattr(self, "_copy_link_click_detected", False):
                            self._clipboard_link_opened = True
                        observation = (
                            (result.text or "new tab opened")[:MAX_OBSERVATION_CHARS]
                            + " NEW_TAB_FOCUS: the CURRENT active tab is now the NEW tab. "
                              "Use the CURRENT PAGE STATE indices below to interact with the new page."
                        )
                    elif tool == "switch_tab":
                        index = int(arguments.get("index"))
                        result = self.browser.call_tool("browser_tabs", {"action": "select", "index": index})
                        # The active tab has changed; invalidate the controller.
                        try:
                            self.browser.page_agent.mark_page_changed()
                            time.sleep(0.15)
                        except Exception:
                            pass
                        observation = (
                            (result.text or f"switched to tab {index}")[:MAX_OBSERVATION_CHARS]
                            + " TAB_FOCUS: the CURRENT active tab has changed. Use the "
                              "CURRENT PAGE STATE indices below to interact with the now-active page."
                        )
                    elif tool == "navigate":
                        url = str(arguments.get("url") or "").strip()
                        evidence = arguments.get("navigation_evidence") or getattr(self, "_last_navigation_evidence", None) or {}
                        if not url or not valid_url(url):
                            raise MCPError("navigate requires an explicit valid URL")
                        if url in self._denied_navigation_targets:
                            raise MCPError("navigation target was already denied; inspect the current live page instead of retrying a guessed route")
                        # If the LLM is trying to navigate to a URL that matches
                        # the last clipboard-read URL, auto-attach the trusted
                        # clipboard evidence so the policy approves it.
                        last_nav = getattr(self, "_last_navigation_evidence", None) or {}
                        if (last_nav.get("navigation_target") == url
                                and last_nav.get("provenance") == "clipboard_from_application"):
                            evidence = last_nav
                        check = self.policy.validate_action("browser_navigate", {"url": url, "navigation_evidence": evidence})
                        if not check["approved"]:
                            self._denied_navigation_targets.add(url)
                            raise MCPError(check["reason"])
                        result = self.browser.call_tool("browser_navigate", {"url": url})
                        # A navigation replaces the page; invalidate the controller.
                        try:
                            self.browser.page_agent.mark_page_changed()
                        except Exception:
                            pass
                        observation = (
                            (result.text or "navigation completed")[:MAX_OBSERVATION_CHARS]
                            + " NAVIGATION_COMPLETED: the page has changed. Use the CURRENT "
                              "PAGE STATE indices below to interact with the new page."
                        )
                    else:
                        raise MCPError(f"Unsupported browser capability: {tool}")
                    actions_count += 1
                    try:
                        pa = self.browser.page_agent.state()
                        self._recent_page_agent_state = pa.get("content", "")
                        self._page_agent_url = pa.get("url", "")
                    except Exception:
                        pass
                    self.store.record_action(tool, {k:v for k,v in arguments.items() if k not in {"text", "value"}}, observation=observation, meta={"requirement_id": requirement_id, "architecture": "playwright-capability"})
                    self._record_frame(actions_count)
                    messages = self._append_turn(messages, decision, f"TOOL_RESULT {tool}: {observation}\n\nCURRENT PAGE STATE:\n{self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS]}")
                    continue
                except (ToolExecutionError, MCPError, ValueError) as e:
                    actions_count += 1
                    observation = f"{tool} ERROR: {str(e)[:MAX_OBSERVATION_CHARS]}"
                    self.store.record_action(tool, {k:v for k,v in arguments.items() if k not in {"text", "value"}}, observation=observation, error=str(e), meta={"requirement_id": requirement_id, "architecture": "playwright-capability"})
                    messages = self._append_turn(messages, decision, observation + "\n\nCURRENT PAGE STATE:\n" + self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS])
                    continue

            if tool.startswith("browser_"):
                actions_count += 1
                observation = (
                    f"BLOCKED: {tool} is not an allowed interaction path. "
                    "Use only Page-Agent indexed DOM actions from the CURRENT PAGE STATE. "
                    "Do not snapshot, find, hover, click by ref, type by ref, or guess a URL/route."
                )
                self.store.record_action(tool, arguments, observation=observation, meta={"requirement_id": requirement_id, "blocked_legacy_browser_tool": True})
                messages = self._append_turn(messages, decision, observation + "\n\nCURRENT PAGE STATE:\n" + self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS])
                continue

            # --- Page-Agent controller action: indexed in-page DOM operations ---
            if tool in PAGE_AGENT_TOOLS:
                if tool == "input_text":
                    guard = self._guard_uninvented_input(arguments.get("index"), arguments.get("text", ""))
                    if guard:
                        actions_count += 1
                        self.store.record_action(tool, {"index": arguments.get("index")}, observation=guard,
                                                 meta={"requirement_id": requirement_id, "blocked_by_runtime": True, "reason": "invented_external_value"})
                        messages = self._append_turn(messages, decision, guard + "\n\nCURRENT PAGE STATE:\n" + self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS])
                        continue
                elif tool == "input_text_batch":
                    guard = None
                    for item in arguments.get("items") or []:
                        guard = self._guard_uninvented_input(item.get("index"), item.get("text", ""))
                        if guard:
                            break
                    if guard:
                        actions_count += 1
                        self.store.record_action(tool, {"items": [{"index": x.get("index")} for x in (arguments.get("items") or [])]}, observation=guard,
                                                 meta={"requirement_id": requirement_id, "blocked_by_runtime": True, "reason": "invented_external_value"})
                        messages = self._append_turn(messages, decision, guard + "\n\nCURRENT PAGE STATE:\n" + self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS])
                        continue

                if tool in {"click_element_by_index", "input_text", "select_dropdown_option"}:
                    current_element, current_state = self._current_page_agent_element(arguments.get("index"))
                    status = (current_element or {}).get("status") or {}
                    if current_element and status.get("disabled"):
                        state_hash = self._page_agent_state_hash()
                        owner = status.get("disabledOwner") or {}
                        owner_key = str(owner.get("name") or current_element.get("name") or arguments.get("index"))[:160]
                        surface_key = (state_hash, owner_key)
                        action_key = (state_hash, self._dom_action_signature(tool, arguments))
                        self._blocked_surface_attempts[surface_key] = self._blocked_surface_attempts.get(surface_key, 0) + 1
                        self._blocked_action_attempts[action_key] = self._blocked_action_attempts.get(action_key, 0) + 1
                        count = self._blocked_surface_attempts[surface_key]
                        candidates = status.get("prerequisiteCandidates") or status.get("blockedBy") or []
                        candidate_text = ", ".join(str(x.get("name") or x) for x in candidates[:8] if x) or "none observed"
                        actions_count += 1
                        state_label = "disabled"
                        observation = (
                            f"ACTION_BLOCKED: target is {state_label} in the current live state. "
                            f"Semantic owner: {owner_key!r}. "
                            f"Candidates: {candidate_text}. "
                            f"This surface has been attempted {count} time(s); choose an actionable prerequisite or a different target."
                        )
                        if count >= 2:
                            observation = (
                                f"HARD STRATEGY BLOCK: this interaction surface is {state_label} and has already been attempted {count} times "
                                "in the same live state. The engine will NOT execute another action on this surface. "
                                f"Observed prerequisite candidates: {candidate_text}."
                            )
                        self.store.record_action(
                            tool, arguments, observation=observation,
                            meta={
                                "requirement_id": requirement_id,
                                "blocked_by_runtime": True,
                                "blocked_surface_key": owner_key,
                                "blocked_surface_kind": state_label,
                                "blocked_surface_attempt": count,
                                "strategy_change_required": True,
                            },
                        )
                        messages = self._append_turn(
                            messages, decision,
                            observation + "\n\nCURRENT PAGE STATE:\n" + self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS]
                            + "\n\nDECISION RULE: choose a DIFFERENT actionable target now. Do not click/type/select any element owned by the same disabled surface again."
                        )
                        if count >= 3:
                            outcome = AgentOutcome(
                                verdict="BLOCKED", expected=goal,
                                actual="disabled interaction surface repeated without a state change",
                                failure_reason="strategy_loop_on_disabled_surface",
                                actions_count=actions_count, finished_normally=False,
                            )
                            break
                        continue

                # Capture the complete pre-action Page-Agent state before any
                # browser action runs. The transition summarizer needs this
                # baseline even for the normal (non-upload) action path.
                try:
                    before_pa = self.browser.page_agent.state()
                    self._recent_page_agent_state = before_pa.get("content", "")
                    self._page_agent_url = before_pa.get("url", "")
                except Exception:
                    before_pa = {
                        "content": getattr(self, "_recent_page_agent_state", ""),
                        "elements": [],
                        "url": getattr(self, "_page_agent_url", ""),
                        "title": "",
                    }
                before_state_hash = self._page_agent_state_hash()
                try:
                    if tool == "click_element_by_index":
                        result = self.browser.page_agent.click(arguments.get("index"))
                    elif tool == "find_elements":
                        query = str(
                            arguments.get("query")
                            or arguments.get("text")
                            or arguments.get("label")
                            or arguments.get("name")
                            or arguments.get("target")
                            or ""
                        ).strip()
                        if not query:
                            raise MCPError(
                                "find_elements requires a semantic query in query/text/label/name/target"
                            )
                        matches = self.browser.page_agent.find(query)
                        result = type("ToolResult", (), {"text": json.dumps(matches, ensure_ascii=False)})()
                    elif tool == "input_text":
                        result = self.browser.page_agent.input_text(arguments.get("index"), arguments.get("text", ""))
                    elif tool == "input_text_batch":
                        result = self.browser.page_agent.input_batch(arguments.get("items") or [])
                    elif tool == "select_dropdown_option":
                        result = self.browser.page_agent.select_option(arguments.get("index"), arguments.get("text", ""))
                    elif tool == "scroll":
                        scroll_guard = self._guard_scroll_before_action(
                            thought=thought,
                            goal=goal,
                            direction_down=bool(arguments.get("down", True)),
                            index=arguments.get("index"),
                        )
                        if scroll_guard.get("blocked"):
                            actions_count += 1
                            observation = scroll_guard["message"]
                            self.store.record_action(
                                tool, arguments, observation=observation,
                                meta={
                                    "requirement_id": requirement_id,
                                    "architecture": "page-agent",
                                    "scroll_guard": scroll_guard,
                                },
                            )
                            self._record_frame(actions_count)
                            messages = self._append_turn(
                                messages, decision,
                                f"TOOL_RESULT scroll: {observation}\n\nCURRENT PAGE STATE:\n{self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS]}"
                            )
                            continue
                        result = self.browser.page_agent.scroll(arguments.get("down", True), arguments.get("pixels"), arguments.get("index"))
                    elif tool == "execute_javascript":
                        if "browser_evaluate" not in self.browser.tools or "browser_evaluate" in config.DENY_TOOLS:
                            raise MCPError("execute_javascript is disabled by runtime policy")
                        result = self.browser.call_tool("browser_evaluate", {"function": arguments.get("script", "")})
                    else:
                        raise MCPError(f"Unsupported Page-Agent tool: {tool}")
                    actions_count += 1
                    observation = (getattr(result, "text", "") or "Action executed")[:MAX_OBSERVATION_CHARS]
                    if tool == "click_element_by_index":
                        try:
                            clicked, _ = self._current_page_agent_element(arguments.get("index"))
                            label = str((clicked or {}).get("name") or "").strip()
                            if label:
                                observation = f"TARGET_CLICKED: {label!r}. " + observation
                        except Exception:
                            pass
                    # One fresh Page-Agent observation after each action. No snapshot round-trip.
                    pa = self.browser.page_agent.state()
                    self._recent_page_agent_state = pa.get("content", "")
                    self._page_agent_url = pa.get("url", "")
                    after_state_hash = self._page_agent_state_hash()
                    no_effect = before_state_hash == after_state_hash

                    # Network correlation is independent of UI presentation state.
                    # The response and fresh Page-Agent state are the sources of truth.
                    response_evidence = {}
                    if tool in {"click_element_by_index", "upload_file"} or (tool == "select_dropdown_option" and getattr(config, "CORRELATE_NETWORK_ON_SELECT", False)) or (tool in {"input_text", "input_text_batch"} and getattr(config, "CORRELATE_NETWORK_ON_INPUTS", False)):
                        try:
                            response_evidence = self._collect_action_network_evidence(
                                tool, arguments, actions_count,
                                wait_for_click_ms=getattr(config, "ACTION_NETWORK_PROBE_MS", 450),
                            )
                            self._last_action_response_evidence = response_evidence or {}
                            response_note = self._format_action_response_evidence(response_evidence)
                            if response_note:
                                observation += "\n\n=== CORRELATED NETWORK RESPONSE ===\n" + response_note
                        except Exception as net_exc:
                            observation += f"\n(network correlation failed: {str(net_exc)[:240]})"

                    transition_note = self._summarize_state_transition(before_pa, pa, tool, arguments)
                    self._last_dom_action = self._dom_action_signature(tool, arguments)
                    self._last_dom_action_state = after_state_hash
                    self._last_action_target = {"tool": tool, "arguments": dict(arguments or {})}
                    observation = transition_note + "\n" + observation
                    if no_effect:
                        observation += "\nNO OBSERVABLE PAGE-STATE CHANGE. The action may have had no effect, been blocked by a business rule, or targeted the wrong semantic surface. Inspect the CURRENT STATE and correlated response before retrying."

                    # Automatic diagnostics are observation-only and do not
                    # consume the browser action budget. This closes a gap in
                    # the old Page-Agent path where no-effect actions were only
                    # described to the model but not investigated.
                    if no_effect and config.OBSERVABILITY_ENABLED and config.OBSERVE_ON_NO_EFFECT:
                        try:
                            dbg = self._collect_observability("no_effect", requirement_id, actions_count)
                            if dbg:
                                observation += "\n\nRUNTIME DEBUG EVIDENCE:\n" + dbg
                        except Exception:
                            pass

                    # Optional composite capability: if the application just copied a URL and
                    # the mission explicitly asks to open that link in a new tab, do it immediately
                    # instead of spending model turns asking the operator to paste/open it.
                    if tool == "click_element_by_index" and getattr(config, "AUTO_FOLLOW_CLIPBOARD_LINKS", False):
                        if self._mission_requests_clipboard_link_follow(goal) and self._looks_like_copy_action(arguments, observation):
                            # Mark that a copy-link click was detected so the
                            # premature-finish guard can block INCONCLUSIVE/BLOCKED
                            # finish until the link is actually opened.
                            self._copy_link_click_detected = True
                            try:
                                auto_link_note = self._open_application_clipboard_link()
                                if auto_link_note.startswith("CLIPBOARD_LINK_OPENED"):
                                    observation += "\n" + auto_link_note
                                    self._human_command_action_count += 1
                                    # The active tab changed; the page-local controller
                                    # has already been invalidated inside
                                    # _open_application_clipboard_link, and the state
                                    # has been refreshed. Re-read the fresh state so
                                    # the loop's later state-based guards use the NEW
                                    # tab, not the old one.
                                    try:
                                        pa = self.browser.page_agent.state()
                                        self._recent_page_agent_state = pa.get("content", "")
                                        self._page_agent_url = pa.get("url", "")
                                    except Exception:
                                        pass
                                else:
                                    observation += "\n" + auto_link_note
                            except Exception as exc:
                                observation += (
                                    f"\nCLIPBOARD AUTO-FOLLOW SKIPPED: {str(exc)[:240]}"
                                    " You MUST call open_application_link explicitly NOW to open the copied link in a new tab."
                                    " Do NOT finish the mission with INCONCLUSIVE or BLOCKED — the link has been copied"
                                    " and the mission requires opening it. If open_application_link also fails,"
                                    " look for the link URL in the live DOM (readonly input, textarea, anchor href)"
                                    " and call open_new_tab with it."
                                )

                    self._runtime_recovery_action_count = 0
                    try:
                        pa, observation = self._auto_recover_rejected_challenge(
                            tool=tool, page_state=pa, observation=observation,
                            response_evidence=response_evidence,
                        )
                    except Exception as exc:
                        observation += f"\nRUNTIME RECOVERY ERROR: {str(exc)[:220]}"
                    recovery_extra = int(getattr(self, "_runtime_recovery_action_count", 0) or 0)
                    if recovery_extra:
                        actions_count += recovery_extra
                        self._runtime_recovery_action_count = 0
                        self._record_frame(actions_count)

                    if next_goal and next_goal != self._micro_goal and getattr(config, "USE_MICRO_GOAL_PLANNER", False):
                        self._micro_goal_completed.append(self._micro_goal)
                        self._micro_goal = next_goal

                    if next_goal and not getattr(config, "USE_MICRO_GOAL_PLANNER", False):
                        observation += "\nNEXT ATOMIC GOAL FROM PREVIOUS TURN: " + next_goal[:500]
                    if self._agent_memory:
                        observation += "\nAGENT MEMORY: " + self._agent_memory[:900]

                    self.store.record_action(tool, arguments, observation=observation, meta={"requirement_id": requirement_id, "architecture": "page-agent"})
                    loop_reason = self.policy.note_action(tool, arguments, before_state_hash=before_state_hash, after_state_hash=after_state_hash)
                    if loop_reason:
                        observation += f"\nLOOP DETECTED: {loop_reason}. Stop repeating this path."
                    self._record_frame(actions_count)
                    messages = self._append_turn(messages, decision, f"TOOL_RESULT {tool}: {observation}\n\nCURRENT PAGE STATE:\n{self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS]}")
                    self._last_action_summary = f"{tool}: {observation[:900]}"
                    if getattr(config, "USE_MICRO_GOAL_PLANNER", False):
                        next_micro, mission_done = self._plan_next_micro_goal(
                            mission_goal=str(goal or ""),
                            context=context or {},
                            current_goal=self._micro_goal,
                            last_action=self._last_action_summary,
                        )
                        if mission_done:
                            messages.append({
                                "role": "user",
                                "content": (
                                    "PLANNER UPDATE: the original mission is now satisfied. "
                                    "Do not perform another browser action. Return finish with "
                                    "the appropriate verdict based only on captured evidence."
                                ),
                            })
                        elif next_micro:
                            if next_micro != self._micro_goal:
                                self._micro_goal_completed.append(self._micro_goal)
                            self._micro_goal = next_micro
                            messages.append({
                                "role": "user",
                                "content": (
                                    "PLANNER UPDATE — CURRENT MICRO-GOAL ONLY:\n"
                                    + self._micro_goal
                                    + "\nDo not act on any other objective."
                                ),
                            })
                    if loop_reason:
                        outcome = AgentOutcome(verdict="BLOCKED", expected=goal, actual="execution stopped by loop detector", failure_reason=f"loop_detected: {loop_reason}", actions_count=actions_count, finished_normally=False)
                        break
                    continue
                except (ToolExecutionError, MCPError) as e:
                    actions_count += 1
                    observation = f"TOOL ERROR: {e}"
                    self.store.record_action(tool, arguments, observation=observation, error=str(e), meta={"requirement_id": requirement_id, "architecture": "page-agent"})
                    # On failure, collect auxiliary QA diagnostics, then one fresh Page-Agent state.
                    try:
                        pa = self.browser.page_agent.state()
                        self._recent_page_agent_state = pa.get("content", "")
                    except Exception:
                        pass
                    response_evidence = {}
                    try:
                        response_evidence = self._collect_action_network_evidence(
                            tool, arguments, actions_count
                        )
                        self._last_action_response_evidence = response_evidence or {}
                        response_note = self._format_action_response_evidence(response_evidence)
                        if response_note:
                            observation += "\n\n=== CORRELATED NETWORK RESPONSE AFTER TOOL ERROR ===\n" + response_note
                    except Exception:
                        pass
                    if config.OBSERVABILITY_ENABLED and config.OBSERVE_ON_ERROR:
                        try:
                            dbg = self._collect_observability("tool_error", requirement_id, actions_count)
                            if dbg: observation += "\n\nRUNTIME DEBUG EVIDENCE:\n" + dbg
                        except Exception: pass
                    messages = self._append_turn(messages, decision, f"TOOL_RESULT {tool}: {observation}\n\nCURRENT PAGE STATE:\n{self._recent_page_agent_state[:MAX_PAGE_AGENT_STATE_CHARS]}")
                    continue

            # --- ابزار MCP: اول سیاست، بعد اجرا ---
            # If the agent is navigating to the exact URL just received from
            # a human checkpoint, restore its immutable provenance metadata.
            if tool == "browser_navigate" and not arguments.get("navigation_evidence"):
                ev = self._last_navigation_evidence or {}
                if ev.get("navigation_target") == arguments.get("url"):
                    arguments = {**arguments, "navigation_evidence": ev}

            self.policy.set_observed_snapshot(getattr(self, "_recent_snapshot", ""))
            policy_check = self.policy.validate_action(tool, arguments)
            if not policy_check["approved"]:
                self.store.record_action(
                    tool, arguments,
                    observation=f"BLOCKED BY POLICY: "
                                f"{policy_check['reason']}",
                    meta={"requirement_id": requirement_id},
                )
                messages = self._append_turn(
                    messages, decision,
                    f"POLICY DENIED your action. Reason: "
                    f"{policy_check['reason']}. Choose a different "
                    f"compliant action or finish with BLOCKED.")
                continue

            # تایپ واقعی مثل کاربر (درخواست صریح کاربر):
            # fill یک‌جایی = رفتار paste؛ slowly=true → pressSequentially
            # = هر کاراکتر با keydown/keypress/input/keyup جدا.
            # اگر LLM خودش slowly تعیین کرده بود، دست نمی‌زنیم.
            if (tool == "browser_type" and config.REALISTIC_TYPING
                    and (not getattr(config, "FAST_MODE", False) or getattr(config, "FAST_KEEP_REALISTIC_TYPING", False))
                    and "slowly" not in arguments):
                arguments = self._prepare_realistic_type(arguments)

            # Generic multi-field input guard: if the live page exposes a
            # related group of single-character textboxes and the model tries
            # to type one character into one cell, do not execute the cell as
            # an isolated action. Ask the model to batch the grounded fields
            # with browser_fill_form. This is runtime-derived only; no OTP,
            # CAPTCHA, label, selector, field count, or site is hard-coded.
            if tool == "browser_type":
                batch_hint = self._multi_field_batch_hint(arguments)
                if batch_hint:
                    self.store.record_action(
                        tool, arguments, observation=batch_hint,
                        meta={"requirement_id": requirement_id,
                              "action_skipped": "multi_field_batch"},
                    )
                    messages = self._append_turn(messages, decision, batch_hint)
                    continue

            # navigation_evidence is engine metadata, not an MCP argument.
            # The policy validates it, then the browser receives only the
            # schema-supported URL/tool arguments.
            browser_arguments = dict(arguments)
            navigation_evidence = browser_arguments.pop("navigation_evidence", None)

            before_state_hash = self._current_state_hash()
            try:
                if tool in {"browser_navigate", "browser_navigate_back", "browser_navigate_forward"}:
                    self.browser.page_agent.mark_page_changed()
                result = self.browser.call_tool(tool, browser_arguments)
                actions_count += 1
                if tool == "browser_navigate" and navigation_evidence:
                    self._last_navigation_evidence = dict(navigation_evidence)
                    self.policy.register_navigation_evidence(navigation_evidence)

                observation = (result.text or "(no text output)")[:MAX_OBSERVATION_CHARS]

                # A successful typing action does not invalidate its grounded
                # ref. Do not make the model spend another turn on a full
                # snapshot merely to confirm a character was entered. If a
                # meaningful state transition is expected, the next action
                # can continue from the existing live refs; failures/no-effect
                # still trigger combined diagnostics below.
                if tool in ("browser_type", "browser_fill_form"):
                    observation += (
                        "\nTYPING ACTION SUCCEEDED: the grounded input action was "
                        "executed. Do not take a new browser_snapshot merely "
                        "to verify typing; continue with the current related "
                        "refs unless navigation, validation, tool error, or "
                        "another meaningful state change requires fresh evidence."
                    )

                # Combined post-action observation: keep a fresh structural
                # snapshot for live refs, but add richer evidence only when it
                # is useful (no-effect/tool-error/ambiguous interaction).
                if (config.MCP_AUTO_SNAPSHOT and not result.is_snapshot
                        and tool in _mutating_tools(self.browser)):
                    try:
                        snap = self.browser.snapshot()
                        observation += self._format_structural_observation(
                            snap.text, "FRESH STRUCTURAL STATE"
                        )
                        self._recent_snapshot = snap.text
                    except (MCPError, ToolExecutionError) as e:
                        observation += f"\n(auto structural observation failed: {e})"

                if result.is_snapshot:
                    self._recent_snapshot = result.text
                    observation = (
                        observation[:MAX_OBSERVATION_CHARS]
                        + self._snapshot_notes(result.text)
                    )

                # تصویر برگشت؟ ذخیره در شواهد
                if result.images:
                    self.store.save_screenshot(
                        f"req-{requirement_id or 'step'}-"
                        f"{actions_count:03d}",
                        image_b64=result.images[0])

                error_note = None

            except (ToolExecutionError, MCPError) as e:
                actions_count += 1
                error_note = str(e)
                observation = f"TOOL ERROR: {error_note[:MAX_OBSERVATION_CHARS]}"

                # Recovery still refreshes refs, but diagnostics are gathered
                # by the combined observer below instead of relying on snapshot
                # alone.
                if config.MCP_AUTO_SNAPSHOT and tool in _mutating_tools(self.browser):
                    try:
                        snap = self.browser.snapshot()
                        observation += self._format_structural_observation(
                            snap.text, "FRESH STRUCTURAL STATE AFTER ERROR"
                        )
                        self._recent_snapshot = snap.text
                    except (MCPError, ToolExecutionError) as snap_err:
                        observation += f"\n(recovery structural observation failed: {snap_err})"

            # Verify whether a mutating action produced a real state change.
            # Repeating an identical no-effect action is forbidden until the
            # evidence/state changes or the strategy changes.
            after_state_hash = self._current_state_hash()
            self.policy.note_no_effect(
                tool, arguments, before_state_hash, after_state_hash
            )
            no_effect = bool(
                before_state_hash and after_state_hash
                and before_state_hash == after_state_hash
                and tool in _mutating_tools(self.browser)
            )
            if no_effect:
                observation += (
                    "\n\nNO OBSERVABLE EFFECT: the post-action state is identical to "
                    "the pre-action state. Do not repeat this exact action "
                    "without new evidence; inspect/choose a different strategy."
                )

            # Combined diagnostics are observation-only and do not consume the
            # mission action budget. On failure/no-effect, collect targeted
            # find + screenshot + console/network evidence instead of blindly
            # taking another full snapshot.
            if (error_note or no_effect):
                try:
                    diagnostic = self._collect_combined_ui_diagnostics(
                        tool=tool, arguments=arguments, trigger=(
                            "tool_error" if error_note else "no_effect"
                        ), requirement_id=requirement_id,
                        action_index=actions_count,
                    )
                    if diagnostic:
                        observation += "\n\n" + diagnostic
                except Exception as diag_err:  # noqa: BLE001
                    observation += f"\n(combined diagnostics failed: {diag_err})"

            # ثبت شواهد + loop check
            action_meta = {"requirement_id": requirement_id}
            if tool == "browser_navigate":
                ev = arguments.get("navigation_evidence") or self._last_navigation_evidence
                if isinstance(ev, dict):
                    action_meta["navigation"] = {
                        "navigation_target": ev.get("navigation_target", arguments.get("url", "")),
                        "source": ev.get("source", ""),
                        "provenance": ev.get("provenance", ""),
                        "evidence": ev.get("evidence", ""),
                        "was_inferred": bool(ev.get("was_inferred", False)),
                        "external": bool(ev.get("external", False)),
                        "decision": ev.get("decision", "allow"),
                    }
            self.store.record_action(
                tool, arguments, observation, error=error_note,
                meta=action_meta,
            )
            state_hash = self._current_state_hash()
            loop_reason = self.policy.note_action(
                tool, arguments,
                before_state_hash=before_state_hash,
                after_state_hash=state_hash,
            )

            # Level-1 (اصل #۱۰): اگر ریدایرکت سرور ما را از allow-list
            # خارج کرده باشد از کد هشدار بدهیم — سیاستِ قبل از ناوبری
            # ریدایرکت‌های HTTP را نمی‌بیند؛ این چک «بعد از وقوع» است.
            drift_note = self._check_domain_drift(requirement_id)
            if drift_note:
                observation += drift_note

            # Smart observability is deliberately outside the action budget.
            # It runs automatically for tool errors/no-effect/error signals,
            # while the model can always call the read-only observability tools
            # itself when deeper diagnosis is needed.
            obs_trigger = None
            if error_note and config.OBSERVABILITY_ENABLED and config.OBSERVE_ON_ERROR:
                obs_trigger = "tool_error"
            elif no_effect and config.OBSERVABILITY_ENABLED and config.OBSERVE_ON_NO_EFFECT:
                obs_trigger = "no_effect"
            if obs_trigger:
                debug_evidence = self._collect_observability(
                    obs_trigger, requirement_id, actions_count)
                if debug_evidence:
                    observation += "\n\n=== RUNTIME DEBUG EVIDENCE ===\n" + debug_evidence

            # Every executed action can become a frame without consuming the
            # mission action budget. This is used to build the final GIF/MP4.
            self._record_frame(actions_count)

            if loop_reason:
                observation += (
                    f"\n\n⚠️ LOOP DETECTED BY ENGINE: {loop_reason}. "
                    f"Per Constitution #13 you must NOT retry the same "
                    f"path. Finish NOW with BLOCKED "
                    f"(failure_reason: loop)."
                )
                if loop_warned:
                    # یک بار هشدار دادیم و باز همان مسیر تکرار شد —
                    # توقف سخت (اصل #13: «دیگر یک بار امتحان می‌کنم» ممنوع)
                    outcome = AgentOutcome(
                        verdict="BLOCKED",
                        expected=goal,
                        actual="execution stopped by loop detector",
                        failure_reason=f"loop_detected: {loop_reason}",
                        actions_count=actions_count,
                        finished_normally=False,
                    )
                    self.store.record_action(
                        "loop_guard", {"reason": loop_reason},
                        observation="hard stop after repeated loop",
                        meta={"requirement_id": requirement_id},
                    )
                    break
                loop_warned = True

            messages = self._append_turn(
                messages, decision,
                f"TOOL_RESULT {tool}: {observation}")

            # budget نزدیک تمام شدن؟ خبر بده
            budget = self.policy.budget_report()
            if budget["actions_done"] >= budget["max_actions"] - 5:
                messages[-1]["content"] += (
                    "\n\n⚠️ BUDGET WARNING: nearly exhausted. Finish now "
                    "with your best verdict."
                )

        else:
            # حلقه بدون finish تمام شد
            outcome = AgentOutcome(
                verdict="INCONCLUSIVE",
                expected=goal,
                actual="agent did not finish within step limit",
                failure_reason="step_limit_reached",
                actions_count=actions_count,
                finished_normally=False,
            )

        if outcome is None:
            outcome = AgentOutcome(
                verdict="INCONCLUSIVE",
                expected=goal,
                failure_reason="agent loop ended unexpectedly",
                actions_count=actions_count,
                finished_normally=False,
            )

        outcome.findings = self._findings + outcome.findings
        outcome.actions_count = actions_count
        self._findings = []
        return outcome

    # -----------------------------------------------------------------
    # کمک‌کننده‌ها
    # -----------------------------------------------------------------

    def _plan_next_micro_goal(self, mission_goal, context, current_goal, last_action):
        """Ask a separate planning pass for exactly one next micro-goal.

        Planning is observation-only and does not consume the browser action
        budget. The actor never receives a request to solve the whole mission
        at once; it receives only this returned micro-goal.
        """
        state = getattr(self, "_recent_page_agent_state", "") or ""
        completed = list(self._micro_goal_completed[-12:])
        context_lines = []
        for key, value in (context or {}).items():
            if value and key != "base_url":
                context_lines.append(f"- {key}: {value}")
        mission_values = self.mission_inputs.values
        prompt = [
            MICRO_GOAL_PLANNER_PROMPT,
            "ORIGINAL MISSION:\n" + str(mission_goal),
        ]
        if mission_values:
            prompt.append(
                "IMMUTABLE MISSION VALUES:\n- " + "\\n- ".join(mission_values)
            )
        if context_lines:
            prompt.append("CONTEXT:\n" + "\\n".join(context_lines))
        if current_goal:
            prompt.append("PREVIOUS MICRO-GOAL:\n" + current_goal)
        if last_action:
            prompt.append("LAST ACTION RESULT:\n" + last_action[:1600])
        if completed:
            prompt.append("COMPLETED MICRO-GOALS (do not repeat):\n- " + "\\n- ".join(completed))
        prompt.append(
            "CURRENT LIVE PAGE-AGENT STATE:\n" + state[:MAX_PAGE_AGENT_STATE_CHARS]
        )
        try:
            decision = self.ai.chat_json([
                {"role": "system", "content": MICRO_GOAL_PLANNER_PROMPT},
                {"role": "user", "content": "\\n\\n".join(prompt)},
            ], temperature=0)
            goal = str(decision.get("goal", "") or "").strip()
            done = bool(decision.get("done", False))
            if done:
                return "", True
            if not goal:
                return current_goal or "", False
            # Keep the planner from accidentally producing a multi-step plan.
            if len(goal) > 360:
                goal = goal[:360].rsplit(" ", 1)[0].strip()
            return goal, False
        except Exception as exc:  # noqa: BLE001
            # Planner failure must not destroy the existing actor loop. Keep
            # the current atomic objective and let the actor recover from live
            # evidence rather than inventing a new objective in code.
            if current_goal:
                return current_goal, False
            return str(mission_goal).strip(), False

    def _compose_goal_message(self, goal, context, requirement_id, micro_goal=None):
        ctx = ""
        if context:
            ctx = "\n".join(
                f"- {k}: {v}" for k, v in context.items() if v
            )
        parts = [f"MISSION GOAL (requirement {requirement_id or '-'}):\n{goal}"]
        if micro_goal:
            parts.append(
                "CURRENT MICRO-GOAL (ONLY THIS OBJECTIVE):\n"
                + str(micro_goal)
                + "\n\nDo not work on any other mission objective in this turn."
            )
        mission_values = self.mission_inputs.values
        if mission_values:
            parts.append(
                "MISSION-PROVIDED LITERAL VALUES (immutable; reuse these values "
                "when the observed UI field semantically requires one; do not "
                "invent replacements):\n- " + "\n- ".join(mission_values)
            )
        if ctx:
            parts.append(f"CONTEXT:\n{ctx}")
        if self._agent_memory:
            parts.append("AGENT MEMORY (short, reusable, non-secret):\n" + self._agent_memory[:900])

        # وضعیت زنده‌ی صفحه — موتور خودش بعد از آخرین اکشن/ناوبریِ
        # اولیه snapshot گرفته. قبلاً این snapshot به LLM نشان داده
        # نمی‌شد و دور اولِ هر requirement صرفِ «دوباره snapshot گرفتن»
        # می‌شد (رفع «چرا همون اول پر نکرده input رو»).
        pa_state = getattr(self, "_recent_page_agent_state", "")
        if pa_state:
            parts.append(
                "CURRENT PAGE STATE (Page-Agent indexed interactive DOM; indices are current):\n"
                + pa_state[:MAX_PAGE_AGENT_STATE_CHARS]
            )
        else:
            snap = getattr(self, "_recent_snapshot", "")
            if snap:
                parts.append("AUXILIARY ACCESSIBILITY STATE:\n" + snap[:MAX_SNAPSHOT_CHARS])

        if self.mode == "explore" and self.mission_type == "exploratory":
            parts.append(
                "EXPLORATION TEST DISCIPLINE:\n"
                "- First inspect the page and act only on controls actually "
                "present in the CURRENT PAGE STATE. Never invent, translate, "
                "or substitute a control name or route; use the exact observed "
                "role/name/context and current live state. Do not assume field "
                "names, language, roles, or layout from previous sites.\n"
                "- For forms, cover representative partitions: empty, "
                "wrong type/format, too short/long, whitespace, special "
                "characters, and relevant boundary values. Use only cases "
                "supported by what the page exposes.\n"
                "- Never invent a valid credential or loop through random "
                "values just to find one. If the mission is negative "
                "testing, invalid values are sufficient unless a valid "
                "value is explicitly required by the observed flow.\n"
                "- Never guess CAPTCHA/OTP. Ask the human only when the "
                "real value is required; user-provided text means only "
                "that value was supplied, NOT that it was verified as "
                "correct.\n"
                "- After an invalid-input response, record the observed "
                "validation result and move to a different test partition. "
                "Do NOT repeat the same value or alternate between the "
                "same two invalid values.\n"
                "- If a test is blocked by a prerequisite such as CAPTCHA, "
                "continue with independent negative cases that do not "
                "require that prerequisite whenever possible.\n"
                "- Treat unexpected new tabs, redirects, blank pages, "
                "console errors, or broken UI as observations/findings, "
                "not as reasons to abandon unrelated tests."
            )

        parts.append(
            "Act in THIS turn on CURRENT MICRO-GOAL only. CURRENT PAGE STATE is the live indexed DOM. Perform ONE logical browser action that advances that goal. A logical batch is allowed when several independent text fields are simultaneously actionable: use one `input_text_batch`. For dropdowns, use one `select_dropdown_option` action instead of click-then-select. For file upload, use one `upload_file` action after the chooser is observed. If an index is not visible because the state is truncated, use find_elements for that single target. Do not enumerate the entire form or plan a future chain. Put a single `next_goal` in your response when useful; the engine will carry it forward without a separate planner call by default."
        )
        return "\n\n".join(parts)

    def _fast_grounded_form_batch(self):
        """High-confidence local fill for explicit mission literals.

        This is intentionally conservative: it never invents values and never
        auto-fills an ambiguous field. It trades a small amount of local matching
        work for avoiding an unnecessary LLM turn on obvious, uniquely-labelled
        fields while preserving semantic safety.
        """
        if not getattr(config, "FAST_MODE", False) or not getattr(config, "FAST_DIRECT_FORM_FILL", True):
            return []
        goal = str(getattr(self, "_mission_goal_text", "") or "")
        if not goal:
            return []

        import re
        patterns = {
            "phone": [
                r"(?:شماره\s*(?:موبایل|تلفن)|موبایل|تلفن(?:\s*همراه)?|phone|mobile)\s*(?:کاربر)?\s*(?:=|:|-)?\s*(09\d{9})",
            ],
            "national": [
                r"(?:کد\s*ملی|کدملی|national\s*code)\s*(?:کاربر)?\s*(?:=|:|-)?\s*(\d{10})",
            ],
            "title": [
                r"(?:عنوان|title)\s*(?:قرارداد|سند)?\s*(?:=|:|-)?\s*[«\"']([^»\"']{2,80})[»\"']",
            ],
            "serial": [
                r"(?:سریال(?:\s*پشت\s*کارت\s*ملی)?|serial)\s*(?:=|:|-)?\s*(\d{8,14})",
            ],
        }

        def mission_value(kind):
            for pat in patterns[kind]:
                m = re.search(pat, goal, flags=re.I)
                if m:
                    return m.group(1).strip()
            return None

        values = {k: mission_value(k) for k in patterns}
        # Never locally resolve a field type when the mission contains multiple
        # literal values of that same protocol type. A duplicate value is often
        # intentional for different semantic roles (e.g. creator vs signer).
        # Let the LLM use live context in that case instead of guessing.
        literal_counts = {
            "phone": len(re.findall(r"09\d{9}", goal)),
            "national": len(re.findall(r"(?<!\d)\d{10}(?!\d)", goal)),
            "serial": len(re.findall(r"(?<!\d)\d{8,14}(?!\d)", goal)),
        }
        for kind in ("phone", "national", "serial"):
            if literal_counts.get(kind, 0) > 1:
                values[kind] = None
        try:
            state = self.browser.page_agent.state()
            elements = state.get("elements", []) or []
        except Exception:
            return []

        filled_signatures = getattr(self, "_fast_filled_signatures", set())
        keyword_map = {
            "phone": ("شماره موبایل", "شماره تلفن", "تلفن همراه", "phone", "mobile", "telephone", "tel"),
            "national": ("کدملی", "کد ملی", "national code"),
            "title": ("عنوان", "title", "subject"),
            "serial": ("سریال", "serial"),
        }

        def texts(e):
            attrs = e.get("attrs") or {}
            raw = [
                e.get("name", ""), e.get("label", ""), attrs.get("aria-label", ""),
                attrs.get("name", ""), attrs.get("placeholder", ""), attrs.get("autocomplete", ""),
            ]
            raw.extend(e.get("context") or [])
            return [normalize_text(str(x)) for x in raw if str(x).strip()]

        def confidence(kind, e):
            ts = texts(e)
            kws = [normalize_text(x) for x in keyword_map[kind]]
            score = 0.0
            for t in ts:
                if t in kws:
                    score = max(score, 1.0)
                elif any(t == normalize_text(k) for k in keyword_map[kind]):
                    score = max(score, 0.98)
                elif any(t.startswith(normalize_text(k)) or normalize_text(k) in t for k in keyword_map[kind]):
                    score = max(score, 0.72)
            attrs = e.get("attrs") or {}
            attr_name = normalize_text(str(attrs.get("name", "")))
            if kind == "phone" and attr_name in {"phone", "mobile", "telephone", "tel"}:
                score = max(score, 1.0)
            if kind == "national" and attr_name in {"nationalcode", "national_code", "national-code"}:
                score = max(score, 1.0)
            if kind == "title" and attr_name in {"title", "subject"}:
                score = max(score, 1.0)
            if kind == "serial" and attr_name in {"serial", "serialnumber", "nationalcardserial"}:
                score = max(score, 1.0)
            return score

        candidates_by_kind = {k: [] for k in values}
        for e in elements:
            st = e.get("status") or {}
            if st.get("disabled") or st.get("readonly"):
                continue
            role = str(e.get("role") or "").lower()
            tag = str(e.get("tag") or "").lower()
            if role not in {"textbox", "searchbox", "spinbutton"} and tag not in {"input", "textarea"}:
                continue
            if str(e.get("value") or "").strip():
                continue
            for kind, value in values.items():
                if not value:
                    continue
                score = confidence(kind, e)
                if score >= getattr(config, "FAST_FORM_MIN_CONFIDENCE", 0.98):
                    candidates_by_kind[kind].append((score, e))

        mappings = []
        for kind, value in values.items():
            if not value:
                continue
            candidates = sorted(candidates_by_kind[kind], key=lambda x: (-x[0], int(x[1].get("index", 1 << 30))))
            if not candidates:
                continue
            best_score = candidates[0][0]
            best = [e for score, e in candidates if score == best_score]
            if getattr(config, "FAST_FORM_REQUIRE_UNIQUE_TARGET", True) and len(best) != 1:
                continue
            e = best[0]
            if kind == "phone" and not re.fullmatch(r"09\d{9}", value):
                continue
            if kind == "national" and not re.fullmatch(r"\d{10}", value):
                continue
            if kind == "serial" and not re.fullmatch(r"\d{8,14}", value):
                continue
            sig = (int(e.get("index", -1)), value)
            if sig in filled_signatures:
                continue
            mappings.append({"index": int(e["index"]), "text": value})

        return mappings[:max(1, int(getattr(config, "FAST_FORM_MAX_BATCH_ITEMS", 6)))]

    def _current_page_agent_element(self, index):
        try:
            page_agent = getattr(self.browser, "page_agent", None)
            state = page_agent.state() if page_agent else {}
            for element in state.get("elements", []) or []:
                if int(element.get("index", -1)) == int(index):
                    return element, state
        except Exception:
            pass
        return None, None

    @staticmethod
    def _dom_action_signature(tool, arguments):
        """Return a stable internal signature for a DOM action.

        Used only for loop/repetition guards. The signature deliberately
        includes the action arguments so a new OTP/CAPTCHA value or a different
        target is not mistaken for the same action. It is never written to the
        user-facing log.
        """
        safe_args = arguments if isinstance(arguments, dict) else {}
        try:
            payload = json.dumps(
                safe_args,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                default=str,
            )
        except Exception:
            payload = repr(safe_args)
        return f"{str(tool or '').strip()}::{payload}"

    @staticmethod
    def _phone_like_element(element):
        if not isinstance(element, dict):
            return False
        attrs = element.get("attrs") or {}
        blob = " ".join([
            str(element.get("name", "")), str(element.get("role", "")),
            str(attrs.get("name", "")), str(attrs.get("autocomplete", "")),
            str(attrs.get("inputmode", "")), str(attrs.get("placeholder", "")),
            " ".join(str(x) for x in (element.get("context") or [])),
        ]).lower()
        return any(term in blob for term in (
            "phone", "mobile", "telephone", "tel",
            "شماره موبایل", "شماره تلفن", "تلفن همراه",
        ))

    def _mission_has_literal_value(self, value):
        value = str(value or "").strip()
        if not value:
            return False
        corpus = self._mission_goal_text + " " + " ".join(
            str(v) for v in getattr(self.mission_inputs, "values", ())
        )
        human_values = " ".join(
            str(v) for v in (getattr(self.mission_state, "human_inputs", {}) or {}).values()
        )
        return value in corpus or value in human_values

    def _guard_uninvented_input(self, index, value):
        element, _ = self._current_page_agent_element(index)
        if not element or not self._phone_like_element(element):
            return None
        text_value = str(value or "").strip()
        if not text_value or self._mission_has_literal_value(text_value):
            return None
        return (
            "MISSING_REQUIRED_EXTERNAL_VALUE: phone/mobile target has no grounded value. "
            "Do not enter a sample or dummy value. Ask the human for the actual phone number."
        )

    @staticmethod
    def _normalize_page_agent_decision(decision):
        """Normalize Alibaba/Page-Agent-style action envelopes and legacy JSON.

        Preferred form:
          {evaluation_previous_goal, memory, next_goal, action:{tool:{...}}}
        Legacy form remains accepted for older local models.
        """
        if not isinstance(decision, dict):
            return {}
        out = dict(decision)
        action = decision.get("action")
        if isinstance(action, dict):
            tool = str(decision.get("tool") or "").strip()
            args = decision.get("arguments")
            if not tool and len(action) == 1:
                tool, payload = next(iter(action.items()))
                tool = str(tool).strip()
                args = payload if isinstance(payload, dict) else {}
            if tool:
                out["tool"] = tool
                out["arguments"] = args if isinstance(args, dict) else {}
        if "thought" not in out:
            out["thought"] = str(decision.get("evaluation_previous_goal") or "")[:400]
        if "arguments" not in out or not isinstance(out.get("arguments"), dict):
            out["arguments"] = {}
        if "tool" not in out:
            out["tool"] = ""
        if "next_goal" not in out:
            out["next_goal"] = ""
        return out

    @staticmethod
    def _state_element_key(element):
        if not isinstance(element, dict):
            return None
        try:
            return int(element.get("index", -1))
        except Exception:
            return None

    @staticmethod
    def _state_element_signature(element):
        if not isinstance(element, dict):
            return ""
        attrs = element.get("attrs") or {}
        status = element.get("status") or {}
        # Values are intentionally reduced to length/presence; sensitive values
        # must never enter the transition summary.
        return json.dumps({
            "name": element.get("name", ""),
            "role": element.get("role", ""),
            "kind": element.get("kind", ""),
            "tag": element.get("tag", ""),
            "valueLength": element.get("valueLength", 0),
            "disabled": bool(status.get("disabled")),
            "readonly": bool(status.get("readonly")),
            "requiredMissing": bool(status.get("requiredMissing")),
            "invalid": bool(status.get("invalid")),
            "countdown": status.get("countdown", ""),
            "disabledOwner": (status.get("disabledOwner") or {}).get("name", ""),
            "blockedBy": [x.get("name", "") for x in (status.get("blockedBy") or []) if isinstance(x, dict)],
            "prereq": [x.get("name", "") for x in (status.get("prerequisiteCandidates") or []) if isinstance(x, dict)],
            "placeholder": attrs.get("placeholder", ""),
        }, ensure_ascii=False, sort_keys=True)

    def _summarize_state_transition(self, before_state, after_state, tool, arguments):
        """Produce a compact evidence-backed description of what changed after an action."""
        if not isinstance(before_state, dict) or not isinstance(after_state, dict):
            return "ACTION OUTCOME: state transition unavailable."

        before = {self._state_element_key(e): e for e in (before_state.get("elements") or []) if self._state_element_key(e) is not None}
        after = {self._state_element_key(e): e for e in (after_state.get("elements") or []) if self._state_element_key(e) is not None}
        added = [k for k in after.keys() if k not in before]
        removed = [k for k in before.keys() if k not in after]
        changed = [k for k in after.keys() if k in before and self._state_element_signature(before[k]) != self._state_element_signature(after[k])]

        target_indices = []
        if isinstance(arguments, dict):
            if "index" in arguments:
                try: target_indices.append(int(arguments["index"]))
                except Exception: pass
            for item in arguments.get("items") or []:
                if isinstance(item, dict) and "index" in item:
                    try: target_indices.append(int(item["index"]))
                    except Exception: pass

        parts = [
            f"ACTION OUTCOME: tool={tool} targets={target_indices or 'n/a'}",
            f"url_changed={before_state.get('url','') != after_state.get('url','')} ",
            f"title_changed={before_state.get('title','') != after_state.get('title','')}",
            f"elements_added={len(added)} removed={len(removed)} changed={len(changed)}",
        ]

        if target_indices:
            target_lines = []
            for idx in target_indices[:8]:
                b, a = before.get(idx), after.get(idx)
                if not b and not a:
                    target_lines.append(f"[{idx}] no longer observed")
                    continue
                if b and not a:
                    target_lines.append(f"[{idx}] disappeared")
                    continue
                if a:
                    st = a.get("status") or {}
                    name = str(a.get("name") or "").strip()
                    role = str(a.get("role") or "").strip()
                    flags = []
                    if st.get("disabled"): flags.append("DISABLED")
                    if st.get("readonly"): flags.append("READONLY")
                    if st.get("requiredMissing"): flags.append("REQUIRED-EMPTY")
                    if st.get("invalid"): flags.append("INVALID")
                    before_len = int((b or {}).get("valueLength", 0) or 0)
                    after_len = int(a.get("valueLength", 0) or 0)
                    if before_len != after_len:
                        flags.append(f"valueLength {before_len}->{after_len}")
                    if before and self._state_element_signature(before) != self._state_element_signature(a):
                        flags.append("STATE_CHANGED")
                    target_lines.append(f"[{idx}] {role} {name!r} {'; '.join(flags) if flags else 'no observed state change'}")
            if target_lines:
                parts.append("TARGET EFFECTS: " + " | ".join(target_lines))

        if added:
            names = []
            for idx in added[:8]:
                e = after.get(idx) or {}
                names.append(f"[{idx}] {e.get('role','')} {str(e.get('name') or '')!r}")
            parts.append("NEW CONTROLS: " + " | ".join(names))
        if removed:
            names = []
            for idx in removed[:8]:
                e = before.get(idx) or {}
                names.append(f"[{idx}] {e.get('role','')} {str(e.get('name') or '')!r}")
            parts.append("REMOVED CONTROLS: " + " | ".join(names))

        def page_markers(state):
            info = state.get("pageInfo") or {}
            timers = info.get("timers") or []
            dialogs = []
            for line in str(state.get("content") or "").splitlines():
                if line.startswith("ACTIVE DIALOG:"):
                    dialogs.append(line[:240])
            return timers[:4], dialogs[:4]

        bt, bd = page_markers(before_state)
        at, ad = page_markers(after_state)
        if bt != at:
            parts.append(f"TIMERS_CHANGED: {json.dumps(at, ensure_ascii=False)[:700]}")
        if bd != ad:
            parts.append("DIALOG_STATE_CHANGED: " + " | ".join(ad or ["no active dialog"]))
        return "\n".join(parts)[:6500]


    def _guard_premature_finish(self, decision):
        """Prevent premature terminal decisions.

        Guards:
          1. After an explicit wait: re-observe before ending.
          2. After a copy-link click: don't let the LLM give up with
             INCONCLUSIVE/BLOCKED before the copied link has been opened
             in a new tab. The mission explicitly requires opening the
             link, so finishing without opening it is always premature.
        """
        verdict = str((decision or {}).get("verdict") or "").upper()
        if verdict not in {"BLOCKED", "INCONCLUSIVE", "FAIL", "FAILED", ""}:
            return ""
        recent = str(getattr(self, "_last_action_summary", "") or "").lower()

        # Guard 1: after an explicit wait.
        if any(term in recent for term in ("wait_completed", "explicit wait", "countdown")) and getattr(self, "_premature_finish_rejections", 0) < 1:
            self._premature_finish_rejections += 1
            return (
                "FINISH_REJECTED: the previous action was an explicit wait. Re-observe the current state before ending the mission."
            )

        # Guard 2: after a copy-link click, the link must be opened before
        # the mission can end. This prevents the LLM from giving up with
        # INCONCLUSIVE right after clicking "کپی لینک" when the auto-follow
        # failed (e.g. clipboard API blocked by user-activation requirements).
        if getattr(self, "_copy_link_click_detected", False) and not getattr(self, "_clipboard_link_opened", False):
            self._premature_finish_rejections += 1
            return (
                "FINISH_REJECTED: the mission requires opening the copied contract link in a new tab, "
                "but the link has NOT been opened yet. A copy-link click was detected, but the auto-follow "
                "did not open a new tab. You MUST call open_application_link NOW to read the clipboard/DOM "
                "and open the link. If that fails, look for the link URL in the live DOM (readonly input, "
                "textarea, anchor href) and call open_new_tab with it. Do NOT finish with INCONCLUSIVE or "
                "BLOCKED until the link is opened."
            )

        return ""

    def _settled_page_agent_state(self, first_state, action_tool=""):
        """Compatibility helper: no artificial delay or state polling."""
        return first_state, False

    @staticmethod
    def _page_agent_state_hash_from_state(state):
        if not isinstance(state, dict):
            return ""
        content = str(state.get("content") or "")
        return hashlib.sha256(content.encode("utf-8", "ignore")).hexdigest()

    def _append_turn(self, messages, decision, observation):
        messages.append({
            "role": "assistant",
            "content": json.dumps(decision, ensure_ascii=False),
        })
        messages.append({
            "role": "user",
            "content": observation,
        })
        # فشرده‌سازی تاریخچه — نتایج قدیمی کوتاه شوند
        return _compact_history(messages)

    _RESEND_TERMS = (
        "ارسال مجدد", "دوباره بفرست", "کد جدید بفرست", "مجدد بفرست",
        "send again", "resend", "resend otp", "send new code",
        "send a new code", "new otp", "new code",
    )
    _RESEND_ROLE_ALLOWLIST = {"button", "link", "menuitem", "menuitemradio", "menuitemcheckbox", "generic"}

    @staticmethod
    def _extract_wait_seconds(text):
        """Parse an OBSERVED cooldown duration; never invent a delay."""
        import re
        value = str(text or "").strip().lower()
        if not value:
            return None
        m = re.search(r"(\d{1,3})\s*(?:ثانیه|ثانیه‌|second|seconds|sec|secs)\b", value, re.I)
        if m:
            return max(0, min(int(m.group(1)) + 1, 60))
        m = re.search(r"\b(\d{1,2})\s*:\s*(\d{2})\b", value)
        if m:
            return max(0, min(int(m.group(1)) * 60 + int(m.group(2)) + 1, 60))
        return None

    @classmethod
    def _is_resend_candidate(cls, element, enabled_only=None):
        role = str(element.get("role") or "").strip().lower()
        if role not in cls._RESEND_ROLE_ALLOWLIST:
            return False
        name = str(element.get("name") or "").strip().lower()
        context = " ".join(str(x) for x in (element.get("context") or [])).lower()
        haystack = f"{name} {context}"
        if not any(term in haystack for term in cls._RESEND_TERMS):
            return False
        status = element.get("status") or {}
        disabled = bool(status.get("disabled"))
        if enabled_only is True and disabled:
            return False
        if enabled_only is False and not disabled:
            return False
        return True

    def _execute_human_resend_command(self):
        """Execute explicit operator resend using a live Page-Agent index."""
        self._pending_human_command = "RESEND_OTP"
        self._human_command_action_count = 0
        try:
            pa = self.browser.page_agent.state()
            self._recent_page_agent_state = pa.get("content", "")
        except Exception as exc:
            return f"HUMAN_COMMAND_BLOCKED: RESEND_OTP could not observe the live page: {exc}"

        def split(current):
            elems = current.get("elements", []) if isinstance(current, dict) else []
            enabled = [e for e in elems if isinstance(e, dict) and self._is_resend_candidate(e, True)]
            disabled = [e for e in elems if isinstance(e, dict) and self._is_resend_candidate(e, False)]
            return enabled, disabled

        enabled, disabled = split(pa)

        # Respect an observed cooldown. No guessed delay.
        if not enabled and disabled:
            durations = []
            for element in disabled:
                status = element.get("status") or {}
                seconds = self._extract_wait_seconds(status.get("countdown"))
                if seconds is not None:
                    durations.append(seconds)
            timers = (pa.get("pageInfo", {}) or {}).get("timers", []) if isinstance(pa, dict) else []
            if isinstance(timers, list):
                for timer in timers[:8]:
                    if isinstance(timer, dict):
                        seconds = self._extract_wait_seconds(timer.get("text"))
                        if seconds is not None:
                            durations.append(seconds)
            if durations:
                wait_seconds = max(0, min(max(durations), 60))
                try:
                    before_hash = self._page_agent_state_hash()
                    self.browser.page_agent.wait(wait_seconds)
                    self.store.record_action(
                        "wait",
                        {"seconds": wait_seconds, "source": "human_command_resend_timer"},
                        observation=f"Observed cooldown; waited {wait_seconds}s before resend.",
                        meta={"architecture": "page-agent", "source": "human_command"},
                    )
                    self.policy.note_action(
                        "wait", {"seconds": wait_seconds, "source": "human_command_resend"},
                        before_state_hash=before_hash, after_state_hash=before_hash,
                    )
                    self._human_command_action_count += 1
                    pa = self.browser.page_agent.state()
                    self._recent_page_agent_state = pa.get("content", "")
                    enabled, disabled = split(pa)
                except Exception as exc:
                    return f"HUMAN_COMMAND_BLOCKED: resend cooldown wait failed: {exc}"

        if len(enabled) == 1:
            target = enabled[0]
            index = int(target.get("index"))
            try:
                before_hash = self._page_agent_state_hash()
                result = self.browser.page_agent.click(index)
                pa_after = self.browser.page_agent.state()
                self._recent_page_agent_state = pa_after.get("content", "")
                after_hash = self._page_agent_state_hash()
                self.store.record_action(
                    "click_element_by_index",
                    {"index": index, "source": "human_command_resend"},
                    observation=(getattr(result, "text", "") or "Resend control clicked")[:1000],
                    meta={"architecture": "page-agent", "source": "human_command"},
                )
                self.policy.note_action(
                    "click_element_by_index",
                    {"index": index, "source": "human_command_resend"},
                    before_state_hash=before_hash, after_state_hash=after_hash,
                )
                self._human_command_action_count += 1
                self._pending_human_command = ""
                return (
                    f"HUMAN_COMMAND_EXECUTED: RESEND_OTP — clicked the uniquely observed enabled "
                    f"resend control [index={index}]. The previous OTP must not be reused. "
                    "The page was re-observed; now ask the operator for the NEW OTP."
                )
            except Exception as exc:
                return f"HUMAN_COMMAND_BLOCKED: could not click observed resend control: {exc}"

        if len(enabled) > 1:
            return (
                "HUMAN_COMMAND_PENDING: RESEND_OTP — multiple enabled resend-like controls are "
                "observed. Resolve the correct target from the CURRENT PAGE STATE; do not ask for OTP yet."
            )
        if disabled:
            details = []
            for element in disabled[:4]:
                timer = (element.get("status") or {}).get("countdown")
                if timer:
                    details.append(str(timer))
            extra = f" Observed cooldown: {' | '.join(details)}" if details else ""
            return (
                "HUMAN_COMMAND_PENDING: RESEND_OTP — resend is still disabled. Re-observe and "
                "wait using the observed timer; do not ask for OTP again yet." + extra
            )
        return (
            "HUMAN_COMMAND_PENDING: RESEND_OTP — no resend control is currently observed. "
            "Re-observe or find the semantic resend target; do not ask for OTP again yet."
        )

    @staticmethod
    def _normalize_human_command(answer):
        """Return a generic operator command for free-form checkpoint replies.

        This is deliberately language/label agnostic: it only recognizes
        common control intents, never site-specific selectors.
        """
        import re
        text_value = str(answer or "").strip().lower()
        compact = re.sub(r"[\s،,!.؟?]+", " ", text_value).strip()
        if not compact:
            return ""
        resend_patterns = QAReActAgent._RESEND_TERMS
        wait_patterns = (
            "صبر کن", "صبر", "منتظر بمون", "منتظر بمان", "wait",
            "wait a bit", "wait until timer",
        )
        if any(p in compact for p in resend_patterns):
            return "RESEND"
        if any(p in compact for p in wait_patterns):
            return "WAIT"
        return ""

    @staticmethod
    def _resolve_human_input_lifecycle(arguments, checkpoint, input_type):
        """Resolve human-input lifetime from runtime checkpoint semantics.

        This is intentionally site/field/label agnostic. Durable mission
        values (phone, ID, file path, etc.) remain immutable. Runtime
        challenge inputs are refreshable when the checkpoint explicitly marks
        them ephemeral, or when the tool declares a generic one-time/challenge
        input type. No page text, selector, field count, or site is inspected.
        """
        explicit = str(
            arguments.get("value_lifecycle")
            or checkpoint.get("value_lifecycle")
            or ""
        ).strip().lower()
        if explicit in {"ephemeral", "durable"}:
            return explicit

        normalized_type = str(input_type or "").strip().lower().replace("-", "_").replace(" ", "_")
        # Generic protocol-level categories only; these are not site labels.
        transient_types = {
            "captcha", "captcha_value", "one_time_code", "one_time_password",
            "verification_code", "verification_code_value", "otp", "otp_value",
            "runtime_challenge", "expiring_challenge",
        }
        if normalized_type in transient_types or normalized_type.endswith("_challenge"):
            return "ephemeral"

        if checkpoint.get("one_time") is True or checkpoint.get("expires") is True:
            return "ephemeral"

        # Generic challenge-language inference. This is deliberately based on
        # protocol concepts (OTP/CAPTCHA), not on any site's labels/selectors.
        question = str(arguments.get("question") or "").strip().lower()
        save_key = str(arguments.get("save_to") or "").strip().lower()
        challenge_terms = (
            "otp", "one-time", "one time", "verification code",
            "captcha", "کد تایید", "کد تأیید", "کد امنیتی",
        )
        if any(term in question for term in challenge_terms) or any(
            term in save_key for term in ("otp", "captcha", "verification_code", "challenge")
        ):
            return "ephemeral"
        return "durable"

    def _handle_ask_human(self, arguments):
        question = arguments.get("question", "Please provide the value:")
        save_to = str(arguments.get("save_to", "") or "")
        input_type = str(arguments.get("input_type", "OTHER_REQUIRED_EXTERNAL_INPUT"))
        checkpoint = dict(arguments.get("checkpoint") or {})
        value_lifecycle = self._resolve_human_input_lifecycle(
            arguments=arguments, checkpoint=checkpoint, input_type=input_type
        )
        ephemeral = value_lifecycle == "ephemeral"

        checkpoint_key = save_to or f"checkpoint_{len(self.mission_state.checkpoints) + 1}"
        if checkpoint:
            try:
                self.mission_state.declare_checkpoint(checkpoint_key, checkpoint)
            except ValueError as exc:
                return f"HUMAN_CHECKPOINT_REJECTED: {exc}"

        self.mission_inputs.begin_clarification(question, save_to)
        answer = self.human_input_fn(question)

        # Free-form interactive replies can be operational commands. In
        # particular, "ارسال مجدد" must never be treated as an OTP value.
        human_command = self._normalize_human_command(answer)
        if human_command:
            self.mission_inputs.clear_clarification()
            if human_command == "RESEND":
                return self._execute_human_resend_command()
            return (
                "HUMAN_COMMAND: WAIT. The operator asked to wait rather than provide the runtime "
                "value. Do not treat the response as OTP/CAPTCHA; inspect any observed timer/cooldown "
                "and wait, then re-observe."
            )

        # If the human explicitly confirms the value already referenced by
        # the clarification question (for example, "same" / "همونه"),
        # resolve it back to the immutable mission value. This is not a new
        # value and never mutates user data.
        resolved = self.mission_inputs.resolve_confirmation(answer)
        if resolved is not None:
            answer = resolved
            resolution_note = (
                " Clarification resolved to the single mission-provided value "
                "explicitly referenced by the question."
            )
        else:
            resolution_note = ""

        # Fast path for transient human values: if the live Page-Agent DOM
        # exposes one unambiguous group of single-character inputs whose
        # cardinality matches the received value, fill the whole group in one
        # browser action. This is runtime-derived and intentionally contains
        # no CAPTCHA/OTP labels, selectors, field counts, or site knowledge.
        auto_batch_note = ""
        if ephemeral and str(answer or "").strip():
            try:
                group_res = self.browser.page_agent.find_input_group(str(answer))
                group = self.browser.page_agent._decode_mcp_json(group_res.text, default=None)
                if isinstance(group, dict) and group.get("indices"):
                    indices = [int(x) for x in group.get("indices", [])]
                    value = str(answer)
                    if len(indices) == len(value):
                        items = [
                            {"index": idx, "text": ch}
                            for idx, ch in zip(indices, value)
                        ]
                        self.browser.page_agent.input_batch(items)
                        self._active_runtime_challenge = {
                            "input_type": input_type,
                            "ephemeral": True,
                            "indices": indices,
                            "length": len(value),
                            "submitted": False,
                            "awaiting_new_value": False,
                        }
                        auto_batch_note = (
                            f" AUTO_BATCH_INPUT: filled {len(items)} observed single-character "
                            "inputs in one Page-Agent action."
                        )
            except Exception as exc:  # noqa: BLE001
                auto_batch_note = f" AUTO_BATCH_INPUT skipped: {str(exc)[:180]}"

        if self._active_runtime_challenge and ephemeral and str(answer or "").strip():
            self._active_runtime_challenge["awaiting_new_value"] = False
            self._active_runtime_challenge["submitted"] = False

        if save_to:
            # Do not persist an empty operator response. Empty submissions
            # are common when the interactive prompt is advanced accidentally;
            # storing them would make the later real CAPTCHA/OTP collide with
            # the immutable-input ledger. A non-empty response is committed
            # once and then reused for this checkpoint.
            if str(answer or "").strip():
                try:
                    self.mission_state.set_human_input(
                        save_to, answer, ephemeral=ephemeral
                    )
                    self.context_vars[save_to] = answer
                except ValueError as exc:
                    return (
                        f"HUMAN_INPUT_REJECTED: {exc}. The checkpoint value "
                        "already exists; reuse the previously accepted value "
                        "instead of asking for a replacement."
                    )
            else:
                self.mission_inputs.clear_clarification()
                return (
                    "HUMAN_INPUT_PENDING: no value was supplied. Do not "
                    "treat this as the actual CAPTCHA/OTP value and do not "
                    "write an empty value into mission state. Ask the human "
                    "again only when the real runtime value is still required."
                )

        # Human input is immutable, but its provenance depends on the request
        # context. Arbitrary human URLs are explicitly NOT trusted.
        if checkpoint_requests_application_artifact(checkpoint):
            artifact_type = str(
                checkpoint.get("requested_artifact_type", "url")
            ).strip().lower()
            if artifact_type == "url" and not valid_url(answer):
                return (
                    f"HUMAN_ARTIFACT_REJECTED: expected a valid {
                        checkpoint.get('expected_format', 'url')} artifact"
                )

            artifact = make_artifact(
                artifact_type=artifact_type,
                value=answer,
                source=str(checkpoint.get("source_context", "human_checkpoint")),
                provenance="human_confirmed_application_artifact",
                evidence="human response to an explicit application-artifact checkpoint",
                confidence=1.0,
            )
            self.mission_state.add_artifact(artifact.as_dict())
            if artifact_type == "url":
                ev = build_navigation_evidence(
                    answer,
                    source="human_checkpoint",
                    provenance="human_confirmed_application_artifact",
                    evidence=(
                        "human supplied the exact application artifact requested by "
                        "the immutable checkpoint"
                    ),
                    was_inferred=False,
                    initial_url=self._initial_url,
                )
                self._last_navigation_evidence = ev.as_dict()
                self.policy.register_navigation_evidence(self._last_navigation_evidence)
        elif valid_url(answer):
            # Explicitly classify a free-form human URL as untrusted. This
            # prevents "human_provided" from becoming an implicit allow-list.
            artifact = make_artifact(
                artifact_type="url",
                value=answer,
                source="human_checkpoint" if checkpoint else "human_input",
                provenance="arbitrary_human_url",
                evidence="no application-artifact checkpoint established",
                confidence=1.0,
            )
            self.mission_state.add_artifact(artifact.as_dict())
            self._last_navigation_evidence = build_navigation_evidence(
                answer,
                source="human_checkpoint" if checkpoint else "human_input",
                provenance="arbitrary_human_url",
                evidence="human supplied URL without an application-artifact trust scope",
                was_inferred=False,
                initial_url=self._initial_url,
            ).as_dict()

        self.mission_inputs.clear_clarification()
        return (
            f"HUMAN_INPUT (saved as {save_to or 'anonymous'}; "
            f"input_type={input_type}; lifecycle={value_lifecycle}; "
            f"checkpoint={checkpoint_key}): {answer}"
            + resolution_note
            + auto_batch_note
        )

    def _handle_finding(self, arguments, requirement_id):
        finding = {
            "description": str(arguments.get("description", ""))[:400],
            "severity": str(arguments.get("severity", "info")),
            "note": str(arguments.get("note", ""))[:400],
            "requirement_id": requirement_id,
            "url": self._current_url_hint(),
        }
        # اسکرین‌شات برای یافته
        idx = len(self._findings) + 1
        name = f"finding-{idx:03d}"
        rel = (f".evidence/runs/{self.store.run_id}"
               f"/evidence/{name}.png")
        try:
            self.browser.call_tool(
                "browser_take_screenshot",
                {"filename": rel, "type": "png"},
            )
            finding["evidence"] = self.store.register_screenshot(name, rel)
        except Exception:                              # noqa: BLE001
            try:
                res = self.browser.call_tool(
                    "browser_take_screenshot", {"type": "png"})
                if res.images:
                    finding["evidence"] = self.store.save_screenshot(
                        name, image_b64=res.images[0])
            except Exception:                          # noqa: BLE001
                pass
        saved = self.store.add_finding(finding)
        self._findings.append(saved)
        return saved

    def _budget_exhausted(self, actions_count):
        """One hard budget boundary for local and shared run counters."""
        maximum = int(self.policy.max_actions)
        return actions_count >= maximum or self.policy.actions_done >= maximum

    def _has_unresolved_validation_evidence(self):
        """Conservative, generic check for unresolved form validation signals."""
        import re
        snapshot = str(getattr(self, "_recent_snapshot", "") or "")
        patterns = (
            r"aria-invalid\s*[:=]\s*[\"']?true",
            r"role\s*[:=]\s*[\"']?alert",
            r"\b(validation error|invalid field|required field|is required)\b",
            r"\b(error|invalid)\b",
            r"الزامی|نامعتبر|خطا",
        )
        return any(re.search(pattern, snapshot, re.IGNORECASE)
                   for pattern in patterns)

    def _outcome_from_final(self, decision, goal, actions_count):
        final = decision.get("arguments") or decision
        verdict = str(final.get("verdict", "INCONCLUSIVE")).upper().strip()
        if verdict not in VERDICTS:
            verdict = "INCONCLUSIVE"
        reason = str(final.get("failure_reason", ""))[:300]

        # Exploratory runs discover and report; they do not prove a test PASS.
        if verdict == "PASS" and self.mode == "explore":
            verdict = "INCONCLUSIVE"
            reason = reason or "exploratory runs do not establish a PASS verdict"
        elif verdict == "PASS" and self._has_unresolved_validation_evidence():
            verdict = "INCONCLUSIVE"
            reason = reason or "unresolved validation evidence prevents PASS"

        return AgentOutcome(
            verdict=verdict,
            expected=str(final.get("expected", ""))[:400] or goal,
            actual=str(final.get("actual", ""))[:400],
            failure_reason=reason,
            reasoning=str(final.get("reasoning", ""))[:500],
            findings=final.get("findings") or [],
            actions_count=actions_count,
            finished_normally=True,
        )

    def _guard_scroll_before_action(self, thought, goal, direction_down=True, index=None):
        """Enforce evidence-first scrolling before any Page-Agent scroll action.

        A scroll is a navigation/search strategy, not a default way to look for
        an element. If the current live Page-Agent state already contains a
        semantic target grounded in the mission/thought, scrolling is blocked
        and the observed target index is returned to the model.

        No site-specific labels, selectors, routes, or field names are used.
        """
        try:
            state = self.browser.page_agent.state()
            elements = state.get("elements") or []
            if not isinstance(elements, list):
                elements = []
            self._recent_page_agent_state = state.get("content", "")
            self._page_agent_url = state.get("url", "")
        except Exception as exc:  # noqa: BLE001
            return {
                "blocked": True,
                "reason": "state_unavailable",
                "message": f"SCROLL BLOCKED: current Page-Agent state could not be observed: {exc}",
            }

        candidates = self._find_current_state_targets(elements, thought, goal)
        if candidates:
            lines = [
                "SCROLL BLOCKED: a semantic target already exists in the CURRENT live Page-Agent state.",
                "Do not scroll. Activate the observed target index directly.",
                "Observed targets:",
            ]
            for item in candidates[:5]:
                lines.append(
                    f"- index={item['index']} role={item['role']} name={item['name']!r} "
                    f"context={item['context']!r} evidence={item['evidence']}"
                )
            return {
                "blocked": True,
                "reason": "target_present_in_current_state",
                "targets": candidates,
                "message": "\n".join(lines),
            }

        # A scroll is only allowed when the live page exposes actual scroll
        # distance in the requested direction. This is evidence, not a guess.
        try:
            evidence = self.browser.page_agent.scroll_evidence(index)
        except Exception as exc:  # noqa: BLE001
            return {
                "blocked": True,
                "reason": "scroll_evidence_unavailable",
                "message": f"SCROLL BLOCKED: could not establish scroll evidence: {exc}",
            }

        scope = evidence.get("target") if index is not None else evidence.get("page")
        if not isinstance(scope, dict):
            return {
                "blocked": True,
                "reason": "scroll_evidence_missing",
                "message": "SCROLL BLOCKED: no observed scrollability evidence exists for the requested scroll target.",
            }

        can_move = bool(scope.get("canDown" if direction_down else "canUp"))
        if not can_move:
            direction = "down" if direction_down else "up"
            return {
                "blocked": True,
                "reason": "no_scroll_distance",
                "evidence": evidence,
                "message": (
                    f"SCROLL BLOCKED: the current live page provides no observed scroll distance {direction}. "
                    "Do not repeat this scroll. Re-evaluate the current interactive state."
                ),
            }

        return {
            "blocked": False,
            "reason": "target_absent_and_scroll_evidence_present",
            "evidence": evidence,
        }

    @staticmethod
    def _find_current_state_targets(elements, thought, goal):
        """Find targets already present in the current indexed DOM.

        Matching is deliberately conservative: exact phrase evidence is
        preferred; otherwise a multi-token semantic phrase from the mission or
        the model's current thought must be represented by the candidate's
        observed name/context. Generic role words alone can never trigger the
        guard.
        """
        import re

        source_text = "\n".join([str(goal or ""), str(thought or "")])
        phrases = []
        # Quoted text is strong target evidence, while still being runtime
        # generated rather than site-specific.
        for pattern in (r'"([^"\n]{2,120})"', r"'([^'\n]{2,120})'", r'«([^»\n]{2,120})»'):
            phrases.extend(m.group(1).strip() for m in re.finditer(pattern, source_text))

        # Add longer natural-language fragments from the mission. These are
        # used only when they exactly occur in an observed candidate.
        normalized_source = normalize_text(source_text)
        source_tokens = list(tokens(normalized_source))
        stop = {
            "the", "a", "an", "to", "of", "and", "or", "for", "in", "on", "at",
            "is", "are", "be", "with", "from", "page", "button", "field", "element",
            "دکمه", "فیلد", "عنصر", "صفحه", "روی", "را", "به", "در", "و", "برای", "از",
            "کن", "کنم", "باید", "می", "شود", "است", "که", "یک", "تا", "با",
        }
        meaningful = [t for t in source_tokens if t not in stop and len(t) >= 2]
        if len(meaningful) >= 2:
            # Keep short windows; this avoids treating the whole mission as a
            # target while still catching natural phrases such as an action
            # label that appears verbatim in the current state.
            for width in (5, 4, 3, 2):
                if len(meaningful) >= width:
                    phrases.extend(" ".join(meaningful[i:i + width]) for i in range(len(meaningful) - width + 1))

        # Preserve order and remove duplicates.
        seen_phrases = set()
        phrases = [p for p in phrases if not (normalize_text(p) in seen_phrases or seen_phrases.add(normalize_text(p)))]

        role_noise = {"button", "link", "textbox", "generic", "input", "select", "combobox", "treeitem"}
        matches = []
        seen_indices = set()
        for element in elements:
            if not isinstance(element, dict):
                continue
            # Scroll containers are evidence targets, not actionable mission
            # controls. They must not cause the evidence-first scroll guard to
            # block a legitimate scroll just because their subtree text matches
            # the requested target.
            if str(element.get("kind") or "") == "scroll-container":
                continue
            idx = element.get("index")
            if idx in seen_indices:
                continue
            name = str(element.get("name") or "").strip()
            context = " ".join(str(x) for x in (element.get("context") or [])).strip()
            haystack = normalize_text(f"{name} {context}")
            if not haystack:
                continue

            evidence = None
            for phrase in phrases:
                pt = tokens(phrase)
                if len(pt) < 2:
                    continue
                pn = normalize_text(phrase)
                if pn and pn in haystack:
                    evidence = f"exact observed phrase: {phrase}"
                    break
                if all(token in set(haystack.split()) for token in pt):
                    evidence = f"all requested tokens observed: {phrase}"
                    break
            if evidence:
                role = str(element.get("role") or "").lower()
                # A generic container matching the phrase is not sufficient
                # when an actionable child also exists.
                if role in role_noise and not name:
                    continue
                matches.append({
                    "index": idx,
                    "role": element.get("role", ""),
                    "name": name,
                    "context": context,
                    "evidence": evidence,
                })
                seen_indices.add(idx)
        return matches

    @staticmethod
    def _looks_like_challenge_rejection(page_state, observation="", response_evidence=None):
        """Detect a rejected one-time challenge using separated evidence sources.

        Never infer rate limiting from HTTP 429 alone. A 429 coming from an
        unrelated endpoint or an application-specific validation response must
        remain unclassified unless its own response explicitly proves throttling.
        """
        import re
        if not isinstance(page_state, dict):
            page_state = {}
        response_evidence = response_evidence or {}

        def _challenge_rejection(text):
            blob = str(text or "")
            if not blob:
                return False
            patterns = (
                r"(?:otp|one[- ]time|verification|authentication|activation|challenge|کد\s*(?:تأیید|تایید|فعال(?:ساز|سازی)?|امنیتی)?|رمز)"
                r".{0,120}(?:invalid|incorrect|wrong|rejected|expired|failed|denied|نامعتبر|نادرست|اشتباه|رد\s*شد|منقضی|خطا)",
                r"(?:invalid|incorrect|wrong|rejected|expired|failed|denied|نامعتبر|نادرست|اشتباه|رد\s*شد|منقضی|خطا)"
                r".{0,120}(?:otp|one[- ]time|verification|authentication|activation|challenge|کد\s*(?:تأیید|تایید|فعال(?:ساز|سازی)?|امنیتی)?|رمز)",
            )
            return any(re.search(pattern, blob, re.I) for pattern in patterns)

        # Strong DOM validation signal.
        for element in page_state.get("elements", []) or []:
            if not isinstance(element, dict):
                continue
            status = element.get("status") or {}
            if status.get("invalid"):
                return True, "element state=INVALID"
            if status.get("validationMessage") and _challenge_rejection(
                " ".join([
                    str(element.get("name") or ""),
                    " ".join(str(x) for x in (element.get("context") or [])),
                    str(status.get("validationMessage")),
                ])
            ):
                return True, "challenge validation message indicates rejection"

        # Page text alone can prove a rejection when the challenge context and
        # failure wording are in the same observable string.
        page_content = str(page_state.get("content") or "")
        if _challenge_rejection(page_content):
            return True, re.sub(r"\s+", " ", page_content)[-900:]

        # Response evidence is already correlated to the action by the network
        # probe; flags here are based on the response headers/body itself.
        if response_evidence.get("rate_limit_confirmed"):
            return True, "correlated response explicitly indicates rate limiting"
        if response_evidence.get("challenge_response_rejected"):
            return True, "correlated response explicitly indicates challenge rejection"

        # Do not combine a generic HTTP error with challenge page text. Only a
        # self-contained observation containing both challenge and rejection
        # semantics may trigger the fallback.
        obs = str(observation or "")
        if not response_evidence and _challenge_rejection(obs):
            return True, re.sub(r"\s+", " ", obs)[-900:]

        return False, ""

    @staticmethod
    def _parse_network_request_list(text):
        """Parse Playwright MCP's numbered request list."""
        import re
        out = []
        pattern = re.compile(
            r"(?m)^\s*(\d+)\.\s+\[([^\]]+)\]\s+(\S+)\s+=>\s+\[(\d{3})\](?:\s+(.*))?$"
        )
        for m in pattern.finditer(str(text or "")):
            out.append({
                "index": int(m.group(1)),
                "method": m.group(2).strip().upper(),
                "url": m.group(3).strip(),
                "status": int(m.group(4)),
                "status_text": (m.group(5) or "").strip(),
            })
        return out

    @staticmethod
    def _response_contains_rate_limit(response_body, response_headers, detail=""):
        """Require explicit throttling evidence; HTTP 429 alone is insufficient."""
        import re
        headers = str(response_headers or "")
        body = str(response_body or "")
        detail = str(detail or "")
        header_re = re.compile(
            r"(?im)(?:^\s*(?:retry-after|x-ratelimit-[^:\n]+|ratelimit-[^:\n]+)\s*:|\b(?:retry-after|x-ratelimit-|ratelimit-))"
        )
        explicit_re = re.compile(
            r"(?:too\s+many\s+requests|rate[- ]?limit(?:ed|ing)?|throttl(?:e|ed|ing)|محدودیت\s*نرخ|تعداد\s+درخواست(?:ها|ها)?\s*(?:زیاد|بیش از حد))",
            re.I,
        )
        return bool(header_re.search(headers) or explicit_re.search(body) or explicit_re.search(detail))

    @staticmethod
    def _response_contains_challenge_rejection(response_body, response_headers, detail=""):
        """Detect explicit challenge rejection inside the correlated response."""
        import re
        blob = " ".join(str(x or "") for x in (response_body, response_headers, detail))
        patterns = (
            r"(?:otp|one[- ]time|verification|authentication|activation|challenge|کد\s*(?:تأیید|تایید|فعال(?:ساز|سازی)?|امنیتی)?|رمز)"
            r".{0,120}(?:invalid|incorrect|wrong|rejected|expired|failed|denied|نامعتبر|نادرست|اشتباه|رد\s*شد|منقضی|خطا)",
            r"(?:invalid|incorrect|wrong|rejected|expired|failed|denied|نامعتبر|نادرست|اشتباه|رد\s*شد|منقضی|خطا)"
            r".{0,120}(?:otp|one[- ]time|verification|authentication|activation|challenge|کد\s*(?:تأیید|تایید|فعال(?:ساز|سازی)?|امنیتی)?|رمز)",
        )
        return any(re.search(p, blob, re.I) for p in patterns)

    def _prime_network_cursor(self):
        """Initialize a page-local network cursor without interpreting responses."""
        if "browser_network_requests" not in getattr(self.browser, "tools", {}):
            return False
        try:
            res = self.browser.call_tool(
                "browser_network_requests", {"static": False}, timeout=20
            )
            items = self._parse_network_request_list(res.text or "")
            self._network_seen_max = max((x["index"] for x in items), default=0)
            self._network_seen_page_url = getattr(self, "_page_agent_url", "") or ""
            return True
        except (MCPError, ToolExecutionError):
            return False

    @staticmethod
    def _format_action_response_evidence(evidence):
        """Safe compact response evidence for the LLM."""
        if not evidence:
            return ""
        lines = [
            f"new_requests={evidence.get('new_request_count', 0)}, failed={evidence.get('failed_request_count', 0)}"
        ]
        for item in (evidence.get("requests") or [])[-8:]:
            lines.append(
                f"#{item.get('index')} {item.get('method')} {item.get('url')} => "
                f"[{item.get('status')}] {item.get('status_text', '')}".strip()
            )
        selected = evidence.get("selected_response") or {}
        if selected:
            lines.append(
                f"SELECTED RESPONSE #{selected.get('index')}: {selected.get('method')} {selected.get('url')} => "
                f"[{selected.get('status')}] {selected.get('status_text', '')} response_checked={bool(selected.get('response_checked'))}"
            )
            sh = redact_text(str(selected.get("response_headers") or ""))[:900]
            sb = redact_text(str(selected.get("response_body") or ""))[:1800]
            if sh:
                lines.append("selected_response_headers=" + sh)
            if sb:
                lines.append("selected_response_body=" + sb)
        for detail in (evidence.get("failed_details") or [])[-5:]:
            safe_headers = redact_text(str(detail.get("response_headers") or ""))[:1800]
            safe_body = redact_text(str(detail.get("response_body") or ""))[:2200]
            lines.append(
                f"RESPONSE #{detail.get('index')}: classification={detail.get('classification')} "
                f"rate_limit_confirmed={bool(detail.get('rate_limit_confirmed'))} "
                f"challenge_response_rejected={bool(detail.get('challenge_response_rejected'))}"
            )
            if safe_headers:
                lines.append("response_headers=" + safe_headers)
            if safe_body:
                lines.append("response_body=" + safe_body)
        return "\n".join(lines)[:5200]

    def _collect_action_network_evidence(self, tool, arguments=None, action_index=None, wait_for_click_ms=None):
        """Correlate newly observed HTTP responses with the just-executed action.

        For click-like actions, poll the MCP network list briefly after the click so
        an asynchronously emitted/in-flight application request is not missed.
        The poll is observation-only and never consumes browser action budget.
        """
        if not config.OBSERVABILITY_ENABLED or "browser_network_requests" not in self.browser.tools:
            return {}
        try:
            listing = self.browser.call_tool(
                "browser_network_requests", {"static": False}, timeout=20
            )
        except (MCPError, ToolExecutionError):
            return {}

        current_url = getattr(self, "_page_agent_url", "") or ""
        prev_url = getattr(self, "_network_seen_page_url", "") or ""
        prev_max = int(getattr(self, "_network_seen_max", 0) or 0)
        if current_url and prev_url and current_url != prev_url:
            prev_max = 0

        def _new_items_from(text):
            parsed = self._parse_network_request_list(text or "")
            return parsed, [item for item in parsed if item["index"] > prev_max]

        items, new_items = _new_items_from(listing.text or "")
        # A click may emit fetch/XHR after the DOM handler returns. Give the
        # request observer a bounded, adaptive window rather than adding an
        # unconditional sleep to every action.
        if not new_items and tool == "click_element_by_index":
            budget_ms = int(wait_for_click_ms if wait_for_click_ms is not None else getattr(config, "ACTION_NETWORK_PROBE_MS", 1200))
            budget_ms = max(0, min(budget_ms, 15000))
            interval_ms = max(50, min(int(getattr(config, "ACTION_NETWORK_POLL_MS", 100)), 500))
            deadline = time.monotonic() + (budget_ms / 1000.0)
            while time.monotonic() < deadline and not new_items:
                remaining = max(0.0, deadline - time.monotonic())
                time.sleep(min(interval_ms / 1000.0, remaining))
                try:
                    listing = self.browser.call_tool(
                        "browser_network_requests", {"static": False}, timeout=20
                    )
                except (MCPError, ToolExecutionError):
                    break
                items, new_items = _new_items_from(listing.text or "")

        self._network_seen_max = max((item["index"] for item in items), default=prev_max)
        self._network_seen_page_url = current_url
        if not new_items:
            return {}

        failed = [item for item in new_items if item["status"] >= 400]
        evidence = {
            "action_index": action_index,
            "action_tool": tool,
            "new_request_count": len(new_items),
            "failed_request_count": len(failed),
            "requests": new_items[-8:],
            "failed_details": [],
        }
        for item in failed[-5:]:
            detail = dict(item)
            if "browser_network_request" in self.browser.tools:
                try:
                    full = self.browser.call_tool(
                        "browser_network_request", {"index": item["index"]}, timeout=20
                    )
                    detail["detail"] = (full.text or "")[:8000]
                except (MCPError, ToolExecutionError):
                    detail["detail"] = ""
                try:
                    hdr = self.browser.call_tool(
                        "browser_network_request", {"index": item["index"], "part": "response-headers"}, timeout=20
                    )
                    detail["response_headers"] = (hdr.text or "")[:5000]
                except (MCPError, ToolExecutionError):
                    detail["response_headers"] = ""
                try:
                    body = self.browser.call_tool(
                        "browser_network_request", {"index": item["index"], "part": "response-body"}, timeout=20
                    )
                    detail["response_body"] = (body.text or "")[:7000]
                except (MCPError, ToolExecutionError):
                    detail["response_body"] = ""
            detail["rate_limit_confirmed"] = (
                item["status"] == 429
                and self._response_contains_rate_limit(
                    detail.get("response_body"), detail.get("response_headers"), detail.get("detail")
                )
            )
            detail["challenge_response_rejected"] = self._response_contains_challenge_rejection(
                detail.get("response_body"), detail.get("response_headers"), detail.get("detail")
            )
            if item["status"] == 429 and not detail["rate_limit_confirmed"]:
                detail["classification"] = "http_429_unclassified"
            elif detail["rate_limit_confirmed"]:
                detail["classification"] = "confirmed_rate_limit"
            elif detail["challenge_response_rejected"]:
                detail["classification"] = "challenge_rejected"
            else:
                detail["classification"] = "http_error_unclassified"
            evidence["failed_details"].append(detail)

        # For click actions, inspect the actual response of the most likely
        # application request even when it is successful. Prefer mutating HTTP
        # methods (POST/PUT/PATCH/DELETE); fall back to the newest request.
        # This gives the next decision concrete response evidence instead of
        # making it infer success from a loading button or unchanged DOM.
        if tool == "click_element_by_index" and new_items and "browser_network_request" in self.browser.tools:
            mutating = [d for d in new_items if d.get("method") in {"POST", "PUT", "PATCH", "DELETE"}]
            candidates = mutating or new_items
            chosen_request = candidates[-1]
            success_detail = dict(chosen_request)
            try:
                full = self.browser.call_tool(
                    "browser_network_request", {"index": chosen_request["index"]}, timeout=20
                )
                success_detail["detail"] = (full.text or "")[:8000]
            except (MCPError, ToolExecutionError):
                success_detail["detail"] = ""
            try:
                hdr = self.browser.call_tool(
                    "browser_network_request", {"index": chosen_request["index"], "part": "response-headers"}, timeout=20
                )
                success_detail["response_headers"] = (hdr.text or "")[:5000]
            except (MCPError, ToolExecutionError):
                success_detail["response_headers"] = ""
            # Successful responses are cheap to classify from status + detail + headers.
            # Fetch the full response body only when explicitly enabled or when the
            # request is not actually successful; this keeps ordinary clicks fast.
            if chosen_request.get("status", 0) >= 400 or getattr(config, "COLLECT_SUCCESS_RESPONSE_BODY", False):
                try:
                    body = self.browser.call_tool(
                        "browser_network_request", {"index": chosen_request["index"], "part": "response-body"}, timeout=20
                    )
                    success_detail["response_body"] = (body.text or "")[:7000]
                except (MCPError, ToolExecutionError):
                    success_detail["response_body"] = ""
            else:
                success_detail["response_body"] = ""
            success_detail["response_checked"] = bool(
                success_detail.get("detail") or success_detail.get("response_headers") or success_detail.get("response_body")
            )
            evidence["selected_response"] = success_detail

        relevant = [
            d for d in evidence["failed_details"]
            if d.get("rate_limit_confirmed") or d.get("challenge_response_rejected")
        ]
        if relevant:
            chosen = relevant[-1]
            evidence.update({
                "response_status": chosen.get("status"),
                "response_url": chosen.get("url"),
                "response_body": chosen.get("response_body", ""),
                "response_headers": chosen.get("response_headers", ""),
                "detail": chosen.get("detail", ""),
                "rate_limit_confirmed": bool(chosen.get("rate_limit_confirmed")),
                "challenge_response_rejected": bool(chosen.get("challenge_response_rejected")),
                "classification": chosen.get("classification"),
            })
        return evidence

    def _resend_state(self, page_state):
        elems = page_state.get("elements", []) if isinstance(page_state, dict) else []
        enabled = [e for e in elems if isinstance(e, dict) and self._is_resend_candidate(e, True)]
        disabled = [e for e in elems if isinstance(e, dict) and self._is_resend_candidate(e, False)]
        return enabled, disabled

    def _observed_cooldown_seconds(self, page_state, disabled_controls):
        durations = []
        for element in disabled_controls or []:
            status = element.get("status") or {}
            sec = self._extract_wait_seconds(status.get("countdown"))
            if sec is not None:
                durations.append(sec)
        timers = (page_state.get("pageInfo", {}) or {}).get("timers", []) if isinstance(page_state, dict) else []
        if isinstance(timers, list):
            for timer in timers[:8]:
                if isinstance(timer, dict):
                    sec = self._extract_wait_seconds(timer.get("text"))
                    if sec is not None:
                        durations.append(sec)
        return max(durations) if durations else None

    def _clear_active_challenge_fields(self, page_state):
        """Clear old one-time challenge cells using fresh indices from current state."""
        challenge = self._active_runtime_challenge or {}
        length = int(challenge.get("length") or 0)
        if length < 2:
            return page_state, False
        try:
            res = self.browser.page_agent.find_input_group_by_length(length)
            group = self.browser.page_agent._decode_mcp_json(res.text, default=None)
            if not isinstance(group, dict) or not group.get("indices"):
                return page_state, False
            indices = [int(x) for x in group.get("indices", [])]
            if len(indices) != length:
                return page_state, False
            items = [{"index": idx, "text": ""} for idx in indices]
            self.browser.page_agent.input_batch(items)
            self.store.record_action(
                "input_text_batch",
                {"items": items, "source": "runtime_challenge_clear"},
                observation="Cleared previously rejected one-time challenge fields before requesting a new value.",
                meta={"architecture": "page-agent", "source": "runtime_recovery"},
            )
            self._runtime_recovery_action_count += 1
            page_state = self.browser.page_agent.state()
            self._recent_page_agent_state = page_state.get("content", "")
            self._page_agent_url = page_state.get("url", "")
            return page_state, True
        except Exception:
            return page_state, False

    def _auto_recover_rejected_challenge(self, tool, page_state, observation, response_evidence=None):
        """After a rejected one-time challenge, issue a fresh challenge before asking again."""
        challenge = self._active_runtime_challenge
        if not challenge or not challenge.get("ephemeral") or challenge.get("awaiting_new_value"):
            return page_state, observation
        if tool == "click_element_by_index":
            challenge["submitted"] = True
        if not challenge.get("submitted"):
            return page_state, observation
        rejected, rejection_evidence = self._looks_like_challenge_rejection(
            page_state, observation=observation, response_evidence=response_evidence
        )
        if not rejected:
            return page_state, observation
        enabled, disabled = self._resend_state(page_state)
        if not enabled and not disabled:
            return page_state, observation
        if len(enabled) > 1:
            return page_state, observation + "\nRUNTIME RECOVERY PENDING: multiple resend-like controls are observed; do not ask for a replacement value yet."

        for _ in range(3):
            if len(enabled) == 1:
                break
            seconds = self._observed_cooldown_seconds(page_state, disabled)
            if seconds is None:
                break
            seconds = max(0, min(int(seconds), 60))
            if seconds > 0:
                try:
                    self.browser.page_agent.wait(seconds)
                    self.store.record_action(
                        "wait",
                        {"seconds": seconds, "source": "runtime_challenge_recovery"},
                        observation=f"Observed challenge cooldown before resend; waited {seconds}s.",
                        meta={"architecture": "page-agent", "source": "runtime_recovery"},
                    )
                    self._runtime_recovery_action_count += 1
                except Exception as exc:
                    return page_state, observation + f"\nRUNTIME RECOVERY BLOCKED: cooldown wait failed: {exc}"
            try:
                page_state = self.browser.page_agent.state()
                self._recent_page_agent_state = page_state.get("content", "")
                self._page_agent_url = page_state.get("url", "")
            except Exception as exc:
                return page_state, observation + f"\nRUNTIME RECOVERY BLOCKED: fresh observation failed: {exc}"
            enabled, disabled = self._resend_state(page_state)
            if not enabled and not disabled:
                break

        if len(enabled) != 1:
            return page_state, observation + "\nRUNTIME RECOVERY PENDING: challenge was rejected, but an enabled resend target is not uniquely available yet. Do not request another challenge value."

        index = int(enabled[0].get("index"))
        try:
            self.browser.page_agent.click(index)
            self.store.record_action(
                "click_element_by_index",
                {"index": index, "source": "runtime_challenge_recovery"},
                observation="Clicked the uniquely observed enabled resend/retry control after rejected challenge.",
                meta={"architecture": "page-agent", "source": "runtime_recovery"},
            )
            self._runtime_recovery_action_count += 1
            page_state = self.browser.page_agent.state()
            self._recent_page_agent_state = page_state.get("content", "")
            self._page_agent_url = page_state.get("url", "")
        except Exception as exc:
            return page_state, observation + f"\nRUNTIME RECOVERY BLOCKED: resend click failed: {exc}"

        page_state, cleared = self._clear_active_challenge_fields(page_state)
        challenge["submitted"] = False
        challenge["awaiting_new_value"] = True
        return page_state, (
            observation
            + "\nRUNTIME RECOVERY EXECUTED: the one-time challenge was rejected. "
            "Observed cooldown was respected, a fresh resend/retry control was clicked, "
            + ("the old challenge fields were cleared, " if cleared else "")
            + "and the page was re-observed. The rejected value MUST NOT be reused. Now ask the human for the NEW challenge value."
            + (f" Evidence: {rejection_evidence}" if rejection_evidence else "")
        )

    @staticmethod
    def _looks_like_copy_action(arguments, observation):
        blob = " ".join(str(arguments.get(k, "")) for k in ("element", "target", "label", "text"))
        blob += " " + str(observation or "")
        return any(term in blob.lower() for term in ("copy", "copied", "کپی", "کپی شد"))

    @staticmethod
    def _mission_requests_clipboard_link_follow(goal):
        blob = str(goal or "").lower()
        return (any(x in blob for x in ("clipboard", "کپی", "لینک", "link"))
                and any(x in blob for x in ("تب جدید", "تب تازه", "new tab", "new browser tab")))

    @staticmethod
    def _extract_url_from_text(text):
        """Extract the first valid HTTP(S) URL from a free-form text blob."""
        if not text:
            return ""
        # Strip surrounding quotes/whitespace first; the URL may be the whole text.
        candidate = text.strip().strip('\"\' `\n\r')
        if valid_url(candidate):
            return candidate
        # Otherwise scan for an embedded URL. Prefer URLs that look like the
        # application host (absolute http/https URLs).
        import re
        matches = re.findall(r'https?://[^\s\'"<>]+', text)
        for m in matches:
            m = m.rstrip('.,);]')
            if valid_url(m):
                return m
        return ""

    @staticmethod
    def _extract_all_urls_from_text(text, mission_host=""):
        """Extract ALL valid HTTP(S) URLs from a text blob, best-first.

        Ranking (highest priority first):
          1. URLs containing 'token' in the full URL string (query or fragment).
             Share links almost always carry a token parameter — this is the
             strongest signal and must rank above same-host navigation links.
          2. URLs sharing the mission host and containing a query/fragment.
          3. Any URL with a query/fragment (even on a different host).
          4. URLs sharing the mission host with a path.
          5. Any other absolute URL with a path.
        Returns a list of URLs, best first. Never constructs or guesses a URL.
        """
        if not text:
            return []
        import re
        raw_matches = re.findall(r'https?://[^\s\'"<>]+', text)
        urls = []
        seen = set()
        for m in raw_matches:
            m = m.rstrip('.,);]»«')
            if valid_url(m) and m not in seen:
                seen.add(m)
                urls.append(m)
        if not urls:
            return []

        def score(u):
            try:
                p = urlparse(u)
            except Exception:
                return (0, 0, 0, 0)
            host = (p.hostname or "").lower()
            has_query = bool(p.query)
            has_fragment = bool(p.fragment)
            has_path = bool(p.path and p.path != "/")
            host_match = 1 if mission_host and host == mission_host else 0
            token_like = 1 if (has_query or has_fragment) else 0
            # 'token' anywhere in the URL string is the strongest share-link
            # signal. This catches both ?token=... and #/portal?token=... (SPA
            # hash routing) patterns. Must rank ABOVE host_match so an external
            # share link like https://sign-sandbox.farashenasa.ir/#/portal?token=abc
            # is preferred over a same-host nav link like https://app.example.test/dashboard.
            has_token = 1 if "token" in u.lower() else 0
            return (has_token, host_match, token_like, 1 if has_path else 0)

        return sorted(urls, key=score, reverse=True)

    def _extract_url_from_page_agent_state(self):
        """Search the current Page-Agent state text for a URL.

        This is instant (no browser call) and uses the indexed DOM text we
        already have. The state includes element values, names, text content
        and attributes — any visible URL in a readonly input, anchor, or text
        node appears here.
        """
        state_text = getattr(self, "_recent_page_agent_state", "") or ""
        if not state_text:
            return ""
        mission_host = ""
        try:
            mission_host = urlparse(self._initial_url or "").hostname or ""
        except Exception:
            mission_host = ""
        urls = self._extract_all_urls_from_text(state_text, mission_host)
        return urls[0] if urls else ""

    def _read_application_clipboard(self):
        """Read the application clipboard via the trusted runtime.

        Returns the raw text or empty string. Never raises — callers decide
        how to react when the clipboard is empty/unreadable.
        """
        if "browser_evaluate" not in getattr(self.browser, "tools", {}):
            return ""
        try:
            # Some applications write to the clipboard asynchronously right
            # after the copy click. Wait briefly so the write completes.
            time.sleep(0.1)
            result = self.browser.call_tool(
                "browser_evaluate",
                {"function": "async () => { try { return await navigator.clipboard.readText(); } catch (e) { return ''; } }"},
            )
            raw = (result.text or "").strip()
            # browser_evaluate may wrap a string result; normalize conservatively.
            return raw.strip('\"\' `\n\r')
        except Exception:
            return ""

    def _scan_dom_for_share_link(self):
        """Aggressive DOM scan for an application-copied URL.

        Used as a fallback when the clipboard API is unavailable (HTTP sites).
        Collects URLs from every visible text source in the page: body text,
        input/textarea values, anchor hrefs, and data-url/data-href attributes.
        Returns the best-ranked URL or empty string.
        """
        if "browser_evaluate" not in getattr(self.browser, "tools", {}):
            return ""
        mission_host = ""
        try:
            mission_host = urlparse(self._initial_url or "").hostname or ""
        except Exception:
            mission_host = ""
        # One single browser_evaluate that gathers ALL URL-bearing text at once.
        # This is deliberately broad: any absolute http(s) URL the page is
        # rendering is a candidate. We never construct or guess a URL.
        js_probe = (
            "async () => {\n"
            "  const out = [];\n"
            "  const seen = new Set();\n"
            "  const push = (v) => {\n"
            "    if (v == null) return;\n"
            "    const s = String(v).trim();\n"
            "    if (!s) return;\n"
            "    if (seen.has(s)) return;\n"
            "    seen.add(s);\n"
            "    out.push(s);\n"
            "  };\n"
            "  // 1) ALL visible text on the page — catches URLs in any element.\n"
            "  try { push(document.body.innerText); } catch (_) {}\n"
            "  try { push(document.body.textContent); } catch (_) {}\n"
            "  // 2) input/textarea values (readonly share-link fields).\n"
            "  document.querySelectorAll('input, textarea').forEach((el) => {\n"
            "    try { push(el.value); } catch (_) {}\n"
            "    try { push(el.getAttribute('data-url')); } catch (_) {}\n"
            "    try { push(el.getAttribute('data-href')); } catch (_) {}\n"
            "    try { push(el.getAttribute('data-clipboard-text')); } catch (_) {}\n"
            "  });\n"
            "  // 3) anchors and elements with href/data-url/data-href.\n"
            "  document.querySelectorAll('a[href], [data-url], [data-href], [data-clipboard-text]').forEach((el) => {\n"
            "    try { push(el.getAttribute('href')); } catch (_) {}\n"
            "    try { push(el.getAttribute('data-url')); } catch (_) {}\n"
            "    try { push(el.getAttribute('data-href')); } catch (_) {}\n"
            "    try { push(el.getAttribute('data-clipboard-text')); } catch (_) {}\n"
            "  });\n"
            "  // 4) Walk shadow DOM roots on common custom-element hosts.\n"
            "  document.querySelectorAll('*').forEach((el) => {\n"
            "    if (el.shadowRoot) {\n"
            "      try { push(el.shadowRoot.textContent); } catch (_) {}\n"
            "      el.shadowRoot.querySelectorAll('input, textarea, a[href]').forEach((inner) => {\n"
            "        try { push(inner.value || inner.getAttribute('href')); } catch (_) {}\n"
            "      });\n"
            "    }\n"
            "  });\n"
            "  return JSON.stringify(out);\n"
            "}\n"
        )
        try:
            result = self.browser.call_tool("browser_evaluate", {"function": js_probe})
            raw = (result.text or "").strip()
            # Decode the JSON array the probe returns.
            import json as _json
            try:
                arr = _json.loads(raw)
            except Exception:
                try:
                    arr = _json.loads(raw.strip('\"\' `\n\r'))
                except Exception:
                    arr = []
            if not isinstance(arr, list):
                return ""
            # Collect all valid URLs from all text blobs, then rank them.
            all_urls = []
            seen = set()
            for item in arr:
                if not isinstance(item, str):
                    continue
                for u in self._extract_all_urls_from_text(item, mission_host):
                    if u not in seen:
                        seen.add(u)
                        all_urls.append(u)
            return all_urls[0] if all_urls else ""
        except Exception:
            return ""

    def _extract_url_from_network_evidence(self):
        """Search the last action's network response evidence for a URL.

        When the application copies a share link, the link is often returned
        by an API call. Even if the response body is not collected, the
        request URL itself or a Location header may contain the share link.
        """
        evidence = getattr(self, "_last_action_response_evidence", {}) or {}
        if not evidence:
            return ""
        mission_host = ""
        try:
            mission_host = urlparse(self._initial_url or "").hostname or ""
        except Exception:
            mission_host = ""
        blobs = []
        # Request URLs from new requests.
        for req in (evidence.get("requests") or []):
            blobs.append(str(req.get("url") or ""))
        # Selected response.
        sel = evidence.get("selected_response") or {}
        if sel:
            blobs.append(str(sel.get("url") or ""))
            blobs.append(str(sel.get("response_headers") or ""))
            blobs.append(str(sel.get("response_body") or ""))
        # Failed request details.
        for det in (evidence.get("failed_details") or []):
            blobs.append(str(det.get("url") or ""))
            blobs.append(str(det.get("response_headers") or ""))
            blobs.append(str(det.get("response_body") or ""))
        combined = " ".join(blobs)
        urls = self._extract_all_urls_from_text(combined, mission_host)
        return urls[0] if urls else ""

    def _resolve_application_link_url(self):
        """Resolve the application-copied URL using multiple strategies.

        Returns (url, source, provenance, evidence_text, candidates) or
        (None, "", "", "", candidates) when no URL is found. ``candidates``
        is a list of all URLs discovered, for the error message.

        Strategy order (clipboard FIRST — it is the most reliable source
        after a 'copy link' click):
          1. Trusted clipboard read (navigator.clipboard.readText).
             Works on HTTPS. Returns empty on HTTP.
          2. Page-Agent state text (instant, no browser call). Only used
             if the clipboard failed. The state text is searched with
             token-aware ranking so share links rank above nav links.
          3. Aggressive DOM scan (body innerText + inputs + hrefs + shadow).
          4. Network response evidence (API-returned link).
        """
        mission_host = ""
        try:
            mission_host = urlparse(self._initial_url or "").hostname or ""
        except Exception:
            mission_host = ""

        # Strategy 1: trusted clipboard read (most reliable after a copy action).
        raw = self._read_application_clipboard()
        if raw:
            candidate = self._extract_url_from_text(raw)
            if candidate:
                return (candidate, "application_clipboard", "clipboard_from_application",
                        "trusted runtime read of application clipboard after copy action",
                        [candidate])

        # Strategy 2: page_agent state text (instant, no browser call).
        # Only reached if the clipboard failed (HTTP sites, permissions, etc.).
        state_url = self._extract_url_from_page_agent_state()
        if state_url:
            return (state_url, "page_agent_state", "application_generated",
                    "URL found in the current Page-Agent indexed DOM state",
                    [state_url])

        # Strategy 3: aggressive DOM scan (body text + inputs + hrefs + shadow roots).
        dom_url = self._scan_dom_for_share_link()
        if dom_url:
            return (dom_url, "application_dom", "application_generated",
                    "URL observed in the live application DOM after copy action",
                    [dom_url])

        # Strategy 4: network response evidence (API-returned link).
        net_url = self._extract_url_from_network_evidence()
        if net_url:
            return (net_url, "network_response", "application_generated",
                    "URL found in the network response of the copy action",
                    [net_url])

        # Collect all candidate URLs for the error message.
        state_text = getattr(self, "_recent_page_agent_state", "") or ""
        all_candidates = self._extract_all_urls_from_text(state_text, mission_host)
        return (None, "", "", "", all_candidates)

    def _open_application_clipboard_link(self):
        """Read the application-copied URL and open it in a new tab.

        Uses a multi-strategy resolver: page-agent state text → clipboard →
        aggressive DOM scan → network response evidence. This works even on
        HTTP sites where the clipboard API is blocked, because the URL is
        almost always also rendered in the DOM or returned by an API.
        """
        url, source, provenance, evidence_text, candidates = \
            self._resolve_application_link_url()

        if not url:
            # Build a helpful error message that includes any candidate URLs
            # found in the state, so the LLM can use open_new_tab directly.
            hint = ""
            if candidates:
                hint = (
                    f" Candidate URLs observed in the current page state: "
                    f"{', '.join(candidates[:3])}. You can call open_new_tab "
                    f"with one of these URLs."
                )
            raise MCPError(
                "could not resolve the application-copied URL: clipboard is "
                "empty/unreadable, no URL was found in the live DOM, and no "
                "URL was found in the network response." + hint
            )

        evidence = build_navigation_evidence(
            url, source=source, provenance=provenance,
            evidence=evidence_text,
            was_inferred=False, initial_url=self._initial_url, decision="approved"
        ).as_dict()
        self._last_navigation_evidence = evidence
        self.policy.register_navigation_evidence(evidence)
        check = self.policy.validate_action(
            "browser_navigate", {"url": url, "navigation_evidence": evidence}
        )
        if not check["approved"]:
            raise MCPError(check["reason"])

        # Open the URL in a new tab. Playwright MCP switches focus to the new
        # tab automatically; we must invalidate the page-local controller so
        # the next state() call installs it on the NEW tab, not the old one.
        tab_result = self.browser.call_tool("browser_tabs", {"action": "new", "url": url})
        try:
            self.browser.page_agent.mark_page_changed()
            # Brief settle for the new tab's initial navigation.
            time.sleep(0.2)
            pa = self.browser.page_agent.state()
            self._recent_page_agent_state = pa.get("content", "")
            self._page_agent_url = pa.get("url", "")
        except Exception:
            pass

        # Never put the URL into LLM-facing observation or evidence text.
        new_url_display = ""
        try:
            new_url_display = str(self._page_agent_url or "")[:120]
        except Exception:
            new_url_display = ""
        self.store.record_action(
            "open_application_link", {},
            observation="Opened application-copied URL in a new tab.",
            meta={
                "architecture": "playwright-capability",
                "provenance": provenance,
                "source": source,
                "new_tab_url_host": urlparse(new_url_display).hostname if new_url_display else "",
            },
        )
        # Mark that the clipboard link has been opened so the premature-finish
        # guard no longer blocks finish verdicts on this account.
        self._clipboard_link_opened = True
        return (
            "CLIPBOARD_LINK_OPENED: application-copied URL opened in a NEW browser tab. "
            "The CURRENT active tab is now the NEW tab. The CURRENT PAGE STATE below "
            "reflects the NEW tab — use those indices to interact with the new page. "
            "Do NOT call read_clipboard or open_application_link again; do NOT go back "
            "to the contracts list. Continue the mission on the NEW tab."
        )

    def _page_agent_state_hash(self):
        state = getattr(self, "_recent_page_agent_state", "") or ""
        url = getattr(self, "_page_agent_url", "") or ""
        return hashlib.md5((url + "\n" + state).encode("utf-8")).hexdigest()[:16]

    def _current_state_hash(self):
        snap = getattr(self, "_recent_snapshot", "")
        if snap:
            index = SnapshotIndex(snap)
            return index.state_hash
        return None

    def _prepare_realistic_type(self, arguments):
        """
        تایپ انسانی: slowly=true → pressSequentially (هر کاراکتر با
        keydown/keypress/input/keyup جدا).
        ⚠ پاک‌سازی فیلد پرشده دیگر اینجا انجام نمی‌شود — لایه‌ی
        mcp_client با snapshot «تازه» تشخیص می‌دهد و fill("") می‌زند
        (اینجا snapshot ممکن است کهنه باشد → کلیک/تایپ اشتباه).
        """
        return {**arguments, "slowly": True}

    def _check_domain_drift(self, requirement_id=None):
        """
        آیا ریدایرکت HTTP ما را از allowed_domains خارج کرده؟
        (تقویت کد-محور Level-1: سیاست فقط URL «درخواستی» را قبل از
        ناوبری چک می‌کند؛ URL نهایی صفحه بعد از ریدایرکت اینجا چک
        می‌شود — یک بار برای هر دامنه‌ی خارج، یافته از سوی خودِ موتور
        ثبت و به مشاهده‌ی agent تزریق می‌شود. قبلاً LLM علاوه بر این،
        یک دور کامل هم صرف report_finding برای همین رویداد می‌کرد —
        F-001 در لاگ واقعی کاربر؛ حالا آن دور حذف شده است.)
        """
        snap = getattr(self, "_recent_snapshot", "")
        if not snap:
            return ""
        try:
            url = SnapshotIndex(snap).url
        except Exception:                                      # noqa: BLE001
            return ""
        if not url:
            return ""
        try:
            parsed = urlparse(url)
        except ValueError:
            return ""
        # فقط صفحه‌های واقعی وب — about:blank و ... خطا نیست
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            return ""

        # این تابع فقط drift بعد از navigation را مشاهده می‌کند؛
        # مجوز navigation در check_navigation و قبل از browser_navigate اعمال می‌شود.
        # تغییر origin به‌تنهایی هرگز نباید mission را متوقف کند.

        check = self.policy.check_navigation(
            url, self._last_navigation_evidence or {}
        )
        if check["ok"]:
            return ""

        host = (parsed.hostname or "").lower()
        seen = getattr(self, "_domain_drift_seen", None)
        if seen is None:
            seen = set()
            self._domain_drift_seen = seen
        if host in seen:
            return ""
        seen.add(host)

        # ثبت خودکار یافته — همان کاری که LLM قبلاً با یک دور کامل
        # (report_finding) انجام می‌ داد؛ حالا رایگان و قطعی است.
        saved = self.store.add_finding({
            "description": (
                f"redirect left the allowed_domains list: now on {url} "
                f"({check['reason']})"
            ),
            "severity": "info",
            "note": "code-detected by the engine (Level-1 domain drift "
                    "guard) — auto-recorded, no agent action spent",
            "requirement_id": requirement_id,
            "url": url,
            "source": "engine",
        })
        self._findings.append(saved)

        self.store.record_action(
            "policy_domain_drift", {"url": url},
            observation=(
                f"redirect left the allowed_domains list: {url} "
                f"({check['reason']}) — auto-recorded as {saved['id']}"
            ),
            meta={"requirement_id": requirement_id},
        )
        return (
            "\n\nℹ️ DOMAIN DRIFT (informational): the browser is now on "
            f"{url}, outside the static allowed-domain list "
            f"({check['reason']}). This is an observed runtime redirect, "
            "not an automatic blocker. Do NOT finish with BLOCKED merely "
            "because the origin changed. Continue inspecting the current "
            "page; only an explicit untrusted navigation attempt or a "
            "genuine inability to continue can block the mission."
        )

    def _multi_field_batch_hint(self, arguments):
        """Return a generic hint when a single-cell field belongs to a
        runtime-discovered multi-field input group.

        This deliberately knows nothing about OTP/CAPTCHA labels or counts.
        It uses only the current accessibility snapshot: textbox-like
        controls, adjacency in the accessibility tree, shared parent path,
        and a one-character/maxlength signal when available. The action is
        skipped so the next model turn can issue ONE browser_fill_form call.
        """
        text = str(arguments.get("text", "") or "")
        if len(text) != 1:
            return ""
        snap = getattr(self, "_recent_snapshot", "") or ""
        if not snap:
            return ""
        target = str(arguments.get("target") or arguments.get("ref") or "")
        if not target:
            return ""
        try:
            idx = SnapshotIndex(snap)
            current = idx.by_ref(target)
            if current is None or current.role not in (
                "textbox", "searchbox", "spinbutton"
            ):
                return ""

            # Find nearby form controls in the same semantic container.
            candidates = []
            for el in idx.elements:
                if el.role not in ("textbox", "searchbox", "spinbutton"):
                    continue
                if not el.path or not current.path:
                    continue
                common = 0
                for a, b in zip(el.path, current.path):
                    if a != b:
                        break
                    common += 1
                if common == 0:
                    continue
                one_char = str(el.attrs.get("maxlength", "")) == "1"
                current_one_char = str(current.attrs.get("maxlength", "")) == "1"
                if one_char or current_one_char:
                    candidates.append(el)

            # Only batch when there are at least two related controls.
            refs = []
            seen = set()
            for el in candidates:
                if el.ref not in seen:
                    seen.add(el.ref)
                    refs.append(el.ref)
            if len(refs) < 2:
                return ""

            return (
                "BATCH INPUT REQUIRED: the current live page exposes a "
                "related multi-field text input group. You attempted to "
                "fill one character with browser_type. Do NOT execute this "
                "as separate character actions. Use ONE browser_fill_form "
                "call containing the currently observed related refs: "
                + ", ".join(refs)
                + ". Reuse the exact user-provided value; do not invent "
                "or modify it. No new snapshot is needed solely because "
                "one character was attempted."
            )
        except Exception:
            return ""

    def _format_structural_observation(self, snapshot_text, title):
        """Compact Page-Agent-style live state, with raw snapshot as fallback.

        The model gets the Page-Agent-style actionable DOM representation first. The complete
        accessibility snapshot remains available for recovery/disambiguation
        but is deliberately not the primary context.
        """
        text = snapshot_text or ""
        try:
            index = SnapshotIndex(text)
            state = index.page_agent_state(max_chars=MAX_PAGE_AGENT_STATE_CHARS)
            return f"\n\n{state}\n\n=== {title} ==="
        except Exception:
            return f"\n\n=== {title} ===\n{text[:MAX_SNAPSHOT_CHARS]}"

    def _snapshot_notes(self, snapshot_text):
        """Add compact live controls and duplicate warnings without raw noise."""
        try:
            index = SnapshotIndex(snapshot_text)
        except Exception:
            return ""
        lines = ["", index.page_agent_state(max_chars=MAX_PAGE_AGENT_STATE_CHARS)]
        dups = index.duplicates()
        if dups:
            lines.extend([
                "",
                "DUPLICATE-NAMED INTERACTIVE ELEMENTS — disambiguate by context:",
            ])
            for d in dups[:5]:
                cands = "; ".join(
                    f"{c} [ref={r}]"
                    for c, r in zip(d["candidates"], d["refs"])
                )
                lines.append(f"- {d['count']}x {d['role']} \"{d['name']}\": {cands}")
        return "\n".join(lines)

    def _current_url_hint(self):
        snap = getattr(self, "_recent_snapshot", "")[:300]
        return snap

    def refresh_skills(self):
        self._system_prompt = None

    def _collect_combined_ui_diagnostics(self, tool, arguments, trigger,
                                        requirement_id=None, action_index=None):
        """Collect targeted UI evidence after an error/no-effect.

        This deliberately combines several complementary signals:
        browser_find for a known semantic target, screenshot for visual state,
        and the existing console/network observer. It never invents selectors
        and never counts these read-only probes against the action budget.
        """
        chunks = []

        # 1) Cheap semantic lookup. Extract only human-facing text from the
        # action description; never turn it into a selector or route.
        if "browser_find" in self.browser.tools:
            element_desc = str((arguments or {}).get("element") or "").strip()
            query = self._find_query_from_element_description(element_desc)
            if query:
                try:
                    find_res = self.browser.call_tool("browser_find", {"text": query})
                    text = (find_res.text or "").strip()
                    if text:
                        chunks.append("=== TARGETED FIND ===\n" + text[:2500])
                        self.store.record_observability(
                            "ui_find", text, trigger=trigger,
                            action_index=action_index,
                            meta={"requirement_id": requirement_id, "query": query},
                        )
                except (MCPError, ToolExecutionError) as e:
                    chunks.append(f"=== TARGETED FIND ERROR ===\n{str(e)[:800]}")

        # 2) Visual evidence is useful for overlays/modals/layout issues.
        # It is stored even when the model cannot receive inline image data.
        if "browser_take_screenshot" in self.browser.tools:
            try:
                shot = self.browser.call_tool("browser_take_screenshot", {"type": "png"})
                if shot.images:
                    self.store.save_screenshot(
                        f"diagnostic-{requirement_id or 'step'}-{action_index:03d}",
                        image_b64=shot.images[0],
                    )
                    chunks.append("=== VISUAL EVIDENCE ===\nA diagnostic screenshot was captured and stored for this failure/no-effect state.")
            except (MCPError, ToolExecutionError) as e:
                chunks.append(f"=== SCREENSHOT ERROR ===\n{str(e)[:800]}")

        return "\n\n".join(chunks)

    @staticmethod
    def _find_query_from_element_description(description):
        """Extract a conservative human-text query for browser_find."""
        if not description:
            return ""
        text = description.strip()
        # Prefer quoted human-visible text.
        import re
        quoted = re.findall(r"['\"]([^'\"]{2,80})['\"]", text)
        if quoted:
            return quoted[0].strip()
        # Avoid searching generic prose such as 'the button inside...'.
        words = [w for w in re.split(r"\s+", text) if w]
        if len(words) <= 8 and not any(w.lower() in {
            "button", "textbox", "field", "form", "element", "inside",
            "the", "a", "an", "dialog"
        } for w in words):
            return text[:80]
        return ""

    def _collect_observability(self, trigger, requirement_id=None, action_index=None):
        """Collect console + network evidence without consuming action budget."""
        if not config.OBSERVABILITY_ENABLED:
            return ""
        chunks = []

        if "browser_console_messages" in self.browser.tools:
            try:
                res = self.browser.call_tool(
                    "browser_console_messages",
                    {"level": config.OBSERVE_CONSOLE_LEVEL, "all": False},
                    timeout=30,
                )
                text = res.text or "(no console messages)"
                self.store.record_observability(
                    "console", text, trigger, action_index,
                    {"requirement_id": requirement_id,
                     "level": config.OBSERVE_CONSOLE_LEVEL},
                )
                chunks.append("[console]\n" + text[:5000])
            except (ToolExecutionError, MCPError) as exc:
                chunks.append(f"[console inspection failed] {exc}")

        if "browser_network_requests" in self.browser.tools:
            try:
                res = self.browser.call_tool(
                    "browser_network_requests",
                    {"static": config.OBSERVE_NETWORK_STATIC},
                    timeout=30,
                )
                text = res.text or "(no network requests)"
                self.store.record_observability(
                    "network", text, trigger, action_index,
                    {"requirement_id": requirement_id},
                )
                chunks.append("[network]\n" + text[:7000])

                # Drill into failed HTTP requests so the report has the actual
                # status/error context, not only a URL list.
                for idx in _failed_network_indexes(text)[:3]:
                    if "browser_network_request" not in self.browser.tools:
                        break
                    try:
                        detail = self.browser.call_tool(
                            "browser_network_request", {"index": idx}, timeout=30
                        )
                        detail_text = detail.text or "(no request detail)"
                        self.store.record_observability(
                            "network", detail_text, trigger, action_index,
                            {"requirement_id": requirement_id,
                             "request_index": idx, "detail": True},
                        )
                        chunks.append(f"[network request #{idx}]\n" + detail_text[:7000])
                    except (ToolExecutionError, MCPError) as exc:
                        chunks.append(f"[network request #{idx} failed] {exc}")
            except (ToolExecutionError, MCPError) as exc:
                chunks.append(f"[network inspection failed] {exc}")

        return "\n\n".join(chunks)[:12000]

    def _record_frame(self, index):
        if not config.RECORD_RUN:
            return False
        index = int(index)
        if index > 0 and index % config.RECORD_EVERY_N_ACTIONS != 0:
            return False
        try:
            return self.screenshot(f"frame-{index:06d}")
        except Exception:
            return False

    def screenshot(self, name):
        """اسکرین‌شات مستقیم توسط harness (نه LLM)."""
        rel = f".evidence/runs/{self.store.run_id}/evidence/{name}.png"
        try:
            self.browser.call_tool(
                "browser_take_screenshot",
                {"filename": rel, "type": "png"},
            )
            ok = self.store.register_screenshot(name, rel) is not None
            if ok:
                return True
            # فایل نوشته نشد — شاید سرور مسیر دیگری دارد؛ بدون filename
        except Exception:                                  # noqa: BLE001
            pass
        try:
            res = self.browser.call_tool(
                "browser_take_screenshot", {"type": "png"})
            if res.images:
                self.store.save_screenshot(name, image_b64=res.images[0])
                return True
        except Exception:                                  # noqa: BLE001
            pass
        return False


# =====================================================================
# کمک‌تابع‌های ماژول
# =====================================================================

def _drain_queued_newlines_and_capture_typed_prefix():
    """On Windows CMD, consume an Enter pressed while LLM output was still flushing.

    Non-newline characters are preserved and prepended to the eventual input, so
    a fast operator who typed the value before the prompt appeared does not lose it.
    """
    if os.name != "nt":
        return ""
    try:
        import msvcrt
        prefix = []
        while msvcrt.kbhit():
            ch = msvcrt.getwch()
            if ch in ("\r", "\n"):
                continue
            # Keep ordinary typed text; ignore console function-key prefixes.
            if ch not in ("\x00", "\xe0"):
                prefix.append(ch)
                continue
            if msvcrt.kbhit():
                msvcrt.getwch()
        return "".join(prefix)
    except Exception:
        return ""


def _default_human_input(question):
    print("\n" + "-" * 56, flush=True)
    try:
        prefix = _drain_queued_newlines_and_capture_typed_prefix()
        prompt = f"👤 {question}\n> "
        print(prompt, end="", flush=True)
        answer = input().strip()
        if prefix:
            answer = prefix + answer
    except (EOFError, KeyboardInterrupt):
        answer = ""
    print("\n" + "-" * 56, flush=True)
    return answer


def _mutating_tools(browser):
    from engine.policy_engine import MUTATING_TOOLS
    return {t for t in MUTATING_TOOLS if t in browser.tools} or \
           {t for t in MUTATING_TOOLS}


def _failed_network_indexes(text):
    import re
    indexes = []
    for match in re.finditer(r"(?m)^\s*(\d+)\.\s+.*?=>\s*\[(4\d\d|5\d\d)\]", str(text or "")):
        indexes.append(int(match.group(1)))
    return indexes


def _compact_history(messages):
    """نتایج قدیمی tool را کوتاه کن؛ آخرین HISTORY_KEEP_FULL تا کامل بمانند."""
    user_turns = [
        i for i, m in enumerate(messages)
        if m.get("role") == "user"
        and isinstance(m.get("content"), str)
        and m["content"].startswith("TOOL_RESULT")
    ]
    old = user_turns[:-HISTORY_KEEP_FULL] if len(user_turns) > HISTORY_KEEP_FULL else []
    for idx in old:
        content = messages[idx]["content"]
        if not content.startswith(COMPACT_PREFIX):
            messages[idx]["content"] = (
                COMPACT_PREFIX + content[:260]
            )
    return messages
