"""Generic mission-input ledger and clarification resolver.

This module does not know any product, site, field label, selector, or
credential. It only preserves literal values explicitly supplied in the
mission and resolves an explicit human confirmation such as "same" / "همونه"
back to the single mission value referenced by the clarification question.
"""
import re
import unicodedata


# Values are discovered from the user's mission text; no domain-specific
# formats are assumed. Numeric/alphanumeric opaque values and URLs are kept as
# literals so the agent can reuse what the user already supplied.
_LITERAL_RE = re.compile(
    r"https?://[^\s\]\[()<>\"']+|(?<!\w)[A-Za-z0-9][A-Za-z0-9._+:/?=&%#-]{2,}(?!\w)|(?<!\w)\d+(?!\w)",
    re.UNICODE,
)

_CONFIRMATION_PHRASES = {
    "yes", "y", "yeah", "yep", "correct", "right", "exactly", "same",
    "same one", "that one", "use it", "use the same", "the same",
    "بله", "اره", "آره", "درست", "دقیقا", "دقیقاً", "همون", "همونه",
    "همان", "همونه دیگه", "همون دیگه",
}


def normalize(value):
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    text = text.replace("\u200c", " ").replace("\u200d", " ")
    return " ".join(text.split())


def extract_literals(text):
    """Return unique explicit literals in appearance order."""
    result = []
    seen = set()
    for match in _LITERAL_RE.finditer(str(text or "")):
        value = match.group(0).strip().strip(".,;،؛:)")
        if len(value) < 3:
            continue
        key = value.casefold()
        if key not in seen:
            seen.add(key)
            result.append(value)
    return tuple(result)


def is_confirmation_reference(answer):
    """Recognize a short explicit confirmation without guessing a value."""
    normalized = normalize(answer)
    if not normalized:
        return False
    if normalized in _CONFIRMATION_PHRASES:
        return True
    tokens = normalized.split()
    # Allow a confirmation phrase followed by harmless conversational filler.
    return bool(tokens and tokens[0] in {"همون", "همونه", "همان", "same", "exactly"}
                and len(tokens) <= 5)


class MissionInputLedger:
    """Immutable ledger of values explicitly present in the mission text."""

    def __init__(self, mission_text=""):
        self.mission_text = str(mission_text or "")
        self.values = extract_literals(self.mission_text)
        self._pending = None

    def referenced_values(self, question):
        """Values that occur in both the mission and the clarification question."""
        question_text = str(question or "")
        qnorm = normalize(question_text)
        return tuple(v for v in self.values if normalize(v) in qnorm)

    def begin_clarification(self, question, save_to=""):
        refs = self.referenced_values(question)
        self._pending = {
            "question": str(question or ""),
            "save_to": str(save_to or ""),
            "referenced_values": refs,
        }
        return refs

    def resolve_confirmation(self, answer):
        """Resolve an explicit confirmation only when exactly one value is referenced."""
        pending = self._pending or {}
        refs = tuple(pending.get("referenced_values") or ())
        if len(refs) != 1 or not is_confirmation_reference(answer):
            return None
        return refs[0]

    def clear_clarification(self):
        self._pending = None
