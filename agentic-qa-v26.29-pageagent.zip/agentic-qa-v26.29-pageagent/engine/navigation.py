"""Generic navigation provenance and artifact tracking.

Navigation trust is provenance-based, not domain/route based. No site,
product, selector, token, or credential knowledge belongs here.
"""
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from urllib.parse import urlparse


TRUSTED_PROVENANCE = {
    "same_origin",
    "observed_href",
    "observed_link",
    "application_generated",
    "application_dialog",
    "clipboard_from_application",
    "human_confirmed_application_artifact",
}

UNTRUSTED_PROVENANCE = {
    "guessed",
    "inferred",
    "fabricated",
    "manually_constructed",
    "unrelated_user_text",
    "arbitrary_human_url",
    "human_provided",
}


@dataclass(frozen=True)
class NavigationEvidence:
    navigation_target: str
    source: str
    provenance: str
    evidence: str = ""
    was_inferred: bool = False
    external: bool = False
    decision: str = "pending"
    created_at: str = ""

    def as_dict(self):
        return asdict(self)


def _same_origin(url, initial_url):
    try:
        a = urlparse(str(url))
        b = urlparse(str(initial_url))
    except ValueError:
        return False
    if not a.hostname or not b.hostname:
        return False
    return (
        a.scheme.lower(), a.hostname.lower(), a.port or _default_port(a.scheme)
    ) == (
        b.scheme.lower(), b.hostname.lower(), b.port or _default_port(b.scheme)
    )


def _default_port(scheme):
    return 443 if str(scheme).lower() == "https" else 80


def build_navigation_evidence(url, source, provenance, evidence="", was_inferred=False,
                              initial_url=None, decision="pending"):
    parsed = urlparse(str(url))
    same_origin = _same_origin(url, initial_url) if initial_url else False
    external = bool(parsed.hostname and initial_url and not same_origin)
    return NavigationEvidence(
        navigation_target=str(url),
        source=str(source or "runtime_evidence"),
        provenance=str(provenance or source or "runtime_evidence").strip().lower(),
        evidence=str(evidence or "")[:2000],
        was_inferred=bool(was_inferred),
        external=external,
        decision=decision,
        created_at=datetime.now(timezone.utc).isoformat(),
    )


def is_trusted(evidence):
    if not isinstance(evidence, dict):
        return False
    if evidence.get("was_inferred") is True:
        return False
    provenance = str(evidence.get("provenance", "")).strip().lower()
    return provenance in TRUSTED_PROVENANCE
