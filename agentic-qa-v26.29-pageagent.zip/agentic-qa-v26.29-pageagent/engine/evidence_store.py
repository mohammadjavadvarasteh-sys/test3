# =====================================================================
# engine/evidence_store.py
# ---------------------------------------------------------------------
# مخزن شواهد — دقیقاً همان ساختاری که .skills/evidence-collection
# و .rules/evidence.yaml انتظار دارند:
#
#   .evidence/runs/<run_id>/
#   ├── run.json          # شناسنامه اجرا (mission، spec، زمان شروع)
#   ├── actions.jsonl     # هر اکشن + مشاهده (redacted)
#   ├── findings.json     # یافته‌های exploratory
#   ├── verdicts.json     # حکم (PASS/FAIL/BLOCKED/INCONCLUSIVE)
#   └── evidence/         # اسکرین‌شات‌ها و خروجی‌ها
#
# Redaction: فیلدهای password/otp/token/authorization/card_number/cvv
# در «همه‌ی» رکوردها خودکار ماسک می‌شوند (Constitution #7).
# =====================================================================

import base64
import json
import os
import re
import time
from datetime import datetime, timezone

import yaml

import config

DEFAULT_REDACT_FIELDS = [
    "password", "otp", "token", "authorization",
    "card_number", "cvv", "secret", "credential", "pin",
]

# الگوهای مقدار حساس در متن آزاد (مثلاً داخل observation)
SENSITIVE_TEXT_PATTERNS = [
    (re.compile(r"(password|passwd|رمز|گذرواژه)\s*[:=]\s*(\S+)",
                re.IGNORECASE), r"\1=***REDACTED***"),
    (re.compile(r"(otp|verification code|کد تایید|کد تأیید)\s*[:=]\s*(\S+)",
                re.IGNORECASE), r"\1=***REDACTED***"),
    (re.compile(r"(token|bearer)\s*[:=]\s*(\S+)",
                re.IGNORECASE), r"\1=***REDACTED***"),
]


def _utc_now():
    return datetime.now(timezone.utc).isoformat()


def redact_text(text):
    if not isinstance(text, str):
        return text
    for pattern, repl in SENSITIVE_TEXT_PATTERNS:
        text = pattern.sub(repl, text)
    return text


def redact(obj, fields=None):
    """کپی عمیق با ماسک کردن کلیدهای حساس (case-insensitive)."""
    fields = {f.lower() for f in (fields or DEFAULT_REDACT_FIELDS)}

    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if str(k).lower() in fields:
                out[k] = "***REDACTED***"
            else:
                out[k] = redact(v, fields)
        return out
    if isinstance(obj, list):
        return [redact(item, fields) for item in obj]
    if isinstance(obj, str):
        return redact_text(obj)
    return obj


def load_evidence_rules(rules_dir=None):
    """قواعد .rules/evidence.yaml — الزامات شواهد هر نوع verdict."""
    rules_dir = rules_dir or config.RULES_DIR
    try:
        with open(os.path.join(rules_dir, "evidence.yaml"),
                  "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        return data.get("evidence", {})
    except Exception:                              # noqa: BLE001
        return {}


class EvidenceStore:

    def __init__(self, run_id=None, base_dir=None, evidence_rules=None):
        self.base_dir = base_dir or config.EVIDENCE_DIR
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        pid = os.getpid()
        self.run_id = run_id or f"run-{ts}-{pid}"

        self.dir = os.path.join(self.base_dir, self.run_id)
        self.evidence_dir = os.path.join(self.dir, "evidence")
        os.makedirs(self.evidence_dir, exist_ok=True)

        self.evidence_rules = evidence_rules or load_evidence_rules()
        self.redact_fields = self.evidence_rules.get(
            "redact_fields", DEFAULT_REDACT_FIELDS
        )

        self.actions = []            # در حافظه؛ روی دیسک jsonl
        self.findings = []
        self.verdicts = []
        self.screenshots = {}        # name -> path
        self.observability = []      # console/network observations
        self.media = {}              # generated run recording artifacts
        self._actions_file = os.path.join(self.dir, "actions.jsonl")
        self._started_at = _utc_now()

    # -----------------------------------------------------------------
    # چرخه‌ی اجرا
    # -----------------------------------------------------------------

    def start_run(self, mission):
        """mission = dict (مطابق ساختار run.json نمونه‌ی خودتان)"""
        self.mission = mission or {}
        self._write_json("run.json", {
            "run_id": self.run_id,
            "mission": mission,
            "spec_id": mission.get("spec_id") if mission else None,
            "started_at": self._started_at,
            "requirements": [],
            "findings_count": 0,
        })

    def finish_run(self, status, extra=None):
        data = {
            "run_id": self.run_id,
            "mission": getattr(self, "mission", None),
            "started_at": self._started_at,
            "finished_at": _utc_now(),
            "status": status,
            "counts": {
                "actions": len(self.actions),
                "findings": len(self.findings),
                "verdicts": len(self.verdicts),
            },
        }
        if extra:
            data.update(extra)
        self._write_json("run.json", data)
        return self.dir

    # -----------------------------------------------------------------
    # اکشن‌ها
    # -----------------------------------------------------------------

    def _redact_action_arguments(self, tool, arguments):
        """
        Action-specific redaction for values that are inherently user-entered.

        Generic key-based redaction cannot protect a password typed through
        Page-Agent because the field is named "text".  For input/fill actions
        we therefore redact the payload value itself while preserving the
        target/index and action shape needed for debugging.  JavaScript is
        omitted wholesale because scripts may contain secrets even when their
        argument names do not.
        """
        args = dict(arguments or {})
        tool_name = str(tool or "").lower()

        input_tools = {
            "input_text",
            "input_text_batch",
            "browser_type",
            "browser_fill_form",
            "browser_press_key",
        }
        if tool_name in input_tools:
            for key in ("text", "value", "values", "fields"):
                if key in args:
                    if key == "fields" and isinstance(args[key], list):
                        redacted_fields = []
                        for field in args[key]:
                            if isinstance(field, dict):
                                item = dict(field)
                                for value_key in ("text", "value"):
                                    if value_key in item:
                                        item[value_key] = "***REDACTED***"
                                redacted_fields.append(item)
                            else:
                                redacted_fields.append("***REDACTED***")
                        args[key] = redacted_fields
                    elif isinstance(args[key], list):
                        args[key] = ["***REDACTED***" for _ in args[key]]
                    else:
                        args[key] = "***REDACTED***"

        if tool_name in {"execute_javascript", "browser_run_code_unsafe"}:
            if "script" in args:
                args["script"] = "***REDACTED_SCRIPT***"
            if "code" in args:
                args["code"] = "***REDACTED_SCRIPT***"
            if "function" in args:
                args["function"] = "***REDACTED_FUNCTION***"

        return args

    def record_action(self, tool, arguments, observation="", error=None,
                      meta=None):
        safe_arguments = self._redact_action_arguments(tool, arguments)
        entry = {
            "ts": _utc_now(),
            "tool": tool,
            "arguments": redact(safe_arguments, self.redact_fields),
            "observation": redact_text(str(observation))[:4000],
            "error": redact_text(str(error))[:800] if error else None,
            "meta": redact(meta or {}, self.redact_fields),
        }
        self.actions.append(entry)
        try:
            with open(self._actions_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except OSError:
            pass
        return entry

    # -----------------------------------------------------------------
    # اسکرین‌شات
    # -----------------------------------------------------------------

    def save_screenshot(self, name, image_b64=None, file_path=None):
        """
        ذخیره تصویر در evidence/<name>.png
        یکی از image_b64 یا file_path (مسیر نسبی پروژه) را بدهید.
        """
        safe = re.sub(r"[^a-zA-Z0-9_\-]", "-", name)[:80]
        target = os.path.join(self.evidence_dir, f"{safe}.png")

        try:
            if image_b64:
                with open(target, "wb") as f:
                    f.write(base64.b64decode(image_b64))
            elif file_path:
                abs_path = os.path.join(config.PROJECT_ROOT, file_path) \
                    if not os.path.isabs(file_path) else file_path
                if os.path.exists(abs_path):
                    with open(abs_path, "rb") as src, \
                            open(target, "wb") as dst:
                        dst.write(src.read())
                else:
                    return None
            else:
                return None
            self.screenshots[safe] = target
            return os.path.relpath(target, config.PROJECT_ROOT)
        except Exception:                              # noqa: BLE001
            return None

    def register_screenshot(self, name, rel_path):
        """
        ثبت فایلی که سرور MCP خودش نوشته است (cwd سرور = ریشه پروژه).
        بعد از فراخوانی browser_take_screenshot با filename نسبی.
        """
        safe = re.sub(r"[^a-zA-Z0-9_\-]", "-", name)[:80]
        abs_path = rel_path if os.path.isabs(rel_path) else \
            os.path.join(config.PROJECT_ROOT, rel_path)
        if os.path.exists(abs_path):
            self.screenshots[safe] = abs_path
            return os.path.relpath(abs_path, config.PROJECT_ROOT)
        return None

    # -----------------------------------------------------------------
    # Runtime observability
    # -----------------------------------------------------------------

    def record_observability(self, kind, content, trigger="", action_index=None, meta=None):
        """Store redacted console/network evidence separately from action logs."""
        entry = {
            "ts": _utc_now(),
            "kind": str(kind),
            "trigger": str(trigger or ""),
            "action_index": action_index,
            "content": redact_text(str(content or ""))[:12000],
            "meta": redact(meta or {}, self.redact_fields),
        }
        self.observability.append(entry)
        filename = f"{kind}.jsonl"
        try:
            with open(os.path.join(self.dir, filename), "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except OSError:
            pass
        return entry

    def register_media(self, media):
        self.media.update(media or {})
        self._write_json("media.json", self.media)
        return dict(self.media)

    def build_run_media(self):
        from engine.recording import build_run_media
        media = build_run_media(self.dir)
        if media:
            self.register_media(media)
        return media

    # -----------------------------------------------------------------
    # Findings (مأموریت‌های exploratory)
    # -----------------------------------------------------------------

    def add_finding(self, finding):
        finding = dict(finding or {})
        finding.setdefault("id", f"F-{len(self.findings) + 1:03d}")
        finding.setdefault("ts", _utc_now())
        finding.setdefault("severity", "info")
        finding["observation"] = redact(finding.get("observation", {}),
                                        self.redact_fields)
        self.findings.append(finding)
        self._write_json("findings.json", self.findings)
        return finding

    # -----------------------------------------------------------------
    # Verdicts
    # -----------------------------------------------------------------

    def add_verdict(self, verdict):
        verdict = dict(verdict or {})
        verdict.setdefault("ts", _utc_now())
        for key in ("expected", "actual", "failure_reason"):
            if verdict.get(key):
                verdict[key] = redact_text(str(verdict[key]))[:600]
        self.verdicts.append(verdict)
        self._write_json("verdicts.json", self.verdicts)
        return verdict

    # -----------------------------------------------------------------
    # بررسی کامل بودن شواهد — Oracle از این استفاده می‌کند
    # -----------------------------------------------------------------

    def has_screenshot_for(self, requirement_id):
        """آیا برای این requirement اسکرین‌شات ثبت شده؟"""
        prefix = f"req-{requirement_id}"
        return any(name.startswith(prefix) for name in self.screenshots)

    def observations_for(self, requirement_id):
        return [
            a for a in self.actions
            if a.get("meta", {}).get("requirement_id") == requirement_id
        ]

    # -----------------------------------------------------------------

    def _write_json(self, name, data):
        path = os.path.join(self.dir, name)
        tmp = path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
        except OSError:
            pass

    @property
    def run_dir(self):
        return self.dir
