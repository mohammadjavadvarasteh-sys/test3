"""Generic runtime artifacts and human-checkpoint provenance.

This module contains no site, route, selector, credential, or product
knowledge. An artifact is trusted because of how it was produced/confirmed,
not because of its domain or value.
"""
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from urllib.parse import urlparse


ARTIFACT_TYPES = {
    "url",
    "file",
    "document_id",
    "request_id",
    "share_link",
    "download_link",
}

TRUSTED_ARTIFACT_PROVENANCE = {
    "application_generated",
    "application_dialog",
    "clipboard_from_application",
    "human_confirmed_application_artifact",
    "observed_href",
    "observed_link",
    "same_origin",
}

UNTRUSTED_ARTIFACT_PROVENANCE = {
    "guessed",
    "inferred",
    "fabricated",
    "manually_constructed",
    "unrelated_user_text",
    "arbitrary_human_url",
}


@dataclass(frozen=True)
class RuntimeArtifact:
    type: str
    value: str
    source: str
    provenance: str
    evidence: str = ""
    confidence: float = 1.0
    created_at: str = ""

    def as_dict(self):
        return asdict(self)


def make_artifact(artifact_type, value, source, provenance, evidence="", confidence=1.0):
    artifact_type = str(artifact_type or "unknown").strip().lower()
    return RuntimeArtifact(
        type=artifact_type,
        value=str(value or ""),
        source=str(source or "runtime"),
        provenance=str(provenance or "unknown").strip().lower(),
        evidence=str(evidence or "")[:2000],
        confidence=float(confidence),
        created_at=datetime.now(timezone.utc).isoformat(),
    )


def valid_url(value):
    try:
        parsed = urlparse(str(value).strip())
    except ValueError:
        return False
    return parsed.scheme in ("http", "https") and bool(parsed.hostname)


def artifact_is_trusted(artifact):
    if not isinstance(artifact, dict):
        return False
    provenance = str(artifact.get("provenance", "")).strip().lower()
    return provenance in TRUSTED_ARTIFACT_PROVENANCE


def checkpoint_requests_application_artifact(checkpoint):
    if not isinstance(checkpoint, dict):
        return False
    checkpoint_type = str(checkpoint.get("checkpoint_type", "")).strip().lower()
    artifact_type = str(checkpoint.get("requested_artifact_type", "")).strip().lower()
    policy = str(checkpoint.get("provenance_policy", "")).strip().lower()
    return (
        checkpoint_type == "external_artifact"
        and artifact_type in ARTIFACT_TYPES
        and policy == "human_confirmed_application_artifact"
    )
