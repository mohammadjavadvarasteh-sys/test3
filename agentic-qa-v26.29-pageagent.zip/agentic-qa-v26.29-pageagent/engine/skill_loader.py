# =====================================================================
# engine/skill_loader.py
# ---------------------------------------------------------------------
# «Dynamic Skill Selection» — همان چیزی که فایل‌های .skills/SKILL.md
# شما انتظار دارند:
#   - همه skill ها از .skills/<name>/SKILL.md خوانده می‌شوند (Markdown)
#   - در هر لحظه، skill های «فعال» بر اساس trigger ها انتخاب می‌شوند:
#       * always          → همیشه (evidence/navigation/loop/recovery/...)
#       * mission_type    → نوع مأموریت (exploratory / security / ...)
#       * page_keywords   → کلمات کلیدی در snapshot صفحه (captcha/otp/...)
#       * page_roles      → نقش‌های a11y روی صفحه (فرم → form-validation)
#       * spec_signal     → فیلدهای خاص Spec (negative_cases → ...)
#       * mode            → حالت اجرا (gen-spec)
#   - متن کامل skill های فعال داخل system prompt تزریق می‌شود
#     → یعنی agent موظف است دقیقاً از همین قوانین پیروی کند
# =====================================================================

import os

import config

from engine.snapshot import SKILL_KEYWORDS, FORM_ROLES


# ---------------------------------------------------------------------
# جدول trigger ها — مطابق فلسفه‌ی فایل‌های skill خودتان
# ---------------------------------------------------------------------

SKILL_TRIGGERS = {
    # --- همیشه فعال (پایه‌ی اجرا) ---
    "evidence-collection":   {"always": True},
    "navigation":            {"always": True},
    "loop-detection":        {"always": True},
    "recovery":              {"always": True},
    "oracle-verdict":        {"always": True},
    "element-disambiguation": {"always": True},

    # --- وابسته به نوع مأموریت ---
    "exploratory-testing":   {"mission_types": ["exploratory"]},
    "authorization":         {"mission_types": ["security"]},

    # --- وابسته به محتوای صفحه (keyword) ---
    "authentication":        {"page_keywords": True},
    "otp":                   {"page_keywords": True},
    "captcha":               {"page_keywords": True},
    "file-upload":           {"page_keywords": True},
    "session-expiry":        {"page_keywords": True},

    # --- وابسته به ساختار صفحه (نقش‌های a11y) ---
    "form-validation":       {"page_roles": True},

    # --- وابسته به سیگنال‌های Spec ---
    "negative-testing":      {"spec_signal": "negative_cases"},
    "boundary-testing":      {"spec_signal": "constraints"},

    # --- حالت‌های خاص ---
    "spec-generation":       {"mode": "gen-spec"},
}


class SkillLoader:

    def __init__(self, skills_dir=None):
        self.skills_dir = skills_dir or config.SKILLS_DIR
        self._cache = {}

    # -----------------------------------------------------------------
    # کشف و خواندن همه‌ی skill ها
    # -----------------------------------------------------------------

    def load_all(self):
        """{skill_name: markdown_content} — هر بار از دیسک می‌خواند."""
        skills = {}
        if not os.path.isdir(self.skills_dir):
            return skills

        for entry in sorted(os.listdir(self.skills_dir)):
            skill_file = os.path.join(self.skills_dir, entry, "SKILL.md")
            if os.path.isfile(skill_file):
                try:
                    with open(skill_file, "r", encoding="utf-8") as f:
                        skills[entry] = f.read()
                except OSError:
                    continue
        self._cache = skills
        return skills

    def available(self):
        return sorted(self.load_all().keys())

    def get(self, name):
        all_skills = self.load_all()
        return all_skills.get(name)

    # -----------------------------------------------------------------
    # انتخاب skill های فعال برای «الان»
    # -----------------------------------------------------------------

    def select(self,
               snapshot_text="",
               url="",
               mission_type=None,
               spec_signals=None,
               mode=None):
        """
        خروجی: list[str] — اسم skill های فعال (مرتب و قطعی).

        snapshot_text : متن snapshot درخت دسترس‌پذیری (اختیاری)
        url           : URL فعلی
        mission_type  : spec | exploratory | security | hybrid
        spec_signals  : سیگنال‌های Spec مثل وجود negative_cases
        mode          : run | explore | gen-spec
        """
        available = set(self.load_all().keys())
        active = set()
        spec_signals = spec_signals or set()

        # keyword های صفحه
        page_keywords = set()
        if snapshot_text:
            from engine.snapshot import detect_skill_triggers
            page_keywords = set(detect_skill_triggers(snapshot_text, url))

        # نقش‌های فرم روی صفحه؟
        has_form_roles = False
        if snapshot_text:
            for role in FORM_ROLES:
                if f"- {role}" in snapshot_text or f' {role} "' in snapshot_text:
                    has_form_roles = True
                    break

        for skill, trigger in SKILL_TRIGGERS.items():
            if skill not in available:
                continue                                    # skill نصب نیست

            if trigger.get("always"):
                active.add(skill)

            if trigger.get("mission_types") and (
                mission_type in trigger["mission_types"]
                or (mission_type == "hybrid" and "exploratory" in trigger["mission_types"])
            ):
                active.add(skill)

            if trigger.get("page_keywords") and skill in page_keywords:
                active.add(skill)

            if trigger.get("page_roles") and has_form_roles:
                active.add(skill)

            sig = trigger.get("spec_signal")
            if sig and sig in spec_signals:
                active.add(skill)

            if trigger.get("mode") and mode == trigger["mode"]:
                active.add(skill)

        return sorted(active)

    # -----------------------------------------------------------------
    # ساخت بلوک پرامپت از skill های فعال
    # -----------------------------------------------------------------

    def compose_prompt(self, active_skills):
        all_skills = self.load_all()
        if not active_skills:
            return "(no skills active)"

        blocks = []
        for name in active_skills:
            content = all_skills.get(name)
            if not content:
                continue
            content = content.strip()
            blocks.append(f"### ACTIVE SKILL: {name}\n{content}")

        return (
            "The following skills are ACTIVE for this run. "
            "You MUST follow their instructions exactly — they are "
            "binding, not advisory:\n\n"
            + "\n\n".join(blocks)
        )

    # -----------------------------------------------------------------
    # نمایش برای CLI (دستور skills)
    # -----------------------------------------------------------------

    def describe_all(self):
        rows = []
        for name, content in sorted(self.load_all().items()):
            trigger = SKILL_TRIGGERS.get(name, {})
            if trigger.get("always"):
                when = "always"
            elif trigger.get("mission_types"):
                when = f"mission in {trigger['mission_types']}"
            elif trigger.get("mode"):
                when = f"mode={trigger['mode']}"
            elif trigger.get("page_keywords"):
                when = f"page contains {SKILL_KEYWORDS.get(name, ['?'])[:3]}"
            elif trigger.get("page_roles"):
                when = "page has form controls"
            else:
                when = "manual"
            rows.append({"skill": name, "activates": when})
        return rows
