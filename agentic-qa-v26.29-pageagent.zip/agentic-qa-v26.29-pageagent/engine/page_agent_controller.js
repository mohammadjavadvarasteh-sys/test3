/*
 * Agentic QA Page-Agent controller
 *
 * Design target: stay close to Alibaba Page Agent's useful browser-side
 * primitives while keeping our own QA safety/evidence layer in Python.
 *
 * Live DOM -> flat indexed interactive state -> semantic search -> indexed
 * actions.  The model never receives CSS/XPath selectors or browser refs.
 *
 * Important invariants:
 *   1) the index map is built during observation and is NOT rebuilt during
 *      an action. A DOM mutation therefore cannot silently retarget index N.
 *   2) open Shadow DOM and accessible same-origin iframe documents are walked.
 *   3) readable page text, accessibility-ish metadata and scroll evidence are
 *      included in the state, not only clickable controls.
 *   4) secrets are redacted from values before the state reaches the model.
 */
(() => {
  const KEY = "__AGENTIC_QA_PAGE_AGENT__";
  if (window[KEY]) return window[KEY];

  const state = {
    elements: [],
    updatedAt: 0,
    revision: 0,
    url: location.href,
    title: document.title,
    content: "",
    pageInfo: null,
    scrollables: [],
  };

  const INTERACTIVE_TAGS = new Set([
    "a", "button", "input", "textarea", "select", "option",
    "summary", "details", "label", "iframe"
  ]);

  const INTERACTIVE_ROLES = new Set([
    "button", "link", "textbox", "searchbox", "spinbutton", "combobox",
    "listbox", "option", "checkbox", "radio", "switch", "tab", "menuitem",
    "menuitemcheckbox", "menuitemradio", "slider", "treeitem", "gridcell",
    "row", "cell", "listitem", "progressbar", "scrollbar"
  ]);

  const SCROLL_ROLES = new Set(["region", "dialog", "listbox", "grid", "tree"]);
  const NON_INTERACTIVE = new Set([
    "script", "style", "meta", "link", "noscript", "template", "svg", "path"
  ]);
  const BLOCK_TEXT_TAGS = new Set([
    "h1", "h2", "h3", "h4", "h5", "h6", "p", "li", "dt", "dd",
    "label", "legend", "caption", "summary", "figcaption", "th", "td",
    "pre", "code", "blockquote", "article", "section", "header", "footer",
    "nav", "main", "aside"
  ]);
  const BLOCK_TEXT_ROLES = new Set([
    "heading", "alert", "status", "log", "note", "region", "dialog",
    "tooltip", "description", "cell", "row"
  ]);
  const SEMANTIC_CLICK_CLASS = /(?:^|[\s_-])(btn|button|clickable|click|action|link|menu-item|menuitem|tab|chip|toggle)(?:$|[\s_-])/i;
  const SENSITIVE = /(?:^|[\s_.-])(password|passwd|passcode|secret|token|authorization|api[-_ ]?key|otp|one[-_ ]?time|verification[-_ ]?code|captcha|security[-_ ]?code)(?:$|[\s_.-])/i;

  function isElement(node) {
    return !!node && node.nodeType === 1;
  }

  function tag(el) {
    return String(el?.tagName || "").toLowerCase();
  }

  function attr(el, name) {
    try { return el.getAttribute(name) || ""; } catch (_) { return ""; }
  }

  function ownerWindow(el) {
    return el?.ownerDocument?.defaultView || window;
  }

  function safeText(value, max = 240) {
    return String(value ?? "").replace(/\s+/g, " ").trim().slice(0, max);
  }

  function rawText(el) {
    try { return safeText(el.innerText || el.textContent || "", 320); }
    catch (_) { return ""; }
  }

  function sensitive(el) {
    const t = tag(el);
    if (t === "input" && String(attr(el, "type")).toLowerCase() === "password") return true;
    const hay = [
      attr(el, "name"), attr(el, "id"), attr(el, "autocomplete"),
      attr(el, "placeholder"), attr(el, "aria-label"), attr(el, "aria-describedby")
    ].join(" ");
    return SENSITIVE.test(hay);
  }

  function isHiddenByAria(el) {
    let p = el;
    let depth = 0;
    while (p && depth < 8) {
      if (attr(p, "aria-hidden").toLowerCase() === "true") return true;
      p = p.parentElement;
      depth++;
    }
    return false;
  }

  function rectVisible(el) {
    if (!isElement(el)) return false;
    const win = ownerWindow(el);
    try {
      const s = win.getComputedStyle(el);
      if (!s || s.display === "none" || s.visibility === "hidden" || s.opacity === "0") return false;
      if (isHiddenByAria(el)) return false;
      const rects = Array.from(el.getClientRects ? el.getClientRects() : []);
      if (!rects.length) return false;
      return rects.some(r => r.width > 0 && r.height > 0);
    } catch (_) {
      return false;
    }
  }

  function inViewport(el) {
    if (!rectVisible(el)) return false;
    const win = ownerWindow(el);
    const r = el.getBoundingClientRect();
    const margin = 8;
    return r.bottom >= -margin && r.right >= -margin &&
      r.top <= win.innerHeight + margin && r.left <= win.innerWidth + margin;
  }

  function pointHit(el, x, y) {
    const doc = el.ownerDocument || document;
    try {
      const hit = doc.elementFromPoint(x, y);
      if (!hit || hit === el || el.contains(hit) || hit.contains(el)) return true;
      // document.elementFromPoint() resolves an open shadow child to its host.
      // Walk the host chain so an exposed Shadow DOM control is not mistaken
      // for an occluded element.
      let root = el.getRootNode?.();
      while (root && root.host) {
        const host = root.host;
        if (hit === host || host.contains(hit)) return true;
        root = host.getRootNode?.();
      }
      return false;
    } catch (_) {
      return true;
    }
  }

  function isActiveDialogAncestor(el) {
    if (!isElement(el)) return false;
    let p = el;
    let depth = 0;
    while (p && depth < 12) {
      try {
        const r = role(p);
        const modal = attr(p, "aria-modal").toLowerCase() === "true";
        const openDialog = tag(p) === "dialog" && p.open === true;
        if ((r === "dialog" || modal || openDialog) && rectVisible(p)) return true;
      } catch (_) {}
      p = p.parentElement;
      depth++;
    }
    return false;
  }

  function topLayer(el) {
    if (!isElement(el) || !inViewport(el)) return false;
    if (isActiveDialogAncestor(el)) return true;
    const r = el.getBoundingClientRect();
    const win = ownerWindow(el);
    const points = [
      [r.left + r.width / 2, r.top + r.height / 2],
      [r.left + Math.min(Math.max(r.width * 0.18, 1), r.width - 1), r.top + Math.min(Math.max(r.height * 0.18, 1), r.height - 1)],
      [r.left + Math.max(r.width * 0.82, 1), r.top + Math.max(r.height * 0.82, 1)],
      [r.left + Math.min(Math.max(r.width * 0.18, 1), r.width - 1), r.top + Math.max(r.height * 0.82, 1)],
    ];
    return points.every(([x, y]) => {
      if (x < 0 || y < 0 || x > win.innerWidth || y > win.innerHeight) return true;
      return pointHit(el, x, y);
    });
  }

  function isInFirstLegend(el, fieldset) {
    try {
      const firstLegend = Array.from(fieldset.children || []).find(child => tag(child) === "legend");
      return !!firstLegend && (el === firstLegend || firstLegend.contains(el));
    } catch (_) { return false; }
  }

  function isDisabledIntrinsic(el) {
    if (!isElement(el)) return false;

    if (el.disabled === true || attr(el, "disabled") !== "") return true;
    if (attr(el, "aria-disabled").toLowerCase() === "true") return true;
    if (el.inert === true || attr(el, "inert") !== "") return true;

    let p = el.parentElement;
    let depth = 0;
    while (p && depth < 12) {
      if (tag(p) === "fieldset" && p.disabled === true && !isInFirstLegend(el, p)) return true;
      if (attr(p, "aria-disabled").toLowerCase() === "true") return true;
      if (p.inert === true || attr(p, "inert") !== "") return true;
      try {
        const ownerRole = role(p);
        const ownerName = accessibleName(p);
        const semanticOwner = INTERACTIVE_ROLES.has(ownerRole)
          || INTERACTIVE_TAGS.has(tag(p))
          || /(?:combobox|select|button|dropdown|picker|menu)/i.test(`${ownerName} ${attr(p, "class")} ${attr(p, "data-testid")} ${attr(p, "data-cy")}`);
        if (semanticOwner) {
          const style = ownerWindow(p).getComputedStyle(p);
          if (style.pointerEvents === "none") return true;
          if (attr(p, "data-disabled").toLowerCase() === "true" || attr(p, "data-state").toLowerCase() === "disabled") return true;
          if (/disabled/i.test(attr(p, "class")) && !/not.?disabled/i.test(attr(p, "class"))) return true;
        }
      } catch (_) {}
      p = p.parentElement;
      depth++;
    }
    return false;
  }

  function findDisabledControllerForPopup(el) {
    if (!isElement(el)) return null;
    const doc = el.ownerDocument || document;

    function tokensFrom(value) {
      return String(value || "").split(/\s+/).map(x => x.trim()).filter(Boolean);
    }

    // Portal/dropdown menus are often rendered outside the disabled combobox
    // subtree. Follow generic WAI-ARIA ownership links so those descendants
    // inherit the disabled state without using any site-specific selector.
    let popup = el;
    for (let depth = 0; popup && depth < 10; popup = popup.parentElement, depth++) {
      const popupId = attr(popup, "id").trim();
      if (!popupId) continue;
      const owners = Array.from(doc.querySelectorAll("[aria-controls], [aria-owns]"));
      for (const owner of owners) {
        if (!isDisabledIntrinsic(owner)) continue;
        const refs = [...tokensFrom(attr(owner, "aria-controls")), ...tokensFrom(attr(owner, "aria-owns"))];
        if (refs.includes(popupId)) {
          return {name: accessibleName(owner), role: role(owner), tag: tag(owner)};
        }
      }
    }
    return null;
  }

  function isDisabled(el) {
    if (!isElement(el)) return false;
    if (isDisabledIntrinsic(el)) return true;
    return !!findDisabledControllerForPopup(el);
  }

  function isReadonly(el) {
    return attr(el, "readonly") !== "" || !!el.readOnly || attr(el, "aria-readonly").toLowerCase() === "true";
  }

  function isRequired(el) {
    return attr(el, "required") !== "" || attr(el, "aria-required").toLowerCase() === "true" || !!el.required;
  }

  function currentValue(el) {
    try {
      if (tag(el) === "input" || tag(el) === "textarea" || tag(el) === "select") return String(el.value ?? "");
      if (isContentEditable(el)) return String(el.innerText || el.textContent || "");
    } catch (_) {}
    return "";
  }

  function validityInfo(el) {
    const required = isRequired(el);
    const value = currentValue(el);
    const base = {required, requiredMissing: required && value.trim() === "", invalid: false, validationMessage: ""};
    try {
      if (el.validity) {
        base.requiredMissing = !!el.validity.valueMissing;
        base.invalid = !!el.validity.valid === false;
        base.validationMessage = safeText(el.validationMessage || "", 160);
      }
    } catch (_) {}
    return base;
  }

  function nearestForm(el) {
    try {
      if (el.form) return el.form;
      return el.closest?.("form") || null;
    } catch (_) { return null; }
  }

  function likelyBlockingFields(el) {
    if (!isDisabled(el)) return [];
    const form = nearestForm(el);
    if (!form) return [];
    const nodes = [];
    try {
      for (const candidate of Array.from(form.querySelectorAll("input, textarea, select, [contenteditable='true'], [aria-required='true']"))) {
        if (candidate === el || !rectVisible(candidate) || isDisabled(candidate)) continue;
        const v = validityInfo(candidate);
        if (!v.requiredMissing && !(attr(candidate, "aria-invalid").toLowerCase() === "true" && currentValue(candidate).trim() === "")) continue;
        nodes.push({name: accessibleName(candidate), role: role(candidate)});
        if (nodes.length >= 8) break;
      }
    } catch (_) {}
    return nodes.filter(x => x.name);
  }

  function likelyPrerequisiteFields(el) {
    if (!isDisabled(el)) return [];
    const form = nearestForm(el);
    if (!form) return [];
    const targetRect = el.getBoundingClientRect?.();
    const nodes = [];
    try {
      const candidates = Array.from(form.querySelectorAll("input, textarea, select, [contenteditable='true'], [role='combobox'], [role='textbox']"));
      for (const candidate of candidates) {
        if (candidate === el || !rectVisible(candidate) || isDisabled(candidate) || isReadonly(candidate)) continue;
        if (currentValue(candidate).trim() !== "") continue;
        const name = accessibleName(candidate);
        if (!name) continue;
        const v = validityInfo(candidate);
        const rect = candidate.getBoundingClientRect?.();
        const isBeforeTarget = targetRect && rect && (rect.top < targetRect.top + 4 || (Math.abs(rect.top - targetRect.top) < 12 && rect.left < targetRect.left));
        if (v.required || v.requiredMissing || isBeforeTarget) {
          nodes.push({name, role: role(candidate), required: !!v.required, beforeTarget: !!isBeforeTarget});
        }
        if (nodes.length >= 10) break;
      }
    } catch (_) {}
    return nodes;
  }

  function countdownMatch(text) {
    const t = safeText(text, 180);
    if (!t) return false;
    return /(\b\d{1,2}\s*:\s*\d{2}\b)|(\b\d{1,3}\s*(?:ثانیه|ثانیه‌|دقیقه|second|seconds|sec|secs|minute|minutes|min)\b)/i.test(t);
  }

  function nearestCountdownText(el) {
    // A countdown near a resend control is a resend cooldown. Do not attach
    // that same timer to ordinary OTP/CAPTCHA inputs; doing so makes the
    // model incorrectly infer that the challenge inputs are disabled.
    const own = `${accessibleName(el)} ${rawText(el)} ${attr(el, "aria-label")} ${attr(el, "name")}`.toLowerCase();
    const resendSemantic = /(?:resend|send again|send new|ارسال مجدد|دوباره|کد جدید)/i.test(own);
    if (!resendSemantic && role(el) !== "timer") return "";
    let p = el;
    for (let depth = 0; p && depth < 5; p = p.parentElement, depth++) {
      const txt = rawText(p);
      if (txt && txt.length <= 220 && countdownMatch(txt)) return txt;
    }
    return "";
  }

  function nearestDisabledOwner(el) {
    if (!isElement(el)) return null;
    if (attr(el, "aria-disabled").toLowerCase() === "true" || el.disabled === true || attr(el, "disabled") !== "") {
      return {name: accessibleName(el), role: role(el), tag: tag(el)};
    }
    let p = el.parentElement;
    let depth = 0;
    while (p && depth < 12) {
      const aria = attr(p, "aria-disabled").toLowerCase();
      const dataDisabled = attr(p, "data-disabled").toLowerCase() === "true";
      const dataState = attr(p, "data-state").toLowerCase() === "disabled";
      const cls = attr(p, "class");
      const classDisabled = /disabled/i.test(cls) && !/not.?disabled/i.test(cls);
      let pointerDisabled = false;
      try {
        const ownerRole = role(p);
        const ownerName = accessibleName(p);
        const semanticOwner = INTERACTIVE_ROLES.has(ownerRole)
          || INTERACTIVE_TAGS.has(tag(p))
          || /(?:combobox|select|button|dropdown|picker|menu)/i.test(`${ownerName} ${cls}`);
        pointerDisabled = semanticOwner && ownerWindow(p).getComputedStyle(p).pointerEvents === "none";
      } catch (_) {}
      if (aria === "true" || dataDisabled || dataState || classDisabled || pointerDisabled) {
        return {name: accessibleName(p), role: role(p), tag: tag(p)};
      }
      p = p.parentElement;
      depth++;
    }
    return null;
  }

  function statusInfo(el) {
    const validity = validityInfo(el);
    const disabled = isDisabled(el);
    const readonly = isReadonly(el);
    const disabledOwner = disabled ? (nearestDisabledOwner(el) || findDisabledControllerForPopup(el)) : null;
    const blockedBy = likelyBlockingFields(el);
    const prerequisiteCandidates = likelyPrerequisiteFields(el);
    const countdown = nearestCountdownText(el);
    return {
      disabled,
      readonly,
      required: validity.required,
      requiredMissing: validity.requiredMissing,
      invalid: validity.invalid,
      validationMessage: validity.validationMessage,
      actionable: !disabled && !readonly,
      disabledOwner,
      blockedBy,
      prerequisiteCandidates,
      countdown: countdown || "",
    };
  }

  function isContentEditable(el) {
    return !!el && (el.isContentEditable || attr(el, "contenteditable").toLowerCase() === "true");
  }

  function isScrollable(el) {
    if (!isElement(el) || !rectVisible(el)) return false;
    const win = ownerWindow(el);
    try {
      const s = win.getComputedStyle(el);
      const y = /(auto|scroll|overlay)/i.test(s.overflowY) && el.scrollHeight > el.clientHeight + 4;
      const x = /(auto|scroll|overlay)/i.test(s.overflowX) && el.scrollWidth > el.clientWidth + 4;
      const explicit = attr(el, "data-scrollable").toLowerCase() === "true";
      return !!(y || x || explicit);
    } catch (_) { return false; }
  }

  function semanticClassSignal(el) {
    return SEMANTIC_CLICK_CLASS.test(`${attr(el, "class")} ${attr(el, "data-testid")} ${attr(el, "data-cy")}`);
  }

  function role(el) {
    const explicit = attr(el, "role").trim().toLowerCase();
    if (explicit) return explicit;
    const t = tag(el);
    if (t === "a") return "link";
    if (t === "button") return "button";
    if (t === "textarea") return "textbox";
    if (t === "select") return "combobox";
    if (t === "option") return "option";
    if (t === "summary") return "button";
    if (t === "iframe") return "iframe";
    if (t === "input") {
      const it = String(attr(el, "type") || "text").toLowerCase();
      if (it === "search") return "searchbox";
      if (["number", "range"].includes(it)) return "spinbutton";
      if (it === "checkbox") return "checkbox";
      if (it === "radio") return "radio";
      if (["button", "submit", "reset", "image"].includes(it)) return "button";
      return "textbox";
    }
    if (isContentEditable(el)) return "textbox";
    return "generic";
  }

  function nearestLabelText(el) {
    const doc = el.ownerDocument || document;
    const id = attr(el, "id").trim();
    if (id) {
      try {
        const labels = doc.querySelectorAll(`label[for="${CSS.escape(id)}"]`);
        for (const label of labels) {
          const txt = rawText(label);
          if (txt) return txt;
        }
      } catch (_) {}
    }
    let p = el.parentElement;
    let depth = 0;
    while (p && depth < 4) {
      if (tag(p) === "label") {
        const txt = rawText(p);
        if (txt) return txt;
      }
      p = p.parentElement;
      depth++;
    }
    return "";
  }

  function accessibleName(el) {
    const aria = attr(el, "aria-label").trim();
    if (aria) return safeText(aria, 180);

    const labelled = attr(el, "aria-labelledby").trim();
    if (labelled) {
      const doc = el.ownerDocument || document;
      const value = labelled.split(/\s+/)
        .map(id => {
          try { return rawText(doc.getElementById(id) || null); } catch (_) { return ""; }
        })
        .filter(Boolean).join(" ");
      if (value) return safeText(value, 180);
    }

    const label = nearestLabelText(el);
    if (label) return safeText(label, 180);

    for (const name of ["title", "alt"]) {
      const value = attr(el, name).trim();
      if (value) return safeText(value, 180);
    }

    const placeholder = attr(el, "placeholder").trim();
    if (placeholder) return safeText(placeholder, 180);

    const name = attr(el, "name").trim();
    if (name) return safeText(name, 180);

    return safeText(rawText(el), 180);
  }

  function attrs(el) {
    const out = {};
    for (const name of [
      "placeholder", "name", "type", "autocomplete", "inputmode", "required",
      "disabled", "readonly", "aria-expanded", "aria-checked", "aria-selected",
      "aria-pressed", "aria-haspopup", "aria-controls", "aria-owns",
      "aria-activedescendant", "aria-invalid", "aria-describedby", "aria-live",
      "aria-valuenow", "aria-valuemin", "aria-valuemax",
      "maxlength", "minlength", "data-testid", "data-cy"
    ]) {
      const value = attr(el, name);
      if (value) out[name] = value.slice(0, 160);
    }
    const win = ownerWindow(el);
    try {
      const s = win.getComputedStyle(el);
      if (s.cursor && s.cursor !== "auto") out.cursor = s.cursor;
    } catch (_) {}
    if (sensitive(el)) out.sensitive = true;
    return out;
  }

  function controlKind(el) {
    if (tag(el) === "iframe") return "frame";
    if (isScrollable(el)) return "scroll-container";
    if (isContentEditable(el)) return "control";
    return "control";
  }

  function interactive(el, includeDisabled = false) {
    if (!isElement(el) || NON_INTERACTIVE.has(tag(el)) || !visibleish(el)) return false;
    const t = tag(el);
    const r = role(el);
    if (isDisabled(el) && !includeDisabled && t !== "iframe") return false;
    if (INTERACTIVE_TAGS.has(t) || INTERACTIVE_ROLES.has(r)) return true;
    if (isContentEditable(el)) return true;
    if (attr(el, "tabindex") !== "") return true;
    if (attr(el, "onclick") || typeof el.onclick === "function") return true;
    const win = ownerWindow(el);
    try {
      const style = win.getComputedStyle(el);
      if (["pointer", "grab", "grabbing", "cell", "copy", "alias", "zoom-in", "zoom-out", "context-menu"].includes(style.cursor)) return true;
    } catch (_) {}
    if (semanticClassSignal(el)) return true;
    return false;
  }

  function visibleish(el) {
    if (!rectVisible(el) || !inViewport(el)) return false;
    const r = role(el);
    return true;
  }

  function context(el) {
    const parts = [];
    let p = el.parentElement;
    let depth = 0;
    while (p && depth < 6) {
      const r = role(p);
      const t = accessibleName(p) || rawText(p);
      const semantic = ["dialog", "form", "main", "nav", "header", "footer", "section", "article", "region"].includes(r)
        || attr(p, "aria-label") || attr(p, "data-testid") || attr(p, "data-cy");
      if (semantic) {
        const label = safeText([r, t].filter(Boolean).join(" "), 120);
        if (label) parts.unshift(label);
      }
      p = p.parentElement;
      depth++;
    }
    return parts.slice(-3);
  }

  function valueInfo(el) {
    const t = tag(el);
    if (t === "input" || t === "textarea" || t === "select") {
      if (sensitive(el)) return {value: "[redacted]", valueLength: safeValueLength(el)};
      return {value: String(el.value ?? "").slice(0, 160), valueLength: safeValueLength(el)};
    }
    if (isContentEditable(el)) {
      return {value: sensitive(el) ? "[redacted]" : safeText(el.innerText || el.textContent || "", 160), valueLength: safeText(el.innerText || el.textContent || "", 10000).length};
    }
    return {value: "", valueLength: 0};
  }

  function safeValueLength(el) {
    try { return String(el.value ?? "").length; } catch (_) { return 0; }
  }

  function framePath(el) {
    const parts = [];
    let doc = el.ownerDocument;
    while (doc && doc.defaultView && doc !== document) {
      const frame = doc.defaultView.frameElement;
      if (!frame) break;
      parts.unshift(safeText(accessibleName(frame) || attr(frame, "title") || "iframe", 100));
      doc = frame.ownerDocument;
    }
    return parts;
  }

  function scrollMetrics(el) {
    if (!isScrollable(el)) return null;
    const byY = Math.max(0, el.scrollHeight - el.clientHeight);
    const byX = Math.max(0, el.scrollWidth - el.clientWidth);
    return {
      scrollTop: Math.round(el.scrollTop || 0),
      scrollLeft: Math.round(el.scrollLeft || 0),
      scrollHeight: Math.round(el.scrollHeight || 0),
      clientHeight: Math.round(el.clientHeight || 0),
      scrollWidth: Math.round(el.scrollWidth || 0),
      clientWidth: Math.round(el.clientWidth || 0),
      canDown: byY > 1 && (el.scrollTop + el.clientHeight) < (el.scrollHeight - 1),
      canUp: (el.scrollTop || 0) > 1,
      canRight: byX > 1 && (el.scrollLeft + el.clientWidth) < (el.scrollWidth - 1),
      canLeft: (el.scrollLeft || 0) > 1,
    };
  }

  function addElement(elements, el, kindOverride = null) {
    const kind = kindOverride || controlKind(el);
    const v = valueInfo(el);
    const status = statusInfo(el);
    const entry = {
      index: elements.length,
      role: role(el),
      name: accessibleName(el),
      value: v.value,
      valueLength: v.valueLength,
      attrs: attrs(el),
      context: context(el),
      tag: tag(el),
      kind: kind || (status.disabled ? "disabled-control" : "control"),
      status,
      framePath: framePath(el),
      scroll: scrollMetrics(el),
      _el: el,
      _doc: el.ownerDocument || document,
    };
    elements.push(entry);
    return entry;
  }

  function isMeaningfulTextElement(el) {
    const t = tag(el);
    const r = role(el);
    if (!BLOCK_TEXT_TAGS.has(t) && !BLOCK_TEXT_ROLES.has(r) && attr(el, "aria-live") === "") return false;
    if (!rectVisible(el)) return false;
    const txt = safeText(el.innerText || el.textContent || "", 260);
    if (!txt) return false;
    // Do not re-add a control's entire subtree as page text.
    if (interactive(el)) return false;
    return true;
  }

  function walkRoot(root, doc, elements, contentBlocks, seenDocs, parentFramePath) {
    if (!root) return;
    const stack = [];
    for (let child = root.lastElementChild; child; child = child.previousElementSibling) {
      stack.push({node: child, framePath: parentFramePath});
    }

    while (stack.length) {
      const item = stack.pop();
      const node = item.node;
      if (!isElement(node) || NON_INTERACTIVE.has(tag(node))) continue;

      const currentFramePath = item.framePath;
      const isControl = interactive(node);
      const isDisabledControl = !isControl && interactive(node, true) && isDisabled(node);
      const scroll = isScrollable(node);

      if ((isControl || isDisabledControl) && topLayer(node)) {
        const added = addElement(elements, node, isDisabledControl ? "disabled-control" : null);
        contentBlocks.push({type: "element", index: added.index});
      } else if (scroll && inViewport(node)) {
        const added = addElement(elements, node, "scroll-container");
        contentBlocks.push({type: "element", index: added.index});
      }

      if (isMeaningfulTextElement(node)) {
        const txt = safeText(node.innerText || node.textContent || "", 260);
        if (txt) contentBlocks.push({type: "text", text: txt, tag: tag(node)});
      }

      // Open Shadow DOM is a separate tree rather than a Document. Walk its
      // children explicitly so custom-element controls become first-class
      // targets, while closed roots remain inaccessible by design.
      if (node.shadowRoot) {
        const shadowPath = currentFramePath.concat([safeText(accessibleName(node) || tag(node), 100)]);
        walkRoot(node.shadowRoot, doc, elements, contentBlocks, seenDocs, shadowPath);
      }

      // Same-origin iframe: inspect its document as a nested browsing context.
      if (tag(node) === "iframe") {
        try {
          const childDoc = node.contentDocument;
          if (childDoc && childDoc !== doc) {
            const nextPath = currentFramePath.concat([safeText(accessibleName(node) || attr(node, "title") || "iframe", 100)]);
            walkDocument(childDoc, elements, contentBlocks, seenDocs, nextPath);
          }
        } catch (_) {
          // Cross-origin iframe: keep the iframe itself observable; browser JS
          // must not bypass the same-origin policy.
        }
      }

      for (let child = node.lastElementChild; child; child = child.previousElementSibling) {
        stack.push({node: child, framePath: currentFramePath});
      }
    }
  }

  function walkDocument(doc, elements, contentBlocks, seenDocs, parentFramePath = []) {
    if (!doc || seenDocs.has(doc)) return;
    seenDocs.add(doc);
    const root = doc.body || doc.documentElement;
    if (!root) return;
    walkRoot(root, doc, elements, contentBlocks, seenDocs, parentFramePath);
  }

  function collectTimers(doc) {
    const out = [];
    try {
      const nodes = doc.querySelectorAll?.("[role=timer], [aria-live], time, body *");
      for (const node of Array.from(nodes || [])) {
        if (!rectVisible(node)) continue;
        const txt = rawText(node);
        if (!txt || txt.length > 220 || !countdownMatch(txt)) continue;
        const roleName = attr(node, "role");
        const ariaLive = attr(node, "aria-live");
        const semantic = roleName === "timer" || ariaLive || /(countdown|timer|resend|ارسال مجدد|دوباره|کد جدید)/i.test(txt);
        if (!semantic) continue;
        const signature = `${roleName}|${ariaLive}|${txt}`;
        if (!out.some(x => x.signature === signature)) out.push({text: txt, role: roleName || "", ariaLive: ariaLive || "", signature});
        if (out.length >= 8) break;
      }
    } catch (_) {}
    return out.map(({signature, ...x}) => x);
  }

  function pageInfo() {
    const win = window;
    const doc = document.documentElement;
    const body = document.body;
    const pageWidth = Math.max(doc?.scrollWidth || 0, body?.scrollWidth || 0, win.innerWidth || 0);
    const pageHeight = Math.max(doc?.scrollHeight || 0, body?.scrollHeight || 0, win.innerHeight || 0);
    const y = win.scrollY || win.pageYOffset || 0;
    const x = win.scrollX || win.pageXOffset || 0;
    const viewportHeight = win.innerHeight || 0;
    const viewportWidth = win.innerWidth || 0;
    const stepY = Math.max(1, Math.round(viewportHeight * 0.8));
    return {
      viewport: {width: Math.round(viewportWidth), height: Math.round(viewportHeight)},
      page: {width: Math.round(pageWidth), height: Math.round(pageHeight)},
      position: {x: Math.round(x), y: Math.round(y)},
      pixelsAbove: Math.round(y),
      pixelsBelow: Math.max(0, Math.round(pageHeight - (y + viewportHeight))),
      pagesAbove: Math.max(0, Math.ceil(y / stepY)),
      pagesBelow: Math.max(0, Math.ceil(Math.max(0, pageHeight - (y + viewportHeight)) / stepY)),
      canScrollUp: y > 1,
      canScrollDown: y + viewportHeight < pageHeight - 1,
      timers: collectTimers(document),
    };
  }

  function buildContent(elements, contentBlocks, info) {
    const activeDialogs = Array.from(document.querySelectorAll?.('[role="dialog"], [aria-modal="true"], dialog[open]') || [])
      .filter(isElement)
      .filter(rectVisible)
      .slice(0, 8)
      .map(d => ({
        role: role(d),
        name: accessibleName(d),
        text: safeText(rawText(d), 260),
      }));
    const lines = [
      `Current Page: [${safeText(document.title, 180)}](${location.href})`,
      `Viewport: ${info.viewport.width}x${info.viewport.height}; scrollY=${info.position.y}; above=${info.pixelsAbove}; below=${info.pixelsBelow}`,
      `Interactive elements: ${elements.length}`,
      ...(activeDialogs.length ? activeDialogs.map(d => `ACTIVE DIALOG: ${d.name || d.role}${d.text ? ` | text=${JSON.stringify(d.text)}` : ""}`) : []),
    ...(info.timers?.length ? info.timers.map(t => `TIMER: ${t.text}`) : []),
      "",
    ];

    const byIndex = new Map(elements.map(e => [e.index, e]));
    let emitted = 0;
    for (const block of contentBlocks.slice(0, 520)) {
      if (emitted >= 360) break;
      if (block.type === "text") {
        lines.push(`TEXT <${block.tag}>: ${block.text}`);
        emitted++;
        continue;
      }
      if (block.type !== "element") continue;
      const e = byIndex.get(block.index);
      if (!e) continue;
      const name = e.name ? ` "${e.name.replace(/"/g, '\\"')}"` : "";
      const frame = e.framePath?.length ? ` | frame=${e.framePath.join(" > ")}` : "";
      const ctx = e.context?.length ? ` | context=${e.context.join(" > ")}` : "";
      const at = Object.entries(e.attrs || {}).map(([k, v]) => `${k}=${JSON.stringify(v)}`).join(" ");
      const val = e.value ? ` | value=${JSON.stringify(e.value)}` : "";
      const sc = e.scroll ? ` | scroll=${e.scroll.canDown ? "down" : ""}${e.scroll.canUp ? "/up" : ""}` : "";
      const st = e.status || {};
      const flags = [];
      if (st.disabled) flags.push("DISABLED");
      if (st.readonly) flags.push("READONLY");
      if (st.required) flags.push(st.requiredMissing ? "REQUIRED-EMPTY" : "REQUIRED-FILLED");
      if (st.invalid) flags.push("INVALID");
      if (st.countdown) flags.push(`countdown=${JSON.stringify(st.countdown)}`);
      if (st.disabledOwner?.name) flags.push(`disabled_owner=${st.disabledOwner.name}`);
      if (st.blockedBy?.length) flags.push(`blocked_by=${st.blockedBy.map(x => x.name).join(" | ")}`);
      if (st.prerequisiteCandidates?.length) flags.push(`prereq_candidates=${st.prerequisiteCandidates.map(x => x.name).join(" | ")}`);
      const stateText = flags.length ? ` | state=${flags.join(",")}` : "";
      lines.push(`[${e.index}] ${e.role}${name} | kind=${e.kind}${stateText}${at ? ` | ${at}` : ""}${val}${sc}${frame}${ctx}`);
      emitted++;
    }

    return lines.join("\n").slice(0, 52000);
  }

  function clean(e) {
    return {
      index: e.index,
      role: e.role,
      name: e.name,
      value: e.value,
      valueLength: e.valueLength,
      attrs: e.attrs,
      context: e.context,
      tag: e.tag,
      kind: e.kind,
      status: e.status,
      framePath: e.framePath,
      scroll: e.scroll,
    };
  }

  function rebuild() {
    const elements = [];
    const contentBlocks = [];
    const seenDocs = new Set();
    walkDocument(document, elements, contentBlocks, seenDocs, []);

    // Stable per-observation mapping. Actions never call rebuild() implicitly.
    state.elements = elements;
    state.updatedAt = Date.now();
    state.revision += 1;
    state.url = location.href;
    state.title = document.title;
    state.pageInfo = pageInfo();
    state.scrollables = elements
      .filter(e => e.kind === "scroll-container" && e.scroll)
      .slice(0, 100)
      .map(clean);
    state.content = buildContent(elements, contentBlocks, state.pageInfo);
    return state;
  }

  function currentMap() {
    if (!state.updatedAt || !state.elements.length && (document.body || document.documentElement)) rebuild();
    return state.elements;
  }

  function cleanFind(e, score, why) {
    return {...clean(e), score, match: why};
  }

  const FIND_CONCEPTS = [
    ["forgot password", ["forgot password", "password reset", "reset password", "فراموشی رمز", "فراموشی کلمه عبور", "بازیابی رمز"]],
    ["login", ["login", "log in", "sign in", "ورود"]],
    ["confirm", ["confirm", "ok", "تایید", "تأیید", "ادامه"]],
    ["phone", ["phone", "mobile", "telephone", "شماره موبایل", "شماره تلفن"]],
  ];

  function queryVariants(query) {
    const raw = safeText(query, 180).toLocaleLowerCase();
    if (!raw) return [];
    const variants = [raw];
    for (const [trigger, aliases] of FIND_CONCEPTS) {
      if (raw.includes(trigger) || aliases.some(alias => raw.includes(alias))) {
        for (const alias of aliases) if (!variants.includes(alias)) variants.push(alias);
      }
    }
    return variants;
  }

  function find(query) {
    const queries = queryVariants(query);
    if (!queries.length) return [];
    rebuild();

    const scored = [];
    for (const e of state.elements) {
      const fields = [
        [e.name, 120],
        [e.attrs?.placeholder, 100],
        [e.attrs?.name, 80],
        [e.attrs?.["data-testid"], 70],
        [e.attrs?.["data-cy"], 70],
        [e.role, 55],
        [e.context?.join(" "), 45],
        [e.framePath?.join(" "), 30],
        [e.status?.countdown, 35],
      ];
      let score = 0;
      let why = "";
      for (const q of queries) {
        for (const [value, weight] of fields) {
          const textValue = String(value || "").toLocaleLowerCase();
          if (!textValue) continue;
          if (textValue === q) { score = Math.max(score, weight + 45); why = "exact"; }
          else if (textValue.startsWith(q)) { score = Math.max(score, weight + 20); if (!why) why = "prefix"; }
          else if (textValue.includes(q)) { score = Math.max(score, weight); if (!why) why = "contains"; }
        }
      }
      if (score) {
        if (e.status?.disabled) score = Math.max(1, score - 90);
        else if (e.status?.actionable) score += 12;
        scored.push(cleanFind(e, score, why));
      }
    }

    return scored.sort((a, b) => b.score - a.score || a.index - b.index).slice(0, 20);
  }

  function ensureIndex(index) {
    const n = Number(index);
    if (!Number.isInteger(n) || n < 0) throw new Error(`Invalid Page-Agent element index: ${index}`);
    const e = currentMap().find(x => x.index === n);
    if (!e) throw new Error(`Element index ${index} is not present in the current observed Page-Agent DOM; request a fresh observation.`);
    if (!e._el || !e._el.isConnected) throw new Error(`Element index ${index} became stale after observation; request a fresh observation.`);
    return e;
  }

  let lastClickedElement = null;

  function eventPayload(win, x, y) {
    return {bubbles: true, cancelable: true, clientX: x, clientY: y, pointerType: "mouse", button: 0, buttons: 1, view: win};
  }

  function dispatchMouseLike(target, type, x, y) {
    const win = ownerWindow(target);
    try {
      if (/^pointer/.test(type) && win.PointerEvent) target.dispatchEvent(new win.PointerEvent(type, eventPayload(win, x, y)));
      else if (type === "mouseenter" || type === "mouseleave") target.dispatchEvent(new win.MouseEvent(type, {...eventPayload(win, x, y), bubbles: false}));
      else target.dispatchEvent(new win.MouseEvent(type, eventPayload(win, x, y)));
    } catch (_) {}
  }

  function clickableTarget(el) {
    const win = ownerWindow(el);
    const doc = el.ownerDocument || document;
    const r = el.getBoundingClientRect();
    const x = Math.min(Math.max(r.left + r.width / 2, 0), Math.max(win.innerWidth - 1, 0));
    const y = Math.min(Math.max(r.top + r.height / 2, 0), Math.max(win.innerHeight - 1, 0));
    const hit = doc.elementFromPoint(x, y);
    if (isElement(hit) && (el === hit || el.contains(hit))) return {target: hit, x, y};
    return {target: el, x, y};
  }

  async function click(index) {
    const e = ensureIndex(index);
    if (e.status?.disabled || isDisabled(e._el)) {
      const blockers = (e.status?.blockedBy || []).map(x => x.name).filter(Boolean);
      const owner = e.status?.disabledOwner?.name ? ` Disabled semantic owner: ${e.status.disabledOwner.name}.` : "";
      const timer = e.status?.countdown ? ` Countdown evidence: ${e.status.countdown}` : "";
      throw new Error(`Element [${index}] is DISABLED in the live page state. Do not click it. Complete currently actionable prerequisites first.${owner}${blockers.length ? ` Likely blocking fields: ${blockers.join(" | ")}.` : ""}${timer}`);
    }
    if (e.kind === "scroll-container") {
      throw new Error(`Element [${index}] is a scroll container; use scroll with this index instead of click.`);
    }
    if (e.tag === "input" && String(e.attrs?.type || "").toLowerCase() === "file") {
      throw new Error(`Element [${index}] is a file input; use the dedicated upload integration instead of clicking the chooser.`);
    }

    const el = e._el;
    el.scrollIntoView({block: "center", inline: "nearest"});
    const {target, x, y} = clickableTarget(el);
    if (lastClickedElement && lastClickedElement !== el && lastClickedElement.blur) {
      try { lastClickedElement.blur(); } catch (_) {}
    }

    ["pointerover", "pointerenter", "mouseover", "mouseenter", "pointerdown", "mousedown"].forEach(type => dispatchMouseLike(target, type, x, y));
    try { el.focus({preventScroll: true}); } catch (_) { try { el.focus(); } catch (_) {} }
    ["pointerup", "mouseup"].forEach(type => dispatchMouseLike(target, type, x, y));
    try { target.click(); } catch (_) { el.click(); }
    lastClickedElement = el;
    await new Promise(resolve => setTimeout(resolve, 160));
    return {success: true, message: `Clicked element [${index}] ${e.role} ${e.name}`};
  }

  function getValueSetter(el) {
    try {
      const proto = Object.getPrototypeOf(el);
      return Object.getOwnPropertyDescriptor(proto, "value")?.set || null;
    } catch (_) { return null; }
  }

  function dispatchInputEvents(el, value) {
    const win = ownerWindow(el);
    try { el.dispatchEvent(new win.Event("beforeinput", {bubbles: true, cancelable: true, inputType: "insertText", data: String(value)})); } catch (_) {}
    try {
      // Use InputEvent when available — this is what Vue/React v-model
      // listeners actually listen for. The data field is critical for
      // frameworks that reconstruct the value from the event.
      el.dispatchEvent(new win.InputEvent("input", {bubbles: true, inputType: "insertText", data: String(value)}));
    } catch (_) {
      el.dispatchEvent(new win.Event("input", {bubbles: true, inputType: "insertText"}));
    }
    el.dispatchEvent(new win.Event("change", {bubbles: true}));
  }

  function setNativeInputValue(el, value) {
    const setter = getValueSetter(el);
    if (setter) setter.call(el, String(value)); else el.value = String(value);
    dispatchInputEvents(el, value);
  }

  // Vue/React controlled inputs sometimes ignore a direct value setter
  // because the framework re-renders from its internal model on the next
  // microtask. This fallback uses the deprecated but widely-supported
  // execCommand("insertText") path, which fires a real trusted input
  // event that frameworks cannot ignore.
  function execCommandInsertText(el, value) {
    const win = ownerWindow(el);
    try {
      el.focus({preventScroll: true});
    } catch (_) { try { el.focus(); } catch (_) {} }
    // Select all existing content and replace it.
    try {
      el.select();
    } catch (_) {}
    try {
      if (win.document.execCommand && win.document.execCommand("insertText", false, String(value))) {
        el.dispatchEvent(new win.Event("input", {bubbles: true}));
        el.dispatchEvent(new win.Event("change", {bubbles: true}));
        return true;
      }
    } catch (_) {}
    return false;
  }

  function replaceContentEditable(el, value) {
    const win = ownerWindow(el);
    try {
      const selection = win.getSelection?.();
      const range = win.document.createRange();
      range.selectNodeContents(el);
      selection?.removeAllRanges();
      selection?.addRange(range);
      if (win.document.execCommand && win.document.execCommand("insertText", false, String(value))) {
        el.dispatchEvent(new win.Event("input", {bubbles: true, inputType: "insertText"}));
        el.dispatchEvent(new win.Event("change", {bubbles: true}));
        return;
      }
    } catch (_) {}

    el.textContent = String(value);
    el.dispatchEvent(new win.Event("input", {bubbles: true, inputType: "insertText"}));
    el.dispatchEvent(new win.Event("change", {bubbles: true}));
  }

  function keyEvent(target, type, key) {
    const win = ownerWindow(target);
    try { target.dispatchEvent(new win.KeyboardEvent(type, {key, code: key.length === 1 ? "Key" + key.toUpperCase() : key, bubbles: true, cancelable: true})); } catch (_) {}
  }

  async function typeRealistically(el, value, options) {
    const textValue = String(value);
    const minDelay = Math.max(0, Number(options?.minDelayMs ?? 55));
    const maxDelay = Math.max(minDelay, Number(options?.maxDelayMs ?? 125));
    const pauseChance = Math.max(0, Math.min(1, Number(options?.pauseChance ?? 0.015)));
    const pauseMin = Math.max(0, Number(options?.pauseMinMs ?? 140));
    const pauseMax = Math.max(pauseMin, Number(options?.pauseMaxMs ?? 320));
    const pre = Math.max(0, Number(options?.preDelayMs ?? 40));

    if (pre) await new Promise(r => setTimeout(r, pre));
    // Clear first using the same framework-aware path as fill, then emit key
    // events for each character. The value setter is still used because many
    // controlled React/Vue inputs ignore direct textContent/value mutation.
    setNativeInputValue(el, "");
    for (const ch of textValue) {
      keyEvent(el, "keydown", ch);
      keyEvent(el, "keypress", ch);
      const current = String(el.value ?? "");
      setNativeInputValue(el, current + ch);
      keyEvent(el, "keyup", ch);
      const delay = minDelay + Math.random() * Math.max(0, maxDelay - minDelay);
      if (delay > 0) await new Promise(r => setTimeout(r, delay));
      if (Math.random() < pauseChance) {
        const pause = pauseMin + Math.random() * Math.max(0, pauseMax - pauseMin);
        await new Promise(r => setTimeout(r, pause));
      }
    }
  }

  async function input(index, value, options = {}) {
    const e = ensureIndex(index);
    if (e.status?.disabled || isDisabled(e._el)) throw new Error(`Element [${index}] is DISABLED in the live page state; input is not allowed until prerequisites are satisfied.`);
    if (e.status?.readonly || isReadonly(e._el)) throw new Error(`Element [${index}] is READONLY in the live page state.`);
    const el = e._el;
    const t = tag(el);
    if (t === "select") throw new Error(`Element [${index}] is a select; use select_dropdown_option`);
    if (t === "input" && ["checkbox", "radio", "button", "submit", "reset", "file", "image"].includes(String(attr(el, "type")).toLowerCase())) {
      throw new Error(`Element [${index}] is not a text-entry control`);
    }
    if (!(t === "input" || t === "textarea" || isContentEditable(el))) {
      throw new Error(`Element [${index}] is not a text input or contenteditable control`);
    }

    const expectedValue = String(value ?? "");
    el.scrollIntoView({block: "center", inline: "nearest"});
    try { el.focus({preventScroll: true}); } catch (_) { try { el.focus(); } catch (_) {} }

    let usedMethod = "native_setter";

    if (isContentEditable(el)) {
      replaceContentEditable(el, expectedValue);
      usedMethod = "contenteditable";
    } else if (options?.realistic) {
      await typeRealistically(el, expectedValue, options);
      usedMethod = "realistic";
    } else {
      // Method 1: native value setter + InputEvent.
      setNativeInputValue(el, expectedValue);
    }

    // Give the framework a microtask to process the input event, then verify
    // the value actually stuck. Vue/React controlled inputs sometimes revert
    // the value on the next microtask if they don't like the input event.
    await new Promise(resolve => setTimeout(resolve, 50));

    let actualValue = "";
    try { actualValue = currentValue(el); } catch (_) {}

    // If the native setter didn't stick, try execCommand insertText as a
    // fallback. This fires a real trusted input event that frameworks
    // cannot ignore.
    if (actualValue !== expectedValue && !isContentEditable(el)) {
      try { el.focus({preventScroll: true}); } catch (_) { try { el.focus(); } catch (_) {} }
      if (execCommandInsertText(el, expectedValue)) {
        usedMethod = "execCommand_insertText";
        await new Promise(resolve => setTimeout(resolve, 50));
        try { actualValue = currentValue(el); } catch (_) {}
      }
    }

    // If execCommand also didn't stick, try a character-by-character native
    // setter approach (no blur between chars). This works for Vue inputs
    // that listen to per-character input events.
    if (actualValue !== expectedValue && !isContentEditable(el)) {
      try { el.focus({preventScroll: true}); } catch (_) { try { el.focus(); } catch (_) {} }
      setNativeInputValue(el, "");
      for (const ch of expectedValue) {
        const cur = String(el.value ?? "");
        setNativeInputValue(el, cur + ch);
        // Small delay between chars to let the framework process each event.
        await new Promise(resolve => setTimeout(resolve, 10));
      }
      usedMethod = "char_by_char";
      await new Promise(resolve => setTimeout(resolve, 30));
      try { actualValue = currentValue(el); } catch (_) {}
    }

    // DO NOT blur. Vue/React components often clear or revert the value on
    // blur if it doesn't pass validation, or if the component uses
    // v-model.lazy that re-syncs from the model on blur. Keeping focus lets
    // the model stay in sync with the input until the user (or the next
    // action) explicitly moves focus.

    const stuck = actualValue === expectedValue;
    return {
      success: true,
      message: stuck
        ? `Input text into element [${index}] (method=${usedMethod}, value_length=${actualValue.length})`
        : `Input attempted on element [${index}] (method=${usedMethod}) but value did not stick — expected length ${expectedValue.length}, got ${actualValue.length}. The field may have validation that rejects this value, or the framework reverted it.`,
      value_stuck: stuck,
      actual_length: actualValue.length,
      expected_length: expectedValue.length,
      method: usedMethod,
    };
  }

  function singleCharInput(el) {
    if (!isElement(el) || tag(el) !== "input") return false;
    const type = String(attr(el, "type") || "text").toLowerCase();
    if (["hidden", "checkbox", "radio", "button", "submit", "reset", "file", "image"].includes(type)) return false;
    if (isDisabled(el) || isReadonly(el) || !rectVisible(el)) return false;
    const max = Number(attr(el, "maxlength") || 0);
    const min = Number(attr(el, "minlength") || 0);
    const value = String(currentValue(el) || "");
    // Prefer explicit maxlength=1; otherwise a currently one-character value
    // or a single-character inputmode/pattern still provides runtime evidence.
    const pattern = attr(el, "pattern");
    const inputmode = attr(el, "inputmode");
    return max === 1 || (value.length <= 1 && (min <= 1 || !!pattern || !!inputmode));
  }

  function inputGroupCandidates() {
    rebuild();
    const all = state.elements.filter(e => {
      const el = e._el;
      return tag(el) === "input" &&
        !["hidden", "checkbox", "radio", "button", "submit", "reset", "file"].includes(String(attr(el, "type")).toLowerCase()) &&
        !isDisabled(el) && attr(el, "readonly") === "" && Number(attr(el, "maxlength") || 0) === 1;
    });

    const groups = [];
    const seen = new Set();
    for (const item of all) {
      if (seen.has(item.index)) continue;
      const el = item._el;
      let container = null;
      for (let p = el.parentElement, depth = 0; p && depth < 6; p = p.parentElement, depth++) {
        if (["fieldset", "form", "section", "main", "dialog"].includes(tag(p)) || ["group", "dialog"].includes(attr(p, "role"))) {
          container = p; break;
        }
      }
      container = container || el.parentElement;
      const members = all.filter(x => {
        const other = x._el;
        return x.index === item.index || (container && (container.contains(other) || other.parentElement === el.parentElement));
      });
      members.sort((a, b) => a.index - b.index);
      if (members.length >= 2) {
        const key = members.map(x => x.index).join(",");
        if (!groups.some(g => g.key === key)) {
          groups.push({key, indices: members.map(x => x.index), elements: members});
          members.forEach(x => seen.add(x.index));
        }
      }
    }
    return groups;
  }

  function findInputGroup(value) {
    const wanted = String(value ?? "");
    if (!wanted) return null;
    const groups = inputGroupCandidates();
    const exact = groups.filter(g => g.indices.length === wanted.length);
    if (exact.length === 1) return cleanInputGroup(exact[0]);
    const fitting = groups.filter(g => g.indices.length >= wanted.length);
    return fitting.length === 1 ? cleanInputGroup(fitting[0]) : null;
  }

  function findInputGroupByLength(length) {
    const wanted = Number(length);
    if (!Number.isInteger(wanted) || wanted < 2 || wanted > 32) return null;
    const groups = inputGroupCandidates();
    const exact = groups.filter(g => g.indices.length === wanted);
    if (exact.length === 1) return cleanInputGroup(exact[0]);
    return null;
  }

  function cleanInputGroup(group) {
    return {
      indices: group.indices,
      elements: group.elements.map(clean),
      length: group.indices.length,
    };
  }

  async function inputBatch(items, options = {}) {
    if (!Array.isArray(items) || !items.length) throw new Error("input_batch requires a non-empty items array");
    const resolved = items.map(item => {
      const index = Number(item?.index);
      const e = ensureIndex(index);
      const t = tag(e._el);
      if (!(t === "input" || t === "textarea" || isContentEditable(e._el))) throw new Error(`Element [${index}] is not a text input`);
      if (t === "input" && ["checkbox", "radio", "button", "submit", "reset", "file"].includes(String(attr(e._el, "type")).toLowerCase())) throw new Error(`Element [${index}] is not text-entry capable`);
      return {e, value: String(item?.text ?? "")};
    });

    for (const {e, value} of resolved) {
      await input(e.index, value, options);
    }
    return {success: true, message: `Batch input into ${resolved.length} observed fields`};
  }

  async function select(index, optionText) {
    const e = ensureIndex(index);
    if (e.status?.disabled || isDisabled(e._el)) {
      const blockers = (e.status?.blockedBy || []).map(x => x.name).filter(Boolean);
      const owner = e.status?.disabledOwner?.name ? ` Disabled semantic owner: ${e.status.disabledOwner.name}.` : "";
      throw new Error(`Element [${index}] is DISABLED in the live page state; do not attempt to open it.${owner}${blockers.length ? ` Complete these currently actionable prerequisites first: ${blockers.join(" | ")}.` : ""}`);
    }
    const el = e._el;
    const wanted = safeText(optionText, 180);
    if (!wanted) throw new Error("select_dropdown_option requires exact observed option text");

    if (tag(el) === "select") {
      const matches = Array.from(el.options || []).filter(o => safeText(o.textContent) .toLocaleLowerCase() === wanted.toLocaleLowerCase());
      if (matches.length !== 1) throw new Error(`No unique observed option matches requested text`);
      el.value = matches[0].value;
      const win = ownerWindow(el);
      el.dispatchEvent(new win.Event("input", {bubbles: true}));
      el.dispatchEvent(new win.Event("change", {bubbles: true}));
      await new Promise(r => setTimeout(r, 40));
      return {success: true, message: `Selected observed option in element [${index}]`};
    }

    // Custom dropdowns: open the observed control, then refresh the map and
    // resolve the option by exact semantic text. This is the only deliberate
    // remapping point in the action.
    const {target} = clickableTarget(el);
    try { target.click(); } catch (_) { el.click(); }
    await new Promise(r => setTimeout(r, 100));
    rebuild();

    const wantedLower = wanted.toLocaleLowerCase();
    const matches = state.elements.filter(candidate => {
      const r = String(candidate.role || "").toLowerCase();
      if (!new Set(["option", "menuitem", "menuitemradio", "menuitemcheckbox", "listitem", "generic"]).has(r)) return false;
      if (!candidate.name || candidate.name.trim().toLocaleLowerCase() !== wantedLower) return false;
      return candidate.kind === "control" && topLayer(candidate._el);
    });

    if (matches.length !== 1) {
      throw new Error(matches.length === 0
        ? `No uniquely observed dropdown option matches exact text: ${wanted}`
        : `Multiple observed dropdown options match exact text: ${wanted}`);
    }

    await click(matches[0].index);
    return {success: true, message: `Selected uniquely observed dropdown option "${wanted}" for element [${index}]`, optionIndex: matches[0].index};
  }

  function scrollEvidence(index) {
    if (index === undefined || index === null) {
      return {
        page: {
          scrollY: Math.round(window.scrollY || window.pageYOffset || 0),
          scrollHeight: Math.round(document.documentElement?.scrollHeight || 0),
          clientHeight: Math.round(document.documentElement?.clientHeight || window.innerHeight || 0),
          canDown: state.pageInfo?.canScrollDown ?? pageInfo().canScrollDown,
          canUp: state.pageInfo?.canScrollUp ?? pageInfo().canScrollUp,
          pixelsAbove: state.pageInfo?.pixelsAbove ?? pageInfo().pixelsAbove,
          pixelsBelow: state.pageInfo?.pixelsBelow ?? pageInfo().pixelsBelow,
        },
        target: null,
      };
    }

    const observed = ensureIndex(index);
    const metrics = scrollMetrics(observed._el);
    if (!metrics) throw new Error(`Element [${index}] is not an observed scrollable container`);
    return {page: pageInfo(), target: {index: observed.index, ...metrics}};
  }

  function scrollTargetFor(observed) {
    if (observed && observed.kind === "scroll-container" && observed._el) return observed._el;
    if (observed?._el) {
      let p = observed._el.parentElement;
      for (let depth = 0; p && depth < 8; p = p.parentElement, depth++) {
        if (isScrollable(p)) return p;
      }
    }
    return null;
  }

  async function scroll({down = true, pixels, index} = {}) {
    const before = scrollEvidence(index);
    const observed = index === undefined || index === null ? null : ensureIndex(index);
    const target = index === undefined || index === null ? null : scrollTargetFor(observed);
    const beforeTarget = target ? scrollMetrics(target) : null;
    const canMove = target
      ? (down ? beforeTarget?.canDown : beforeTarget?.canUp)
      : (down ? before.page.canDown : before.page.canUp);

    if (!canMove) {
      return {success: false, blocked: true, reason: "no_scroll_evidence", before, message: `No observed scrollable distance ${down ? "down" : "up"}`};
    }

    const amount = Math.max(40, Math.min(Number(pixels || Math.round((ownerWindow(target || document.documentElement)).innerHeight * 0.8)), 4000));
    if (target) {
      target.scrollBy({top: down ? amount : -amount, left: 0, behavior: "auto"});
    } else {
      window.scrollBy({top: down ? amount : -amount, left: 0, behavior: "auto"});
    }

    await new Promise(r => setTimeout(r, 40));
    const after = scrollEvidence(index);
    const moved = target
      ? beforeTarget?.scrollTop !== scrollMetrics(target)?.scrollTop
      : before.page.scrollY !== after.page.scrollY;
    return {
      success: moved,
      blocked: !moved,
      reason: moved ? "scrolled_with_evidence" : "scroll_no_effect",
      before,
      after,
      message: moved ? `Scrolled ${down ? "down" : "up"}` : "Scroll produced no observed movement",
    };
  }

  async function wait(seconds = 1) {
    const ms = Math.max(0, Math.min(Number(seconds || 0) * 1000, 60000));
    if (ms) await new Promise(resolve => setTimeout(resolve, ms));
    return {success: true, message: `Waited ${Math.round(ms)}ms`};
  }

  async function getState() {
    // One semantic observation per turn. If an actual dialog exists but its
    // interactive surface has not rendered yet, allow one short render turn.
    rebuild();
    try {
      const dialogs = Array.from(document.querySelectorAll?.('[role="dialog"], [aria-modal="true"], dialog[open]') || [])
        .filter(isElement).filter(rectVisible);
      if (dialogs.length) {
        const roots = new Set(dialogs);
        const controls = state.elements.filter(e => {
          let p = e._el;
          let depth = 0;
          while (p && depth < 12) {
            if (roots.has(p)) return true;
            p = p.parentElement;
            depth++;
          }
          return false;
        });
        if (controls.length <= 1) {
          await new Promise(resolve => setTimeout(resolve, 80));
          rebuild();
        }
      }
    } catch (_) {}
    return JSON.stringify({
      url: state.url,
      title: state.title,
      content: state.content,
      elements: state.elements.map(clean),
      pageInfo: state.pageInfo,
      scrollables: state.scrollables,
      revision: state.revision,
      updatedAt: state.updatedAt,
    });
  }

  window[KEY] = {
    getState,
    find,
    click,
    input,
    inputBatch,
    findInputGroup,
    select,
    scroll,
    scrollEvidence,
    wait,
    rebuild,
  };
  return window[KEY];
})()
