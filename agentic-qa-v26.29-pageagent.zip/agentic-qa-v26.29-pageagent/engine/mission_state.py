"""Generic mission state with immutable user inputs and checkpoints."""
from dataclasses import dataclass, field
from types import MappingProxyType


@dataclass
class MissionState:
    declared_inputs: dict = field(default_factory=dict)
    human_inputs: dict = field(default_factory=dict)
    checkpoints: dict = field(default_factory=dict)
    artifacts: list = field(default_factory=list)
    blocked_reasons: list = field(default_factory=list)

    def __post_init__(self):
        self.declared_inputs = dict(self.declared_inputs or {})
        self.human_inputs = dict(self.human_inputs or {})
        self.checkpoints = dict(self.checkpoints or {})

    @staticmethod
    def _write_once(mapping, key, value, label):
        if key in mapping and mapping[key] != value:
            raise ValueError(f"immutable {label} conflict for {key!r}")
        mapping[key] = value

    def declare(self, key, value):
        self._write_once(self.declared_inputs, key, value, "mission input")

    def set_human_input(self, key, value, ephemeral=False):
        # Empty/whitespace responses are pending input, never committed.
        text = str(value or "")
        if not text.strip():
            return
        # Runtime one-time values (for example a CAPTCHA/OTP) can legitimately
        # change when the page refreshes or the challenge expires. Mission
        # literals and durable human inputs remain immutable.
        if ephemeral:
            self.human_inputs[key] = value
            return
        self._write_once(self.human_inputs, key, value, "human input")

    def declare_checkpoint(self, key, checkpoint):
        self._write_once(self.checkpoints, key, dict(checkpoint or {}), "checkpoint")

    def add_artifact(self, artifact):
        self.artifacts.append(dict(artifact))

    def block(self, reason):
        if reason not in self.blocked_reasons:
            self.blocked_reasons.append(reason)

    def view(self):
        return {
            "declared_inputs": MappingProxyType(dict(self.declared_inputs)),
            "human_inputs": MappingProxyType(dict(self.human_inputs)),
            "checkpoints": MappingProxyType({k: dict(v) for k, v in self.checkpoints.items()}),
            "artifacts": tuple(dict(x) for x in self.artifacts),
            "blocked_reasons": tuple(self.blocked_reasons),
        }
