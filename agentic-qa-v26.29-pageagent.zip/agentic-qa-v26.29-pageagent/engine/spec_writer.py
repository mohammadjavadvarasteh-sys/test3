# =====================================================================
# engine/spec_writer.py
# ---------------------------------------------------------------------
# «spec» — ساخت خودکار فایل Spec فقط از یک URL + هدف.
#
#   python main.py spec --url https://site.ir --goal "ورود کاربر را تست کن"
#   → specs/<slug>.yaml
#
# دو مسیر تولید:
#   1) LLM (اگر endpoint در دسترس باشد) — قدم‌های معقول از روی هدف
#      می‌نویسد: پر کردن فیلدها، prompt_user برای کپچا/OTP،
#      کلیک ورود، wait_for بعد از submit و ...
#   2) قالب حداقلی (fallback) — بدون هوش مصنوعی هم همیشه یک Spec
#      معتبر تولید می‌شود (agent در اجرا خودش مسیر را پیدا می‌کند).
#
# قواعد (مطابق Constitution):
#   - هیچ selector ی نوشته نمی‌شود (#14) — فقط توصیف معنایی
#   - کپچا / کد تایید → prompt_user + placeholder {var}
#   - رمز عبور → {secret:...} (هرگز در spec ذخیره نمی‌شود)
#   - خانه‌های تک‌کاراکتری (کپچا/OTP) → multi_input: true
# =====================================================================

import os
import re

import yaml

import config

VALID_ACTIONS = {
    "", "type", "click", "select", "upload", "prompt_user", "wait", "verify",
}
VALID_POLICIES = {
    "must_complete_before_submit", "requires_all_inputs_filled",
    "must_complete", "post_submit", "optional", "",
}

SPEC_HEADER_NOTE = (
    "# ------------------------------------------------------------------\n"
    "# این Spec به‌صورت خودکار ساخته شده (agentic-qa spec).\n"
    "# قبل از اجرا می‌توانید مقدارها را ویرایش کنید؛ فیلدهای هر قدم:\n"
    "#   description : جمله‌ی انسانی — سیگنال اصلی برای agent\n"
    "#   action      : type | click | select | upload | prompt_user | wait\n"
    "#   target_hint : راهنمای معنایی (متن دکمه/label — نه CSS!)\n"
    "#   value       : مقدار؛ از {var}، {secret:...} و {env:...} پشتیبانی می‌کند\n"
    "#   wait_for    : معیار پذیرش (متنی که باید دیده شود)\n"
    "# ------------------------------------------------------------------\n"
)


# ---------------------------------------------------------------------
# کمک‌تابع‌ها
# ---------------------------------------------------------------------

def slugify(text, fallback="spec"):
    """نام فایل امن از متن (فارسی/انگلیسی) — فقط حروف لاتین و خط تیره."""
    # حروف فارسی و علائم حذف می‌شوند؛ اگر چیزی نماند از fallback
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", str(text or "")).strip("-").lower()
    return (slug or fallback)[:60]


def _is_persian(text):
    return bool(re.search(r"[\u0600-\u06FF]", str(text or "")))


# ---------------------------------------------------------------------
# پرامپت LLM
# ---------------------------------------------------------------------

SPEC_WRITER_SYSTEM = """You are a senior QA spec writer. You convert a plain
testing goal into a machine-runnable test Spec (YAML schema, JSON here).
You NEVER write CSS/XPath selectors — steps describe WHAT the user wants,
the runtime agent finds elements semantically from the live accessibility
snapshot.

Output STRICT JSON only:
{
  "feature": "<short-slug-name>",
  "target_url": "<the url>",
  "intent": "<one or two sentences, same language as the goal>",
  "steps": [
    {
      "id": "REQ-001",
      "description": "<human sentence, same language as the goal>",
      "action": "type|click|select|upload|prompt_user|wait|verify",
      "target_hint": "<semantic hint: visible label/text of the element>",
      "value": "<value to type/select/upload — may use {var} placeholders>",
      "wait_for": "<text that should become visible after this step>",
      "multi_input": false,
      "policy": "must_complete_before_submit|requires_all_inputs_filled|must_complete|post_submit|optional"
    }
  ]
}

Hard rules:
- 3 to 10 steps, ordered like a real user would act.
- Login flows: type username/identifier first, then password as
  {"action":"type","value":"{secret:password}"} — secrets are NEVER
  written literally, always {secret:NAME}.
- Captcha or SMS OTP: first a prompt_user step
  ({"action":"prompt_user","message":"...","save_to":"captcha"}), then a
  type step whose value is "{captcha}". If the captcha/OTP is split into
  single-character cells, set "multi_input": true on the type step.
- Before any submit button click, fill steps carry policy
  "must_complete_before_submit"; the submit click itself carries
  "requires_all_inputs_filled" and a "wait_for" describing the next
  screen/expected message.
- Steps that might legitimately not appear (optional popups) use
  policy "optional".
- Do NOT invent literal values you don't know — use {var} / {secret:NAME}
  placeholders instead.
- Write descriptions/intent in the SAME language as the goal
  (Persian goal → Persian descriptions; ids and action values stay
  English)."""


def draft_with_ai(base_url, goal, name=None, max_steps=10, ai=None):
    """
    تلاش برای تولید Spec با LLM.
    خروجی: (spec_dict, warning) — warning در صورت افتادن به قالب.
    """
    from engine.ai_client import AIClient

    warnings = []
    ai = ai or AIClient()
    user_prompt = (
        f"URL to test: {base_url}\n"
        f"Testing goal: {goal}\n"
        f"Max steps: {max_steps}\n\n"
        "Write the complete spec JSON now."
    )
    raw = ai.chat_json(
        [{"role": "system", "content": SPEC_WRITER_SYSTEM},
         {"role": "user", "content": user_prompt}],
    )
    spec = _normalize_spec(raw, base_url, goal, name, max_steps)
    if not spec.get("steps"):
        raise ValueError("LLM returned no usable steps")
    return spec, warnings


def template_spec(base_url, goal, name=None):
    """قالب حداقلی — بدون LLM همیشه یک Spec معتبر."""
    return {
        "feature": name or slugify(goal, "auto-spec"),
        "target_url": base_url,
        "mission_type": "spec",
        "intent": goal,
        "steps": [
            {
                "id": "REQ-001",
                "description": goal,
                "action": "",
                "target_hint": "",
                "policy": "must_complete",
            }
        ],
    }


# ---------------------------------------------------------------------
# نرمال‌سازی خروجی LLM → Spec معتبر
# ---------------------------------------------------------------------

def _normalize_spec(raw, base_url, goal, name=None, max_steps=10):
    if not isinstance(raw, dict):
        raise ValueError("spec draft is not an object")

    steps = []
    for i, st in enumerate(raw.get("steps") or [][:max_steps], 1):
        if not isinstance(st, dict):
            continue
        step = {}
        step_id = str(st.get("id") or "").strip() or f"REQ-{i:03d}"
        # id باید یکتا و ساده باشد
        step_id = re.sub(r"[^A-Za-z0-9\-_]", "-", step_id)
        if any(s["id"] == step_id for s in steps):
            step_id = f"{step_id}-{i}"
        step["id"] = step_id

        step["description"] = str(
            st.get("description") or st.get("desc") or
            f"Perform step {i}").strip()

        action = str(st.get("action") or "").strip().lower()
        if action not in VALID_ACTIONS:
            action = ""
        step["action"] = action

        if st.get("target_hint"):
            step["target_hint"] = str(st["target_hint"]).strip()
        if st.get("value") is not None and st.get("value") != "":
            step["value"] = str(st["value"])
        if st.get("wait_for"):
            step["wait_for"] = str(st["wait_for"]).strip()
        if st.get("multi_input"):
            step["multi_input"] = True
        if st.get("message") and action == "prompt_user":
            step["message"] = str(st["message"]).strip()
        if st.get("save_to") and action == "prompt_user":
            step["save_to"] = re.sub(
                r"[^A-Za-z0-9_]", "_", str(st["save_to"]).strip())

        policy = str(st.get("policy") or "").strip()
        if policy not in VALID_POLICIES:
            if action == "prompt_user":
                policy = "post_submit"
            elif action == "click":
                policy = "requires_all_inputs_filled"
            else:
                policy = "must_complete_before_submit"
        step["policy"] = policy

        # Constitution #14 — selector ممنوع
        steps.append(step)

    spec = {
        "feature": slugify(
            raw.get("feature") or name or goal, "auto-spec"),
        "target_url": str(raw.get("target_url") or base_url),
        "mission_type": "spec",
        "intent": str(raw.get("intent") or goal or "").strip(),
        "steps": steps,
    }
    return spec


# ---------------------------------------------------------------------
# ذخیره
# ---------------------------------------------------------------------

def save_spec(spec, out_path, note=SPEC_HEADER_NOTE):
    """Spec را با کامنت راهنما در مسیر داده‌شده ذخیره می‌کند."""
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    body = yaml.safe_dump(
        spec, allow_unicode=True, sort_keys=False, width=100,
        default_flow_style=False,
    )
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(note)
        f.write(body)
    return out_path


def draft_spec(base_url, goal, name=None, max_steps=10, ai=None,
               use_ai=True):
    """
    تولید کامل Spec: اول LLM، در صورت خطا قالب حداقلی.
    خروجی: (spec_dict, source) — source = "ai" | "template"
    use_ai=False → بدون تلاش برای LLM (مستقیم قالب).
    """
    base_url = str(base_url or "").strip()
    goal = str(goal or "").strip()
    if not base_url:
        raise ValueError("--url is required")
    if not goal:
        raise ValueError("--goal is required")

    name = slugify(name) if name else None
    if use_ai:
        try:
            spec, _ = draft_with_ai(
                base_url, goal, name=name, max_steps=max_steps, ai=ai)
            return spec, "ai"
        except Exception:                                 # noqa: BLE001
            pass
    # بدون هوش مصنوعی (یا endpoint قطع) → قالب حداقلی
    return template_spec(base_url, goal, name=name), "template"
