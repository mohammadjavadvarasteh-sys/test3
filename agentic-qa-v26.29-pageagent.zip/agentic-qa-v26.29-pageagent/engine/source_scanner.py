# =====================================================================
# engine/source_scanner.py
# ---------------------------------------------------------------------
# اسکن سورس‌کد یک پروژه وب (React / Vue / Angular / Svelte / HTML / ...)
# بدون اجرای آن — فقط استاتیک:
#   - کشف فریم‌ورک و ساختار
#   - استخراج route ها (react-router / next / vue-router / ...)
#   - استخراج فرم‌ها، فیلدها، دکمه‌ها، label ها
#   - استخراج فراخوانی‌های API
# خروجی: بلوک‌های متنی فشرده برای فرستادن به LLM
# =====================================================================

import os
import re

# ---------------------------------------------------------------------
# تنظیمات اسکن
# ---------------------------------------------------------------------

INCLUDE_EXTS = {
    ".js", ".jsx", ".ts", ".tsx", ".vue", ".svelte",
    ".html", ".htm", ".astro",
}

SKIP_DIRS = {
    "node_modules", ".git", "dist", "build", "out", ".next", ".nuxt",
    ".output", "coverage", "__pycache__", ".cache", "vendor",
    ".venv", "venv", "target", "bin", "obj",
}

SKIP_FILE_PATTERNS = [
    r"\.min\.(js|css)$", r"\.map$", r"-lock\.", r"\.d\.ts$",
    r"\.test\.", r"\.spec\.", r"\.stories\.",
]

MAX_FILE_BYTES = 200_000          # فایل‌های بزرگ‌تر از این رد می‌شوند
MAX_FILES_DEFAULT = 120
CHAR_BUDGET_PER_CHUNK = 22_000    # هر chunk ~ 6k توکن

# اولویت فایل‌ها برای انتخاب وقتی تعداد زیاد است
PRIORITY_PATTERNS = [
    r"router", r"routes?\.", r"app[/\\].*page", r"pages?[/\\]",
    r"app[/\\].*layout", r"navigation", r"menu", r"login", r"auth",
    r"form", r"index\.(js|ts|tsx|jsx|vue)$",
]

# ---------------------------------------------------------------------
# الگوهای استخراج
# ---------------------------------------------------------------------

RE_ROUTE_REACT = re.compile(
    r"""(?:<Route[^>]*\spath|path|to)\s*=\s*["']([^"']+)["']""")
RE_ROUTE_VUE = re.compile(r"""path\s*:\s*["']([^"']+)["']""")
RE_NEXT_PAGE = re.compile(r"")
RE_LINK = re.compile(r"""(?:href|to)\s*=\s*["']([^"']+)["']""")
RE_INPUT = re.compile(
    r"<(input|textarea|select)\b([^>]*)>", re.IGNORECASE)
RE_INPUT_ATTR = re.compile(
    r"""(name|id|type|placeholder|label|aria-label|required|pattern|"
    r"minlength|maxlength|min|max|accept)\s*=\s*["']([^"']*)["']""",
    re.VERBOSE)
RE_LABEL_TEXT = re.compile(
    r"<label\b[^>]*>(.*?)</label>", re.IGNORECASE | re.DOTALL)
RE_BUTTON = re.compile(
    r"<(?:button|Button|v-btn|el-button)\b[^>]*>(.*?)</"
    r"(?:button|Button|v-btn|el-button)>",
    re.IGNORECASE | re.DOTALL)
RE_VMODEL = re.compile(r"""(?:v-model|ngModel|value)\s*=\s*["'`{]([^"'`}]+)""")
RE_API = re.compile(
    r"""(?:fetch|axios(?:\.\w+)?|\$http\.\w+|\.get|\.post|\.put|\.delete|"
    r"useSWR|useQuery)\s*\(\s*[`"']([^`"']+)[`"']""",
    re.VERBOSE)
RE_TEXT_JSX = re.compile(r">\s*([A-Za-z\u0600-\u06FF][^<>{}\n]{1,60})\s*<")

PERSIAN_RE = re.compile(r"[\u0600-\u06FF]")


# =====================================================================
# نتیجه اسکن
# =====================================================================

class ScanResult:

    def __init__(self, root):
        self.root = root
        self.framework = "unknown"
        self.files = []            # list[dict: {path, rel, size, priority}]
        self.routes = []
        self.detected_language = "en"

    # -----------------------------------------------------------------

    def add_route(self, source, route):
        route = (route or "").strip()
        if not route or route.startswith(("http://", "https://", "data:")):
            return
        if not route.startswith(("/", "#",)):
            route = "/" + route
        if any(r["route"] == route and r["source"] == source
               for r in self.routes):
            return
        self.routes.append({"route": route, "source": source})


# =====================================================================
# اسکنر
# =====================================================================

class SourceScanner:

    def __init__(self, root, max_files=MAX_FILES_DEFAULT):
        self.root = os.path.abspath(root)
        self.max_files = max_files
        self.result = ScanResult(self.root)

    # -----------------------------------------------------------------

    def scan(self):
        if not os.path.isdir(self.root):
            raise ValueError(f"source path is not a directory: {self.root}")

        self._collect_files()
        self._detect_framework()
        self._extract_all()
        self._detect_language()
        return self.result

    # -----------------------------------------------------------------

    def _collect_files(self):
        candidates = []
        for dirpath, dirnames, filenames in os.walk(self.root):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
            for fn in filenames:
                ext = os.path.splitext(fn)[1].lower()
                if ext not in INCLUDE_EXTS:
                    continue
                if any(re.search(p, fn) for p in SKIP_FILE_PATTERNS):
                    continue
                full = os.path.join(dirpath, fn)
                try:
                    size = os.path.getsize(full)
                except OSError:
                    continue
                if size > MAX_FILE_BYTES:
                    continue
                rel = os.path.relpath(full, self.root).replace("\\", "/")
                priority = self._priority_of(rel)
                candidates.append({
                    "path": full, "rel": rel, "size": size,
                    "priority": priority,
                })

        # مرتب‌سازی: اولویت + کوچکی
        candidates.sort(key=lambda f: (-f["priority"], f["size"]))
        self.result.files = candidates[: self.max_files]

    @staticmethod
    def _priority_of(rel):
        score = 0
        for i, pattern in enumerate(PRIORITY_PATTERNS):
            if re.search(pattern, rel, re.IGNORECASE):
                score += len(PRIORITY_PATTERNS) - i
        # فایل‌های خیلی بزرگ کم‌ارزش‌ترند
        return score

    # -----------------------------------------------------------------

    def _detect_framework(self):
        pkg_path = os.path.join(self.root, "package.json")
        deps = ""
        try:
            with open(pkg_path, "r", encoding="utf-8") as f:
                content = f.read()
            deps = content.lower()
        except OSError:
            pass

        signals = [
            ("next", ("\"next\"", "'next'", "app router")),
            ("nuxt", ("nuxt",)),
            ("react", ("react-router", "\"react\"", "'react'",
                       "react-dom")),
            ("vue", ("\"vue\"", "'vue'", "vue-router")),
            ("angular", ("@angular/",)),
            ("svelte", ("svelte",)),
            ("astro", ("\"astro\"", "'astro'")),
        ]
        for name, keys in signals:
            if any(k in deps for k in keys):
                self.result.framework = name
                return

        # از ساختار پوشه‌ها حدس بزن
        if os.path.isdir(os.path.join(self.root, "app")):
            self.result.framework = "next-like"
        elif os.path.isdir(os.path.join(self.root, "pages")):
            self.result.framework = "pages-based"

    # -----------------------------------------------------------------

    def _extract_all(self):
        for file_info in self.result.files:
            try:
                with open(file_info["path"], "r",
                          encoding="utf-8", errors="replace") as f:
                    content = f.read()
            except OSError:
                continue
            self._extract_file(file_info, content)

    def _extract_file(self, file_info, content):
        rel = file_info["rel"]

        # route ها
        if self.result.framework in ("react", "next", "next-like",
                                     "unknown"):
            for m in RE_ROUTE_REACT.finditer(content):
                self.result.add_route(rel, m.group(1))
        if self.result.framework in ("vue", "nuxt", "unknown"):
            for m in RE_ROUTE_VUE.finditer(content):
                self.result.add_route(rel, m.group(1))

        # pages/: فایل خودش مسیر است
        if rel.startswith(("pages/", "app/")) and any(
                seg in rel for seg in ("page.", "index.")):
            pseudo = "/" + re.sub(
                r"^(pages|app)/", "", rel
            ).split("/")[0].replace(".", "/").rstrip("/")
            self.result.add_route(rel, pseudo or "/")

    # -----------------------------------------------------------------

    def _detect_language(self):
        """هم‌زبان سورس: نسبت حروف فارسی در label/دکمه متن‌ها."""
        persian = 0
        total = 0
        for file_info in self.result.files[:40]:
            try:
                with open(file_info["path"], "r",
                          encoding="utf-8", errors="replace") as f:
                    content = f.read()
            except OSError:
                continue
            for m in RE_LABEL_TEXT.finditer(content):
                total += 1
                if PERSIAN_RE.search(m.group(1)):
                    persian += 1
            for m in RE_TEXT_JSX.finditer(content):
                total += 1
                if PERSIAN_RE.search(m.group(1)):
                    persian += 1

        if total and persian / total > 0.25:
            self.result.detected_language = "fa"
        else:
            self.result.detected_language = "en"

    # -----------------------------------------------------------------
    # ساخت بلوک‌های متنی برای LLM
    # -----------------------------------------------------------------

    def build_chunks(self):
        """
        فایل‌ها را به chunk های متنی فشرده تبدیل می‌کند.
        هر chunk: مسیر فایل + خطوط «مرتبط» (route/form/button/api/label)
        """
        chunks = []
        current = []
        current_len = 0

        for file_info in self.result.files:
            try:
                with open(file_info["path"], "r",
                          encoding="utf-8", errors="replace") as f:
                    content = f.read()
            except OSError:
                continue

            block = self._file_block(file_info, content)
            if not block:
                continue

            if current_len + len(block) > CHAR_BUDGET_PER_CHUNK and current:
                chunks.append("\n\n".join(current))
                current, current_len = [], 0

            current.append(block)
            current_len += len(block)

        if current:
            chunks.append("\n\n".join(current))
        return chunks

    def _file_block(self, file_info, content):
        rel = file_info["rel"]
        lines = content.splitlines()
        keep = []

        patterns = [
            RE_ROUTE_REACT, RE_ROUTE_VUE, RE_LINK, RE_INPUT, RE_LABEL_TEXT,
            RE_BUTTON, RE_VMODEL, RE_API, RE_TEXT_JSX,
        ]

        matched_line_idx = set()
        for pattern in patterns:
            for m in pattern.finditer(content):
                # شماره خط تقریبی
                idx = content[:m.start()].count("\n")
                for delta in (0, 1, 2):
                    matched_line_idx.add(idx + delta)

        for idx in sorted(matched_line_idx):
            if idx < len(lines):
                line = lines[idx].strip()
                if line and len(line) < 300:
                    keep.append(f"  L{idx + 1}: {line}")

        if not keep:
            # fallback: ۶ خط اول فایل‌های کوچک
            head = [l.strip() for l in lines[:6] if l.strip()]
            if not head:
                return ""
            keep = [f"  {l}" for l in head[:6]]

        header = f"### FILE: {rel} ({len(lines)} lines)"
        return header + "\n" + "\n".join(keep[:80])
