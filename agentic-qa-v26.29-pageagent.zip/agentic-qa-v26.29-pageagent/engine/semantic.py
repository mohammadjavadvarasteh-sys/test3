"""Deterministic, field-aware semantic matching.

The matcher deliberately has no site-specific labels, selectors, options,
or fuzzy "closest match" behavior. A candidate is a match only when the
requested concept is represented by the candidate's own observed tokens.
"""
import re
import unicodedata


# Language-neutral punctuation/spacing normalization. These are not product
# terms; they merely make equivalent textual representations comparable.
TOKEN_RE = re.compile(r"[\w\u0600-\u06ff]+", re.UNICODE)


def normalize_text(value):
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    text = text.replace("\u200c", " ").replace("\u200d", " ")
    return " ".join(TOKEN_RE.findall(text))


def tokens(value):
    return tuple(t for t in normalize_text(value).split() if t)


def concept_is_in_intent(requested_concept, mission_intent):
    """Require the requested concept to be grounded in the original mission.

    Matching is phrase-based after normalization. This prevents the model from
    relabeling an unrelated option as the user's requested concept.
    """
    requested = tokens(requested_concept)
    intent = tokens(mission_intent)
    if not requested or not intent or len(requested) > len(intent):
        return False
    width = len(requested)
    return any(intent[i:i + width] == requested
               for i in range(len(intent) - width + 1))


def semantic_match(requested_concept, candidate):
    """Return a strict boolean; never returns a ranked/closest candidate.

    A non-empty requested concept matches a candidate only when every
    normalized requested token occurs in the candidate. This is intentionally
    conservative: shared words alone are insufficient when the request has
    additional concepts that the option does not contain.
    """
    requested = set(tokens(requested_concept))
    observed = set(tokens(candidate))
    if not requested or not observed:
        return False
    return requested.issubset(observed)


class SemanticResolver:
    """Resolve a requested concept against one field's observed candidates."""

    def match_options(self, requested_concept, observed_options):
        matches = [
            option for option in (observed_options or [])
            if semantic_match(requested_concept, option)
        ]
        # Multiple matches are ambiguous and therefore are not silently ranked.
        if len(matches) != 1:
            return {"status": "NO_MATCH" if not matches else "AMBIGUOUS", "matches": matches}
        return {"status": "MATCH", "matches": matches}

    def validate_selected_options(self, requested_concept, selected, observed_options,
                                  mission_intent=None):
        if not concept_is_in_intent(requested_concept, mission_intent):
            return {"status": "UNANCHORED_REQUEST", "matches": []}
        selected = [str(v).strip() for v in (selected or [])]
        observed = [str(v).strip() for v in (observed_options or [])]
        if not selected or not observed:
            return {"status": "NO_MATCH", "matches": []}

        if any(value not in observed for value in selected):
            return {"status": "NO_MATCH", "matches": []}

        result = self.match_options(requested_concept, observed)
        if result["status"] != "MATCH":
            return result
        if selected != result["matches"]:
            return {"status": "NO_MATCH", "matches": result["matches"]}
        return result
