# =====================================================================
# engine/snapshot.py
# ---------------------------------------------------------------------
# تجزیه «snapshot درخت دسترس‌پذیری» که سرور Playwright MCP برمی‌گرداند.
#
# خروجی browser_snapshot چیزی شبیه این است:
#
#   - generic [ref=e1]:
#     - heading "صفحه ورود" [level=1] [ref=e2]
#     - textbox "شناسه کاربر" [ref=e3]
#     - button "ورود" [ref=e10]
#     - dialog "پیام سیستم" [ref=e50]:
#       - button "ورود" [ref=e52]
#
# این ماژول آن را به ساختار داده تبدیل می‌کند تا:
#   1) state hash برای LoopDetector ساخته شود (URL + اثر انگشت صفحه)
#   2) المنت‌های هم‌نام پیدا شوند (مشکل اصلی پروژه قبلی!) و مسیر
#      سلسله‌مراتبی هر کدام برای disambiguation گزارش شود
#   3) trigger های skills (captcha/otp/file-upload/...) روشن شوند
# =====================================================================

import hashlib
import re
from urllib.parse import urlparse

LINE_PREFIX_RE = re.compile(r"^(?P<indent>\s*)-\s+(?P<body>.+?)\s*$")
REF_RE = re.compile(r"\[ref=([^\]\s]+)\]")
NAME_RE = re.compile(r'"(?P<name>(?:[^"\\]|\\.)*)"')
ATTR_RE = re.compile(r"\[(?P<key>[a-zA-Z_-]+)=(?P<value>[^\]]*)\]")
# مقدار متنی بعد از ref — مثل:  textbox "field label" [ref=e2]: "<value>"
VALUE_RE = re.compile(r':\s*"(?P<value>(?:[^"\\]|\\.)*)"\s*$')
# متن بدون نقل‌قول بعد از نقش/نام — مثل:  paragraph [ref=e3]: keydown:0
TEXT_SUFFIX_RE = re.compile(
    r"^[a-z]+\s*(?:\"(?:[^\"\\]|\\.)*\")?\s*:\s*(?P<text>.+)$")
PAGE_URL_RE = re.compile(r"^- Page URL:\s*(?P<url>\S+)", re.MULTILINE)

# نقش‌هایی که «فرم کنترل» حساب می‌شوند
FORM_ROLES = {"textbox", "spinbutton", "combobox", "searchbox", "slider"}

# نقش‌های کلیک‌پذیر/تعاملی
INTERACTIVE_ROLES = {
    "button", "link", "menuitem", "tab", "option", "checkbox",
    "radio", "switch", "menuitemcheckbox", "menuitemradio",
}


class Element:
    __slots__ = ("ref", "role", "name", "attrs", "path", "depth")

    def __init__(self, ref, role, name, attrs, path, depth):
        self.ref = ref
        self.role = role
        self.name = name
        self.attrs = attrs      # dict — مثل {"level": "1"}
        self.path = path        # list[str] — زنجیره والد‌ها مثل ["dialog 'پیام'"]
        self.depth = depth

    # -----------------------------------------------------------------

    def describe(self):
        """توصیف معنایی با زمینه — همان چیزی که برای انتخاب لازم است."""
        base = self.role
        if self.name:
            base = f'{self.role} "{self.name}"'
        if self.path:
            return f"{base} — inside: {' > '.join(self.path[-3:])}"
        return base

    def to_dict(self):
        return {
            "ref": self.ref,
            "role": self.role,
            "name": self.name,
            "path": self.path,
        }


class SnapshotIndex:
    """نتیجه تجزیه یک snapshot."""

    def __init__(self, text, url=None):
        self.raw = text or ""
        # URL از هدر snapshot خود MCP («- Page URL: ...») قابل استخراج است
        if url is None:
            m = PAGE_URL_RE.search(self.raw)
            url = m.group("url") if m else None
        self.url = url
        self.texts = []                 # گره‌های متنی بدون ref (برای هش)
        self.elements = self._parse(self.raw)
        self.state_hash = self._compute_hash()

    # -----------------------------------------------------------------

    def _parse(self, text):
        """
        فرمت واقعی browser_snapshot:
            ### Page
            - Page URL: https://...
            ### Snapshot
            ```yaml
            - generic [active] [ref=e1]:
              - heading "Login Page" [level=2] [ref=e8]
              - img "icon" [ref=e9] [cursor=pointer]
              - /url: https://...
        توجه: ref لزوما آخرین attribute نیست.
        """
        elements = []
        stack = []          # (depth, (role, name))

        for line in text.splitlines():
            m = LINE_PREFIX_RE.match(line)
            if not m:
                continue

            body = m.group("body").strip()

            # خطوط metadata مثل «/url: ...» و «/value: ...»
            if body.startswith("/"):
                continue

            # گره‌های متنی بدون ref — مثل  text: پیام خطا —
            # برای state-hash مهم‌اند (ظاهر شدن پیام خطا = تغییر وضعیت)
            if body.startswith("text:") or body.startswith("text "):
                t = body.split(":", 1)[-1].strip().strip('"').strip("'")
                if t:
                    self.texts.append(t[:80])
                continue

            # فقط خطوط دارای ref عنصر قابل آدرس‌دهی‌اند
            ref_match = REF_RE.search(body)
            if not ref_match:
                continue
            ref = ref_match.group(1)
            depth = len(m.group("indent")) // 2

            # body بدون attr مربوط به ref
            body_clean = REF_RE.sub("", body).strip()
            if body_clean.endswith(":"):
                body_clean = body_clean[:-1].rstrip()

            # نقش = اولین کلمه
            parts = body_clean.split(None, 1)
            role = parts[0] if parts else "generic"

            # نام = اولین رشته‌ی نقل‌قولی
            name = ""
            name_match = NAME_RE.search(body_clean)
            if name_match:
                name = name_match.group("name").replace('\\"', '"')

            # صفات اضافی مثل [level=1] [cursor=pointer]
            attrs = {}
            for attr in ATTR_RE.finditer(body_clean):
                attrs[attr.group("key")] = attr.group("value")
            for flag in ("checked", "disabled", "required", "active",
                         "expanded", "collapsed", "selected"):
                if f"[{flag}]" in body_clean:
                    attrs[flag] = "true"

            # مقدار متنی المنت — textbox "field label" [ref=e2]: "<value>"
            # (برای state-hash حیاتی است: تایپ باید هش را عوض کند)
            value_match = VALUE_RE.search(body_clean)
            if value_match:
                attrs["value"] = value_match.group("value").replace(
                    '\\"', '"')
                body_clean = VALUE_RE.sub("", body_clean).rstrip()

            # متن/مقدار «بدون نقل‌قول» بعد از کولون — MCP گاهی مقدار را
            # بدون کوتیشن می‌فرستد (مثل فارسی/اعداد):
            #   textbox [active] [ref=e2]: تست۱۲۳     → مقدار فرم
            #   paragraph [ref=e3]: keydown:0         → متن داینامیک/پیام
            body_nb = re.sub(r"\[[^\]]*\]", "", body_clean).strip()
            m_text = TEXT_SUFFIX_RE.match(body_nb)
            if m_text and not m_text.group("text").startswith('"'):
                trailing = m_text.group("text")[:80]
                if role in FORM_ROLES and "value" not in attrs:
                    attrs["value"] = trailing
                else:
                    attrs["text"] = trailing

            # زنجیره والد‌ها
            while stack and stack[-1][0] >= depth:
                stack.pop()

            path = [_mk_label(r, n) for _, (r, n) in stack]

            elements.append(Element(ref, role, name, attrs, path, depth))
            stack.append((depth, (role, name)))

        return elements

    # -----------------------------------------------------------------

    def _compute_hash(self):
        """
        اثر انگشت وضعیت صفحه — URL + نقش/نام المنت‌ها + صفات پویا.
        ⚠ مقدار فیلدها (value) و focus فعال (active) باید وارد هش شوند؛
        وگرنه تایپ کاراکتر به کاراکتر کپچا/فرم «وضعیت ثابت» دیده می‌شود
        و LoopDetector به‌درستی state_repetition می‌زند (false-positive).
        """
        signature = self.url or ""
        for el in self.elements:
            signature += f"|{el.role}:{el.name}"
            if el.attrs:
                for key in ("value", "text", "active", "checked",
                            "disabled", "expanded", "selected"):
                    if key in el.attrs:
                        signature += f"[{key}={el.attrs[key]}]"
        for t in self.texts:
            signature += f"|T:{t}"
        return hashlib.md5(signature.encode("utf-8")).hexdigest()[:16]

    # -----------------------------------------------------------------
    # جستجو و تحلیل
    # -----------------------------------------------------------------

    def by_ref(self, ref):
        for el in self.elements:
            if el.ref == ref:
                return el
        return None

    def find_by_name(self, name, role=None):
        """همه المنت‌هایی که نامشان دقیقاً این است — برای تشخیص تکرار."""
        name = (name or "").strip()
        return [
            el for el in self.elements
            if el.name == name and (role is None or el.role == role)
        ]

    def duplicates(self):
        """
        گروه‌بندی المنت‌های «نقش+نام» یکسان که بیشتر از یکی هستند.
        خروجی: list[dict] برای هشدار disambiguation به agent.
        """
        groups = {}
        for el in self.elements:
            if not el.name:
                continue
            key = (el.role, el.name)
            groups.setdefault(key, []).append(el)

        result = []
        for (role, name), els in sorted(groups.items()):
            if len(els) > 1:
                # فقط وقتی مهم است که تعاملی/فرمی باشد
                if role not in (INTERACTIVE_ROLES | FORM_ROLES):
                    continue
                result.append({
                    "role": role,
                    "name": name,
                    "count": len(els),
                    "candidates": [e.describe() for e in els[:6]],
                    "refs": [e.ref for e in els[:12]],
                })
        return result

    # -----------------------------------------------------------------


    def navigation_targets_for(self, ref=None):
        """Return URLs explicitly observed in the live accessibility tree.

        Playwright accessibility snapshots can expose a link target as a
        ``/url: ...`` child of the link node. The association is derived
        from indentation and therefore remains generic: no route, path,
        domain, or product-specific knowledge is used.
        """
        targets = []
        lines = self.raw.splitlines()
        parent_stack = []  # (indent, ref)
        for raw_line in lines:
            m = LINE_PREFIX_RE.match(raw_line)
            if not m:
                continue
            indent = len(m.group("indent"))
            body = m.group("body").strip()
            while parent_stack and parent_stack[-1][0] >= indent:
                parent_stack.pop()

            ref_match = REF_RE.search(body)
            current_ref = ref_match.group(1) if ref_match else None
            if body.startswith("/url:"):
                value = body.split(":", 1)[1].strip().strip('"')
                if valid_navigation_url(value):
                    owner_ref = parent_stack[-1][1] if parent_stack else None
                    if ref is None or owner_ref == str(ref):
                        targets.append(value)
                continue

            if current_ref:
                parent_stack.append((indent, current_ref))

        return list(dict.fromkeys(targets))

    def observed_navigation_targets(self):
        """Return all explicit navigation URLs observed in this snapshot."""
        return self.navigation_targets_for(None)

    def options_for(self, ref):
        """Return option names observed under a specific control ref.

        The relationship is derived from the live accessibility tree and
        indentation; no field name, selector, or option count is assumed.
        """
        target = self.by_ref(ref)
        if target is None:
            return []
        try:
            idx = next(i for i, el in enumerate(self.elements) if el.ref == ref)
        except StopIteration:
            return []
        values = []
        for el in self.elements[idx + 1:]:
            if el.depth <= target.depth:
                break
            if el.role == "option" and el.name:
                values.append(el.name.strip())
        return values

    def form_control_count(self):
        return sum(1 for el in self.elements if el.role in FORM_ROLES)

    def interactive_count(self):
        return sum(1 for el in self.elements
                   if el.role in INTERACTIVE_ROLES)

    def headings(self, limit=12):
        return [
            el.name for el in self.elements
            if el.role == "heading" and el.name
        ][:limit]

    def text_sample(self, limit=1500):
        return self.raw[:limit]

    def inventory(self, max_items=120):
        """
        Compact semantic inventory built from the FULL accessibility snapshot.

        The LLM may receive only a bounded raw snapshot for context safety.
        This inventory prevents important controls near the end of a large
        page from disappearing simply because the raw snapshot was truncated.
        """
        items = []
        seen = set()

        # Interactive/form controls first: these are the elements most useful
        # for an autonomous QA agent.
        priority_roles = INTERACTIVE_ROLES | FORM_ROLES
        ordered = [
            el for el in self.elements if el.role in priority_roles
        ] + [
            el for el in self.elements
            if el.role not in priority_roles and el.name
        ]

        for el in ordered:
            key = (el.ref, el.role, el.name, tuple(el.path[-2:]))
            if key in seen:
                continue
            seen.add(key)

            label = el.describe()
            attrs = []
            for k in ("value", "disabled", "required", "checked",
                      "expanded", "selected"):
                if k in el.attrs:
                    value = el.attrs[k]
                    # Do not expose likely secret field contents.
                    if k == "value" and el.role in FORM_ROLES:
                        value = "<filled>" if value else "<empty>"
                    attrs.append(f"{k}={value}")

            if attrs:
                label += " [" + ", ".join(attrs) + "]"
            items.append(f"{label} [ref={el.ref}]")
            if len(items) >= max_items:
                break

        return items


    def page_agent_state(self, max_items=90, max_chars=7000):
        """Build a Page-Agent-style compact live browser state.

        This is deliberately DOM/accessibility-first: only currently observed
        interactive/form controls are sent to the model, with their live ref
        and parent context. It contains no site-specific labels/selectors.
        """
        priority_roles = INTERACTIVE_ROLES | FORM_ROLES
        controls = []
        index = 0
        for el in self.elements:
            interactive = (
                el.role in priority_roles
                or el.attrs.get("cursor") == "pointer"
                or el.attrs.get("onclick") == "true"
                or el.attrs.get("tabindex") is not None
            )
            if not interactive:
                continue
            if not (el.name or el.attrs.get("text") or el.role):
                continue
            index += 1
            label = el.name or el.attrs.get("text") or ""
            item = f"[{index}] {el.role}"
            if label:
                item += f' "{label}"'
            if el.attrs.get("disabled") == "true":
                item += " [disabled]"
            if el.attrs.get("required") == "true":
                item += " [required]"
            if el.attrs.get("expanded") == "true":
                item += " [expanded]"
            if el.attrs.get("selected") == "true":
                item += " [selected]"
            if el.attrs.get("active") == "true":
                item += " [active]"
            if el.path:
                item += " — " + " > ".join(el.path[-2:])
            item += f" [ref={el.ref}]"
            controls.append(item)
            if len(controls) >= max_items:
                break

        lines = [
            "=== PAGE-AGENT-STYLE LIVE STATE ===",
            f"Current URL: {self.url or '(unknown)'}",
            f"Interactive elements: {len(controls)}",
            "Interactive Elements:",
        ]
        lines.extend(controls or ["(none observed)"])
        # Compatibility/readability marker retained for existing reports/tests.
        # The indexed interactive state above is the primary representation.
        lines.append("=== ACTIONABLE UI MAP (LIVE) ===")
        for item in controls:
            # Keep the original concise form while retaining the live ref.
            base = re.sub(r"^\[\d+\]\s+", "", item)
            ref_match = re.search(r"\[ref=([^\]]+)\]", base)
            if ref_match:
                prefix = base[:ref_match.start()].rstrip()
                prefix = prefix.split(" — ", 1)[0].rstrip()
                base = prefix
                ref = f" [ref={ref_match.group(1)}]"
            else:
                ref = ""
            lines.append("- " + base + ref)

        headings = self.headings(limit=8)
        if headings:
            lines.append("Visible headings:")
            lines.extend(f"- {h}" for h in headings)
        if self.texts:
            lines.append("Visible text signals:")
            lines.extend(f"- {t}" for t in self.texts[:12])

        result = "\n".join(lines)
        if len(result) > max_chars:
            result = result[:max_chars].rsplit("\n", 1)[0] + "\n[truncated]"
        return result

    def summary(self):
        return {
            "url": self.url,
            "element_count": len(self.elements),
            "interactive": self.interactive_count(),
            "form_controls": self.form_control_count(),
            "headings": self.headings(limit=6),
            "state_hash": self.state_hash,
        }


def _mk_label(role, name):
    return f'{role} "{name}"' if name else role


# =====================================================================
# trigger های skill — کلمات کلیدی روی متن snapshot
# (پیاده‌سازی انتخابی در skill_loader.py)
# =====================================================================

SKILL_KEYWORDS = {
    "captcha": [
        "captcha", "recaptcha", "hcaptcha", "کپچا", "کپجا",
        "i am not a robot", "robot verification",
    ],
    "otp": [
        "otp", "one-time", "one time", "کد تایید", "کد تأیید",
        "verification code", "verify code", "کد یکبار",
        "resend", "ارسال مجدد", "code sent", "sent to your",
    ],
    "authentication": [
        "login", "log in", "sign in", "signin", "ورود",
        "password", "رمز عبور", "گذرواژه", "username",
        "نام کاربری", "identifier", "شناسه کاربر", "log out", "خروج",
        "log out", "logout", "sso",
    ],
    "file-upload": [
        "choose file", "no file chosen", "drop file", "drag and drop",
        "upload", "آپلود", "فایل", "رها کنید", "رها نمایید",
        "drag & drop", "browse",
    ],
    "session-expiry": [
        "session expired", "منقضی", "session timeout",
        "login again", "دوباره وارد",
    ],
}


def detect_skill_triggers(snapshot_text, url=""):
    """کدام trigger ها در متن صفحه/URL روشن شده‌اند؟"""
    haystack = (snapshot_text or "") + " " + (url or "")
    lowered = haystack.lower()
    triggered = []
    for skill, words in SKILL_KEYWORDS.items():
        for w in words:
            if w.lower() in lowered:
                triggered.append(skill)
                break
    return triggered


def valid_navigation_url(value):
    try:
        parsed = urlparse(str(value).strip())
    except ValueError:
        return False
    return parsed.scheme in ("http", "https") and bool(parsed.netloc)
