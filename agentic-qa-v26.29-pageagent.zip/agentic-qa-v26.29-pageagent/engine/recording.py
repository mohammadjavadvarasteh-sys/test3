"""Run recording helpers: build a compact GIF and optional MP4 from evidence frames."""

import os
import shutil
import subprocess

import config


def build_run_media(run_dir):
    if not config.RECORD_RUN:
        return {}

    evidence_dir = os.path.join(run_dir, "evidence")
    frames = []
    if os.path.isdir(evidence_dir):
        for name in sorted(os.listdir(evidence_dir)):
            if name.startswith("frame-") and name.lower().endswith(".png"):
                frames.append(os.path.join(evidence_dir, name))

    if not frames:
        return {}

    result = {}
    gif_path = os.path.join(run_dir, "run.gif")
    try:
        from PIL import Image

        images = []
        for path in frames:
            try:
                img = Image.open(path).convert("RGB")
                if img.width > config.RECORD_MAX_WIDTH:
                    height = int(img.height * config.RECORD_MAX_WIDTH / img.width)
                    img = img.resize((config.RECORD_MAX_WIDTH, max(1, height)))
                images.append(img.copy())
                img.close()
            except Exception:
                continue

        if images:
            duration = max(40, int(1000 / config.RECORD_FPS))
            images[0].save(
                gif_path,
                save_all=True,
                append_images=images[1:],
                duration=duration,
                loop=0,
                optimize=True,
            )
            result["gif"] = gif_path
    except Exception as exc:
        print(f"⚠️ run GIF could not be generated: {exc}")

    # MP4 is optional and only generated when ffmpeg is already installed.
    # Never download/install binaries during a test run.
    if config.RECORD_MP4:
        ffmpeg = shutil.which("ffmpeg")
        if ffmpeg and frames:
            mp4_path = os.path.join(run_dir, "run.mp4")
            pattern = os.path.join(evidence_dir, "frame-%06d.png")
            cmd = [
                ffmpeg, "-y", "-loglevel", "error",
                "-framerate", str(config.RECORD_FPS),
                "-i", pattern,
                "-vf", f"scale='min(iw,{config.RECORD_MAX_WIDTH})':-2",
                "-c:v", "libx264", "-pix_fmt", "yuv420p",
                mp4_path,
            ]
            try:
                subprocess.run(cmd, check=True, timeout=120)
                result["mp4"] = mp4_path
            except Exception as exc:
                print(f"⚠️ run MP4 could not be generated: {exc}")

    return result
