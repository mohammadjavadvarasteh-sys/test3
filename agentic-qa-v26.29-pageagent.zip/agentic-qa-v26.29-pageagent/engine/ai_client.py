# =====================================================================
# engine/ai_client.py
# ---------------------------------------------------------------------
# کلاینت LLM سازگار با OpenAI (/v1/chat/completions).
# خروجی همیشه متن است؛ تبدیل به JSON با _parse_json انجام می‌شود.
# هیچ فراخوانی ابزار (function calling) لازم نیست — پروتکل ReAct
# خودمان روی متن JSON سوار شده تا با هر مدلی کار کند.
# =====================================================================

import json
import re
import time

import requests

import config


class AIClient:
    """کلاینت ساده و مقاوم برای endpoint های سازگار با OpenAI."""

    def __init__(self, base_url=None, model=None, api_key=None, timeout=None):
        self.base_url = (base_url or config.AI_BASE_URL).rstrip("/")
        self.model = model or config.AI_MODEL
        self.api_key = api_key if api_key is not None else config.AI_API_KEY
        self.timeout = timeout or config.AI_TIMEOUT

    # -----------------------------------------------------------------

    def _url(self):
        if self.base_url.endswith("/chat/completions"):
            return self.base_url
        return f"{self.base_url}/chat/completions"

    def _headers(self):
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    # -----------------------------------------------------------------
    # یک مکالمه ساده — پیام‌ها را می‌دهد، متن پاسخ را می‌گیرد
    # -----------------------------------------------------------------

    def chat(self, messages, temperature=None, max_tokens=None, retries=2):
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "temperature": config.AI_TEMPERATURE if temperature is None else temperature,
            "max_tokens": config.AI_MAX_TOKENS if max_tokens is None else max_tokens,
        }

        last_error = None
        for attempt in range(retries + 1):
            try:
                resp = requests.post(
                    self._url(),
                    headers=self._headers(),
                    json=payload,
                    timeout=self.timeout,
                )
                resp.raise_for_status()
                data = resp.json()
                return data["choices"][0]["message"]["content"]
            except Exception as e:                              # noqa: BLE001
                last_error = e
                if attempt < retries:
                    time.sleep(1.5 * (attempt + 1))

        raise ConnectionError(
            f"AI request failed after {retries + 1} attempts: {last_error}"
        )

    # -----------------------------------------------------------------
    # مکالمه با خروجی JSON — مقاوم در برابر ```json و متن اضافه
    # -----------------------------------------------------------------

    def chat_json(self, messages, retries=2, temperature=None, max_tokens=None):
        last_raw = None
        for attempt in range(retries + 1):
            raw = self.chat(messages, temperature=temperature, max_tokens=max_tokens)
            last_raw = raw
            parsed = parse_json_loose(raw)
            if parsed is not None:
                return parsed
            # پاسخ JSON نبود — یک turn اصلاحی اضافه کن
            messages = list(messages) + [
                {"role": "assistant", "content": raw or ""},
                {"role": "user", "content": (
                    "Your previous reply was not a valid JSON object. "
                    "Reply again with ONLY the JSON object — no markdown "
                    "fences, no prose."
                )},
            ]
        raise ValueError(
            f"Model did not return valid JSON. Last response: {str(last_raw)[:400]}"
        )

    # -----------------------------------------------------------------

    def ping(self):
        """بررسی سلامت برای دستور doctor."""
        messages = [
            {"role": "user", "content": "Reply with exactly: OK"},
        ]
        raw = self.chat(messages, max_tokens=8, retries=0)
        return (raw or "").strip()[:60]


# =====================================================================
# ابزار عمومی — تجزیه JSON آزاد
# =====================================================================

def parse_json_loose(text):
    """```json``` fences، متن اضافه و کامنت را تحمل می‌کند."""
    if not text:
        return None

    cleaned = text.strip()
    cleaned = cleaned.replace("```json", "```")

    # اگر کل پاسخ داخل fence است
    if "```" in cleaned:
        parts = cleaned.split("```")
        for part in parts:
            part = part.strip()
            if part.startswith("{"):
                cleaned = part
                break

    # تلاش مستقیم
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # استخراج بیرونی‌ترین {...}
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start != -1 and end > start:
        candidate = cleaned[start:end + 1]
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            # شاید کامنت // داشته باشد
            no_comments = re.sub(
                r"^\s*//.*$", "", candidate, flags=re.MULTILINE
            )
            try:
                return json.loads(no_comments)
            except json.JSONDecodeError:
                pass

    return None
