import json
import os
import tempfile
import unittest
import time
from pathlib import Path

from engine.artifacts import make_artifact
from engine.navigation import build_navigation_evidence
from engine.policy_engine import PolicyEngine
from engine.snapshot import SnapshotIndex
from engine.mission_state import MissionState
from engine.semantic import SemanticResolver
from engine.agent import QAReActAgent


class GenericRegressionTests(unittest.TestCase):

    def test_action_outcome_reports_target_effect_and_state_changes(self):
        agent = QAReActAgent(
            browser=object(), ai=object(), policy=self.policy, evidence=object(),
            skill_loader=object(),
        )
        before = {
            "url": "https://app.example.test/form",
            "title": "Form",
            "content": "",
            "elements": [{"index": 1, "role": "textbox", "name": "Code", "valueLength": 0, "status": {"disabled": False}}],
            "pageInfo": {"timers": []},
        }
        after = {
            "url": "https://app.example.test/otp",
            "title": "OTP",
            "content": "ACTIVE DIALOG: OTP",
            "elements": [{"index": 1, "role": "textbox", "name": "Code", "valueLength": 5, "status": {"disabled": False}}],
            "pageInfo": {"timers": []},
        }
        note = agent._summarize_state_transition(before, after, "input_text", {"index": 1, "text": "12345"})
        self.assertIn("ACTION OUTCOME", note)
        self.assertIn("TARGET EFFECTS", note)
        self.assertIn("valueLength 0->5", note)
        self.assertIn("url_changed=True", note)
        self.assertIn("DIALOG_STATE_CHANGED", note)
        self.assertNotIn("12345", note)

    def test_settled_state_does_not_use_wait_tool_or_consume_action_budget(self):
        self.assertTrue(hasattr(QAReActAgent, "_settled_page_agent_state"))
        self.assertTrue(hasattr(QAReActAgent, "_page_agent_state_hash_from_state"))

    def setUp(self):
        self.rules = tempfile.mkdtemp()
        with open(os.path.join(self.rules, "safety.yaml"), "w", encoding="utf-8") as f:
            f.write(
                "allow_requested_domain: true\n"
                "allowed_domains: []\n"
                "destructive_actions: {patterns: []}\n"
            )
        with open(os.path.join(self.rules, "execution.yaml"), "w", encoding="utf-8") as f:
            f.write(
                "execution: {max_actions: 100, mission_timeout_seconds: 60}\n"
                "loop_detection: {enabled: true}\n"
            )
        with open(os.path.join(self.rules, "validation.yaml"), "w", encoding="utf-8") as f:
            f.write("{}\n")
        self.policy = PolicyEngine(rules_dir=self.rules)
        self.policy.set_mission_url("https://app.example.test/start")
        self.policy.set_mission_intent("Select Digital Signature Gateway for the requested setting")

    def _nav(self, provenance, url="https://external.example.test/x", source=None, inferred=False):
        return build_navigation_evidence(
            url,
            source or provenance,
            provenance,
            f"generic runtime evidence for {provenance}",
            inferred,
            "https://app.example.test/start",
        ).as_dict()

    def test_01_observed_href_external_allowed(self):
        result = self.policy.validate_action(
            "browser_navigate",
            {"url": "https://external.example.test/x", "navigation_evidence": self._nav("observed_href")},
        )
        self.assertTrue(result["approved"])

    def test_02_application_generated_external_allowed(self):
        result = self.policy.validate_action(
            "browser_navigate",
            {"url": "https://external.example.test/x", "navigation_evidence": self._nav("application_generated")},
        )
        self.assertTrue(result["approved"])

    def test_03_application_dialog_external_allowed(self):
        result = self.policy.validate_action(
            "browser_navigate",
            {"url": "https://external.example.test/x", "navigation_evidence": self._nav("application_dialog")},
        )
        self.assertTrue(result["approved"])

    def test_04_copied_application_url_human_checkpoint_allowed(self):
        result = self.policy.validate_action(
            "browser_navigate",
            {"url": "https://external.example.test/x", "navigation_evidence": self._nav("human_confirmed_application_artifact")},
        )
        self.assertTrue(result["approved"])

    def test_05_arbitrary_human_url_blocked(self):
        result = self.policy.validate_action(
            "browser_navigate",
            {"url": "https://external.example.test/x", "navigation_evidence": self._nav("arbitrary_human_url")},
        )
        self.assertFalse(result["approved"])

    def test_06_guessed_url_blocked(self):
        result = self.policy.validate_action(
            "browser_navigate",
            {"url": "https://external.example.test/x", "navigation_evidence": self._nav("guessed")},
        )
        self.assertFalse(result["approved"])

    def test_07_inferred_url_blocked(self):
        result = self.policy.validate_action(
            "browser_navigate",
            {"url": "https://external.example.test/x", "navigation_evidence": self._nav("inferred", inferred=True)},
        )
        self.assertFalse(result["approved"])

    def _set_select_snapshot(self):
        snapshot = '''
- Page URL: https://app.example.test/form
- generic [ref=r1]:
  - combobox "Recipient" [ref=r2]:
    - option "Integrated Digital Signature Gateway" [ref=o1]
  - combobox "Settings" [ref=r3]:
    - option "Parallel Signature Profile" [ref=o2]
    - option "Serial Signature Profile" [ref=o3]
    - option "Check Signature Profile" [ref=o4]
'''
        self.policy.set_observed_snapshot(snapshot)
        return snapshot

    def test_08_semantic_exact_match_selects(self):
        self._set_select_snapshot()
        result = self.policy.validate_action(
            "browser_select_option",
            {
                "target": "r2",
                "values": ["Integrated Digital Signature Gateway"],
                "requested_concept": "Digital Signature Gateway",
            },
        )
        self.assertTrue(result["approved"])

    def test_09_semantic_no_match_does_not_select(self):
        self._set_select_snapshot()
        result = self.policy.validate_action(
            "browser_select_option",
            {
                "target": "r3",
                "values": ["Parallel Signature Profile"],
                "requested_concept": "Digital Signature Gateway",
            },
        )
        self.assertFalse(result["approved"])

    def test_10_first_option_unrelated_does_not_select(self):
        self._set_select_snapshot()
        result = self.policy.validate_action(
            "browser_select_option",
            {
                "target": "r3",
                "values": ["Parallel Signature Profile"],
                "requested_concept": "Digital Signature Gateway",
            },
        )
        self.assertFalse(result["approved"])

    def test_11_default_option_unrelated_does_not_select(self):
        self._set_select_snapshot()
        result = self.policy.validate_action(
            "browser_select_option",
            {
                "target": "r3",
                "values": ["Parallel Signature Profile"],
                "requested_concept": "Digital Signature Gateway",
                "selection_reason": "default option",
            },
        )
        self.assertFalse(result["approved"])

    def test_12_required_field_error_is_not_semantic_evidence(self):
        self._set_select_snapshot()
        # A validation message is intentionally not passed to the selector
        # as semantic evidence. With no requested concept, selection is denied.
        result = self.policy.validate_action(
            "browser_select_option",
            {
                "target": "r3",
                "values": ["Parallel Signature Profile"],
            },
        )
        self.assertFalse(result["approved"])

    def test_dom_action_signature_exists_and_distinguishes_arguments(self):
        sig1 = QAReActAgent._dom_action_signature(
            "input_text", {"index": 4, "text": "12345"}
        )
        sig2 = QAReActAgent._dom_action_signature(
            "input_text", {"index": 4, "text": "54321"}
        )
        sig3 = QAReActAgent._dom_action_signature(
            "click_element_by_index", {"index": 4}
        )
        self.assertNotEqual(sig1, sig2)
        self.assertNotEqual(sig1, sig3)
        self.assertIn("input_text", sig1)
        self.assertIn('"index":4', sig1)

    def test_13_action_no_effect_requires_new_evidence(self):
        snapshot = "- Page URL: https://app.example.test/form\n- button \"Action\" [ref=b1]\n"
        self.policy.set_observed_snapshot(snapshot)
        before = SnapshotIndex(snapshot).state_hash
        self.policy.note_no_effect("browser_click", {"target": "b1"}, before, before)
        result = self.policy.validate_action("browser_click", {"target": "b1", "element": "Action"})
        self.assertFalse(result["approved"])

        changed = snapshot + "- text: new evidence\n"
        self.policy.set_observed_snapshot(changed)
        result = self.policy.validate_action("browser_click", {"target": "b1", "element": "Action"})
        self.assertTrue(result["approved"])

    def test_14_repeated_identical_action_loop_prevention(self):
        snapshot = "- Page URL: https://app.example.test/form\n- button \"Action\" [ref=b1]\n"
        self.policy.set_observed_snapshot(snapshot)
        state = SnapshotIndex(snapshot).state_hash
        self.policy.note_no_effect("browser_click", {"target": "b1"}, state, state)
        first = self.policy.validate_action("browser_click", {"target": "b1", "element": "Action"})
        self.assertFalse(first["approved"])


    def test_16_before_page_agent_state_is_initialized_before_transition_summary(self):
        import ast
        from pathlib import Path

        source = Path(__file__).resolve().parents[1].joinpath("engine", "agent.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        run_goal = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "QAReActAgent")
        fn = next(n for n in run_goal.body if isinstance(n, ast.FunctionDef) and n.name == "run_goal")

        transition_lineno = next(
            n.lineno for n in ast.walk(fn)
            if isinstance(n, ast.Assign)
            and isinstance(n.targets[0], ast.Name)
            and n.targets[0].id == "transition_note"
        )
        before_pa_lines = [
            n.lineno for n in ast.walk(fn)
            if isinstance(n, ast.Assign)
            and any(isinstance(t, ast.Name) and t.id == "before_pa" for t in n.targets)
            and n.lineno < transition_lineno
        ]
        self.assertTrue(before_pa_lines, "before_pa must be initialized before transition summary")
        self.assertLess(max(before_pa_lines), transition_lineno)

    def test_15_mission_inputs_are_immutable(self):
        state = MissionState({"requested_value": "A"})
        state.declare("requested_value", "A")
        with self.assertRaises(ValueError):
            state.declare("requested_value", "B")
        state.set_human_input("checkpoint", "X")
        with self.assertRaises(ValueError):
            state.set_human_input("checkpoint", "Y")
        checkpoint = {
            "checkpoint_type": "external_artifact",
            "requested_artifact_type": "url",
            "source_context": "application_generated_artifact",
            "expected_format": "url",
            "provenance_policy": "human_confirmed_application_artifact",
        }
        state.declare_checkpoint("artifact", checkpoint)
        with self.assertRaises(ValueError):
            state.declare_checkpoint("artifact", {**checkpoint, "source_context": "other"})


    def test_human_application_artifact_checkpoint_preserves_trusted_provenance(self):
        answer = "https://external.example.test/generated?artifact=opaque"
        agent = QAReActAgent(
            browser=object(),
            ai=object(),
            policy=self.policy,
            evidence=object(),
            skill_loader=object(),
            human_input_fn=lambda _question: answer,
        )
        agent._initial_url = "https://app.example.test/start"
        result = agent._handle_ask_human({
            "question": "Provide the application-generated artifact.",
            "save_to": "artifact_url",
            "input_type": "EXTERNAL_ARTIFACT",
            "checkpoint": {
                "checkpoint_type": "external_artifact",
                "requested_artifact_type": "url",
                "source_context": "application_generated_artifact",
                "expected_format": "url",
                "provenance_policy": "human_confirmed_application_artifact",
            },
        })
        self.assertIn("HUMAN_INPUT", result)
        self.assertEqual(
            agent._last_navigation_evidence["provenance"],
            "human_confirmed_application_artifact",
        )
        self.assertEqual(
            agent.mission_state.artifacts[-1]["provenance"],
            "human_confirmed_application_artifact",
        )
        allowed = self.policy.validate_action(
            "browser_navigate",
            {
                "url": answer,
                "navigation_evidence": agent._last_navigation_evidence,
            },
        )
        self.assertTrue(allowed["approved"])

    def test_arbitrary_human_url_checkpoint_remains_untrusted(self):
        answer = "https://external.example.test/random"
        agent = QAReActAgent(
            browser=object(),
            ai=object(),
            policy=self.policy,
            evidence=object(),
            skill_loader=object(),
            human_input_fn=lambda _question: answer,
        )
        agent._initial_url = "https://app.example.test/start"
        agent._handle_ask_human({
            "question": "Provide a URL.",
            "save_to": "url",
            "input_type": "URL",
        })
        self.assertEqual(
            agent._last_navigation_evidence["provenance"],
            "arbitrary_human_url",
        )
        blocked = self.policy.validate_action(
            "browser_navigate",
            {
                "url": answer,
                "navigation_evidence": agent._last_navigation_evidence,
            },
        )
        self.assertFalse(blocked["approved"])

    def test_artifact_model_does_not_auto_trust_arbitrary_human_url(self):
        artifact = make_artifact(
            "url", "https://external.example.test/x", "human", "arbitrary_human_url"
        )
        self.assertEqual(artifact.provenance, "arbitrary_human_url")

    def test_semantic_resolver_reports_no_match_not_closest(self):
        resolver = SemanticResolver()
        result = resolver.match_options(
            "Digital Signature Gateway",
            ["Parallel Signature Profile", "Serial Signature Profile"],
        )
        self.assertEqual(result["status"], "NO_MATCH")
        self.assertEqual(result["matches"], [])


    def test_16_semantic_request_must_be_grounded_in_mission(self):
        self._set_select_snapshot()
        result = self.policy.validate_action(
            "browser_select_option",
            {
                "target": "r3",
                "values": ["Parallel Signature Profile"],
                "requested_concept": "Parallel Signature Profile",
            },
        )
        self.assertFalse(result["approved"])
        self.assertIn("UNANCHORED_REQUEST", result["reason"])

    def test_17_budget_counts_internal_actions(self):
        self.policy.max_actions = 2
        self.assertTrue(self.policy.consume_internal_action())
        self.assertTrue(self.policy.consume_internal_action())
        self.assertFalse(self.policy.consume_internal_action())
        self.assertEqual(self.policy.actions_done, 2)

    def test_18_exploratory_pass_is_downgraded(self):
        agent = QAReActAgent.__new__(QAReActAgent)
        agent.mode = "explore"
        agent._recent_snapshot = ""
        result = agent._outcome_from_final(
            {"arguments": {"verdict": "PASS", "expected": "goal", "actual": "done"}},
            "goal", 2,
        )
        self.assertEqual(result.verdict, "INCONCLUSIVE")

    def test_19_unresolved_validation_prevents_pass(self):
        agent = QAReActAgent.__new__(QAReActAgent)
        agent.mode = "run"
        agent._recent_snapshot = '- textbox "Location" [aria-invalid=true]'
        result = agent._outcome_from_final(
            {"arguments": {"verdict": "PASS", "expected": "goal", "actual": "done"}},
            "goal", 2,
        )
        self.assertEqual(result.verdict, "INCONCLUSIVE")

    def test_20_mission_concept_phrase_is_required(self):
        self.policy.set_mission_intent("Choose a recipient application")
        self._set_select_snapshot()
        result = self.policy.validate_action(
            "browser_select_option",
            {
                "target": "r2",
                "values": ["Integrated Digital Signature Gateway"],
                "requested_concept": "Digital Signature Gateway",
            },
        )
        self.assertFalse(result["approved"])


    def test_25_unobserved_same_origin_route_is_blocked(self):
        snapshot = "- Page URL: https://app.example.test/start\n- link \"Observed\" [ref=l1]:\n  - /url: https://app.example.test/observed\n"
        self.policy.set_observed_snapshot(snapshot)
        result = self.policy.validate_action(
            "browser_navigate",
            {"url": "https://app.example.test/unobserved-route"},
        )
        self.assertFalse(result["approved"])
        self.assertIn("not observed", result["reason"])

    def test_26_observed_same_origin_href_is_allowed_without_model_claim(self):
        snapshot = "- Page URL: https://app.example.test/start\n- link \"Observed\" [ref=l1]:\n  - /url: https://app.example.test/observed\n"
        self.policy.set_observed_snapshot(snapshot)
        result = self.policy.validate_action(
            "browser_navigate",
            {"url": "https://app.example.test/observed"},
        )
        self.assertTrue(result["approved"])

    def test_27_same_click_after_no_effect_stays_blocked_even_after_snapshot_text_refresh(self):
        snapshot = "- Page URL: https://app.example.test/form\n- button \"Action\" [ref=b1]\n"
        self.policy.set_observed_snapshot(snapshot)
        before = SnapshotIndex(snapshot).state_hash
        self.policy.note_no_effect("browser_click", {"target": "b1"}, before, before)
        refreshed_same_state = snapshot + "\n"
        self.policy.set_observed_snapshot(refreshed_same_state)
        result = self.policy.validate_action(
            "browser_click", {"target": "b1", "element": "Action"}
        )
        self.assertFalse(result["approved"])

    def test_28_new_state_evidence_allows_strategy_retry(self):
        snapshot = "- Page URL: https://app.example.test/form\n- button \"Action\" [ref=b1]\n"
        self.policy.set_observed_snapshot(snapshot)
        before = SnapshotIndex(snapshot).state_hash
        self.policy.note_no_effect("browser_click", {"target": "b1"}, before, before)
        changed = snapshot + "- dialog \"New state\" [ref=d1]\n"
        self.policy.set_observed_snapshot(changed)
        result = self.policy.validate_action(
            "browser_hover", {"target": "b1", "element": "Action"}
        )
        self.assertTrue(result["approved"])

    def test_21_agent_budget_guard_blocks_next_action_at_limit(self):
        agent = QAReActAgent.__new__(QAReActAgent)
        agent.policy = self.policy
        self.policy.max_actions = 3
        self.policy.actions_done = 2
        self.assertFalse(agent._budget_exhausted(2))
        self.policy.consume_internal_action()
        self.assertTrue(agent._budget_exhausted(2))
        self.assertTrue(agent._budget_exhausted(3))


    def test_29_dropdown_open_then_select_is_not_loop(self):
        first = self.policy.note_action(
            "browser_click", {"target": "control-open", "element": "dropdown"},
            before_state_hash="state-a", after_state_hash="state-b",
        )
        second = self.policy.note_action(
            "browser_click", {"target": "option-1", "element": "option"},
            before_state_hash="state-b", after_state_hash="state-c",
        )
        self.assertIsNone(first)
        self.assertIsNone(second)

    def test_30_same_action_target_and_state_is_loop(self):
        first = self.policy.note_action(
            "browser_click", {"target": "same-ref", "element": "same control"},
            before_state_hash="state-a", after_state_hash="state-a",
        )
        second = self.policy.note_action(
            "browser_click", {"target": "same-ref", "element": "same control"},
            before_state_hash="state-a", after_state_hash="state-a",
        )
        self.assertIsNone(first)
        self.assertIsNotNone(second)
        self.assertIn("unchanged state", second)

    def test_31_different_target_same_state_is_not_loop(self):
        first = self.policy.note_action(
            "browser_click", {"target": "ref-a", "element": "same label"},
            before_state_hash="state-a", after_state_hash="state-a",
        )
        second = self.policy.note_action(
            "browser_click", {"target": "ref-b", "element": "same label"},
            before_state_hash="state-a", after_state_hash="state-a",
        )
        self.assertIsNone(first)
        self.assertIsNone(second)

    def test_32_same_target_changed_state_is_not_loop(self):
        first = self.policy.note_action(
            "browser_click", {"target": "same-ref", "element": "same label"},
            before_state_hash="state-a", after_state_hash="state-b",
        )
        second = self.policy.note_action(
            "browser_click", {"target": "same-ref", "element": "same label"},
            before_state_hash="state-b", after_state_hash="state-c",
        )
        self.assertIsNone(first)
        self.assertIsNone(second)

    def test_33_cross_control_semantic_match_is_reported(self):
        self._set_select_snapshot()
        denied = self.policy.validate_action(
            "browser_select_option",
            {
                "target": "r3",
                "values": ["Parallel Signature Profile"],
                "requested_concept": "Digital Signature Gateway",
            },
        )
        self.assertFalse(denied["approved"])
        self.assertIn("Other observed controls with a semantic match", denied["reason"])
        self.assertIn("ref=r2", denied["reason"])

    def test_34_cross_control_matching_option_is_allowed(self):
        self._set_select_snapshot()
        allowed = self.policy.validate_action(
            "browser_select_option",
            {
                "target": "r2",
                "values": ["Integrated Digital Signature Gateway"],
                "requested_concept": "Digital Signature Gateway",
            },
        )
        self.assertTrue(allowed["approved"])

    def test_35_same_ref_with_new_ui_state_can_progress(self):
        first = self.policy.note_action(
            "browser_click", {"target": "same-ref"},
            before_state_hash="closed", after_state_hash="open",
        )
        second = self.policy.note_action(
            "browser_click", {"target": "same-ref"},
            before_state_hash="open", after_state_hash="selected",
        )
        self.assertIsNone(first)
        self.assertIsNone(second)

    def test_36_failed_action_then_fresh_state_allows_different_strategy(self):
        snapshot = "- Page URL: https://app.example.test/form\n- button \"Action\" [ref=b1]\n"
        self.policy.set_observed_snapshot(snapshot)
        state = SnapshotIndex(snapshot).state_hash
        self.policy.note_no_effect("browser_click", {"target": "b1"}, state, state)
        self.assertFalse(self.policy.validate_action("browser_click", {"target": "b1"})["approved"])
        changed = snapshot + "- dialog \"New state\" [ref=d1]\n"
        self.policy.set_observed_snapshot(changed)
        self.assertTrue(self.policy.validate_action("browser_hover", {"target": "b1"})["approved"])

    def test_37_semantic_mismatch_never_selects_first_option(self):
        self._set_select_snapshot()
        result = self.policy.validate_action(
            "browser_select_option",
            {
                "target": "r3",
                "values": ["Parallel Signature Profile"],
                "requested_concept": "Digital Signature Gateway",
            },
        )
        self.assertFalse(result["approved"])

    def test_38_selected_state_transition_is_not_loop(self):
        first = self.policy.note_action(
            "browser_select_option", {"target": "option-ref", "values": ["x"]},
            before_state_hash="dropdown-open", after_state_hash="selected",
        )
        self.assertIsNone(first)

    def test_39_semantic_control_search_has_no_site_specific_knowledge(self):
        self._set_select_snapshot()
        evidence = self.policy.semantic_option_evidence("Digital Signature Gateway")
        self.assertEqual(len(evidence), 1)
        self.assertEqual(evidence[0]["target"], "r2")
        self.assertEqual(evidence[0]["matches"], ["Integrated Digital Signature Gateway"])

    def test_45_trusted_external_navigation_is_allowed_even_on_new_origin(self):
        result = self.policy.validate_action(
            "browser_navigate",
            {"url": "https://new-app.example.test/next",
             "navigation_evidence": self._nav("application_generated", "https://new-app.example.test/next")},
        )
        self.assertTrue(result["approved"])

    def test_46_untrusted_external_navigation_is_still_blocked(self):
        result = self.policy.validate_action(
            "browser_navigate",
            {"url": "https://unknown.example.test/path",
             "navigation_evidence": self._nav("guessed", "https://unknown.example.test/path")},
        )
        self.assertFalse(result["approved"])


    def test_wait_is_not_false_positive_loop_when_dom_hash_does_not_change(self):
        from engine.policy_engine import LoopDetector
        detector = LoopDetector({"enabled": True, "max_same_action_repeat": 2})
        first = detector.record("wait", "", "same", "same", evidence_hash="wait-1")
        second = detector.record("wait", "", "same", "same", evidence_hash="wait-2")
        third = detector.record("wait", "", "same", "same", evidence_hash="wait-3")
        self.assertIsNone(first)
        self.assertIsNone(second)
        self.assertIsNone(third)

    def test_loading_modeling_is_removed_from_controller(self):
        from pathlib import Path
        js = Path(__file__).resolve().parents[1].joinpath("engine", "page_agent_controller.js").read_text(encoding="utf-8")
        self.assertNotIn("nearestBusyOwner", js)
        self.assertNotIn('aria-busy="true"', js)
        self.assertNotIn('data-loading="true"', js)
        self.assertNotIn("BUSY/LOADING", js)

    def test_network_correlation_is_independent_of_loading_flags(self):
        from pathlib import Path
        source = Path(__file__).resolve().parents[1].joinpath("engine", "agent.py").read_text(encoding="utf-8")
        self.assertIn("_collect_action_network_evidence", source)
        self.assertNotIn("_detect_async_signal", source)
        self.assertNotIn("_settle_async_operation", source)
        self.assertNotIn("ACTION_NETWORK_BUSY_WAIT_MS", source)

class AsyncSettlementRuntimeTests(unittest.TestCase):
    def test_wait_is_not_an_exposed_page_agent_tool(self):
        from engine.agent import PAGE_AGENT_TOOLS
        self.assertNotIn("wait", PAGE_AGENT_TOOLS)

    def test_wait_is_not_in_tool_catalog(self):
        agent = object.__new__(QAReActAgent)
        agent._system_prompt = None
        agent.mission_type = "exploratory"
        agent.mode = "explore"
        agent.policy = PolicyEngine()
        agent.skills = type("S", (), {"select": lambda *_a, **_k: [], "compose_prompt": lambda *_a, **_k: ""})()
        agent._last_snapshot_text = lambda: ""
        catalog = QAReActAgent._tools_catalog(agent)
        self.assertNotIn("- wait:", catalog)

class AsyncWaitLoopHardeningTests(unittest.TestCase):
    def test_loading_settle_path_has_no_delay_or_polling(self):
        import inspect
        source = inspect.getsource(QAReActAgent._settled_page_agent_state)
        self.assertNotIn("time.sleep", source)
        self.assertNotIn("page_agent.state()", source)
        self.assertNotIn("_smart_wait_action", inspect.getsource(QAReActAgent))

class AsyncWaitPolicyTests(unittest.TestCase):
    def test_system_prompt_forbids_blind_wait_for_generic_loading(self):
        import inspect
        source = inspect.getsource(QAReActAgent.system_prompt)
        self.assertNotIn("loading/pending", source)
        self.assertIn("countdown", source)


class BusySignalPrecisionTests(unittest.TestCase):
    def test_busy_signal_state_is_deleted(self):
        from pathlib import Path
        js = Path(__file__).resolve().parents[1].joinpath("engine", "page_agent_controller.js").read_text(encoding="utf-8")
        self.assertNotIn("busyOwner", js)
        self.assertNotIn("nearestBusyOwner", js)
        self.assertNotIn("BUSY/LOADING", js)


if __name__ == "__main__":
    unittest.main()

class MissionInputLedgerTests(unittest.TestCase):
    def test_41_mission_literal_is_preserved(self):
        from engine.mission_inputs import MissionInputLedger
        ledger = MissionInputLedger("login with 0927407043")
        self.assertIn("0927407043", ledger.values)

    def test_42_confirmation_reuses_single_referenced_mission_value(self):
        from engine.mission_inputs import MissionInputLedger
        ledger = MissionInputLedger("login with 0927407043")
        refs = ledger.begin_clarification(
            "Is 0927407043 the value for this field?", "field_value"
        )
        self.assertEqual(refs, ("0927407043",))
        self.assertEqual(ledger.resolve_confirmation("همونه بابا"), "0927407043")

    def test_43_confirmation_does_not_guess_when_multiple_values_are_referenced(self):
        from engine.mission_inputs import MissionInputLedger
        ledger = MissionInputLedger("use 123456 and 987654")
        ledger.begin_clarification("Which one, 123456 or 987654?", "field")
        self.assertIsNone(ledger.resolve_confirmation("same"))

    def test_44_non_confirmation_does_not_resolve(self):
        from engine.mission_inputs import MissionInputLedger
        ledger = MissionInputLedger("login with 0927407043")
        ledger.begin_clarification("Is 0927407043 the value?", "field")
        self.assertIsNone(ledger.resolve_confirmation("no, another value"))

    def test_45_observability_tools_are_read_only(self):
        from engine.policy_engine import OBSERVATION_TOOLS
        self.assertIn("browser_console_messages", OBSERVATION_TOOLS)
        self.assertIn("browser_network_requests", OBSERVATION_TOOLS)
        self.assertIn("browser_network_request", OBSERVATION_TOOLS)
        self.assertNotIn("browser_network_request", __import__("engine.policy_engine", fromlist=["MUTATING_TOOLS"]).MUTATING_TOOLS)

    def test_46_observability_evidence_is_redacted(self):
        from engine.evidence_store import EvidenceStore
        store = EvidenceStore(base_dir=tempfile.mkdtemp())
        entry = store.record_observability(
            "network",
            'Authorization: Bearer token=secret-value; otp=12345',
            trigger="test",
            action_index=1,
        )
        self.assertIn("REDACTED", entry["content"])
        self.assertNotIn("secret-value", entry["content"])
        self.assertNotIn("12345", entry["content"])

    def test_47_run_media_is_optional(self):
        import config
        old = config.RECORD_RUN
        try:
            config.RECORD_RUN = False
            from engine.recording import build_run_media
            result = build_run_media(tempfile.mkdtemp())
            self.assertEqual(result, {})
        finally:
            config.RECORD_RUN = old

    def test_48_recording_frame_names_are_deterministic(self):
        from engine.recording import build_run_media
        from PIL import Image
        import config
        run_dir = tempfile.mkdtemp()
        ev = os.path.join(run_dir, "evidence")
        os.makedirs(ev, exist_ok=True)
        for i in range(2):
            Image.new("RGB", (32, 32), (i * 20, i * 20, i * 20)).save(
                os.path.join(ev, f"frame-{i:06d}.png")
            )
        old_run, old_fps = config.RECORD_RUN, config.RECORD_FPS
        try:
            config.RECORD_RUN = True
            config.RECORD_FPS = 5
            result = build_run_media(run_dir)
            self.assertTrue(result.get("gif"))
            self.assertTrue(os.path.exists(result["gif"]))
        finally:
            config.RECORD_RUN, config.RECORD_FPS = old_run, old_fps

class CombinedObservationTests(unittest.TestCase):
    def test_51_browser_find_is_observation_only(self):
        from engine.policy_engine import OBSERVATION_TOOLS
        self.assertIn("browser_find", OBSERVATION_TOOLS)

    def test_52_combined_strategy_is_in_prompt(self):
        from engine.agent import ADDRESSING_PROMPT
        self.assertIn("COMBINED observation strategy", ADDRESSING_PROMPT)
        self.assertIn("browser_find", ADDRESSING_PROMPT)
        self.assertIn("console", ADDRESSING_PROMPT)
        self.assertIn("network", ADDRESSING_PROMPT)



class ActionNetworkPollingTests(unittest.TestCase):
    def test_click_network_probe_polls_until_new_request_appears(self):
        class FakeBrowser:
            def __init__(self):
                self.tools = {"browser_network_requests": {}, "browser_network_request": {}}
                self.calls = 0
            def call_tool(self, name, args=None, timeout=None):
                class R:
                    def __init__(self, text): self.text = text
                if name == "browser_network_requests":
                    self.calls += 1
                    if self.calls < 3:
                        return R("1. [GET] https://app.test/api/background => [200] OK\n")
                    return R(
                        "1. [GET] https://app.test/api/background => [200] OK\n"
                        "2. [POST] https://app.test/api/save => [201] Created\n"
                    )
                if name == "browser_network_request" and args.get("part") == "response-headers":
                    return R("content-type: application/json\n")
                if name == "browser_network_request" and args.get("part") == "response-body":
                    return R('{"ok":true}')
                return R("#2 [POST] https://app.test/api/save\nstatus: [201] Created")

        agent = object.__new__(QAReActAgent)
        agent.browser = FakeBrowser()
        agent._network_seen_max = 1
        agent._network_seen_page_url = "https://app.test/form"
        agent._page_agent_url = "https://app.test/form"
        evidence = agent._collect_action_network_evidence(
            "click_element_by_index", {"index": 12}, action_index=9, wait_for_click_ms=400
        )
        self.assertEqual(evidence["new_request_count"], 1)
        self.assertEqual(evidence["requests"][0]["url"], "https://app.test/api/save")

    def test_click_network_probe_is_fast_when_no_request_exists(self):
        class FakeBrowser:
            def __init__(self):
                self.tools = {"browser_network_requests": {}}
            def call_tool(self, name, args=None, timeout=None):
                class R:
                    text = "1. [GET] https://app.test/api/background => [200] OK\n"
                return R()
        agent = object.__new__(QAReActAgent)
        agent.browser = FakeBrowser()
        agent._network_seen_max = 1
        agent._network_seen_page_url = "https://app.test/form"
        agent._page_agent_url = "https://app.test/form"
        start = time.monotonic()
        evidence = agent._collect_action_network_evidence(
            "click_element_by_index", {"index": 12}, action_index=10, wait_for_click_ms=0
        )
        self.assertEqual(evidence, {})
        self.assertLess(time.monotonic() - start, 0.5)


class BusyInteractionGuardTests(unittest.TestCase):
    def test_disabled_guard_does_not_reference_loading(self):
        source = Path(__file__).resolve().parents[1].joinpath("engine", "agent.py").read_text(encoding="utf-8")
        self.assertNotIn("strategy_loop_on_busy_or_disabled_surface", source)
        self.assertIn("strategy_loop_on_disabled_surface", source)


class BusySignalPrecisionTests(unittest.TestCase):
    def test_legacy_loading_signal_logic_is_deleted(self):
        from pathlib import Path
        js = Path(__file__).resolve().parents[1].joinpath("engine", "page_agent_controller.js").read_text(encoding="utf-8")
        self.assertNotIn("aria/data-loading-confirmed", js)
        self.assertNotIn("visibleActivitySignal", js)


if __name__ == "__main__":
    unittest.main()

class ActionableUiMapTests(unittest.TestCase):
    def test_live_actionable_ui_map_surfaces_controls_before_raw_snapshot(self):
        agent = object.__new__(QAReActAgent)
        snapshot = '''
- Page URL: https://app.example.test/login
- dialog "Login" [ref=d1]:
  - textbox "Mobile" [ref=t1]
  - button "Confirm" [ref=b1]
  - link "Help" [ref=l1]
'''
        rendered = agent._format_structural_observation(snapshot, "FRESH")
        self.assertIn("=== ACTIONABLE UI MAP (LIVE) ===", rendered)
        self.assertIn('button "Confirm" [ref=b1]', rendered)
        self.assertIn('textbox "Mobile" [ref=t1]', rendered)
        self.assertLess(
            rendered.index("=== ACTIONABLE UI MAP (LIVE) ==="),
            rendered.index("=== FRESH ==="),
        )

    def test_actionable_ui_map_is_runtime_derived_not_site_specific(self):
        agent = object.__new__(QAReActAgent)
        snapshot = '''
- Page URL: https://another.example.test/form
- form "Example" [ref=f1]:
  - textbox "Email" [ref=t1]
  - button "Submit Form" [ref=b1]
'''
        rendered = agent._format_structural_observation(snapshot, "STATE")
        self.assertIn('button "Submit Form" [ref=b1]', rendered)
        self.assertNotIn("ورود", rendered)
        self.assertNotIn("تایید", rendered)

class GenericClickableUiTests(unittest.TestCase):
    def test_runtime_clickable_generic_text_is_actionable(self):
        agent = object.__new__(QAReActAgent)
        snapshot = '''
- Page URL: https://app.example.test/modal
- generic [ref=g1]:
  - generic "Confirm" [cursor=pointer] [ref=g2]
'''
        rendered = agent._format_structural_observation(snapshot, "STATE")
        self.assertIn('generic "Confirm" [ref=g2]', rendered)

class BatchTypingTests(unittest.TestCase):
    def test_single_character_in_related_maxlength_one_group_is_batched(self):
        agent = object.__new__(QAReActAgent)
        agent._recent_snapshot = '''
- Page URL: https://app.example.test/verify
- dialog "Verification" [ref=d1]:
  - textbox "Code digit 1" [maxlength=1] [ref=e1]
  - textbox "Code digit 2" [maxlength=1] [ref=e2]
  - textbox "Code digit 3" [maxlength=1] [ref=e3]
  - button "Continue" [ref=b1]
'''
        hint = agent._multi_field_batch_hint({"target": "e1", "text": "2"})
        self.assertIn("BATCH INPUT REQUIRED", hint)
        self.assertIn("e1, e2, e3", hint)

    def test_single_character_normal_field_is_not_forced_to_batch(self):
        agent = object.__new__(QAReActAgent)
        agent._recent_snapshot = '''
- Page URL: https://app.example.test/form
- form "Example" [ref=f1]:
  - textbox "Name" [ref=e1]
  - button "Save" [ref=b1]
'''
        self.assertEqual(
            agent._multi_field_batch_hint({"target": "e1", "text": "A"}),
            "",
        )

    def test_typing_prompt_forbids_snapshot_after_success(self):
        from engine.agent import ENVIRONMENT_FACTS_PROMPT
        self.assertIn("DO NOT request a\n  browser_snapshot", ENVIRONMENT_FACTS_PROMPT)
        self.assertIn("browser_fill_form", ENVIRONMENT_FACTS_PROMPT)


class HumanCheckpointLifecycleTests(unittest.TestCase):
    def test_empty_human_input_does_not_poison_slot(self):
        from engine.mission_state import MissionState
        state = MissionState()
        state.set_human_input("challenge", "")
        state.set_human_input("challenge", "5ZGN")
        self.assertEqual(state.human_inputs["challenge"], "5ZGN")

    def test_ephemeral_human_input_can_refresh(self):
        from engine.mission_state import MissionState
        state = MissionState()
        state.set_human_input("challenge", "OLD", ephemeral=True)
        state.set_human_input("challenge", "NEW", ephemeral=True)
        self.assertEqual(state.human_inputs["challenge"], "NEW")

    def test_durable_human_input_remains_immutable(self):
        from engine.mission_state import MissionState
        state = MissionState()
        state.set_human_input("phone", "09120000000")
        with self.assertRaises(ValueError):
            state.set_human_input("phone", "09121111111")


class HumanInputLifecycleResolverTests(unittest.TestCase):
    def test_generic_one_time_input_type_is_ephemeral(self):
        from engine.agent import QAReActAgent
        self.assertEqual(
            QAReActAgent._resolve_human_input_lifecycle(
                {"input_type": "one_time_code"}, {}, "one_time_code"
            ),
            "ephemeral",
        )

    def test_generic_challenge_checkpoint_is_ephemeral(self):
        from engine.agent import QAReActAgent
        self.assertEqual(
            QAReActAgent._resolve_human_input_lifecycle(
                {}, {"one_time": True}, "OTHER_REQUIRED_EXTERNAL_INPUT"
            ),
            "ephemeral",
        )

    def test_unknown_human_input_stays_durable(self):
        from engine.agent import QAReActAgent
        self.assertEqual(
            QAReActAgent._resolve_human_input_lifecycle(
                {}, {}, "OTHER_REQUIRED_EXTERNAL_INPUT"
            ),
            "durable",
        )


class PageAgentStateTests(unittest.TestCase):
    def test_page_agent_state_indexes_interactive_elements_and_keeps_context(self):
        snapshot = """
### Page
- Page URL: https://example.test
### Snapshot
```yaml
- dialog "Example" [ref=d1]:
  - generic "Open form" [cursor=pointer] [ref=g1]
  - textbox "Email" [ref=t1]
  - button "Continue" [ref=b1]
```
"""
        state = SnapshotIndex(snapshot).page_agent_state()
        self.assertIn('[1] generic "Open form"', state)
        self.assertIn('[2] textbox "Email"', state)
        self.assertIn('[3] button "Continue"', state)
        self.assertIn('[ref=g1]', state)
        self.assertIn('dialog "Example"', state)


class TestScrollGuard(unittest.TestCase):
    def test_current_state_target_blocks_scroll(self):
        from engine.agent import QAReActAgent
        elements = [
            {
                "index": 9,
                "role": "button",
                "name": "افزودن سند جهت امضا",
                "context": ["main اسناد و قرارداد ها"],
            },
            {
                "index": 10,
                "role": "button",
                "name": "بازگشت",
                "context": ["main"],
            },
        ]
        matches = QAReActAgent._find_current_state_targets(
            elements,
            "دکمه «افزودن سند جهت امضا» را پیدا کن و اجرا کن.",
            "اسناد و قراردادها > افزودن سند جهت امضا",
        )
        self.assertEqual([m["index"] for m in matches], [9])

    def test_unrelated_current_state_does_not_block_scroll(self):
        from engine.agent import QAReActAgent
        elements = [
            {"index": 1, "role": "button", "name": "بازگشت", "context": ["main"]},
            {"index": 2, "role": "link", "name": "صفحه بعد", "context": ["nav"]},
        ]
        matches = QAReActAgent._find_current_state_targets(
            elements,
            "دکمه افزودن سند جهت امضا را پیدا کن.",
            "افزودن سند جهت امضا",
        )
        self.assertEqual(matches, [])

    def test_generic_target_is_not_matched_by_role_word_alone(self):
        from engine.agent import QAReActAgent
        elements = [
            {"index": 1, "role": "button", "name": "ثبت", "context": ["main"]},
            {"index": 2, "role": "button", "name": "افزودن", "context": ["main"]},
        ]
        matches = QAReActAgent._find_current_state_targets(
            elements,
            "دکمه را پیدا کن.",
            "دکمه افزودن سند جهت امضا را اجرا کن",
        )
        self.assertEqual(matches, [])

class TestIndexGroundingRegression(unittest.TestCase):
    def test_find_elements_tool_is_available(self):
        from engine.agent import PAGE_AGENT_TOOLS
        self.assertIn("find_elements", PAGE_AGENT_TOOLS)

    def test_prompt_forbids_index_guessing(self):
        from engine.agent import ADDRESSING_PROMPT
        self.assertIn("NEVER invent, estimate, extrapolate", ADDRESSING_PROMPT)
        self.assertIn("find_elements", ADDRESSING_PROMPT)
        self.assertIn("DROPDOWN GROUNDING", ADDRESSING_PROMPT)


class TestAtomicTargetingRegression(unittest.TestCase):
    def test_response_protocol_documents_find_elements(self):
        from engine.agent import RESPONSE_PROTOCOL
        self.assertIn('find_elements', RESPONSE_PROTOCOL)
        self.assertIn('"query": "semantic text/label/context', RESPONSE_PROTOCOL)

    def test_response_protocol_requires_atomic_steps(self):
        from engine.agent import RESPONSE_PROTOCOL
        self.assertIn('ATOMIC STEP RULE', RESPONSE_PROTOCOL)
        self.assertIn('ONE unfinished target at a time', RESPONSE_PROTOCOL)

    def test_find_elements_accepts_query_aliases(self):
        from engine.agent import PAGE_AGENT_TOOLS
        self.assertIn('find_elements', PAGE_AGENT_TOOLS)

class TestMicroGoalPlannerRegression(unittest.TestCase):
    def test_micro_goal_architecture_is_present(self):
        from engine.agent import MICRO_GOAL_PLANNER_PROMPT
        self.assertIn('SINGLE next unfinished objective', MICRO_GOAL_PLANNER_PROMPT)
        self.assertIn('Do NOT enumerate all controls', MICRO_GOAL_PLANNER_PROMPT)
        self.assertIn('Never describe future objectives', MICRO_GOAL_PLANNER_PROMPT)

    def test_actor_prompt_is_scoped_to_current_micro_goal(self):
        from engine.agent import QAReActAgent
        self.assertTrue(hasattr(QAReActAgent, '_plan_next_micro_goal'))
        import inspect
        source = inspect.getsource(QAReActAgent._compose_goal_message)
        self.assertIn('CURRENT MICRO-GOAL', source)
        self.assertIn('Do not work on any other mission objective', source)

class PageAgentControllerRegressionTests(unittest.TestCase):
    def test_default_single_loop_without_separate_micro_planner(self):
        import config
        self.assertFalse(config.USE_MICRO_GOAL_PLANNER)

    def test_agent_js_requires_two_runtime_flags(self):
        import config
        self.assertFalse(config.ALLOW_AGENT_JS)
        self.assertFalse(config.ALLOW_EVALUATE)

    def test_controller_contains_page_agent_capabilities(self):
        from pathlib import Path
        js = Path("engine/page_agent_controller.js").read_text(encoding="utf-8")
        for needle in (
            "shadowRoot", "contentDocument", "getClientRects", "contenteditable",
            "aria-labelledby", "label[for=", "scroll-container", "state.revision",
            "beforeinput", "execCommand", "canScrollDown",
        ):
            self.assertIn(needle, js)

    def test_controller_does_not_rebuild_on_indexed_action_lookup(self):
        from pathlib import Path
        js = Path("engine/page_agent_controller.js").read_text(encoding="utf-8")
        self.assertIn("const e = currentMap().find(x => x.index === n);", js)
        self.assertIn("request a fresh observation", js)

    def test_input_function_does_not_blur_after_typing(self):
        """Vue/React controlled inputs often clear/revert the value on blur.
        The input function must NOT call el.blur() after typing."""
        from pathlib import Path
        js = Path("engine/page_agent_controller.js").read_text(encoding="utf-8")
        # The comment explaining why we don't blur must be present.
        self.assertIn("DO NOT blur", js)
        self.assertIn("Vue/React components often clear or revert the value on", js)

    def test_input_function_verifies_value_stuck(self):
        """The input function must verify the value actually stuck and return
        a value_stuck field so the agent knows if the input was accepted."""
        from pathlib import Path
        js = Path("engine/page_agent_controller.js").read_text(encoding="utf-8")
        self.assertIn("value_stuck", js)
        self.assertIn("actual_length", js)
        self.assertIn("expected_length", js)

    def test_input_function_has_execCommand_fallback(self):
        """When the native setter doesn't stick, the input function must try
        execCommand insertText as a fallback (fires trusted input events)."""
        from pathlib import Path
        js = Path("engine/page_agent_controller.js").read_text(encoding="utf-8")
        self.assertIn("execCommandInsertText", js)
        self.assertIn("execCommand_insertText", js)

    def test_input_function_has_char_by_char_fallback(self):
        """When execCommand also doesn't stick, the input function must try
        a character-by-character native setter approach."""
        from pathlib import Path
        js = Path("engine/page_agent_controller.js").read_text(encoding="utf-8")
        self.assertIn("char_by_char", js)

    def test_dispatchInputEvents_uses_InputEvent(self):
        """Vue/React v-model listeners listen for InputEvent, not generic
        Event. The dispatchInputEvents function must use InputEvent when
        available."""
        from pathlib import Path
        js = Path("engine/page_agent_controller.js").read_text(encoding="utf-8")
        self.assertIn("new win.InputEvent", js)


class FormDependencyAndHumanCommandTests(unittest.TestCase):
    def test_controller_exposes_disabled_state_prerequisites_and_timers(self):
        from pathlib import Path
        js = Path("engine/page_agent_controller.js").read_text(encoding="utf-8")
        for needle in (
            'disabled,', 'prerequisiteCandidates', 'prereq_candidates=',
            'collectTimers', 'TIMER:', 'isDisabled(e._el)',
        ):
            self.assertIn(needle, js)

    def test_human_resend_command_is_not_treated_as_otp(self):
        self.assertEqual(
            QAReActAgent._normalize_human_command("بزن ارسال مجدد تا واردش کنم"),
            "RESEND",
        )
        self.assertEqual(
            QAReActAgent._normalize_human_command("resend please"),
            "RESEND",
        )
        self.assertEqual(
            QAReActAgent._normalize_human_command("صبر کن تا تایمر تموم شه"),
            "WAIT",
        )
        self.assertEqual(
            QAReActAgent._normalize_human_command("60111"),
            "",
        )

    def test_prompt_requires_prerequisites_before_disabled_target(self):
        from engine.agent import ADDRESSING_PROMPT, RESPONSE_PROTOCOL
        self.assertIn("FORM DEPENDENCIES", ADDRESSING_PROMPT)
        self.assertIn("disabled/read-only", RESPONSE_PROTOCOL)
        self.assertIn("RESEND command is handled by runtime", RESPONSE_PROTOCOL)


class HumanResendExecutionTests(unittest.TestCase):
    class FakePageAgent:
        def __init__(self, disabled=True):
            self.disabled = disabled
            self.calls = []
            self.state_reads = 0

        def state(self):
            self.state_reads += 1
            element = {
                "index": 7,
                "role": "button",
                "name": "ارسال مجدد",
                "context": ["form Verification"],
                "status": {
                    "disabled": self.disabled,
                    "actionable": not self.disabled,
                    "countdown": "3 ثانیه" if self.disabled else "",
                },
            }
            return {
                "url": "https://app.example.test/verify",
                "content": "button \"ارسال مجدد\"",
                "elements": [element],
                "pageInfo": {"timers": [{"text": "ارسال مجدد تا 3 ثانیه"}] if self.disabled else []},
            }

        def wait(self, seconds):
            self.calls.append(("wait", seconds))
            self.disabled = False
            return type("R", (), {"text": "waited"})()

        def click(self, index):
            self.calls.append(("click", index))
            return type("R", (), {"text": "clicked resend"})()

    def _agent(self, page_agent):
        from engine.agent import QAReActAgent
        from engine.evidence_store import EvidenceStore
        from engine.policy_engine import PolicyEngine
        import tempfile
        agent = object.__new__(QAReActAgent)
        agent.browser = type("B", (), {"page_agent": page_agent})()
        td = tempfile.mkdtemp()
        agent.store = EvidenceStore(run_id="resend-test", base_dir=td, evidence_rules={"redact_fields": []})
        agent.policy = PolicyEngine()
        agent.policy.max_actions = 10
        agent._recent_page_agent_state = ""
        agent._page_agent_url = ""
        agent._human_command_action_count = 0
        agent._pending_human_command = ""
        return agent

    def test_resend_clicks_unique_enabled_control(self):
        page = self.FakePageAgent(disabled=False)
        agent = self._agent(page)
        message = agent._execute_human_resend_command()
        self.assertIn("HUMAN_COMMAND_EXECUTED", message)
        self.assertEqual(page.calls, [("click", 7)])
        self.assertEqual(agent._human_command_action_count, 1)
        self.assertEqual(agent._pending_human_command, "")

    def test_resend_waits_on_observed_countdown_then_clicks(self):
        page = self.FakePageAgent(disabled=True)
        agent = self._agent(page)
        message = agent._execute_human_resend_command()
        self.assertIn("HUMAN_COMMAND_EXECUTED", message)
        self.assertEqual(page.calls, [("wait", 4), ("click", 7)])
        self.assertEqual(agent._human_command_action_count, 2)
        self.assertEqual(agent._pending_human_command, "")

class EvidenceRedactionRegressionTests(unittest.TestCase):
    def test_page_agent_input_payload_is_redacted_in_action_log(self):
        from engine.evidence_store import EvidenceStore
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            store = EvidenceStore(run_id="redaction-test", base_dir=td,
                                  evidence_rules={"redact_fields": []})
            entry = store.record_action(
                "input_text",
                {"index": 7, "text": "MyRealPassword123!"},
                observation="typed password successfully",
            )
            self.assertEqual(entry["arguments"]["index"], 7)
            self.assertEqual(entry["arguments"]["text"], "***REDACTED***")
            self.assertNotIn("MyRealPassword123!", json.dumps(entry, ensure_ascii=False))

    def test_batch_input_payload_is_redacted(self):
        from engine.evidence_store import EvidenceStore
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            store = EvidenceStore(run_id="redaction-batch-test", base_dir=td,
                                  evidence_rules={"redact_fields": []})
            entry = store.record_action(
                "input_text_batch",
                {"fields": [
                    {"index": 1, "text": "secret-one"},
                    {"index": 2, "text": "secret-two"},
                ]},
            )
            self.assertEqual(
                entry["arguments"]["fields"],
                [
                    {"index": 1, "text": "***REDACTED***"},
                    {"index": 2, "text": "***REDACTED***"},
                ],
            )

    def test_javascript_payload_is_omitted(self):
        from engine.evidence_store import EvidenceStore
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            store = EvidenceStore(run_id="redaction-js-test", base_dir=td,
                                  evidence_rules={"redact_fields": []})
            entry = store.record_action(
                "browser_run_code_unsafe",
                {"code": "fetch('/x', {headers: {Authorization: 'Bearer SECRET'}})"},
            )
            self.assertEqual(entry["arguments"]["code"], "***REDACTED_SCRIPT***")
            self.assertNotIn("SECRET", json.dumps(entry, ensure_ascii=False))

class AutomaticRejectedChallengeRecoveryTests(unittest.TestCase):
    class FakeChallengePageAgent:
        def __init__(self):
            self.enabled = False
            self.calls = []
            self.cleared = False

        def state(self):
            status = {
                "disabled": not self.enabled,
                "actionable": self.enabled,
                "countdown": "1:14" if not self.enabled else "",
            }
            return {
                "url": "https://app.example.test/verify",
                "content": "کد تایید نامعتبر است",
                "elements": [
                    {
                        "index": 21,
                        "role": "textbox",
                        "name": "verification code",
                        "context": ["verification"],
                        "status": {"invalid": True, "validationMessage": "invalid code"},
                    },
                    {
                        "index": 22,
                        "role": "button",
                        "name": "ارسال مجدد",
                        "context": ["verification"],
                        "status": status,
                    },
                ],
                "pageInfo": {
                    "timers": [{"text": "ارسال مجدد تا 1:14"}] if not self.enabled else []
                },
            }

        def wait(self, seconds):
            self.calls.append(("wait", seconds))
            self.enabled = True
            return type("R", (), {"text": "waited"})()

        def click(self, index):
            self.calls.append(("click", index))
            return type("R", (), {"text": "resent"})()

        def find_input_group_by_length(self, length):
            self.calls.append(("find_group", length))
            return type("R", (), {"text": json.dumps({"indices": [31, 32, 33, 34, 35], "length": length})})()

        def input_batch(self, items):
            self.calls.append(("clear", items))
            self.cleared = True
            return type("R", (), {"text": "cleared"})()

        @staticmethod
        def _decode_mcp_json(text, default=None):
            return json.loads(text)

    def _agent(self, page_agent):
        from engine.agent import QAReActAgent
        from engine.evidence_store import EvidenceStore
        from engine.policy_engine import PolicyEngine
        import tempfile
        agent = object.__new__(QAReActAgent)
        agent.browser = type("B", (), {"page_agent": page_agent})()
        td = tempfile.mkdtemp()
        agent.store = EvidenceStore(run_id="auto-recovery-test", base_dir=td, evidence_rules={"redact_fields": []})
        agent.policy = PolicyEngine()
        agent._recent_page_agent_state = ""
        agent._page_agent_url = ""
        agent._runtime_recovery_action_count = 0
        agent._active_runtime_challenge = {
            "input_type": "otp",
            "ephemeral": True,
            "indices": [1, 2, 3, 4, 5],
            "length": 5,
            "submitted": False,
            "awaiting_new_value": False,
        }
        return agent

    def test_429_action_result_alone_does_not_trigger_recovery(self):
        from engine.agent import QAReActAgent
        agent = object.__new__(QAReActAgent)
        self.assertFalse(
            agent._looks_like_challenge_rejection(
                {"content": "OTP verification page", "elements": []},
                observation="TOOL ERROR: HTTP 429",
            )[0]
        )

    def test_remaining_challenge_surface_triggers_recovery_without_error_text(self):
        page = self.FakeChallengePageAgent()
        # Simulate a SPA where neither DOM nor tool text exposes an explicit
        # error. The challenge group is still live and resend is observed.
        state = page.state()
        state["content"] = "OTP verification"
        for element in state["elements"]:
            element["context"] = ["verification"]
        # Make the currently observed challenge group discoverable by length.
        original = page.find_input_group_by_length
        def group(length):
            if length != 5:
                return type("R", (), {"text": json.dumps({"indices": []})})()
            return original(length)
        page.find_input_group_by_length = group
        agent = self._agent(page)
        state, obs = agent._auto_recover_rejected_challenge(
            "click_element_by_index", state, "Clicked verify"
        )
        self.assertIn("RUNTIME RECOVERY EXECUTED", obs)
        self.assertIn(("click", 22), page.calls)
        self.assertTrue(agent._active_runtime_challenge["awaiting_new_value"])

    def test_rejected_otp_waits_resends_clears_before_new_prompt(self):
        page = self.FakeChallengePageAgent()
        agent = self._agent(page)
        state = page.state()
        state, obs = agent._auto_recover_rejected_challenge(
            "click_element_by_index", state, "OTP submit result: error"
        )
        self.assertIn("RUNTIME RECOVERY EXECUTED", obs)
        self.assertIn(("wait", 60), page.calls)
        self.assertIn(("click", 22), page.calls)
        self.assertTrue(page.cleared)
        self.assertTrue(agent._active_runtime_challenge["awaiting_new_value"])
        self.assertFalse(agent._active_runtime_challenge["submitted"])
        self.assertEqual(agent._runtime_recovery_action_count, 3)

class ChallengeLifecycleInferenceTests(unittest.TestCase):
    def test_otp_question_without_explicit_input_type_is_ephemeral(self):
        from engine.agent import QAReActAgent
        agent = object.__new__(QAReActAgent)
        lifecycle = agent._resolve_human_input_lifecycle(
            arguments={"question": "Please enter the OTP sent by SMS", "save_to": "otp_value"},
            checkpoint={},
            input_type="OTHER_REQUIRED_EXTERNAL_INPUT",
        )
        self.assertEqual(lifecycle, "ephemeral")

    def test_otp_save_key_is_ephemeral(self):
        from engine.agent import QAReActAgent
        agent = object.__new__(QAReActAgent)
        lifecycle = agent._resolve_human_input_lifecycle(
            arguments={"question": "enter the code", "save_to": "otp_value"},
            checkpoint={},
            input_type="OTHER_REQUIRED_EXTERNAL_INPUT",
        )
        self.assertEqual(lifecycle, "ephemeral")

class FileUploadAndPerformanceRegressionTests(unittest.TestCase):
    def test_upload_tool_is_documented_as_hybrid_browser_capability(self):
        from engine.agent import QAReActAgent, PAGE_AGENT_TOOLS, RESPONSE_PROTOCOL
        self.assertIn("upload_file", PAGE_AGENT_TOOLS)
        self.assertIn("upload_file", RESPONSE_PROTOCOL)
        self.assertIn("select_dropdown_option", RESPONSE_PROTOCOL)
        self.assertIn("input_text_batch", RESPONSE_PROTOCOL)

    def test_page_agent_controller_install_is_cached_and_resettable(self):
        from engine.mcp_client import PageAgentController

        class FakeBrowser:
            def __init__(self):
                self.calls = []

            def _execute_tool(self, name, arguments, timeout=None):
                self.calls.append((name, arguments.get("function", ""), timeout))
                fn = arguments.get("function", "")
                if "getState" in fn:
                    return type("R", (), {
                        "text": '{"url":"https://app.example.test","elements":[],"content":"","pageInfo":{},"scrollables":[]}',
                        "is_snapshot": False,
                        "images": [],
                    })()
                return type("R", (), {"text": "", "is_snapshot": False, "images": []})()

        browser = FakeBrowser()
        controller = PageAgentController(browser)
        controller.state()
        calls_after_first = len(browser.calls)
        controller.state()
        self.assertEqual(len(browser.calls), calls_after_first + 1)
        controller.mark_page_changed()
        controller.state()
        self.assertEqual(len(browser.calls), calls_after_first + 3)

    def test_upload_file_route_uses_official_playwright_upload_tool(self):
        from engine.agent import QAReActAgent
        from engine.evidence_store import EvidenceStore
        from engine.policy_engine import PolicyEngine

        class FakePageAgent:
            def state(self):
                return {"url": "https://app.example.test/form", "content": "", "elements": []}

        class FakeBrowser:
            def __init__(self):
                self.page_agent = FakePageAgent()
                self.upload_calls = []
                self.tools = {"browser_file_upload": {}}

            def call_tool(self, name, arguments):
                self.upload_calls.append((name, arguments))
                return type("R", (), {"text": "uploaded", "is_snapshot": False, "images": []})()

        class FakeAI:
            def __init__(self):
                self.i = 0

            def chat_json(self, _messages):
                self.i += 1
                if self.i == 1:
                    return {"thought": "upload the observed file", "tool": "upload_file", "arguments": {"path": __file__}}
                return {"tool": "finish", "arguments": {"verdict": "INCONCLUSIVE", "actual": "upload smoke"}}

        import tempfile
        td = tempfile.mkdtemp()
        browser = FakeBrowser()
        policy = PolicyEngine()
        policy.max_actions = 5
        store = EvidenceStore(run_id="upload-route-test", base_dir=td, evidence_rules={"redact_fields": []})
        agent = QAReActAgent(browser=browser, ai=FakeAI(), policy=policy, evidence=store)
        outcome = agent.run_goal("Upload the provided test file", requirement_id="UPLOAD")
        self.assertEqual(browser.upload_calls[0][0], "browser_file_upload")
        self.assertEqual(browser.upload_calls[0][1]["paths"], [__file__])
        self.assertEqual(outcome.actions_count, 1)

class NetworkResponseCorrelationTests(unittest.TestCase):
    def test_429_alone_is_not_rate_limit_evidence(self):
        agent = object.__new__(QAReActAgent)
        self.assertEqual(
            agent._looks_like_challenge_rejection(
                {"content": "OTP verification page", "elements": []},
                observation="Action returned HTTP 429",
                response_evidence={
                    "response_status": 429,
                    "response_body": "business validation failed",
                    "response_headers": "content-type: application/json",
                    "rate_limit_confirmed": False,
                    "challenge_response_rejected": False,
                },
            )[0],
            False,
        )

    def test_429_with_explicit_throttle_response_is_rejected_for_recovery(self):
        agent = object.__new__(QAReActAgent)
        self.assertEqual(
            agent._looks_like_challenge_rejection(
                {"content": "OTP verification page", "elements": []},
                observation="Action failed",
                response_evidence={
                    "response_status": 429,
                    "response_body": '{"message":"Too many requests"}',
                    "response_headers": "retry-after: 30",
                    "rate_limit_confirmed": True,
                    "challenge_response_rejected": False,
                },
            )[0],
            True,
        )

    def test_429_with_challenge_rejection_body_is_not_rate_limit(self):
        agent = object.__new__(QAReActAgent)
        evidence = {
            "response_status": 429,
            "response_body": '{"message":"invalid OTP code"}',
            "response_headers": "content-type: application/json",
        }
        self.assertFalse(agent._response_contains_rate_limit(
            evidence["response_body"], evidence["response_headers"]
        ))
        self.assertTrue(agent._response_contains_challenge_rejection(
            evidence["response_body"], evidence["response_headers"]
        ))

    def test_parse_network_request_list(self):
        parsed = QAReActAgent._parse_network_request_list(
            "1. [GET] https://app.test/api/me => [200] OK\n"
            "2. [POST] https://app.test/api/verify => [429] Too Many Requests\n"
        )
        self.assertEqual(len(parsed), 2)
        self.assertEqual(parsed[1]["status"], 429)
        self.assertEqual(parsed[1]["url"], "https://app.test/api/verify")


    def test_network_summary_cannot_create_false_challenge_rejection(self):
        agent = object.__new__(QAReActAgent)
        result = agent._looks_like_challenge_rejection(
            {"content": "OTP verification", "elements": []},
            observation=(
                "=== CORRELATED NETWORK RESPONSE ===\n"
                "RESPONSE #4: classification=http_429_unclassified \n"
                "response_body={\"message\":\"business validation failed\"}"
            ),
            response_evidence={
                "response_status": 429,
                "rate_limit_confirmed": False,
                "challenge_response_rejected": False,
            },
        )
        self.assertFalse(result[0])

    def test_format_response_hides_sensitive_body_patterns(self):
        text = QAReActAgent._format_action_response_evidence({
            "new_request_count": 1,
            "failed_request_count": 1,
            "requests": [{
                "index": 3, "method": "POST", "url": "https://app.test/api/verify",
                "status": 422, "status_text": "Unprocessable Entity"
            }],
            "failed_details": [{
                "index": 3,
                "classification": "challenge_rejected",
                "rate_limit_confirmed": False,
                "challenge_response_rejected": True,
                "response_headers": "content-type: application/json",
                "response_body": "otp: 12345 token=secret-token",
            }],
        })
        self.assertIn("classification=challenge_rejected", text)
        self.assertIn("***REDACTED***", text)

class ActionNetworkCorrelationRuntimeTests(unittest.TestCase):
    class FakeBrowser:
        def __init__(self):
            self.tools = {"browser_network_requests": {}, "browser_network_request": {}}

        def call_tool(self, name, args=None, timeout=None):
            class R:
                def __init__(self, text):
                    self.text = text
                    self.images = []
            args = args or {}
            if name == "browser_network_requests":
                return R(
                    "1. [GET] https://app.test/api/background => [200] OK\n"
                    "2. [POST] https://app.test/api/other => [429] OK\n"
                )
            if name == "browser_network_request":
                if args.get("part") == "response-headers":
                    return R("content-type: application/json\n")
                if args.get("part") == "response-body":
                    return R('{"message":"business rule blocked"}')
                return R("#2 [POST] https://app.test/api/other\nstatus: [429] OK")
            raise AssertionError(name)

    def test_action_network_probe_classifies_unrelated_429_as_unclassified(self):
        agent = object.__new__(QAReActAgent)
        agent.browser = self.FakeBrowser()
        agent._network_seen_max = 1
        agent._network_seen_page_url = "https://app.test/form"
        agent._page_agent_url = "https://app.test/form"
        evidence = agent._collect_action_network_evidence(
            "click_element_by_index", {"index": 12}, action_index=7
        )
        self.assertEqual(evidence["failed_details"][0]["classification"], "http_429_unclassified")
        self.assertFalse(evidence["failed_details"][0]["rate_limit_confirmed"])
        self.assertFalse(evidence["failed_details"][0]["challenge_response_rejected"])

    def test_action_network_probe_requires_explicit_rate_limit_response(self):
        class RateLimitedBrowser(ActionNetworkCorrelationRuntimeTests.FakeBrowser):
            def call_tool(self, name, args=None, timeout=None):
                class R:
                    def __init__(self, text):
                        self.text = text
                        self.images = []
                args = args or {}
                if name == "browser_network_requests":
                    return R("2. [POST] https://app.test/api/verify => [429] Too Many Requests\n")
                if name == "browser_network_request" and args.get("part") == "response-headers":
                    return R("retry-after: 30\nx-ratelimit-remaining: 0\n")
                if name == "browser_network_request" and args.get("part") == "response-body":
                    return R('{"message":"too many requests"}')
                return R("#2 [POST] https://app.test/api/verify\nstatus: [429] Too Many Requests")

        agent = object.__new__(QAReActAgent)
        agent.browser = RateLimitedBrowser()
        agent._network_seen_max = 1
        agent._network_seen_page_url = "https://app.test/form"
        agent._page_agent_url = "https://app.test/form"
        evidence = agent._collect_action_network_evidence(
            "click_element_by_index", {"index": 12}, action_index=8
        )
        self.assertEqual(evidence["failed_details"][0]["classification"], "confirmed_rate_limit")
        self.assertTrue(evidence["failed_details"][0]["rate_limit_confirmed"])


class FastRuntimeAndClipboardTests(unittest.TestCase):
    def test_pending_business_state_is_not_modelled_as_busy(self):
        from pathlib import Path
        controller = (Path(__file__).parents[1] / "engine" / "page_agent_controller.js").read_text(encoding="utf-8")
        self.assertNotIn("busy", controller.lower())
        self.assertNotIn("loading", controller.lower())

    def test_fast_mode_does_not_treat_countdown_as_otp_input_lock(self):
        from pathlib import Path
        controller = (Path(__file__).parents[1] / "engine" / "page_agent_controller.js").read_text(encoding="utf-8")
        self.assertIn("A countdown near a resend control is a resend cooldown", controller)
        self.assertIn("if (!resendSemantic && role(el) !== \"timer\") return \"\";", controller)

    def test_fast_system_prompt_has_immediate_otp_rule(self):
        agent = object.__new__(QAReActAgent)
        agent._system_prompt = None
        agent.mission_type = "exploratory"
        agent.mode = "explore"
        agent.policy = PolicyEngine()
        agent.skills = type("S", (), {"select": lambda *_a, **_k: [], "compose_prompt": lambda *_a, **_k: ""})()
        agent._last_snapshot_text = lambda: ""
        agent._tools_catalog = QAReActAgent._tools_catalog.__get__(agent)
        prompt = QAReActAgent.system_prompt(agent)
        self.assertIn("resend countdown NEVER proves the OTP inputs are disabled", prompt)

    def test_clipboard_follow_is_trusted_external_navigation(self):
        class FakeBrowser:
            def __init__(self):
                self.tools = {"browser_evaluate": {}, "browser_tabs": {}}
                self.calls = []
                self.page_agent = type("PA", (), {
                    "state": lambda self: {"url": "https://app.example.test", "content": "", "elements": []},
                    "mark_page_changed": lambda self: None,
                })()
            def call_tool(self, name, arguments):
                self.calls.append((name, arguments))
                if name == "browser_evaluate":
                    return type("R", (), {"text": "https://sign.example.test/#/portal?token=opaque", "images": []})()
                if name == "browser_tabs":
                    return type("R", (), {"text": "0: app\n1: sign", "images": []})()
                raise AssertionError(name)

        rules = tempfile.mkdtemp()
        with open(os.path.join(rules, "safety.yaml"), "w", encoding="utf-8") as f:
            f.write("allow_requested_domain: true\nallowed_domains: []\ndestructive_actions: {patterns: []}\n")
        with open(os.path.join(rules, "execution.yaml"), "w", encoding="utf-8") as f:
            f.write("execution: {max_actions: 20, mission_timeout_seconds: 60}\nloop_detection: {enabled: true}\n")
        with open(os.path.join(rules, "validation.yaml"), "w", encoding="utf-8") as f:
            f.write("{}\n")
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        policy.max_actions = 20
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://app.example.test/start"
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        note = agent._open_application_clipboard_link()
        self.assertTrue(note.startswith("CLIPBOARD_LINK_OPENED"))
        self.assertEqual(browser.calls[-1][0], "browser_tabs")
        self.assertEqual(browser.calls[-1][1]["action"], "new")
        self.assertEqual(agent._last_navigation_evidence["provenance"], "clipboard_from_application")


class ClipboardDomFallbackRegressionTests(unittest.TestCase):
    """Regression: on HTTP sites the clipboard API is blocked; the runtime
    must fall back to scanning the live DOM for the application-copied URL
    instead of failing silently and letting the agent wander back to the
    contracts list."""

    def _rules(self):
        rules = tempfile.mkdtemp()
        with open(os.path.join(rules, "safety.yaml"), "w", encoding="utf-8") as f:
            f.write("allow_requested_domain: true\nallowed_domains: []\ndestructive_actions: {patterns: []}\n")
        with open(os.path.join(rules, "execution.yaml"), "w", encoding="utf-8") as f:
            f.write("execution: {max_actions: 20, mission_timeout_seconds: 60}\nloop_detection: {enabled: true}\n")
        with open(os.path.join(rules, "validation.yaml"), "w", encoding="utf-8") as f:
            f.write("{}\n")
        return rules

    def test_extract_url_from_text_handles_bare_url(self):
        self.assertEqual(
            QAReActAgent._extract_url_from_text("https://app.example.test/x"),
            "https://app.example.test/x",
        )

    def test_extract_url_from_text_handles_quoted_url(self):
        self.assertEqual(
            QAReActAgent._extract_url_from_text('"https://app.example.test/y"'),
            "https://app.example.test/y",
        )

    def test_extract_url_from_text_handles_embedded_url(self):
        self.assertEqual(
            QAReActAgent._extract_url_from_text("link: https://app.example.test/z please open"),
            "https://app.example.test/z",
        )

    def test_extract_url_returns_empty_for_non_url(self):
        self.assertEqual(QAReActAgent._extract_url_from_text("not a url"), "")
        self.assertEqual(QAReActAgent._extract_url_from_text(""), "")

    def test_open_application_link_falls_back_to_dom_when_clipboard_empty(self):
        """When the clipboard is empty/unreadable (HTTP site), the runtime
        must scan the live DOM and still open the application-copied URL."""
        import json as _json

        class FakeBrowser:
            def __init__(self):
                self.tools = {"browser_evaluate": {}, "browser_tabs": {}}
                self.calls = []
                self.page_agent = type("PA", (), {
                    "state": lambda self: {"url": "https://app.example.test", "content": "", "elements": []},
                    "mark_page_changed": lambda self: None,
                })()

            def call_tool(self, name, arguments):
                self.calls.append((name, arguments))
                if name == "browser_evaluate":
                    # First call: clipboard read returns empty (HTTP site).
                    # Second call: DOM probe returns a JSON array of URLs.
                    call_count = sum(1 for c in self.calls if c[0] == "browser_evaluate")
                    if call_count == 1:
                        return type("R", (), {"text": "", "images": []})()
                    # DOM probe: returns a JSON array of candidate URLs.
                    return type("R", (), {
                        "text": _json.dumps(["https://sign.example.test/portal?token=abc", "/relative", "not a url"]),
                        "images": [],
                    })()
                if name == "browser_tabs":
                    return type("R", (), {"text": "0: app\n1: sign", "images": []})()
                raise AssertionError(name)

        rules = self._rules()
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        policy.max_actions = 20
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://app.example.test/start"
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        note = agent._open_application_clipboard_link()
        self.assertTrue(note.startswith("CLIPBOARD_LINK_OPENED"))
        self.assertEqual(agent._last_navigation_evidence["provenance"], "application_generated")
        # The new tab must have been opened with the DOM-discovered URL.
        tab_calls = [c for c in browser.calls if c[0] == "browser_tabs"]
        self.assertTrue(tab_calls)
        self.assertEqual(tab_calls[-1][1]["action"], "new")
        self.assertEqual(tab_calls[-1][1]["url"], "https://sign.example.test/portal?token=abc")

    def test_open_application_link_raises_when_both_clipboard_and_dom_fail(self):
        class FakeBrowser:
            def __init__(self):
                self.tools = {"browser_evaluate": {}, "browser_tabs": {}}
                self.calls = []
                self.page_agent = type("PA", (), {
                    "state": lambda self: {"url": "https://app.example.test", "content": "", "elements": []},
                    "mark_page_changed": lambda self: None,
                })()

            def call_tool(self, name, arguments):
                self.calls.append((name, arguments))
                if name == "browser_evaluate":
                    # Both clipboard and DOM probe return empty.
                    return type("R", (), {"text": "", "images": []})()
                raise AssertionError(name)

        rules = self._rules()
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        policy.max_actions = 20
        from engine.mcp_client import MCPError
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://app.example.test/start"
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        with self.assertRaises(MCPError):
            agent._open_application_clipboard_link()

    def test_open_application_link_invalidates_page_agent_after_new_tab(self):
        """After opening a new tab, mark_page_changed() must be called so the
        next state() call installs the controller on the NEW tab."""
        class FakePageAgent:
            def __init__(self):
                self.mark_changed_calls = 0
                self.state_calls = 0

            def state(self):
                self.state_calls += 1
                return {"url": "https://sign.example.test", "content": "", "elements": []}

            def mark_page_changed(self):
                self.mark_changed_calls += 1

        class FakeBrowser:
            def __init__(self):
                self.tools = {"browser_evaluate": {}, "browser_tabs": {}}
                self.calls = []
                self.page_agent = FakePageAgent()

            def call_tool(self, name, arguments):
                self.calls.append((name, arguments))
                if name == "browser_evaluate":
                    return type("R", (), {"text": "https://sign.example.test/x", "images": []})()
                if name == "browser_tabs":
                    return type("R", (), {"text": "0: app\n1: sign", "images": []})()
                raise AssertionError(name)

        rules = self._rules()
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        policy.max_actions = 20
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://app.example.test/start"
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        note = agent._open_application_clipboard_link()
        self.assertTrue(note.startswith("CLIPBOARD_LINK_OPENED"))
        self.assertGreaterEqual(browser.page_agent.mark_changed_calls, 1)

    def test_open_application_link_observation_tells_llm_to_stay_on_new_tab(self):
        class FakeBrowser:
            def __init__(self):
                self.tools = {"browser_evaluate": {}, "browser_tabs": {}}
                self.calls = []
                self.page_agent = type("PA", (), {
                    "state": lambda self: {"url": "https://sign.example.test", "content": "", "elements": []},
                    "mark_page_changed": lambda self: None,
                })()

            def call_tool(self, name, arguments):
                self.calls.append((name, arguments))
                if name == "browser_evaluate":
                    return type("R", (), {"text": "https://sign.example.test/x", "images": []})()
                if name == "browser_tabs":
                    return type("R", (), {"text": "0: app\n1: sign", "images": []})()
                raise AssertionError(name)

        rules = self._rules()
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        policy.max_actions = 20
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://app.example.test/start"
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        note = agent._open_application_clipboard_link()
        # The observation must clearly tell the LLM that the current tab is the
        # NEW tab and that it must NOT go back to the previous tab or call
        # read_clipboard again.
        self.assertIn("NEW tab", note)
        self.assertIn("do not call read_clipboard", note.lower())
        self.assertIn("do not go back", note.lower())


class TabAndClipboardPromptRegressionTests(unittest.TestCase):
    """The prompt must clearly tell the LLM how to behave after a tab switch
    or clipboard follow, so the agent does not wander back to the old tab."""

    def test_response_protocol_documents_find_elements_with_query(self):
        from engine.agent import RESPONSE_PROTOCOL
        self.assertIn("find_elements", RESPONSE_PROTOCOL)
        self.assertIn('"query": "semantic text/label/context', RESPONSE_PROTOCOL)

    def test_response_protocol_has_tab_and_clipboard_rules(self):
        from engine.agent import RESPONSE_PROTOCOL
        self.assertIn("TAB & CLIPBOARD", RESPONSE_PROTOCOL)
        self.assertIn("open_application_link", RESPONSE_PROTOCOL)
        self.assertIn("switch_tab", RESPONSE_PROTOCOL)
        self.assertIn("Do NOT call read_clipboard", RESPONSE_PROTOCOL)

    def test_addressing_prompt_documents_tab_and_clipboard_rules(self):
        from engine.agent import ADDRESSING_PROMPT
        self.assertIn("TAB & CLIPBOARD", ADDRESSING_PROMPT)
        self.assertIn("open_application_link", ADDRESSING_PROMPT)

    def test_fast_addressing_documents_tab_behavior(self):
        import inspect
        from engine.agent import QAReActAgent
        source = inspect.getsource(QAReActAgent.system_prompt)
        self.assertIn("After open_application_link the CURRENT tab is the NEW tab", source)


class CopyLinkPrematureFinishGuardTests(unittest.TestCase):
    """v26.28: The agent must NOT finish with INCONCLUSIVE after a copy-link
    click until the copied link has been opened in a new tab. The mission
    explicitly requires opening the link, so finishing without opening it
    is always premature."""

    def _rules(self):
        rules = tempfile.mkdtemp()
        with open(os.path.join(rules, "safety.yaml"), "w", encoding="utf-8") as f:
            f.write("allow_requested_domain: true\nallowed_domains: []\ndestructive_actions: {patterns: []}\n")
        with open(os.path.join(rules, "execution.yaml"), "w", encoding="utf-8") as f:
            f.write("execution: {max_actions: 20, mission_timeout_seconds: 60}\nloop_detection: {enabled: true}\n")
        with open(os.path.join(rules, "validation.yaml"), "w", encoding="utf-8") as f:
            f.write("{}\n")
        return rules

    def test_guard_rejects_finish_after_copy_link_click_when_link_not_opened(self):
        """After a copy-link click, if the link hasn't been opened, the
        guard must reject INCONCLUSIVE finish."""
        agent = QAReActAgent(
            browser=object(), ai=object(),
            policy=PolicyEngine(rules_dir=self._rules()),
            evidence=object(), skill_loader=object(),
        )
        agent._copy_link_click_detected = True
        agent._clipboard_link_opened = False
        agent._premature_finish_rejections = 0
        decision = {"verdict": "INCONCLUSIVE"}
        guard = agent._guard_premature_finish(decision)
        self.assertIn("FINISH_REJECTED", guard)
        self.assertIn("open_application_link", guard)

    def test_guard_allows_finish_after_link_opened(self):
        """After the link has been opened, the guard must NOT reject finish."""
        agent = QAReActAgent(
            browser=object(), ai=object(),
            policy=PolicyEngine(rules_dir=self._rules()),
            evidence=object(), skill_loader=object(),
        )
        agent._copy_link_click_detected = True
        agent._clipboard_link_opened = True
        agent._premature_finish_rejections = 0
        decision = {"verdict": "INCONCLUSIVE"}
        guard = agent._guard_premature_finish(decision)
        self.assertEqual(guard, "")

    def test_guard_allows_finish_when_no_copy_link_click_detected(self):
        """Without a copy-link click, the guard must NOT reject finish."""
        agent = QAReActAgent(
            browser=object(), ai=object(),
            policy=PolicyEngine(rules_dir=self._rules()),
            evidence=object(), skill_loader=object(),
        )
        agent._copy_link_click_detected = False
        agent._clipboard_link_opened = False
        agent._premature_finish_rejections = 0
        decision = {"verdict": "INCONCLUSIVE"}
        guard = agent._guard_premature_finish(decision)
        self.assertEqual(guard, "")

    def test_guard_rejects_blocked_finish_after_copy_link_click(self):
        """The guard must also reject BLOCKED verdict, not just INCONCLUSIVE."""
        agent = QAReActAgent(
            browser=object(), ai=object(),
            policy=PolicyEngine(rules_dir=self._rules()),
            evidence=object(), skill_loader=object(),
        )
        agent._copy_link_click_detected = True
        agent._clipboard_link_opened = False
        agent._premature_finish_rejections = 0
        decision = {"verdict": "BLOCKED"}
        guard = agent._guard_premature_finish(decision)
        self.assertIn("FINISH_REJECTED", guard)

    def test_guard_does_not_reject_pass_verdict(self):
        """PASS verdict must never be rejected by the premature-finish guard."""
        agent = QAReActAgent(
            browser=object(), ai=object(),
            policy=PolicyEngine(rules_dir=self._rules()),
            evidence=object(), skill_loader=object(),
        )
        agent._copy_link_click_detected = True
        agent._clipboard_link_opened = False
        agent._premature_finish_rejections = 0
        decision = {"verdict": "PASS"}
        guard = agent._guard_premature_finish(decision)
        self.assertEqual(guard, "")

    def test_open_application_link_sets_clipboard_link_opened_flag(self):
        """When _open_application_clipboard_link succeeds, it must set
        _clipboard_link_opened = True so the guard stops blocking finish."""
        import json as _json
        class FakePageAgent:
            def state(self):
                return {"url": "https://sign.example.test/portal", "content": "new page", "elements": []}
            def mark_page_changed(self): pass
        class FakeBrowser:
            tools = {"browser_evaluate": {}, "browser_tabs": {}}
            page_agent = FakePageAgent()
            def call_tool(self, name, args):
                if name == "browser_evaluate":
                    return type("R", (), {"text": "https://sign.example.test/#/portal?token=abc", "images": []})()
                if name == "browser_tabs":
                    return type("R", (), {"text": "0: app\n1: sign", "images": []})()
                raise AssertionError(name)
        rules = self._rules()
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        policy.set_mission_url("https://sandbox.pki.partdp.ir/dashboard")
        policy.max_actions = 20
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://sandbox.pki.partdp.ir/dashboard"
        agent._recent_page_agent_state = "no url in state"
        agent._copy_link_click_detected = True
        agent._clipboard_link_opened = False
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        note = agent._open_application_clipboard_link()
        self.assertTrue(note.startswith("CLIPBOARD_LINK_OPENED"))
        self.assertTrue(agent._clipboard_link_opened)


class MultiStrategyUrlResolutionRegressionTests(unittest.TestCase):
    """v26.24: URL resolution must use page-agent state text + aggressive DOM
    scan + network evidence, not just the clipboard. This is what makes
    open_application_link work on HTTP sites."""

    def _rules(self):
        rules = tempfile.mkdtemp()
        with open(os.path.join(rules, "safety.yaml"), "w", encoding="utf-8") as f:
            f.write("allow_requested_domain: true\nallowed_domains: []\ndestructive_actions: {patterns: []}\n")
        with open(os.path.join(rules, "execution.yaml"), "w", encoding="utf-8") as f:
            f.write("execution: {max_actions: 20, mission_timeout_seconds: 60}\nloop_detection: {enabled: true}\n")
        with open(os.path.join(rules, "validation.yaml"), "w", encoding="utf-8") as f:
            f.write("{}\n")
        return rules

    def test_extract_all_urls_ranks_mission_host_with_query_first(self):
        urls = QAReActAgent._extract_all_urls_from_text(
            "visit https://cdn.example.test/lib.js and "
            "https://app.example.test/contract/share?token=abc "
            "or https://app.example.test/about",
            mission_host="app.example.test",
        )
        self.assertTrue(urls)
        # The mission-host URL with a query parameter should rank first.
        self.assertEqual(urls[0], "https://app.example.test/contract/share?token=abc")

    def test_extract_all_urls_returns_empty_for_no_urls(self):
        self.assertEqual(QAReActAgent._extract_all_urls_from_text("no urls here"), [])
        self.assertEqual(QAReActAgent._extract_all_urls_from_text(""), [])

    def test_extract_url_from_page_agent_state_finds_url(self):
        class FakePageAgent:
            def state(self):
                return {"url": "https://app.example.test", "content": "Page URL: https://app.example.test\n[5] textbox 'لینک' 'https://sign.example.test/portal?token=xyz' readonly", "elements": []}
            def mark_page_changed(self): pass
        class FakeBrowser:
            tools = {"browser_evaluate": {}, "browser_tabs": {}}
            page_agent = FakePageAgent()
            def call_tool(self, name, args):
                if name == "browser_tabs":
                    return type("R", (), {"text": "0: app", "images": []})()
                raise AssertionError(name)
        rules = self._rules()
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://app.example.test/start"
        agent._recent_page_agent_state = FakePageAgent().state()["content"]
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        note = agent._open_application_clipboard_link()
        self.assertTrue(note.startswith("CLIPBOARD_LINK_OPENED"))
        self.assertEqual(agent._last_navigation_evidence["source"], "page_agent_state")

    def test_dom_scan_uses_body_inner_text(self):
        """The aggressive DOM scan must check document.body.innerText, not
        just leaf text nodes. This catches URLs embedded in dialog text."""
        import json as _json
        class FakePageAgent:
            def state(self):
                return {"url": "https://app.example.test", "content": "no url here", "elements": []}
            def mark_page_changed(self): pass
        class FakeBrowser:
            tools = {"browser_evaluate": {}, "browser_tabs": {}}
            page_agent = FakePageAgent()
            def call_tool(self, name, args):
                if name == "browser_evaluate":
                    # Count browser_evaluate calls to differentiate clipboard vs DOM scan.
                    call_count = sum(1 for c in self.calls if c[0] == "browser_evaluate") if hasattr(self, "calls") else 0
                    if not hasattr(self, "calls"):
                        self.calls = []
                    self.calls.append((name, args))
                    call_count = len(self.calls)
                    if call_count == 1:
                        # First call: clipboard read returns empty (HTTP site).
                        return type("R", (), {"text": "", "images": []})()
                    # Second call: DOM scan returns body text with the share link.
                    return type("R", (), {
                        "text": _json.dumps([
                            "لینک قرارداد: https://sign.example.test/portal?token=abc123 کپی شد",
                            "https://app.example.test/dashboard",
                        ]),
                        "images": [],
                    })()
                if name == "browser_tabs":
                    return type("R", (), {"text": "0: app\n1: sign", "images": []})()
                raise AssertionError(name)
        rules = self._rules()
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://app.example.test/start"
        agent._recent_page_agent_state = "no url in state"
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        note = agent._open_application_clipboard_link()
        self.assertTrue(note.startswith("CLIPBOARD_LINK_OPENED"))
        self.assertEqual(agent._last_navigation_evidence["source"], "application_dom")

    def test_resolver_returns_candidates_in_error_when_all_fail(self):
        """When all strategies fail, the error must include candidate URLs
        from the page-agent state so the LLM can use open_new_tab."""
        from engine.mcp_client import MCPError
        class FakePageAgent:
            def state(self):
                return {"url": "https://app.example.test", "content": "see https://app.example.test/contract/123", "elements": []}
            def mark_page_changed(self): pass
        class FakeBrowser:
            tools = {"browser_evaluate": {}, "browser_tabs": {}}
            page_agent = FakePageAgent()
            def call_tool(self, name, args):
                if name == "browser_evaluate":
                    return type("R", (), {"text": "", "images": []})()
                raise AssertionError(name)
        rules = self._rules()
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://app.example.test/start"
        agent._recent_page_agent_state = "see https://app.example.test/contract/123"
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        # The state text contains a URL, so strategy 1 should actually succeed
        # here. Let's test the real all-fail case instead:
        agent._recent_page_agent_state = "no urls at all"
        with self.assertRaises(MCPError) as ctx:
            agent._open_application_clipboard_link()
        # When there are truly no candidates, the error should still be clear.
        self.assertIn("could not resolve", str(ctx.exception).lower())

    def test_network_evidence_url_extraction(self):
        """When the link is only in the network response (not in the DOM),
        the resolver must find it in _last_action_response_evidence."""
        import json as _json
        class FakePageAgent:
            def state(self):
                return {"url": "https://app.example.test", "content": "no url in DOM", "elements": []}
            def mark_page_changed(self): pass
        class FakeBrowser:
            tools = {"browser_evaluate": {}, "browser_tabs": {}}
            page_agent = FakePageAgent()
            def call_tool(self, name, args):
                if name == "browser_evaluate":
                    # Clipboard returns empty, DOM scan returns empty.
                    return type("R", (), {"text": _json.dumps(["no urls here"]), "images": []})()
                if name == "browser_tabs":
                    return type("R", (), {"text": "0: app\n1: sign", "images": []})()
                raise AssertionError(name)
        rules = self._rules()
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://app.example.test/start"
        agent._recent_page_agent_state = "no url in state"
        agent._last_action_response_evidence = {
            "requests": [{"url": "https://app.example.test/api/contract/123", "method": "POST", "status": 200}],
            "selected_response": {
                "url": "https://app.example.test/api/contract/123",
                "response_body": '{"shareLink":"https://sign.example.test/portal?token=xyz789"}',
            },
        }
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        note = agent._open_application_clipboard_link()
        self.assertTrue(note.startswith("CLIPBOARD_LINK_OPENED"))
        self.assertEqual(agent._last_navigation_evidence["source"], "network_response")


class ExternalHostShareLinkRegressionTests(unittest.TestCase):
    """v26.26: Share links are often on a DIFFERENT host from the mission
    (e.g. mission=sandbox.pki.partdp.ir, share=sign-sandbox.farashenasa.ir).
    The resolver must:
      1. Try the clipboard FIRST (most reliable after a copy click).
      2. Rank URLs with 'token' in them ABOVE same-host navigation links.
    Otherwise the resolver picks a same-host nav URL from the state text
    and never even tries the clipboard."""

    def _rules(self):
        rules = tempfile.mkdtemp()
        with open(os.path.join(rules, "safety.yaml"), "w", encoding="utf-8") as f:
            f.write("allow_requested_domain: true\nallowed_domains: []\ndestructive_actions: {patterns: []}\n")
        with open(os.path.join(rules, "execution.yaml"), "w", encoding="utf-8") as f:
            f.write("execution: {max_actions: 20, mission_timeout_seconds: 60}\nloop_detection: {enabled: true}\n")
        with open(os.path.join(rules, "validation.yaml"), "w", encoding="utf-8") as f:
            f.write("{}\n")
        return rules

    def test_token_url_ranks_above_same_host_nav_url(self):
        """A share link with 'token' in the URL must rank above a same-host
        navigation URL, even when the share link is on a different host."""
        urls = QAReActAgent._extract_all_urls_from_text(
            "Page URL: https://sandbox.pki.partdp.ir/dashboard\n"
            "[1] link 'اسناد' 'https://sandbox.pki.partdp.ir/contracts'\n"
            "[5] textbox 'لینک' 'https://sign-sandbox.farashenasa.ir/#/portal?token=iHllMCrH3QRK822T3nRIpg' readonly",
            mission_host="sandbox.pki.partdp.ir",
        )
        self.assertTrue(urls)
        # The share link with 'token' must be first, not the same-host nav links.
        self.assertEqual(urls[0], "https://sign-sandbox.farashenasa.ir/#/portal?token=iHllMCrH3QRK822T3nRIpg")

    def test_resolver_tries_clipboard_before_state_text(self):
        """The resolver must try the clipboard FIRST. If the clipboard has
        a valid URL, the state text (which may contain same-host nav URLs)
        must NOT be consulted."""
        class FakePageAgent:
            def state(self):
                # The state text contains same-host nav URLs that would be
                # picked if strategy 1 (state text) ran first.
                return {"url": "https://sandbox.pki.partdp.ir/dashboard", "content": "Page URL: https://sandbox.pki.partdp.ir/dashboard\n[1] link 'https://sandbox.pki.partdp.ir/contracts'", "elements": []}
            def mark_page_changed(self): pass
        class FakeBrowser:
            tools = {"browser_evaluate": {}, "browser_tabs": {}}
            page_agent = FakePageAgent()
            def call_tool(self, name, args):
                if name == "browser_evaluate":
                    # Clipboard returns the external share link.
                    return type("R", (), {"text": "https://sign-sandbox.farashenasa.ir/#/portal?token=iHllMCrH3QRK822T3nRIpg", "images": []})()
                if name == "browser_tabs":
                    return type("R", (), {"text": "0: app\n1: sign", "images": []})()
                raise AssertionError(name)
        rules = self._rules()
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        policy.set_mission_url("https://sandbox.pki.partdp.ir/dashboard")
        policy.max_actions = 20
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://sandbox.pki.partdp.ir/dashboard"
        # Set the state text to contain same-host nav URLs.
        agent._recent_page_agent_state = FakePageAgent().state()["content"]
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        note = agent._open_application_clipboard_link()
        self.assertTrue(note.startswith("CLIPBOARD_LINK_OPENED"))
        # The source must be 'application_clipboard', not 'page_agent_state'.
        self.assertEqual(agent._last_navigation_evidence["source"], "application_clipboard")

    def test_open_application_link_with_farashenasa_share_link(self):
        """End-to-end: the exact share link from the user's real run must
        be opened successfully. Mission host = pki sandbox, share link host
        = sign-sandbox.farashenasa.ir, token in fragment."""
        SHARE_LINK = "https://sign-sandbox.farashenasa.ir/#/portal?token=iHllMCrH3QRK822T3nRIpg"
        class FakePageAgent:
            def state(self):
                return {"url": "https://sandbox.pki.partdp.ir/dashboard", "content": "Page URL: https://sandbox.pki.partdp.ir/dashboard", "elements": []}
            def mark_page_changed(self): pass
        class FakeBrowser:
            tools = {"browser_evaluate": {}, "browser_tabs": {}}
            page_agent = FakePageAgent()
            calls = []
            def call_tool(self, name, args):
                self.calls.append((name, args))
                if name == "browser_evaluate":
                    return type("R", (), {"text": SHARE_LINK, "images": []})()
                if name == "browser_tabs":
                    # Verify the URL passed to browser_tabs is the share link.
                    assert args["url"] == SHARE_LINK, f"Expected share link, got {args['url']}"
                    return type("R", (), {"text": "0: app\n1: sign", "images": []})()
                raise AssertionError(name)
        rules = self._rules()
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        policy.set_mission_url("https://sandbox.pki.partdp.ir/dashboard")
        policy.max_actions = 20
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://sandbox.pki.partdp.ir/dashboard"
        agent._recent_page_agent_state = "Page URL: https://sandbox.pki.partdp.ir/dashboard"
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        note = agent._open_application_clipboard_link()
        self.assertTrue(note.startswith("CLIPBOARD_LINK_OPENED"))
        self.assertEqual(agent._last_navigation_evidence["provenance"], "clipboard_from_application")
        # Verify browser_tabs was called with the share link.
        tab_calls = [c for c in browser.calls if c[0] == "browser_tabs"]
        self.assertTrue(tab_calls)
        self.assertEqual(tab_calls[-1][1]["url"], SHARE_LINK)


class SameHostTrustedProvenanceRegressionTests(unittest.TestCase):
    """v26.25: The policy must approve same-host navigation when the
    provenance is trusted (clipboard_from_application, application_generated).
    Previously, same-host URLs were always rejected as 'guessed routes'
    even when the runtime just read them from the trusted clipboard."""

    def _rules(self, mission_url="https://app.example.test"):
        rules = tempfile.mkdtemp()
        with open(os.path.join(rules, "safety.yaml"), "w", encoding="utf-8") as f:
            f.write("allow_requested_domain: true\nallowed_domains: []\ndestructive_actions: {patterns: []}\n")
        with open(os.path.join(rules, "execution.yaml"), "w", encoding="utf-8") as f:
            f.write("execution: {max_actions: 20, mission_timeout_seconds: 60}\nloop_detection: {enabled: true}\n")
        with open(os.path.join(rules, "validation.yaml"), "w", encoding="utf-8") as f:
            f.write("{}\n")
        return rules

    def test_same_host_clipboard_url_is_approved(self):
        """A clipboard-copied URL on the mission host must be approved."""
        rules = self._rules()
        policy = PolicyEngine(rules_dir=rules)
        policy.set_mission_url("https://app.example.test/dashboard")
        from engine.navigation import build_navigation_evidence
        evidence = build_navigation_evidence(
            "https://app.example.test/contract/share?token=abc",
            source="application_clipboard",
            provenance="clipboard_from_application",
            evidence="trusted clipboard read",
            was_inferred=False,
            initial_url="https://app.example.test/dashboard",
            decision="approved",
        ).as_dict()
        result = policy.check_navigation(
            "https://app.example.test/contract/share?token=abc",
            evidence,
        )
        self.assertTrue(result["ok"], f"Expected approved but got: {result['reason']}")

    def test_same_host_application_generated_url_is_approved(self):
        """An application-generated URL on the mission host must be approved."""
        rules = self._rules()
        policy = PolicyEngine(rules_dir=rules)
        policy.set_mission_url("https://app.example.test/dashboard")
        from engine.navigation import build_navigation_evidence
        evidence = build_navigation_evidence(
            "https://app.example.test/portal/sign?token=xyz",
            source="application_dom",
            provenance="application_generated",
            evidence="URL observed in DOM",
            was_inferred=False,
            initial_url="https://app.example.test/dashboard",
            decision="approved",
        ).as_dict()
        result = policy.check_navigation(
            "https://app.example.test/portal/sign?token=xyz",
            evidence,
        )
        self.assertTrue(result["ok"], f"Expected approved but got: {result['reason']}")

    def test_same_host_untrusted_url_is_still_denied(self):
        """A guessed URL on the mission host with untrusted provenance
        must still be denied — trusted provenance doesn't open the door
        to arbitrary guessed routes."""
        rules = self._rules()
        policy = PolicyEngine(rules_dir=rules)
        policy.set_mission_url("https://app.example.test/dashboard")
        result = policy.check_navigation(
            "https://app.example.test/admin/delete-all",
            {"provenance": "guessed", "was_inferred": True},
        )
        self.assertFalse(result["ok"])

    def test_external_clipboard_url_is_approved(self):
        """An external clipboard-copied URL must still be approved
        (this was already working; the fix must not break it)."""
        rules = self._rules()
        policy = PolicyEngine(rules_dir=rules)
        policy.set_mission_url("https://app.example.test/dashboard")
        from engine.navigation import build_navigation_evidence
        evidence = build_navigation_evidence(
            "https://sign.example.test/portal?token=abc",
            source="application_clipboard",
            provenance="clipboard_from_application",
            evidence="trusted clipboard read",
            was_inferred=False,
            initial_url="https://app.example.test/dashboard",
            decision="approved",
        ).as_dict()
        result = policy.check_navigation(
            "https://sign.example.test/portal?token=abc",
            evidence,
        )
        self.assertTrue(result["ok"])

    def test_open_application_link_approves_same_host_share_link(self):
        """End-to-end: open_application_link must succeed when the share
        link is on the same host as the mission (the most common case
        for SPA share links)."""
        class FakePageAgent:
            def state(self):
                return {"url": "https://app.example.test/dashboard", "content": "Page URL: https://app.example.test/dashboard\n[5] button 'کپی لینک'", "elements": []}
            def mark_page_changed(self): pass
        class FakeBrowser:
            tools = {"browser_evaluate": {}, "browser_tabs": {}}
            page_agent = FakePageAgent()
            def call_tool(self, name, args):
                if name == "browser_evaluate":
                    # Clipboard returns a same-host share link.
                    return type("R", (), {"text": "https://app.example.test/contract/share?token=abc123", "images": []})()
                if name == "browser_tabs":
                    return type("R", (), {"text": "0: app\n1: share", "images": []})()
                raise AssertionError(name)
        rules = self._rules()
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        policy.set_mission_url("https://app.example.test/dashboard")
        policy.max_actions = 20
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://app.example.test/dashboard"
        agent._recent_page_agent_state = "no url in state text"
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        note = agent._open_application_clipboard_link()
        self.assertTrue(note.startswith("CLIPBOARD_LINK_OPENED"))

    def test_read_clipboard_registers_trusted_evidence_for_open_new_tab(self):
        """After read_clipboard returns a URL, open_new_tab with that URL
        must be approved by the policy (auto-attached trusted evidence)."""
        class FakePageAgent:
            def state(self):
                return {"url": "https://app.example.test/dashboard", "content": "", "elements": []}
            def mark_page_changed(self): pass
        class FakeBrowser:
            tools = {"browser_evaluate": {}, "browser_tabs": {}}
            page_agent = FakePageAgent()
            calls = []
            def call_tool(self, name, args):
                self.calls.append((name, args))
                if name == "browser_evaluate":
                    return type("R", (), {"text": "https://app.example.test/share?token=xyz", "images": []})()
                if name == "browser_tabs":
                    return type("R", (), {"text": "0: app\n1: share", "images": []})()
                raise AssertionError(name)
        rules = self._rules()
        browser = FakeBrowser()
        policy = PolicyEngine(rules_dir=rules)
        policy.set_mission_url("https://app.example.test/dashboard")
        policy.max_actions = 20
        agent = QAReActAgent(browser=browser, ai=object(), policy=policy, evidence=object(), skill_loader=object())
        agent._initial_url = "https://app.example.test/dashboard"
        agent._recent_page_agent_state = ""
        agent.store = type("Store", (), {"record_action": lambda *_a, **_k: None})()
        # Simulate the LLM calling read_clipboard then open_new_tab.
        # We can't easily run the full loop, so test the evidence flow:
        from engine.navigation import build_navigation_evidence
        clip_evidence = build_navigation_evidence(
            "https://app.example.test/share?token=xyz",
            source="application_clipboard",
            provenance="clipboard_from_application",
            evidence="trusted clipboard read",
            was_inferred=False,
            initial_url="https://app.example.test/dashboard",
            decision="approved",
        ).as_dict()
        agent._last_navigation_evidence = clip_evidence
        policy.register_navigation_evidence(clip_evidence)
        # Now check that the policy approves this URL:
        result = policy.check_navigation(
            "https://app.example.test/share?token=xyz",
            clip_evidence,
        )
        self.assertTrue(result["ok"], f"Expected approved but got: {result['reason']}")



class DisabledSemanticOwnerRegressionTests(unittest.TestCase):
    def setUp(self):
        self.js = Path("engine/page_agent_controller.js").read_text(encoding="utf-8")

    def test_disabled_semantic_owner_blocks_descendant(self):
        self.assertIn("function nearestDisabledOwner(el)", self.js)
        self.assertIn("Disabled semantic owner:", self.js)
        self.assertIn('attr(p, "aria-disabled").toLowerCase() === "true"', self.js)
        self.assertIn('style.pointerEvents === "none"', self.js)

    def test_rendered_state_exposes_disabled_owner(self):
        self.assertIn("disabled_owner=", self.js)
        self.assertIn("disabledOwner,", self.js)

    def test_disabled_semantic_owner_is_treated_as_subtree_boundary(self):
        self.assertIn("function isDisabled(el)", self.js)
        self.assertIn("semanticOwner", self.js)
        self.assertIn("data-disabled", self.js)
        self.assertIn("data-state", self.js)
        self.assertIn('pointerEvents === "none"', self.js)
        self.assertIn("disabledOwner", self.js)

    def test_disabled_owner_is_rendered_to_page_agent_state(self):
        self.assertIn("flags.push(`disabled_owner=${st.disabledOwner.name}`)", self.js)
        self.assertIn("disabled_owner=", self.js)




class DisabledSurfaceLoopRegressionTests(unittest.TestCase):
    def test_agent_has_hard_stuck_breaker_for_disabled_surface(self):
        agent = Path("engine/agent.py").read_text(encoding="utf-8")
        self.assertIn("_blocked_surface_attempts", agent)
        self.assertIn("HARD STRATEGY BLOCK", agent)
        self.assertIn("strategy_loop_on_disabled_surface", agent)
        self.assertIn("Do not click/type/select any element owned by the same disabled surface again", agent)

    def test_controller_tracks_portal_owner_relationships(self):
        js = Path("engine/page_agent_controller.js").read_text(encoding="utf-8")
        self.assertIn("function findDisabledControllerForPopup(el)", js)
        self.assertIn("[aria-controls], [aria-owns]", js)
        self.assertIn("isDisabledIntrinsic(owner)", js)

class V269SemanticRegressionTests(unittest.TestCase):
    def test_active_dialog_bypass_is_present(self):
        js = (Path(__file__).parents[1] / "engine" / "page_agent_controller.js").read_text(encoding="utf-8")
        self.assertIn("function isActiveDialogAncestor(el)", js)
        self.assertIn("if (isActiveDialogAncestor(el)) return true;", js)

    def test_state_mentions_active_dialog(self):
        js = (Path(__file__).parents[1] / "engine" / "page_agent_controller.js").read_text(encoding="utf-8")
        self.assertIn("ACTIVE DIALOG:", js)

    def test_controller_does_not_contain_guessed_login_route_instruction(self):
        agent = (Path(__file__).parents[1] / "engine" / "agent.py").read_text(encoding="utf-8")
        self.assertNotIn("likely login URL", agent)

    def test_dialog_settle_is_bounded(self):
        js = (Path(__file__).parents[1] / "engine" / "page_agent_controller.js").read_text(encoding="utf-8")
        self.assertIn("setTimeout(resolve, 80)", js)
        self.assertIn("setTimeout(resolve, 160)", js)


class AgentBehaviorRegressionTests(unittest.TestCase):
    def test_phone_value_can_be_supplied_by_human_after_missing_in_mission(self):
        class DummyPageAgent:
            def state(self):
                return {
                    "elements": [{
                        "index": 7, "name": "شماره موبایل", "role": "textbox",
                        "attrs": {"name": "phone", "autocomplete": "tel"},
                        "context": ["dialog"], "status": {}
                    }]
                }
        class DummyBrowser:
            page_agent = DummyPageAgent()
        agent = QAReActAgent(browser=DummyBrowser(), ai=object(), policy=PolicyEngine(), evidence=object(), skill_loader=object())
        agent._mission_goal_text = "با این شماره لاگین کن"
        agent.mission_state.set_human_input("phone", "09120000000")
        self.assertIsNone(agent._guard_uninvented_input(7, "09120000000"))

    def test_unobserved_route_is_not_retried(self):
        class DummyPageAgent:
            def state(self):
                return {"content": "Page URL: https://app.example.test", "url": "https://app.example.test", "elements": []}
        class DummyBrowser:
            page_agent = DummyPageAgent()
        agent = QAReActAgent(browser=DummyBrowser(), ai=object(), policy=PolicyEngine(), evidence=object(), skill_loader=object())
        agent._denied_navigation_targets.add("https://app.example.test/login")
        self.assertIn("https://app.example.test/login", agent._denied_navigation_targets)

class FastFormFillRegressionTests(unittest.TestCase):
    def _agent(self, elements, mission):
        from engine.agent import QAReActAgent
        class PA:
            def __init__(self, elems):
                self.elems = elems
            def state(self):
                return {"elements": self.elems}
        agent = object.__new__(QAReActAgent)
        agent.browser = type("B", (), {"page_agent": PA(elements)})()
        agent._mission_goal_text = mission
        agent._fast_filled_signatures = set()
        return agent

    def test_known_national_code_is_locally_batchable(self):
        import config
        old_fast = config.FAST_MODE
        old_fill = getattr(config, "FAST_DIRECT_FORM_FILL", True)
        config.FAST_MODE = True
        config.FAST_DIRECT_FORM_FILL = True
        try:
            agent = self._agent([
                {"index": 3, "role": "textbox", "name": "کدملی", "tag": "input", "value": "", "attrs": {}, "context": [], "status": {"disabled": False, "readonly": False}},
            ], "با کدملی 0927407043 وارد شو")
            self.assertEqual(agent._fast_grounded_form_batch(), [{"index": 3, "text": "0927407043"}])
        finally:
            config.FAST_MODE = old_fast
            config.FAST_DIRECT_FORM_FILL = old_fill

    def test_missing_phone_is_not_invented(self):
        import config
        old_fast = config.FAST_MODE
        old_fill = getattr(config, "FAST_DIRECT_FORM_FILL", True)
        config.FAST_MODE = True
        config.FAST_DIRECT_FORM_FILL = True
        try:
            agent = self._agent([
                {"index": 8, "role": "textbox", "name": "شماره موبایل", "tag": "input", "value": "", "attrs": {}, "context": [], "status": {"disabled": False, "readonly": False}},
            ], "با این شماره لاگین کن و OTP بگیر")
            self.assertEqual(agent._fast_grounded_form_batch(), [])
        finally:
            config.FAST_MODE = old_fast
            config.FAST_DIRECT_FORM_FILL = old_fill

    def test_fast_mode_prompt_forbids_fill_narration(self):
        agent = object.__new__(QAReActAgent)
        agent._system_prompt = None
        agent.mission_type = "exploratory"
        agent.mode = "explore"
        agent.policy = PolicyEngine()
        agent.skills = type("S", (), {"select": lambda *_a, **_k: [], "compose_prompt": lambda *_a, **_k: ""})()
        agent._last_snapshot_text = lambda: ""
        prompt = QAReActAgent.system_prompt(agent)
        self.assertIn("For simple field filling, do not narrate", prompt)
        self.assertIn("high-confidence and unique", prompt)


class BalancedSpeedAccuracyRegressionTests(unittest.TestCase):
    def _agent(self, elements, mission):
        from engine.agent import QAReActAgent
        class PA:
            def __init__(self, elems):
                self.elems = elems
            def state(self):
                return {"elements": self.elems, "content": ""}
        agent = object.__new__(QAReActAgent)
        agent.browser = type("B", (), {"page_agent": PA(elements)})()
        agent._mission_goal_text = mission
        agent._fast_filled_signatures = set()
        return agent

    def test_ambiguous_national_fields_disable_local_fast_fill(self):
        import config
        old = (config.FAST_MODE, config.FAST_DIRECT_FORM_FILL, config.FAST_FORM_MIN_CONFIDENCE, config.FAST_FORM_REQUIRE_UNIQUE_TARGET)
        config.FAST_MODE = True
        config.FAST_DIRECT_FORM_FILL = True
        config.FAST_FORM_MIN_CONFIDENCE = 0.98
        config.FAST_FORM_REQUIRE_UNIQUE_TARGET = True
        try:
            elems = [
                {"index": 3, "role": "textbox", "name": "کدملی", "tag": "input", "value": "", "attrs": {}, "context": [], "status": {"disabled": False, "readonly": False}},
                {"index": 8, "role": "textbox", "name": "کدملی امضاکننده", "tag": "input", "value": "", "attrs": {}, "context": [], "status": {"disabled": False, "readonly": False}},
            ]
            agent = self._agent(elems, "کد ملی کاربر 0927407043 است و امضاکننده را با کد ملی 0927407043 اضافه کن")
            self.assertEqual(agent._fast_grounded_form_batch(), [])
        finally:
            config.FAST_MODE, config.FAST_DIRECT_FORM_FILL, config.FAST_FORM_MIN_CONFIDENCE, config.FAST_FORM_REQUIRE_UNIQUE_TARGET = old

    def test_exact_title_field_remains_fast(self):
        import config
        old = (config.FAST_MODE, config.FAST_DIRECT_FORM_FILL, config.FAST_FORM_MIN_CONFIDENCE)
        config.FAST_MODE = True
        config.FAST_DIRECT_FORM_FILL = True
        config.FAST_FORM_MIN_CONFIDENCE = 0.98
        try:
            elems = [
                {"index": 3, "role": "textbox", "name": "عنوان", "tag": "input", "value": "", "attrs": {"name": "title"}, "context": [], "status": {"disabled": False, "readonly": False}},
            ]
            agent = self._agent(elems, 'قرارداد با عنوان «تست» ایجاد کن')
            self.assertEqual(agent._fast_grounded_form_batch(), [{"index": 3, "text": "تست"}])
        finally:
            config.FAST_MODE, config.FAST_DIRECT_FORM_FILL, config.FAST_FORM_MIN_CONFIDENCE = old

    def test_balanced_defaults_keep_more_state_and_output(self):
        import config
        self.assertGreaterEqual(getattr(config, "FAST_AI_MAX_TOKENS", 0), 768)
        self.assertGreaterEqual(getattr(config, "FAST_PAGE_STATE_CHARS", 0), 9000)
        self.assertGreaterEqual(getattr(config, "FAST_HISTORY_KEEP_FULL", 0), 4)

    def test_network_correlation_defaults_to_actionable_clicks(self):
        import config
        self.assertFalse(getattr(config, "CORRELATE_NETWORK_ON_INPUTS", True))
        self.assertFalse(getattr(config, "CORRELATE_NETWORK_ON_SELECT", True))

class ObservationEfficiencyRegressionTests(unittest.TestCase):
    def test_settle_does_not_duplicate_immediate_state_read(self):
        from engine.agent import QAReActAgent
        class PA:
            def __init__(self):
                self.calls = 0
            def state(self):
                self.calls += 1
                return {"content": "same", "elements": [], "url": "https://example.test"}
        pa = PA()
        agent = object.__new__(QAReActAgent)
        agent.browser = type("B", (), {"page_agent": pa})()
        first = {"content": "same", "elements": [], "url": "https://example.test"}
        settled, changed = agent._settled_page_agent_state(first, "click_element_by_index")
        self.assertFalse(changed)
        self.assertEqual(settled, first)
        self.assertEqual(pa.calls, 0)
