# Agent Role — Recovery

- **نقش:** رویه‌ی استاندارد بازیابی خطا — همان «standard procedure»
  که اکثر skill ها به آن ارجاع می‌دهند. اجرای آن توسط harness و
  agent انجام می‌شود.
- **حداکثر تلاش:** `max_recovery_attempts` از `.rules/execution.yaml`
  (پیش‌فرض ۵). هر تلاش بازیابی مثل هر اکشن دیگر از بودجه کم می‌کند
  (اصل #12) و در EvidenceStore ثبت می‌شود (اصل #1).

## طبقه‌بندی خطا و واکنش

| کلاس خطا | نشانه‌ها | واکنش |
|---|---|---|
| `transient` | timeout ابزار، خطای شبکه لحظه‌ای | یک snapshot تازه، سپس **یک** تلاش مجدد همان هدف (نه همان اکشنِ منکرِ policy) |
| `element_not_found` | ref معتبر نبود / المنت ناپیدا شد | snapshot جدید بگیر، ref تازه انتخاب کن (refs موقت‌اند!) |
| `navigation_error` | goto/redirect شکست خورد | برگرد به آخرین URL معلومِ موفق؛ اگر دوباره شکست خورد → BLOCKED |
| `loop_detected` | فلگ LoopDetector | توقف فوری مسیر؛ تغییر رادیکال استراتژی یا BLOCKED با `failure_reason: loop` — تکرار همان مسیر ممنوع (اصل #13) |
| `session_expired` | ریدایرکت ناگهانی به ورود | ثبت Finding (`session-expiry` skill) + BLOCKED برای requirement در جریان — نه crash |
| `permanent` | ریست فرم، خطای منطقی تکرارشونده | retry ممنوع؛ requirement را همان‌جا به FAIL/BLOCKED برسان |

## قواعد

1. **Snapshot قبل از retry** — همیشه. رفرنس‌های قدیمی مشکل‌سازترین
   علت شکست‌های تکراری‌اند.
2. **هرگز دوبارِ پشت‌سرهم همان (tool, target)** — PolicyEngine در کد
   بلاک می‌کند.
3. **خطاها شواهدند** — هر خطای ابزار با متن کامل در actions.jsonl
   ثبت می‌شود؛ Oracle از آن‌ها برای قضاوت استفاده می‌کند.
4. **اگر بازیابی نشد:** verdict صادقانه — BLOCKED (بیرونی) یا
   INCONCLUSIVE (نامعلون) — هرگز FAILِ غیرواقعی و هرگز PASSِ
   دل‌خواه.
