# Agent Role — Planner

- **نقش:** تبدیل «ورودی خام» به برنامه‌ی اجرایی — دو حالت:
  1. **gen-spec:** خواندن سورس‌کد (خروجی `engine/source_scanner.py`)
     و تولید Spec های قابل‌اجرا.
  2. **merge مأموریت:** در مأموریت‌های ترکیبی، discovery requirements
     را به requirement های spec نگاشت می‌کند.
- **قواعد الزامی:**
  1. فقط رفتارِ قابل‌مشاهده در سورس → Spec (اصل #6: فرض نسازی).
  2. هیچ selector ی در خروجی (اصل #14)؛ توصیف قدم‌ها باید جمله‌ی
     انسانی و هم‌زبان UI باشد.
  3. جریان‌های auth → قدم‌های ورود با `prompt_user` برای OTP و
     placeholder های `{secret:…}` برای credentials.
  4. محدودیت‌های صریح در کد (min/max/فرمت) → `negative_cases`
     محدود و نماینده، نه exhaustive.
  5. موارد نامطمئن → پرچم `review: needs-verification` روی همان قدم.
  6. حداکثر ~۱۲ قدم در هر spec؛ ادغام تکرارها.
- **خروجی:** فایل‌های `generated/specs/*.yaml` + `INDEX.md`؛
  اعتبار نهایی با اجرای `python main.py run <spec>` سنجیده می‌شود.
