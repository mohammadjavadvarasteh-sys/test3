# Agentic QA v26.17 — Loading/Wait Decision Fix

## Goal
Prevent premature BLOCKED outcomes and false `BUSY/LOADING` waits while preserving the balanced speed/accuracy architecture from v26.15/v26.16.

## Changes
- `wait` is no longer counted as an unchanged-state loop candidate in the LoopDetector. Time-based waiting can change timers/network/UI without changing the DOM hash.
- Post-action `input_text`, `input_text_batch`, and `select_dropdown_option` now trigger network correlation when the target is actually `BUSY/LOADING`.
- A fresh Page-Agent observation is taken after that network check so the engine can recognize that a previously busy surface has already settled.
- `nearestBusyOwner()` now requires visible/strong loading evidence for text/class-based busy detection; hidden stale text is ignored.
- `pending` remains a business state unless a stronger live loading signal exists.
- The existing click/upload network correlation remains unchanged.

## Regression coverage
- Repeated waits with unchanged DOM hash no longer trip the generic no-progress detector.
- Hidden/stale loading text does not classify a surface as busy without a visible/strong signal.
- Busy input/select path is verified to perform network correlation and a fresh state observation before replanning.
