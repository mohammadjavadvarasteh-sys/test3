# v15

- Human checkpoint lifecycle is resolved generically from checkpoint/tool protocol semantics.
- Runtime one-time/expiring challenge inputs can refresh without colliding with immutable mission values.
- No site, selector, label, field-count, route, or product-specific logic was added.
- Durable human inputs remain immutable.
