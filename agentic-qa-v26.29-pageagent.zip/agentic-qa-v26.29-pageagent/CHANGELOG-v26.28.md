# Agentic QA v26.28 — Copy-Link Premature-Finish Guard

## Goal
The agent was finishing with INCONCLUSIVE right after clicking "کپی لینک"
(copy link) without opening the link in a new tab. The auto-follow either
failed (clipboard API blocked by user-activation requirements on synthetic
clicks) or the LLM decided to give up instead of calling
`open_application_link` explicitly.

## Root cause
1. The auto-follow clipboard link path triggered after the "کپی لینک" click
   but failed — `navigator.clipboard.writeText()` requires a user gesture
   (transient activation), and synthetic clicks dispatched by the in-page
   controller don't provide one. So the clipboard was empty.
2. The error message told the LLM to call `open_application_link` explicitly,
   but the LLM chose to finish with INCONCLUSIVE instead.
3. The `_guard_premature_finish` function only rejected finish after an
   explicit wait — it did NOT guard against premature finish after a
   copy-link click.

## Changes

### Premature-finish guard for copy-link clicks
`_guard_premature_finish()` now has a second guard: if a copy-link click
was detected (`_copy_link_click_detected = True`) and the link has NOT
been opened yet (`_clipboard_link_opened = False`), any INCONCLUSIVE or
BLOCKED finish is rejected with:
```
FINISH_REJECTED: the mission requires opening the copied contract link
in a new tab, but the link has NOT been opened yet. A copy-link click
was detected, but the auto-follow did not open a new tab. You MUST call
open_application_link NOW to read the clipboard/DOM and open the link.
If that fails, look for the link URL in the live DOM (readonly input,
textarea, anchor href) and call open_new_tab with it. Do NOT finish
with INCONCLUSIVE or BLOCKED until the link is opened.
```
PASS verdict is never rejected — if the mission is genuinely complete,
the guard doesn't interfere.

### Tracking flags
- `_copy_link_click_detected`: set to True when the auto-follow detects
  a copy-link click (the click observation contains copy/کپی terms and
  the mission requests clipboard link follow).
- `_clipboard_link_opened`: set to True when `_open_application_clipboard_link`
  succeeds OR when `open_new_tab` is called with a URL after a copy-link
  click. This tells the guard that the link has been opened and finish
  is no longer premature.

### Stronger error message on auto-follow failure
When the auto-follow fails, the error message now says:
```
You MUST call open_application_link explicitly NOW to open the copied
link in a new tab. Do NOT finish the mission with INCONCLUSIVE or
BLOCKED — the link has been copied and the mission requires opening it.
```
This gives the LLM a clear instruction that it must not give up.

### Tests
- 6 new regression tests covering: guard rejects INCONCLUSIVE after
  copy-link click, guard allows finish after link opened, guard allows
  finish when no copy-link click detected, guard rejects BLOCKED, guard
  does not reject PASS, and `_open_application_clipboard_link` sets the
  `_clipboard_link_opened` flag.
- All 180 tests pass (174 from v26.27 + 6 new).

## Upstream alignment
The Alibaba Page Agent control loop is unchanged. The fix only adds a
runtime guard that prevents the LLM from giving up prematurely after a
copy-link click when the mission explicitly requires opening the link.
