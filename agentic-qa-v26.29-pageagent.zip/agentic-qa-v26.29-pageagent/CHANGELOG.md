# v26.19

Action-scoped async detection, stale-loading suppression, and no-blind-wait policy.

## v26.16 — Loading-state precision

- `pending` خام دیگر سیگنال BUSY/LOADING نیست؛ detector برای جلوگیری از false positive فقط از سیگنال‌های صریح loading استفاده می‌کند.
## v26.14 — Click → Network Response Awareness

- Added bounded post-click network polling.
- New request is correlated before the next decision.
- Exact request details and response headers/body remain authoritative for failures.
- Loading/busy click surfaces get a longer observation window to avoid duplicate clicks during slow saves/creates.
- Added generic `busy`/`busyOwner` state for `aria-busy`, data loading/state, and common loading semantics.
- Default fast path: 1200ms probe with 100ms polling; busy controls: up to 8000ms. No unconditional sleep on every action.


## v26.13.2 — before_pa initialization hotfix
- Fixed `UnboundLocalError` in the normal action path where `_summarize_state_transition()` used `before_pa` before it was initialized.
- Normal actions now capture the complete pre-action Page-Agent state before execution, matching the upload path.
- Added regression coverage to ensure the pre-action state is initialized before transition summarization.
## v26.12 — disabled-surface decision / loop breaker
- Fixed semantic disabled-state gaps for portal-rendered dropdown/searchbox controls by following generic `aria-controls` / `aria-owns` ownership from a disabled controller to its popup descendants.
- Added executor-level disabled-surface tracking: repeated attempts against the same disabled semantic surface in the same live state are blocked instead of consuming the run in a click/searchbox loop.
- When a disabled surface is blocked, the runtime returns observed prerequisite candidates and explicitly requires a different actionable strategy.
- Added a hard stop after repeated strategy failure so the agent cannot loop indefinitely on a disabled control.
- Reset disabled-surface loop state at the start of each goal so a real page-state transition permits a fresh decision.
- Regression suite expanded to 122 tests.

## v26.10.1 — dom action signature regression fix
- Fixed `AttributeError: QAReActAgent has no attribute _dom_action_signature`.
- Added a stable internal DOM-action signature used by repetition/loop tracking.
- Signature includes tool + normalized arguments so different OTP/CAPTCHA values are not treated as the same action.
- Added regression coverage for signature existence and argument differentiation.
## v26.10 — semantic navigation + input grounding

- Deterministic guard prevents fabricated phone/mobile values when the mission does not contain the actual number.
- Generic semantic find aliases cover login/confirm/forgot-password/phone concepts across English/Persian UI labels.
- Exact observed control labels are preserved in action evidence; generic labels such as «تأیید» are not renamed to «Login».
- Rejected/unobserved navigation targets are not retried as guessed routes.
- Modal/current-state transitions are treated as state changes; agent is instructed to re-observe instead of repeating the previous control.

# v26.9 — modal-aware semantic discovery / no guessed login routes

- Active dialog/modal controls are no longer dropped because the backdrop or another overlay wins the `elementFromPoint()` hit test. Dialog descendants are first-class Page-Agent targets based on generic dialog semantics (`role=dialog`, `aria-modal=true`, or an open `<dialog>`).
- Page-Agent state explicitly exposes active dialog text/context so the model can use the actual visible control names (for example, a button named `تأیید`) instead of translating them to an assumed label such as `login`.
- Added a bounded 80ms dynamic-dialog settle only when a visible dialog exists but its interactive surface has not rendered yet; ordinary pages do not pay this wait.
- Click actions use a bounded 160ms UI settle before the normal state refresh to accommodate SPA modal/portal transitions without adding large fixed waits.
- Exploration guidance now forbids invented/transliterated labels and guessed routes such as `/login`; target selection must come from the current live Page-Agent state.
- Regression suite: 114 tests passing, plus a real Chromium smoke test covering a modal with a backdrop and Persian `تأیید` button.

# v26.8 — semantic disabled-owner guard

- Fixed custom combobox/dropdown cases where the wrapper is disabled but a child searchbox remains technically enabled.
- Disabledness now propagates through semantic owners/ancestors for Page-Agent state and action execution.
- Added `disabledOwner` evidence to page state so the model sees why a target is unavailable.
- Added runtime-level prevention for click/input/select on descendants of disabled semantic controls.
- Added regression coverage for custom disabled-owner behavior.

# v26.7 — Fast browser capabilities + human I/O

- OTP countdown is no longer attached to ordinary OTP/CAPTCHA inputs; resend cooldown is associated with resend/timer controls only. The actor must not wait before asking for a newly issued OTP unless the input itself is actually disabled.
- Added trusted `open_application_link`, `read_clipboard`, `open_new_tab`, `switch_tab`, and `navigate` browser capabilities backed by Playwright MCP. Application-copied URLs can be opened automatically in a new tab without asking the operator to paste/open them. External host names are not used as a hard-coded allow-list; trusted navigation provenance is used instead.
- Added Fast Actor Mode: compact system prompt, shorter context/history, lower output budget, and one-sentence reasoning guidance to reduce LLM latency.
- CMD output is forced line-buffered/write-through. Windows human checkpoints drain queued Enter presses and preserve already-typed non-newline input so accidental Enter during model inference does not skip the next `ask_human`.

# v26.6 — Correlated Network Response Verification

- Added action-scoped correlation of newly observed Playwright network requests with each mutating browser action.
- For new HTTP 4xx/5xx responses, the runtime reads the exact request detail and response headers/body before classification.
- HTTP 429 alone is never considered proof of rate limiting. Without explicit throttling evidence in the correlated response, it is classified as `http_429_unclassified` and cannot trigger OTP resend recovery.
- Challenge rejection detection now keeps page/UI evidence and network-response evidence separate, preventing unrelated error text from creating false OTP rejection.
- Correlated network evidence is returned to the LLM and stored in observability evidence with secret redaction.
- Added regressions for unrelated 429, explicit rate-limit response, explicit challenge rejection, network correlation, parser behavior, and sensitive response-body redaction.
- Regression suite: 103 tests passing.

# v26.4 — File Upload Bridge + Action/Observation Performance

- Added `upload_file` as a first-class agent action backed by the official Playwright MCP `browser_file_upload` capability. The legacy `browser_file_upload` name is also accepted as a compatibility alias, so the agent no longer blocks a valid upload request.
- Local upload paths are validated before execution; the browser receives only explicit `paths` and the upload remains one logical action in the agent budget.
- Updated the Page-Agent protocol to prefer `select_dropdown_option` directly for known dropdown choices instead of spending one turn on open + another on select.
- `input_text_batch` is now explicitly recommended for multiple independent, currently actionable text fields visible in the same live state.
- Page-Agent controller installation is cached per page. The full controller script is no longer sent on every action; after navigation/reload it is lazily reinstalled.
- Added regression coverage for upload routing, dropdown/batch guidance, and controller installation caching.
- Regression suite: 93 tests passing.

# v26.3 — OTP Recovery / Challenge Lifecycle Fix

- **Rejected OTP recovery is now runtime-enforced:** after a transient challenge submit is rejected and a resend/retry control is observed, the engine no longer asks for another OTP immediately.
- Observed cooldown is waited out using the live timer; the state is re-observed before the resend click.
- The uniquely observed enabled resend/retry control is clicked automatically.
- Previously entered one-time challenge cells are cleared using fresh live indices before requesting the new value.
- OTP/CAPTCHA values are inferred as `ephemeral` from generic challenge semantics even when the LLM omits `input_type`, preventing false `immutable ... conflict` errors and preventing reuse of rejected OTP values.
- Added regression coverage for 90 tests, including 60-second cooldown handling, resend execution, challenge clearing, and OTP lifecycle inference.


## v4 — semantic grounding, hard budget, and outcome guard

- Semantic option selection now requires the requested concept to be present as a phrase in the original mission/spec goal, then requires a unique match among options observed under the exact target control.
- Internal actions (`ask_human`, `report_finding`) consume the same action budget as MCP actions.
- The agent refuses to start any non-final action once the shared run budget is exhausted.
- Exploratory runs can no longer report `PASS`; unresolved generic validation evidence also prevents a `PASS` verdict.
- Added regression coverage for mission-grounded semantic selection, shared budget accounting, and outcome downgrading.
## v10 — combined UI evidence strategy

- Added a combined observation strategy: accessibility snapshot + `browser_find` + screenshot + console/network evidence are selected according to the current state instead of treating full snapshots as the only discovery mechanism.
- `browser_find` is now explicitly observation-only and can provide fresh refs cheaply when the semantic target is already known.
- After a tool error or no-effect action, the engine performs targeted `browser_find` and captures a diagnostic screenshot in addition to the existing console/network diagnostics.
- Existing snapshot refresh remains enabled after mutating actions so live element refs stay valid; it is no longer presented as the only recovery strategy.
- No selectors, URLs, routes, credentials, domain-specific rules, or application-specific logic were added.


## v17 — Page-Agent architecture
- Replaced the primary browser-control loop with a Page-Agent-style in-page controller.
- Live DOM → interactive indexed tree → simplified/dehydrated state → LLM → indexed action.
- Added `engine/page_agent_controller.js` for runtime DOM extraction and indexed actions.
- Primary actions are `click_element_by_index`, `input_text`, `select_dropdown_option`, `scroll`, `wait`, and `execute_javascript`.
- Removed snapshot-driven interaction from the primary control path; snapshots/find/screenshots remain auxiliary QA evidence.
- Page-Agent state is refreshed once after each action, without a separate snapshot round-trip.
- Interactive detection uses runtime semantics (native controls, ARIA roles, computed cursor, observed onclick), with no site-specific selectors or labels.
- Existing QA layers remain for human checkpoints, evidence, policy, console/network diagnostics, reporting, and recordings.
## v22 — evidence-first target resolution before scroll

- Page-Agent state is checked before every scroll action.
- If a semantic target already exists in the current live interactive DOM, the engine blocks the scroll and returns the observed target index.
- Scroll is allowed only when the requested target is absent and actual scroll distance is observed in the requested direction.
- Page-Agent controller now reports scroll evidence and verifies that scrolling actually moved the page/container.
- Repeated/no-effect scrolling remains protected by the existing state/loop guard.
- Added regression tests for current-state target priority and role-only false matches.


## v26.1 — browser-agent alignment + evidence hardening

- Added `docs/COMPARISON-2026-10.md` with a current technical comparison against Alibaba Page Agent, Playwright MCP, Browser Use, Stagehand, Skyvern and BrowserGym.
- Hardened `EvidenceStore.record_action()` so Page-Agent text/fill payloads cannot leak raw user-entered values into `actions.jsonl`.
- JavaScript/code action arguments are omitted from evidence logs.
- Added regression coverage for input, batch input and JavaScript redaction.
- Regression suite: 82 tests passing.


## v26.2 — dependency-aware form progression / OTP resend recovery

- Disabled/read-only controls remain observable with explicit runtime state instead of disappearing from the Page-Agent state.
- Disabled controls expose generic `blocked_by`, `prereq_candidates`, and `countdown` evidence when available.
- Action execution rejects disabled/read-only targets before any click/type/selection attempt.
- Form guidance now prioritizes currently actionable prerequisites before later mission targets.
- Human checkpoint replies such as `ارسال مجدد` / `resend` are classified as operational commands, never OTP values.
- Countdown/timer evidence is exposed in Page-Agent state; wait supports cooldowns up to 60 seconds.

## v26.11 — Fast routine form filling
- Added conservative local `input_text_batch` fast-path for high-confidence mission literals (`phone`, `national`, `title`, `serial`) on observed editable fields.
- Fast actor prompt now explicitly suppresses reasoning narration during simple field filling.
- Reduced fast LLM response budget to 384 tokens.
- In FAST_MODE, human-paced typing is disabled by default; opt back in with `AGENTIC_QA_FAST_KEEP_REALISTIC_TYPING=1`.
- Added regressions for grounded national-code autofill and missing-phone no-invention.

## v26.13 — Action outcome awareness
- Added compact ACTION OUTCOME / TARGET EFFECTS evidence after every Page-Agent action.
- Verifies URL/title/dialog/timer and target state/value-length changes before the next decision.
- Added bounded 120ms observation settle only when the first post-action state appears unchanged.
- LLM prompt now treats action outcome evidence as authoritative and replans on contradictions instead of repeating actions.
- No selectors or site-specific workflow rules added.
## v26.13.1
- Fixed regression crash in `QAReActAgent._page_agent_state_hash_from_state`: added the missing top-level `hashlib` import.
- Kept the v26.13 action-outcome awareness behavior unchanged.


# v26.15 — balanced speed + accuracy

- Restored 9000-character fast Page-Agent state and 4 full recent tool results to avoid accuracy loss from aggressive truncation.
- Increased fast actor output ceiling from 384 to 768 tokens while keeping a strict action-oriented prompt.
- Reworked local form autofill to require high-confidence unique semantic targets; repeated literal values are not locally guessed.
- Removed the redundant immediate Page-Agent state() call from the settle path; only one short poll runs when the first post-action state is unchanged.
- Limited default network correlation to click/upload actions; input/select network correlation is opt-in.
- Shortened ordinary click network probing and kept the longer window only for observed busy/loading controls.
- Avoided fetching successful response bodies unless explicitly requested; failure response bodies remain inspected.
- Added regression coverage for ambiguity protection, state-read efficiency, and balanced actor defaults.
