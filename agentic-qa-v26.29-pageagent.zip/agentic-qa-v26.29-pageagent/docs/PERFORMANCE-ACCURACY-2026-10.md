# Agentic QA v26.15 — Performance/Accuracy Balance

این نسخه بر اساس مقایسه‌ی معماری فعلی با Page Agent، Browser Use، Stagehand و Playwright MCP تنظیم شده است.

## هدف

کاهش latency بدون کم‌کردن information مهمی که برای انتخاب action لازم است.

## تغییرات

- Fast state budget از 5200 به 9000 کاراکتر برگشت تا صفحات واقعی با فرم‌ها، dialogها، dependencyها و گزینه‌های dropdown truncate نشوند.
- Fast history از 2 به 4 نتیجه‌ی کامل افزایش یافت.
- Fast actor output از 384 به 768 token افزایش یافت؛ خروجی همچنان action-oriented و کوتاه است.
- Fast form fill فقط با literalهای موجود در mission و targetهای high-confidence/unique انجام می‌شود. در صورت ambiguity، LLM دوباره تصمیم می‌گیرد.
- اگر یک نوع literal چند بار در mission آمده باشد (مثلاً یک کد ملی برای کاربر و امضاکننده)، local fast-fill برای آن نوع خاموش می‌شود تا semantic role اشتباه نشود.
- بعد از هر action یک state خوانده می‌شود؛ settle دیگر یک state خواندنِ فوری و تکراری ندارد و فقط در صورت unchanged بودن، یک poll کوتاه انجام می‌دهد.
- network correlation برای click/upload باقی مانده است، اما به‌صورت پیش‌فرض برای هر input/select اجرا نمی‌شود.
- probe شبکه برای clickهای عادی کوتاه شده و فقط وقتی target واقعاً busy/loading باشد پنجره‌ی طولانی استفاده می‌شود.
- response body موفقیت‌آمیز به‌صورت پیش‌فرض دوباره fetch نمی‌شود؛ status/detail/headers برای success کافی است. body کامل برای failureها یا زمانی که صریحاً فعال شده لازم است.
- در Fast Mode یک retry برای JSON نامعتبر LLM باقی می‌ماند و از retryهای اضافه جلوگیری می‌شود.

## اصل تصمیم‌گیری

`fast` باید به معنی «کمتر تصمیم‌گیری غیرضروری» باشد، نه «اطلاعات کمتر برای تصمیم‌گیری».

مسیر اصلی:

`observe → grounded action → outcome/state diff → next decision`

و فقط actionهای deterministic و با confidence بالا bypass می‌شوند.
