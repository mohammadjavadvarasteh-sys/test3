# Network response correlation

A browser action may trigger multiple concurrent HTTP requests, including background telemetry. Therefore the runtime does not interpret a status code in isolation.

For each mutating action, the engine keeps a per-page request cursor and observes only newly added requests. For newly observed 4xx/5xx responses it calls Playwright MCP's `browser_network_request` and reads the response headers/body.

Classification:

- `confirmed_rate_limit`: the correlated 429 response includes explicit throttling evidence such as `Retry-After`, `X-RateLimit-*`, or clear rate-limit language.
- `challenge_rejected`: the correlated response explicitly rejects the one-time challenge.
- `http_429_unclassified`: 429 without response-level throttling evidence. It does not trigger resend recovery.
- `http_error_unclassified`: other 4xx/5xx responses without sufficient semantic evidence.

The LLM receives a compact response summary. Sensitive response content is redacted before it is shown to the model or stored as ordinary action evidence.


## v26.14 click-response settling

After a DOM click, Agentic QA performs a bounded observation-only poll of `browser_network_requests`. If a new non-static request appears, the engine correlates it with that click and can inspect the exact response headers/body. The default probe is 1200ms and runs only for click actions; when the clicked control reports a loading/busy state, the window extends to 8000ms. This prevents a slow save/create request from being followed by a duplicate click while preserving fast execution for ordinary clicks.

Playwright MCP exposes `browser_network_requests` as a numbered request list and `browser_network_request` for full request/response details, so this correlation uses those official read-only inspection tools rather than guessing URLs.
