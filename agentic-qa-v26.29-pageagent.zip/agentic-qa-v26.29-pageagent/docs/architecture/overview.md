# Architecture Overview

این سند همان `docs/architecture/overview.md` است که
`.skills/exploratory-testing/SKILL.md` و بقیه‌ی skill ها به آن ارجاع
می‌دهند.

## نمای کلی

```
                       ┌──────────────────────────┐
                       │        main.py (CLI)     │
                       │  run │ explore │ gen-spec │
                       └────────────┬─────────────┘
                                    │
        ┌───────────────────────────┼───────────────────────────┐
        ▼                           ▼                           ▼
┌───────────────┐         ┌────────────────┐         ┌────────────────┐
│ SpecRunner    │         │ Explorer       │         │ SpecGenerator  │
│ (spec-driven) │         │ (exploratory)  │         │ (source→spec)  │
└──────┬────────┘         └───────┬────────┘         └───────┬────────┘
       │                          │                          │
       └──────────┬───────────────┴──────────────┬───────────┘
                  ▼                              ▼
        ┌──────────────────┐            ┌──────────────────┐
        │ QAReActAgent     │            │ SourceScanner    │
        │ (engine/agent)   │            │ (استاتیک، بدون   │
        │ think→act→observe│            │  اجرای مرورگر)   │
        └───┬─────────┬────┘            └──────────────────┘
            │         │
            ▼         ▼
┌────────────────┐  ┌─────────────────────────────┐
│ PolicyEngine + │  │ PlaywrightMCPBrowser        │
│ LoopDetector   │  │ (engine/mcp_client.py)      │
│ (pre-execution │  │  JSON-RPC over stdio        │
│  enforcement)  │  │  → npx @playwright/mcp      │
└────────────────┘  │  → browser_snapshot (a11y   │
       │            │    tree با ref یکتا)        │
       ▼            └─────────────┬───────────────┘
┌────────────────────────┐        │
│ EvidenceStore + Oracle │        ▼
│ (.evidence/runs/<id>/) │   ┌─────────────┐
│ verdicts, findings,    │   │  Chrome     │
│ actions.jsonl, shots   │   │ (real page) │
└────────────────────────┘   └─────────────┘
```

## چرا مشکل «دو المنت هم‌اسم» حل شد

| | پروژه قبلی (new2) | agentic-qa |
|---|---|---|
| نگاه agent به صفحه | لیست مسطح ۴۰ تا المنت (بدون والد) | درخت کامل دسترس‌پذیری با سلسله‌مراتب |
| آدرس المنت | CSS selector که LLM می‌سازد | `ref` موقتِ snapshot + توصیف معنایی با زمینه |
| دو دکمه «ورود» | `text=ورود` → `.first` → کلیک اشتباه | agent می‌بیند یکی داخل `form` و یکی داخل `dialog` است و ref درست را انتخاب می‌کند |
| staleness | selector قدیمی بعد از تغییر صفحه | هر ref از snapshot زنده است؛ بعد از هر mutation خودکار snapshot تازه |
| spec | گاهی selector هارد کد | هیچ selector ی مجاز نیست (Constitution #14) |

## جریان داده‌ی یک قدم spec

1. **SpecRunner** قدم را می‌خواند، placeholder ها (`{var}`،
   `{secret:…}`، `{env:…}`) را حل می‌کند و gating قدم‌ها را چک
   می‌کند.
2. هدف → **QAReActAgent**: حلقه‌ی think/act/observe روی ابزارهای MCP.
3. هر اکشن اول از **PolicyEngine** (دامنه، مخرب‌ها، بودجه، ابزار
   ممنوع) رد می‌شود؛ بعد اجرا؛ بعد **LoopDetector** state hash جدید
   را می‌سنجد.
4. مشاهدات → **EvidenceStore** (redacted) + اسکرین‌شات.
5. پایان قدم → **Oracle** (قضاوت LLM + الزامات evidence.yaml در کد)
   → verdict در `verdicts.json`.
6. پایان run → خلاصه ترمینال + `report.html`.

## جریان مأموریت exploratory

همان حلقه، ولی هدف = intent مأموریت؛ خروجی = **Finding** ها
(`findings.json`) نه Verdict (اصل #8). در پایان، یک Spec کشف‌شده در
`generated/` نوشته می‌شود تا دفعه بعد قطعی اجرا شود (اصل #11).

## gen-spec (سورس → Spec)

`SourceScanner` (فقط استاتیک) → chunk های فشرده → Planner LLM →
فایل‌های `generated/specs/*.yaml` + `INDEX.md`. هر spec این‌قدر
معتبر می‌شود که مستقیماً با `python main.py run` قابل اجراست.

## نقش فایل‌ها

| مسیر | نقش |
|---|---|
| `docs/CONSTITUTION.md` | Level 0 — اصول ۱۵ ماده‌ای |
| `.rules/*.yaml` | Level 1 — safety/execution/evidence/validation/security |
| `.steering/steering.yaml` | Level 2 — تنظیمات جهت‌گیری |
| `.steering/secrets.yaml` | secret store (gitignored) |
| `.skills/*/SKILL.md` | Level 3 — skill های مارک‌داونی (انتخاب پویا) |
| `.agents/*.md` | نقش‌های agent: explorer/oracle/recovery/planner |
| `engine/policy_engine.py` | اعمال کد + `LoopDetector` |
| `engine/oracle.py` | منطق متمرکز verdict |
| `engine/skill_loader.py` | Dynamic Skill Selection |
| `engine/evidence_store.py` | مخزن شواهد + redaction |
| `.evidence/runs/<run_id>/` | خروجی هر اجرا (run/findings/verdicts/evidence) |
