# مقایسه Agentic QA با ابزارهای Browser-Agent — 2026-10

این سند وضعیت نسخه v26 را با چند پروژهٔ آماده و شناخته‌شده در اکوسیستم browser-agent مقایسه می‌کند. هدف، استخراج الگوهای فنی قابل‌استفاده و مشخص‌کردن gapهاست؛ نه رتبه‌بندی ابزارها.

## خلاصهٔ اجرایی

نسخهٔ v26 عمداً معماری اصلی را به Page Agent نزدیک کرده است:

`Live DOM → flat indexed state → LLM reflection/action → indexed operation → fresh observation`

در عین حال، لایه‌های QA شما، PolicyEngine، LoopDetector، EvidenceStore و Playwright MCP را نگه می‌دارد. مهم‌ترین تغییر معماری این است که در حالت پیش‌فرض دیگر برای هر اکشن یک micro-planner جداگانه اجرا نمی‌شود؛ مدل می‌تواند `evaluation_previous_goal`، `memory` و `next_goal` را همراه action برگرداند.

## مقایسهٔ معماری

| قابلیت | Agentic QA v26 | Alibaba Page Agent | Playwright MCP | Browser Use | Stagehand | Skyvern |
|---|---|---|---|---|---|---|
| مدل اصلی تعامل | DOM درون صفحه + index | DOM درون صفحه + index | Accessibility snapshot + ref | DOM + AX + CDP | agent SDK + Playwright-style API + AI actions | browser agent روی Playwright |
| ReAct / reflection | بله؛ یک turn در حالت پیش‌فرض | بله؛ reflection/history داخلی | loop بیرون از MCP | بله؛ Agent loop + history | act/observe/extract | act/extract/validate |
| DOM dehydration / compact state | بله | بله | accessibility snapshot | بله، enhanced DOM/AX | بله، hybrid trimming | بله |
| ref/index staleness | index map در observation نگه داشته می‌شود و action روی همان map resolve می‌شود | indexed operations روی PageController | ref با تغییر صفحه stale می‌شود و باید snapshot تازه گرفت | browser state / DOM tree lifecycle | locator/self-healing | Playwright locator/AI resolution |
| Shadow DOM | open shadow roots | DOM controller | Playwright supports browser structures through browser layer | DOM service + browser layer | open/closed Shadow DOM | browser layer |
| iframe | same-origin iframe در state؛ cross-origin به‌صورت boundary | page-controller/browser extension layer | frame refs (`f1e...`) در snapshot | same-origin + CDP-based cross-origin handling | nested iframes | browser/Playwright layer |
| nested scrolling | first-class `scroll-container` + evidence | scrollable elements in DOM model | snapshot + scrolling tools | DOM scroll/iframe scroll handling | browser interaction layer | browser interaction layer |
| visual mode | screenshot فقط evidence/diagnostic | text-first؛ screenshot پیش‌فرض نیست | screenshot/vision اختیاری | vision + screenshot support | screenshot + visual capabilities | visual/browser capabilities |
| multi-tab | لایهٔ MCP/Browser؛ در Page-Agent model اولیه expose نشده | extension برای multi-page | browser_tabs | browser session | browser context/page APIs | workflow/browser layer |
| file upload | intentionally خارج از in-page controller؛ نیازمند upload integration در browser layer | controller action set محدودتر | `browser_file_upload` | browser action support | browser API support | workflow/browser layer |
| arbitrary JS | پیش‌فرض خاموش؛ دو flag برای فعال‌سازی | ابزار داخلی صفحه-agent | `browser_evaluate`/unsafe code capability | browser/CDP layer | Playwright APIs | browser automation APIs |
| QA evidence | screenshot + console/network + findings + verdict | history/activity بیشتر برای agent UI | tracing/video/network/storage و snapshot | history/actions/errors/screenshots | OTel/tracing و browser artifacts | observability/workflow artifacts |
| policy/safety | PolicyEngine + immutable mission inputs + loop guard | agent/core policy عمدتاً سمت application | browser tool permissions/caps | configurable browser/agent controls | domain/security controls | workflow/security controls |

## Alibaba Page Agent — مهم‌ترین مرجع

Page Agent یک JavaScript in-page agent است و طبق مستندات پروژه نیازی به browser extension، Python یا headless browser برای مسیر پایه ندارد. همچنین به‌صورت پیش‌فرض text-based DOM manipulation را به‌جای screenshot/MMLL vision استفاده می‌کند و امکان BYO LLM دارد. این دقیقاً همان جهتی است که v26 برای لایهٔ اصلی interaction گرفته است.

معماری Core آن صراحتاً loop «step → observe → think → reflection → action → act → loop» را تعریف می‌کند و `history` را به‌عنوان حافظهٔ persistent بین stepها نگه می‌دارد. نسخهٔ v26 این الگو را در envelope تصمیم (`evaluation_previous_goal`, `memory`, `next_goal`, `action`) و history پیام‌های LLM پیاده کرده است.

Page Agent همچنین DOM را از Live DOM به FlatDomTree، سپس به نمایش ساده‌شده برای LLM می‌برد و در نهایت action را با index روی PageController اجرا می‌کند. در v26 همین pipeline با کنترل‌های QA اختصاصی ترکیب شده، به‌جای اینکه snapshot/selector را surface اصلی تصمیم‌گیری کند.

**چیزی که از Page Agent گرفتیم:**

- reflection/history به‌جای planner مستقل در هر اکشن؛
- DOM-first و text-first برای کاهش token و حذف coordinate guessing؛
- indexed actions با map تولیدشده از observation؛
- تفکیک Core agent از controller؛
- امکان BYO/local LLM.

**چیزی که عمداً کپی نکردیم:**

- Page Agent یک page-side enhancement است، در حالی که این پروژه QA server-side و evidence-first است؛
- policy، verdict، immutable mission state و evidence lifecycle در Page Agent هدف اصلی نیست و در این پروژه باقی مانده‌اند؛
- browser navigation/tab/file features همچنان در Playwright MCP/browser layer باقی مانده‌اند.

## Playwright MCP

Playwright MCP از accessibility snapshot استفاده می‌کند و برای هر node یک `ref` می‌دهد. ref تا زمانی معتبر است که page تغییر نکرده باشد؛ وقتی stale شود، ابزار خطا می‌دهد و snapshot تازه لازم است. این دقیقاً یک اصل مهم برای جلوگیری از silent retargeting است که v26 در map/index خود نیز enforce می‌کند.

Playwright MCP علاوه بر interaction، سطح بسیار گسترده‌تری از browser capability دارد: navigation، tabs، screenshots، dialogs، upload، console/network، storage، tracing، video و evaluate. بنابراین v26 آن را به‌عنوان browser/evidence backend نگه می‌دارد، نه اینکه همهٔ این قابلیت‌ها را دوباره در in-page controller بازسازی کند.

یک نکتهٔ مهم از snapshot design هم برای v26 اعمال شده: `find` باید observation-only باشد و برای صفحهٔ بزرگ targeted search بدهد، نه اینکه مدل مجبور شود کل DOM را هر بار ببیند.

## Browser Use

Browser Use از یک DOM service ترکیبی با DOM، accessibility tree و CDP استفاده می‌کند و برای iframeها، visibility، scroll state و click-listener detection منطق اختصاصی دارد. همچنین AgentHistoryList آن history، actions، errors و سایر runtime evidence را نگه می‌دارد.

این مقایسه باعث شد در v26 چند چیز تقویت شود: پیمایش Shadow DOM، frame path برای iframe، state مربوط به nested scrolling، richer accessible-name resolution، و جداسازی observation map از action execution.

**Gap باقی‌مانده:** عمق CDP و cross-origin frame handling این پروژه هنوز با Browser Use یکی نیست؛ v26 عمداً cross-origin frame را در controller in-page دور نمی‌زند و آن را به browser layer واگذار می‌کند.

## Stagehand

Stagehand به‌عنوان SDK مخصوص browser agents روی APIهای Playwright-style، `act()`، `observe()` و `extract()`، self-healing و batched commands تمرکز دارد و روی ساختارهای پیچیده‌ای مثل iframeهای تو در تو و closed Shadow DOM نیز قابلیت ارائه می‌کند.

از اینجا دو ایدهٔ مهم برای v26 گرفته شد: action باید بتواند از تغییرات runtime جان سالم به‌در ببرد و observation باید کم‌حجم و agent-optimized باشد. در نتیجه v26 index را به DOM ساختاریافتهٔ همان observation گره زده و از remap خاموش جلوگیری می‌کند.

**Gap باقی‌مانده:** self-healing واقعی مبتنی بر fallback locator strategy در v26 هنوز وجود ندارد؛ عمداً selectorها را کنار گذاشته‌ایم. recovery فعلی semantic `find_elements` + fresh observation است.

## Skyvern

Skyvern یک browser-agent platform/SDK است که روی Playwright-based browser automation و API/MCP/observability تمرکز دارد و برای self-hosting نیز مستندات ارائه می‌کند.

برای معماری v26 مهم است که ابزارهای QA فقط action نباشند؛ validation و evidence باید جزئی از workflow باشند. بنابراین v26 `PolicyEngine` و `EvidenceStore/Oracle` را بیرون از Page-Agent controller نگه می‌دارد.

## BrowserGym / AgentLab

BrowserGym بیشتر یک framework پژوهشی و benchmark environment است تا محصول مصرفی. وجود benchmarkهایی مثل MiniWoB، WebArena، WorkArena و VisualWebArena آن را برای ارزیابی agentها ارزشمند می‌کند، ولی معماری production این پروژه مستقیماً از BrowserGym کپی نشده است.

برای این repo نتیجهٔ عملی این است که علاوه بر unit regression، باید در آینده یک benchmark داخلی از flowهای واقعی PKI، edge caseهای login، OTP/CAPTCHA checkpoints و فرم‌های contract ایجاد شود تا تغییرات agent فقط با تست‌های mock سنجیده نشوند.

## مشکلات مهمی که در v25 باقی بود و در v26 رفع شد

### 1. دو LLM turn برای هر اکشن

**مشکل:** micro-planner قبل/بعد از action اجرا می‌شد و هزینه و latency را بالا می‌برد.

**رفع:** پیش‌فرض `AGENTIC_QA_USE_MICRO_GOAL_PLANNER=0`؛ مدل action را همراه reflection/memory/next_goal برمی‌گرداند. planner قدیمی فقط opt-in است.

### 2. index می‌توانست با DOM mutation silently remap شود

**مشکل:** rebuild در زمان resolve کردن index می‌توانست index قدیمی را به element دیگری وصل کند.

**رفع:** observation map فقط در observe ساخته می‌شود؛ action همان map را استفاده می‌کند و element detach شده را stale گزارش می‌کند.

### 3. Shadow DOM و iframe در state نبودند

**رفع:** open Shadow DOM و same-origin iframe document recursion + `framePath` اضافه شد.

### 4. نام semantic و label ضعیف بود

**رفع:** `aria-label`, `aria-labelledby`, `label[for]`, ancestor label، title، alt، placeholder، name و context در accessible-name استفاده می‌شوند.

### 5. state فقط control list بود

**رفع:** heading/status/alert/log و متن‌های معنی‌دار کنار کنترل‌ها وارد state شده‌اند تا مدل پس‌زمینهٔ واقعی صفحه را ببیند.

### 6. nested scroll درست مدل نشده بود

**رفع:** scroll container یک kind مستقل دارد و `scrollHeight/clientHeight/scrollTop` و evidence قبل/بعد گزارش می‌شوند.

### 7. controlled input / contenteditable شکننده بود

**رفع:** setter framework-aware، `beforeinput/input/change` و fallback برای contenteditable اضافه شده و typing اختیاری با pacing انسانی انجام می‌شود.

### 8. execute JavaScript بیش‌ازحد در معرض مدل بود

**رفع:** از catalog پیش‌فرض حذف شد و فقط با `AGENTIC_QA_ALLOW_EVALUATE=1` و `AGENTIC_QA_ALLOW_AGENT_JS=1` فعال می‌شود.

### 9. ورودی‌های حساس می‌توانستند در action log بمانند

**رفع:** payloadهای `input_text`, `input_text_batch`, `browser_type`, `browser_fill_form` و اجرای JavaScript قبل از ثبت evidence redacted می‌شوند.

## gapهای فعلی که عمداً باز گذاشته شده‌اند

این موارد باگ پنهان نیستند و در نسخهٔ v26 به‌عنوان مرز معماری ثبت شده‌اند:

1. **File upload داخل in-page controller:** JavaScript داخل page نمی‌تواند به‌تنهایی FileList واقعی سیستم را مثل browser automation layer تنظیم کند. برای این مورد باید از upload integration لایهٔ Playwright استفاده شود.
2. **Closed Shadow DOM:** controller جاوااسکریپت فقط open shadow roots را می‌بیند. برای closed shadow DOM باید browser/CDP layer وارد شود.
3. **Cross-origin iframe interaction:** controller همان frame boundary را حفظ می‌کند و bypass نمی‌کند. تعامل کامل باید از browser/CDP layer انجام شود.
4. **Visual/canvas tasks:** DOM-first است و screenshot فقط auxiliary است. برای canvas/chart/layout-heavy flows باید vision mode فعال شود.
5. **Multi-tab orchestration:** در model tool surface اولیه نیست؛ browser/MCP layer قابلیت آن را دارد.
6. **Self-healing locator graph:** recovery فعلی semantic search + fresh state است؛ locator-based self-healing مانند Stagehand هنوز پیاده نشده است.

## نتیجهٔ مهندسی

v26 اکنون از نظر **الگوی agent loop و DOM interaction** به Page Agent نزدیک شده، از نظر **browser surface و evidence** بر Playwright MCP تکیه دارد، از Browser Use ایدهٔ DOM+AX+runtime evidence را گرفته، و از Stagehand/Skyvern الگوهای self-healing/observability/agent-oriented browser APIs را به‌عنوان مسیر توسعه در نظر گرفته است.

بنابراین هدف این نسخه «ساخت دوبارهٔ همهٔ browser automation دنیا» نیست؛ هدف، داشتن یک **QA agent با DOM-first interaction و browser-grade backend** است که سیاست، loop prevention، evidence و verdict را خارج از مدل و قابل‌تست نگه می‌دارد.

## منابع آنلاین بررسی‌شده

- Alibaba Page Agent: https://github.com/alibaba/page-agent
- Alibaba PageAgentCore: https://github.com/alibaba/page-agent/blob/main/packages/core/src/PageAgentCore.ts
- Alibaba architecture notes: https://github.com/alibaba/page-agent/blob/main/AGENTS.md
- Microsoft Playwright MCP snapshots: https://github.com/microsoft/playwright.dev/blob/main/mcp/snapshots.mdx
- Microsoft Playwright MCP introduction: https://github.com/microsoft/playwright.dev/blob/main/mcp/introduction.mdx
- Microsoft Playwright MCP server/tool catalog: https://github.com/microsoft/playwright-mcp
- Browser Use DOM service: https://github.com/browser-use/browser-use/blob/main/browser_use/dom/service.py
- Browser Use repository architecture: https://github.com/browser-use/browser-use
- Stagehand: https://www.stagehand.dev/
- Stagehand overview: https://www.stagehand.dev/blog/what-is-stagehand
- Skyvern docs update: https://www.skyvern.com/blog/new-month-new-docs/
- BrowserGym / AgentLab: https://github.com/ServiceNow/BrowserGym


## v26.2 regression found in real execution — disabled form dependency + resend command

### Observed failure
In a real `explore` run, the agent filled the contract title and immediately targeted the Receiver App combobox. The control was disabled because other form prerequisites had not yet been completed. Because the old Page-Agent state intentionally omitted disabled controls, the model did not have an explicit availability signal and could waste turns trying to open an unavailable control.

A second real failure occurred on the OTP checkpoint: after an invalid OTP, the human replied with an operational instruction (`ارسال مجدد`). The checkpoint handler treated that reply as a value-shaped response instead of a UI command, so the agent repeatedly asked for OTP and never clicked resend or consulted the cooldown.

### v26.2 fix
The browser-side controller now keeps disabled/read-only controls observable and annotates them with runtime state, required/missing/invalid status, likely prerequisite candidates, and countdown evidence. Indexed click/type/select actions reject disabled/read-only targets before execution. The model prompt explicitly prioritizes currently actionable prerequisites over later disabled mission targets.

For interactive checkpoints, common resend/wait commands are recognized as commands rather than OTP/CAPTCHA values. An explicit resend command is executed against a uniquely observed live Page-Agent target; if the resend target is disabled and a countdown is observed, the runtime waits using that observed duration, re-observes, and retries the click. Only after successful resend does the flow request the new OTP.

### Validation
- Python unittest discovery: 87/87 passing
- Python compile: passing
- JavaScript `node --check`: passing
- Added regression coverage for form dependency state, timer exposure, human resend classification, direct resend execution, and cooldown-aware resend recovery.

## v26.4 update — upload and performance

The earlier comparison correctly identified file upload as a gap between an in-page controller and the browser automation layer. v26.4 closes that gap with a first-class `upload_file` agent action mapped to the official Playwright MCP `browser_file_upload` capability. Playwright documents this tool as accepting absolute file paths and uploading them into the file chooser. citeturn187163view2

For action latency, v26.4 also caches the page-local controller installation and prefers one logical `select_dropdown_option` action for a known dropdown. This follows the broader agent pattern used by Stagehand, which recommends cached observations/actions and exposes `act`/`observe` primitives, while still keeping the QA runtime's indexed DOM grounding. citeturn885039search15turn885039search1
