# v16 — Page-Agent-style DOM-first state

- Added a compact Page-Agent-style live interactive state derived entirely from runtime page evidence.
- Interactive/form controls are indexed, include live MCP refs, and retain parent context.
- Generic pointer-interactive elements are included without site-specific labels or selectors.
- The compact interactive state is now the primary LLM browser context; raw accessibility snapshots are fallback evidence.
- Automatic post-action observation is enabled by default so the model does not spend separate reasoning turns requesting snapshots.
- Preserved existing Network/Console, human checkpoints, semantic grounding, navigation provenance, recording, and zero-hardcoding rules.
- No site, route, selector, field name, button text, CAPTCHA/OTP count, or workflow was added.
