# Agentic QA v26.24 — Multi-Strategy URL Resolution + Speed

## Goal
v26.23 added a DOM fallback for the clipboard, but the scan was too
conservative: it only checked leaf text nodes and specific element types.
On the real PKI sandbox (HTTP, not HTTPS), the clipboard API is blocked and
the conservative DOM scan missed the share-link URL, causing the agent to
fall back to clicking rows in the contracts table. v26.24 makes URL
resolution work reliably on HTTP sites by trying four strategies in order,
and reduces per-action latency.

## Root cause
1. `navigator.clipboard.readText()` requires a secure context (HTTPS or
   localhost). `http://sandbox.pki.partdp.ir` is HTTP → clipboard always
   returns empty.
2. The v26.23 DOM fallback only checked:
   - `input.value` / `textarea.value`
   - `a[href]`, `[data-url]`, `[data-href]`
   - leaf text nodes (`el.children.length === 0`) starting with `http`
   It did NOT check `document.body.innerText`, so URLs embedded in dialog
   text like `"لینک قرارداد: https://sign.example.test/portal?token=abc کپی شد"`
   were invisible to the scanner.
3. When both clipboard and DOM scan failed, the error gave the LLM no
   actionable candidates, so it spent ~7 actions wandering through the
   contracts table.

## Changes

### Four-strategy URL resolver
New method `_resolve_application_link_url()` tries in order:
1. **Page-Agent state text** (instant, no browser call): searches
   `self._recent_page_agent_state` for URL patterns. The indexed DOM text
   already contains element values and text content, so any visible URL in
   a readonly input, anchor, or text node is found here without any
   browser round-trip.
2. **Clipboard** (100ms delay): `navigator.clipboard.readText()` wrapped
   in try/catch. Returns empty on HTTP sites.
3. **Aggressive DOM scan** (one `browser_evaluate` call): now collects
   `document.body.innerText` + `document.body.textContent` + all
   `input/textarea` values + all `href`/`data-url`/`data-href`/
   `data-clipboard-text` attributes + shadow DOM root text. Catches URLs
   embedded in any visible text, not just leaf nodes.
4. **Network response evidence**: searches
   `self._last_action_response_evidence` (request URLs, response headers,
   response bodies) for URL patterns. Catches the case where the share
   link is returned by an API call but not rendered in the DOM.

### URL ranking
New method `_extract_all_urls_from_text(text, mission_host)` extracts ALL
valid HTTP(S) URLs from a text blob and ranks them:
1. URLs sharing the mission host AND containing a query/fragment (share
   links almost always carry a token parameter) — highest priority.
2. URLs sharing the mission host with a path.
3. Any other absolute URL with a query/fragment.
4. Any other absolute URL with a path.

This prevents picking CDN/analytics URLs over the real share link.

### Actionable error message
When all four strategies fail, the error now includes any candidate URLs
found in the page-agent state text:
```
could not resolve the application-copied URL: ... Candidate URLs observed
in the current page state: https://sign.example.test/portal?token=abc,
https://app.example.test/dashboard. You can call open_new_tab with one
of these URLs.
```
This lets the LLM immediately use `open_new_tab` with the right URL
instead of wandering through the UI.

### Speed improvements
- Clipboard read delay: 250ms → 100ms.
- New-tab settle delay: 400ms → 200ms.
- Switch-tab settle delay: 300ms → 150ms.
- Page-Agent state text is searched FIRST (instant, no browser call) —
  when the URL is visible in the indexed DOM, no browser_evaluate is
  needed at all.

### Tests
- 6 new regression tests covering: URL ranking, page-agent state
  extraction, body.innerText DOM scan, network evidence extraction, and
  the all-fail error path with candidate hint.
- All 160 tests pass (154 from v26.23 + 6 new).

## Upstream alignment
The Alibaba Page Agent control loop is unchanged. The fix only hardens
the trusted capability layer: the model still chooses one indexed DOM
action per turn and never receives selectors or browser refs. The
multi-strategy resolver is consistent with Page Agent's "ground every
action in the live DOM" principle — when the clipboard is unavailable,
the runtime reads the URL from whatever source the application exposes
(indexed state, raw DOM text, or API response), rather than asking the
model to guess.

## Recommended .env settings for speed
```
AGENTIC_QA_REALISTIC_TYPING=0
AGENTIC_QA_PAGE_AGENT_REALISTIC_TYPING=0
AGENTIC_QA_ACTION_NETWORK_PROBE_MS=300
AGENTIC_QA_FAST_MODE=1
AGENTIC_QA_FAST_PAGE_STATE_CHARS=7000
```
