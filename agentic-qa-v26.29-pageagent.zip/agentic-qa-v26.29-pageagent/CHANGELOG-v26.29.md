# Agentic QA v26.29 — Initial State Retry + Error Reporting

## Goal
v26.28 introduced a regression where the agent finished with INCONCLUSIVE
at 0 actions — the initial `page_agent.state()` call in `run_goal` was
failing (likely due to the page still loading or the controller needing
a re-install after navigation), and the failure was silently caught
without any error message visible to the user.

## Root cause
The `run_goal` method's initial Page-Agent state observation had a single
try/except that bundled `page_agent.state()` and `_prime_network_cursor()`
together. If either failed, the mission ended immediately with
INCONCLUSIVE and 0 actions, with no visible error message.

The most common trigger was a timing issue: after `browser.navigate()`,
the page may still be rendering (SPA route change, async data loading).
The first `page_agent.state()` call (in the explorer) might succeed on
a partially-loaded DOM, but the second call (in `run_goal`) might fail
if the page re-rendered and invalidated the controller.

## Changes

### Retry mechanism for initial state observation
`run_goal` now retries `page_agent.state()` up to 3 times with a 500ms
delay between retries. Each retry calls `mark_page_changed()` to force
the controller to re-install on the current page. This handles:
- Page still loading after navigation
- SPA route changes that invalidate the controller
- Transient `browser_evaluate` timeouts

### Separated `_prime_network_cursor()` from state observation
`_prime_network_cursor()` is now in its own try/except block. If it fails
for any reason (network tools unavailable, MCP error, parse error), the
mission continues — network correlation is best-effort, not a hard
dependency.

### Explorer: settle delay after navigation
The explorer now waits 500ms after `browser.navigate()` before calling
`page_agent.state()`. This gives SPA pages time to finish their initial
route render before the DOM is extracted.

### Explorer: error reporting
The explorer now:
- Catches and logs initial `page_agent.state()` failures instead of
  crashing (run_goal has its own retry).
- Prints `failure_reason` when the outcome has 0 actions, so the user
  can see exactly why the mission ended early instead of a mysterious
  "INCONCLUSIVE (0 actions)".

### Tests
- All 180 existing tests still pass.
- No new tests needed — the change is in error handling/retry logic
  that's difficult to unit-test without a real browser.

## Upstream alignment
The Alibaba Page Agent control loop is unchanged. The fix only makes
the initial observation more resilient to page-load timing issues and
gives the user visibility into failures.
