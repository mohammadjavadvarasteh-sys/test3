# Agentic QA v26.26 — External-Host Share Link + Token-Aware Ranking

## Goal
v26.25 fixed the same-host trusted-provenance policy, but the URL
resolver still had two bugs that prevented external-host share links
(like `https://sign-sandbox.farashenasa.ir/#/portal?token=...`) from
being opened:

1. The resolver tried page-agent state text FIRST. The state text
   contains same-host navigation links (e.g. `https://sandbox.pki.partdp.ir/dashboard`),
   which ranked higher than the external share link. So the resolver
   picked a wrong same-host URL and never even tried the clipboard.

2. The URL ranking preferred same-host URLs over external URLs with
   tokens. A share link like `https://sign-sandbox.farashenasa.ir/#/portal?token=abc`
   scored lower than a same-host nav link, even though the share link
   is clearly the intended target.

## Root cause
The real PKI sandbox uses a separate signing host (`sign-sandbox.farashenasa.ir`)
for the contract signing portal. The share link copied by the app points
to this external host, with the token embedded in the URL fragment
(SPA hash-routing pattern: `/#/portal?token=...`).

The v26.25 resolver order was:
1. page_agent_state text → picks first URL found, with same-host preference
2. clipboard → never reached if state text had any URL
3. DOM scan
4. network evidence

Since the contracts page always has same-host nav links in its DOM,
strategy 1 picked a wrong URL and returned immediately.

## Changes

### Resolver: clipboard FIRST
`_resolve_application_link_url()` now tries the clipboard before
anything else. The clipboard is the most reliable source after a
'copy link' click — it contains exactly the URL the application
intended to share.

New order:
1. **Clipboard** (navigator.clipboard.readText) — works on HTTPS,
   returns empty on HTTP.
2. **Page-Agent state text** — fallback for HTTP sites. Uses
   token-aware ranking (see below) so share links rank above nav links.
3. **Aggressive DOM scan** — body innerText + inputs + hrefs + shadow.
4. **Network response evidence** — API-returned link.

### Token-aware URL ranking
`_extract_all_urls_from_text()` now ranks URLs with a 4-tuple score:
1. `has_token` — 'token' appears anywhere in the URL string (query or
   fragment). This is the **strongest** signal and ranks ABOVE host_match.
   Catches both `?token=...` and `#/portal?token=...` (SPA hash routing).
2. `host_match` — URL shares the mission host.
3. `token_like` — URL has a query or fragment.
4. `has_path` — URL has a non-root path.

This means an external share link like
`https://sign-sandbox.farashenasa.ir/#/portal?token=abc` now ranks
ABOVE a same-host nav link like `https://sandbox.pki.partdp.ir/dashboard`.

### Tests
- 3 new regression tests covering: token URL ranks above same-host nav
  URL, resolver tries clipboard before state text, and end-to-end
  open_application_link with the exact farashenasa share link from the
  user's real run.
- All 169 tests pass (166 from v26.25 + 3 new).

## Upstream alignment
The Alibaba Page Agent control loop is unchanged. The fix only corrects
the URL resolution order and ranking so that the clipboard (the most
direct source after a copy action) is tried first, and token-bearing
share links are preferred over same-host navigation links.
