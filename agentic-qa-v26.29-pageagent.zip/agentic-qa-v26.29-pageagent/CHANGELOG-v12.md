# v12

- Restored fast default execution: automatic full snapshots after every mutating action are OFF by default.
- Run recording is OFF by default because a screenshot per action adds a browser round-trip on every step.
- Recording remains fully available with `AGENTIC_QA_RECORD_RUN=1`.
- Added `AGENTIC_QA_RECORD_EVERY_N_ACTIONS` (default `3`) to sample frames instead of capturing every action.
- Recording output remains under `.evidence/runs/<run-id>/` alongside the run evidence.
- No site-specific selectors, labels, URLs, routes, credentials, or workflow hardcoding added.
