# Changelog v11

## Combined runtime UI grounding

- Added a compact-first `ACTIONABLE UI MAP` to structural observations.
- The map is derived only from the live accessibility snapshot at runtime.
- Includes semantic interactive roles and generic elements with observed interaction evidence such as `cursor=pointer` / `onclick`.
- Actionable controls are surfaced before the large raw snapshot so important controls near the end of a page are not lost to context limits.
- Generic clickable elements can now be grounded without hard-coded labels, selectors, routes, domains, or workflows.
- Updated the agent constitution/addressing guidance to treat the actionable UI map as first-class evidence.
- Added regression coverage for generic clickable elements and runtime-only grounding.
