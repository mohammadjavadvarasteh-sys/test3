# Agentic QA v26.27 — Vue/React Input Field Fix

## Goal
The agent was stuck in an infinite loop trying to fill the mobile number
field on the Farashenasa sign portal. The field used a Vue `base-text-field`
component with `v-model`, and the runtime's `input_text` action appeared
to succeed (no error) but the value never actually stuck — the agent
retried 13+ times until the budget ran out.

## Root cause
The `input()` function in `page_agent_controller.js` had three problems
with framework-controlled inputs (Vue `v-model`, React controlled inputs):

1. **`el.blur()` after typing.** The function called `el.blur()` at the
   end. Vue components with `v-model` or `v-model.lazy` often re-sync
   from their internal model on blur — if the model wasn't updated (or
   the value failed validation), the component reverts the input to
   empty. So the value appeared to stick for 30ms, then disappeared on
   blur.

2. **No verification.** The function returned `{success: true}` without
   checking whether the value actually stuck. The agent had no way to
   know the input failed, so it retried the same action — wasting the
   entire budget on a single field.

3. **Generic `Event` instead of `InputEvent`.** Vue/React `v-model`
   listeners listen for `InputEvent` (which has a `data` field), not
   generic `Event`. The old `dispatchInputEvents` used `new win.Event("input")`,
   which some framework listeners ignored.

## Changes

### No blur after typing
The `input()` function no longer calls `el.blur()`. The input keeps
focus, so the Vue/React model stays in sync with the input until the
next action explicitly moves focus.

### Value verification + fallback chain
The `input()` function now verifies the value stuck and tries multiple
methods if it didn't:

1. **Method 1: native value setter + InputEvent.** Uses the prototype
   setter and dispatches a proper `InputEvent` (with `data` field) so
   Vue/React `v-model` listeners can process it.

2. **Method 2: `execCommand("insertText")`.** If method 1 didn't stick,
   tries the deprecated but widely-supported `execCommand` path, which
   fires a real trusted input event that frameworks cannot ignore.
   Selects existing content first, then replaces it.

3. **Method 3: character-by-character native setter.** If execCommand
   also didn't stick, types one character at a time with a 10ms delay
   between chars, letting the framework process each input event
   individually.

After all methods, the function verifies the actual value and returns:
```js
{
  success: true,
  message: "Input text into element [5] (method=execCommand_insertText, value_length=11)",
  value_stuck: true,
  actual_length: 11,
  expected_length: 11,
  method: "execCommand_insertText"
}
```
If the value didn't stick, the message tells the agent why:
```
Input attempted on element [5] (method=char_by_char) but value did not
stick — expected length 11, got 0. The field may have validation that
rejects this value, or the framework reverted it.
```

### InputEvent instead of generic Event
`dispatchInputEvents()` now uses `new win.InputEvent("input", {...})`
when available (with `data` field), falling back to `new win.Event(...)`
only if `InputEvent` is not supported.

### Tests
- 5 new regression tests covering: no blur after typing, value_stuck
  field in return, execCommand fallback, char_by_char fallback, and
  InputEvent usage.
- All 174 tests pass (169 from v26.26 + 5 new).

## Upstream alignment
The Alibaba Page Agent control loop is unchanged. The fix only hardens
the in-page controller's `input()` function so it works reliably with
framework-controlled inputs (Vue/React) that revert values on blur or
ignore synthetic events.
