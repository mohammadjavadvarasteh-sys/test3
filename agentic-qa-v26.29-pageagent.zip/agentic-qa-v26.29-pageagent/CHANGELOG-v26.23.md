# Agentic QA v26.23 — Clipboard / New-Tab Follow-Through Fix

## Goal
Close the gap that caused the agent to wander back to the contracts list
after clicking "کپی لینک" instead of following the copied link into the new
tab where the signing/KYC flow continues. The fix keeps the Alibaba Page-Agent
execution model intact (Live DOM → indexed state → one action → refreshed
state) and only hardens the trusted capability layer that sits outside the
in-page controller.

## Root cause
1. `navigator.clipboard.readText()` requires a secure context (HTTPS or
   localhost). The sandbox site (`http://sandbox.pki.partdp.ir`) is HTTP, so
   the clipboard read returned empty/error and `open_application_link`
   raised `MCPError("clipboard does not contain a valid HTTP(S) URL")`.
2. After the AUTO_FOLLOW path skipped (or after an explicit
   `open_application_link` failed), the model had no fallback signal, so it
   re-observed the OLD tab (the contracts list) and started clicking rows
   there.
3. Even when `browser_tabs` action="new" succeeded, the in-page
   PageAgentController's `_installed` flag was NOT invalidated, so the next
   `state()` call could keep reading the OLD tab's controller instead of
   re-installing on the NEW tab.

## Changes

### Clipboard resolution with DOM fallback
- `_read_application_clipboard()` is now non-throwing: it tries
  `navigator.clipboard.readText()` (wrapped in try/catch on the page side)
  and returns `""` when the clipboard API is blocked (HTTP sites, missing
  permissions, async write not yet flushed). A short 250 ms delay gives the
  application time to complete the clipboard write.
- `_scan_dom_for_share_link()` is a new fallback that walks the live DOM
  for an absolute HTTP(S) URL the application is rendering — readonly
  inputs, textareas, anchor hrefs, `data-url`/`data-href` attributes, and
  leaf text nodes. URLs that share the mission host are preferred; only an
  explicitly rendered URL is used (no construction, no guessing).
- `_open_application_clipboard_link()` now runs the clipboard reader first
  and falls back to the DOM scan. When both fail it raises a clear
  `MCPError` so the model knows to look for the URL in the DOM directly
  or finish BLOCKED — not to loop on `read_clipboard`.

### Tab focus invalidation
- After `browser_tabs` action="new" (open_application_link, open_new_tab)
  and `browser_tabs` action="select" (switch_tab), the runtime now calls
  `page_agent.mark_page_changed()` so the in-page controller is
  re-installed on the NEW active tab. A short settle delay (300–400 ms)
  lets the new page finish its initial navigation before the indexed DOM
  is read.
- The same invalidation is applied to `navigate` (current-tab navigation).

### Clearer observation feedback
- `open_application_link` returns: `CLIPBOARD_LINK_OPENED: ... opened in a
  NEW browser tab. The CURRENT active tab is now the NEW tab. ... Do NOT
  call read_clipboard or open_application_link again; do NOT go back to the
  contracts list. Continue the mission on the NEW tab.`
- `open_new_tab`, `switch_tab`, and `navigate` observations now append a
  `NEW_TAB_FOCUS` / `TAB_FOCUS` / `NAVIGATION_COMPLETED` suffix telling
  the model that the page has changed and that the CURRENT PAGE STATE
  indices come from the new page.
- The AUTO_FOLLOW path re-reads the page-agent state after a successful
  clipboard follow so the loop's later state-based guards use the NEW tab.

### Prompt hardening (RESPONSE_PROTOCOL, ADDRESSING_PROMPT, fast-addressing)
- Added a binding `TAB & CLIPBOARD RULES` block to RESPONSE_PROTOCOL:
  after `open_application_link`/`open_new_tab` the current tab is the NEW
  tab; do NOT call `read_clipboard` afterwards; do NOT go back to the
  previous tab; if `open_application_link` fails, do NOT loop on
  `read_clipboard` — look for the URL in the live DOM or finish BLOCKED.
- Documented `find_elements`, `input_text_batch`, `upload_file`,
  `open_application_link`, `read_clipboard`, `open_new_tab`, `switch_tab`,
  and `navigate` in the RESPONSE_PROTOCOL tool catalog so the model knows
  exactly when to use each.
- Added the same TAB & CLIPBOARD rule to ADDRESSING_PROMPT and to the
  fast-actor addressing block.
- Re-added `RESEND command is handled by runtime` to RESPONSE_PROTOCOL
  (was dropped in an earlier refactor, causing a pre-existing test
  failure).

### Tests
- 12 new regression tests covering: `_extract_url_from_text` (bare, quoted,
  embedded, non-URL), clipboard-empty DOM fallback, both-fail error path,
  `mark_page_changed` invalidation after new tab, observation feedback
  wording, and the new prompt rules.
- All 154 tests pass (142 original + 12 new).

## Upstream alignment
The Alibaba Page Agent control loop (Observe → Reflect → One Action →
Re-observe) is preserved. The fix only hardens the trusted capability
layer that sits outside the in-page PageController — the model still
chooses one indexed DOM action per turn and never receives selectors or
browser refs. The DOM fallback for the clipboard is consistent with Page
Agent's "ground every action in the live DOM" principle: when the
clipboard API is unavailable, the runtime reads the URL the application
itself is rendering, rather than asking the model to guess.
