# v6 Architecture Fix — Semantic Selection + State-Aware Loop Detection

## Root causes

1. The loop fingerprint preferred the human-readable `element` description over the live MCP `target`/`ref`. Two different live elements could therefore collapse into the same loop identity.
2. The previous loop detector treated repeated state hashes and action cycles globally. Valid state transitions could be mistaken for loops.
3. Semantic validation only evaluated the currently targeted control. When that control had no match, the executor did not expose runtime evidence about another observed control containing the requested semantic match.

## Architecture changes

- Loop identity now prefers `target`/`ref` and includes before/after state hashes.
- A loop is flagged only for the same action + same target + unchanged relevant state repeated without progress.
- Different targets are distinct even when their semantic descriptions are identical.
- The same target is allowed again when the UI state changes.
- Valid dropdown progression such as OPEN -> OBSERVE -> SELECT is not considered a loop.
- `PolicyEngine.semantic_option_evidence()` discovers matching options across all observed combobox/listbox controls using only the live accessibility snapshot.
- A select action with a non-matching candidate is rejected before MCP execution; when another observed control contains a semantic match, that evidence is returned to the agent so it can continue with the matching control.
- No site-specific selector, URL, route, domain, label, credential, or application value was added.

## Verification

- `python -m compileall -q .` — PASS
- Regression suite — 40/40 PASS
- Forbidden site-specific hard-code scan — PASS
- First/default/closest selection logic scan — no executable fallback logic found

## v6 follow-up — mission input reuse

- Added `engine/mission_inputs.py` with a generic immutable mission-input ledger.
- Runtime now preserves literal values explicitly supplied in the mission.
- Human confirmations such as `same` / `همونه` can resolve to a single mission value explicitly referenced by the clarification question.
- CAPTCHA/OTP behavior remains human-gated; no guessing or automatic visual-value substitution was added.
- Added regression tests for mission-value preservation, confirmation resolution, ambiguity rejection, and non-confirmation handling.
