#!/usr/bin/env python3
# =====================================================================
# agentic-qa — main.py (CLI)
# ---------------------------------------------------------------------
# دو نوع تست + سه قابلیت تولید + پنل وب (اختیاری):
#
#   python main.py run specs/pki_login.yaml          # ۱) Spec-Driven
#   python main.py explore --url https://...         # ۲) Explorer
#   python main.py spec --url https://... --goal ... # ۳) ساخت خودکار Spec
#   python main.py gen-spec --source ../my-webapp    # ۴) سورس → Spec
#   python main.py to-spec <run_id> | --last         # ۵) اجرا → Spec
#        (از شواهد یک اجرای explorer که انجام شده،
#         Spec قابل بازاجرایی می‌سازد و ذخیره می‌کند)
#
#   python main.py panel [--port 8787]               # ۶) پنل وب (اختیاری)
#   python main.py runs                              # لیست اجراها
#   python main.py doctor                            # چک سلامت
#   python main.py skills [list|show <name>]         # دیدن skill ها
# =====================================================================

import argparse
import json
import os
import sys

# تا خروجی فارسی در ترمینال ویندوز هم درست باشد
try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:                                          # noqa: BLE001
    pass

import config


# =====================================================================
# run — حالت spec-driven
# =====================================================================

def _configure_stdio():
    """Make CMD output visible immediately during long model/tool turns."""
    import sys
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(line_buffering=True, write_through=True)
        except Exception:
            pass



def cmd_run(args):
    from engine.spec_runner import SpecDrivenRunner
    from engine.reporter import print_terminal_report, write_html_report

    if not os.path.exists(args.spec):
        print(f"❌ spec file not found: {args.spec}")
        return 2

    runner = SpecDrivenRunner(
        args.spec,
        allow_destructive=args.allow_destructive,
        max_actions=args.budget,
    )
    verdict = runner.run()

    print_terminal_report(runner.store, runner.results, runner.feature)
    write_html_report(
        runner.store, runner.results, runner.feature,
        title=f"گزارش تست Spec-Driven — {runner.feature}",
    )

    return {
        "PASSED": 0, "FAILED": 1,
        "PARTIAL": 2, "INCONCLUSIVE": 3,
    }.get(verdict, 1)


# =====================================================================
# explore — حالت explorer
# =====================================================================

def cmd_explore(args):
    from engine.explorer import ExploratoryRunner
    from engine.reporter import write_html_report

    if not args.url:
        print("❌ --url is required for explore")
        return 2

    runner = ExploratoryRunner(
        base_url=args.url,
        intent=args.intent,
        budget=args.budget,
        mission_id=args.mission_id,
        allow_destructive=args.allow_destructive,
    )
    result = runner.run()

    # explorer یافته دارد نه verdict (اصل #8) — گزارش بر همان اساس
    fake_results = [
        {
            "id": f.get("id", "?"),
            "verdict": "INCONCLUSIVE",
            "description": f.get("description", ""),
            "reason": f"finding [{f.get('severity')}]",
        }
        for f in result.get("findings", [])
    ]
    write_html_report(
        runner.store, fake_results, runner.mission_id,
        title=f"گزارش اکتشاف — {runner.mission_id}",
    )

    if result.get("generated_spec"):
        print(f"\n💡 برای اجرای قطعی مسیر کشف‌شده:")
        print(f"   python main.py run {result['generated_spec']}")
    return 0


# =====================================================================
# gen-spec — سورس‌کد → Spec
# =====================================================================

def cmd_gen_spec(args):
    from engine.spec_generator import SpecGenerator

    if not os.path.isdir(args.source):
        print(f"❌ source directory not found: {args.source}")
        return 2

    generator = SpecGenerator(
        source_path=args.source,
        out_dir=args.out,
        max_files=args.max_files,
        base_url=args.base_url,
    )
    written = generator.generate()

    if written:
        print(f"\n✅ {len(written)} spec(s) generated:")
        for p in written:
            print(f"   - {p}")
        print(f"\n💡 اجرا: python main.py run {written[0]}")
        return 0
    return 1


# =====================================================================
# to-spec — اجرای گذشته → Spec قابل بازاجرایی
# =====================================================================

def cmd_to_spec(args):
    from engine.spec_extractor import (
        SpecExtractor, resolve_run, spec_from_run,
    )
    from engine.ai_client import AIClient

    try:
        run_dir = resolve_run(args.run, last=args.last)
    except ValueError as e:
        print(f"❌ {e}")
        return 2

    print("🔄 استخراج Spec از اجرا...")
    print(f"   run     : {os.path.basename(run_dir)}")

    extractor = SpecExtractor(run_dir)
    print(f"   actions : {len(extractor.actions)} recorded, "
          f"status={getattr(extractor, 'status', '?')}")

    ai = AIClient() if args.polish else None
    path = spec_from_run(run_dir, out_path=args.out, polish=args.polish,
                         ai=ai)
    if not path:
        print("⚠️ این اجرا مسیر قابل استخراجی ندارد "
              "(فقط مشاهده/اکشن ناموفق ثبت شده است)")
        return 1

    import yaml as _yaml
    with open(path, "r", encoding="utf-8") as f:
        data = _yaml.safe_load(f)
    n = len((data or {}).get("steps") or [])

    print(f"\n✅ Spec ساخته شد: {path}")
    print(f"   {n} steps")
    print(f"\n💡 بازاجرای قطعی (به‌جای explorer):")
    print(f"   python main.py run {path}")
    return 0


# =====================================================================
# spec — ساخت خودکار فایل Spec (URL + هدف)
# =====================================================================

def cmd_spec(args):
    from engine.spec_writer import draft_spec, save_spec, slugify

    print("🪄 ساخت خودکار Spec...")
    print(f"   url  : {args.url}")
    print(f"   goal : {args.goal[:100]}")
    if args.no_ai:
        print("   ai   : off (قالب حداقلی — بدون LLM)")

    spec, source = draft_spec(
        args.url, args.goal, name=args.name,
        max_steps=args.max_steps, use_ai=not args.no_ai,
    )

    # مسیر خروجی
    if args.out:
        out_path = args.out
    else:
        base = slugify(args.name or args.goal, "spec")
        if args.project:
            pdir = os.path.join(config.PROJECT_ROOT, "projects",
                                args.project, "specs")
        else:
            pdir = os.path.join(config.PROJECT_ROOT, "specs")
        out_path = os.path.join(pdir, f"{base}.yaml")
        i = 2
        while os.path.exists(out_path):
            out_path = os.path.join(pdir, f"{base}-{i}.yaml")
            i += 1

    save_spec(spec, out_path)

    n = len(spec.get("steps") or [])
    mode = "پیش‌نویس هوشمند (LLM)" if source == "ai" else \
        "قالب حداقلی (LLM در دسترس نبود)"
    print(f"\n✅ Spec ساخته شد: {out_path}")
    print(f"   {n} steps · {mode}")
    if source == "template":
        print("   💡 با LLM در دسترس، قدم‌ها دقیق‌تر پیش‌نویس می‌شوند")
    print(f"\n💡 قبل از اجرا بازش کنید و مقدارها را تنظیم کنید، بعد:")
    print(f"   python main.py run {out_path}")
    print(f"   python main.py panel   ← یا از پنل وب اجرا کنید")
    return 0


# =====================================================================
# panel — پنل وب اختیاری
# =====================================================================

def cmd_panel(args):
    from engine.panel.server import run_panel
    return run_panel(
        host=args.host, port=args.port,
        open_browser=not args.no_open,
    )


# =====================================================================
# runs — لیست اجراهای گذشته
# =====================================================================

def cmd_runs(args):
    from engine.spec_extractor import list_runs

    rows = list_runs()
    if not rows:
        print(f"هنوز اجرایی ثبت نشده (.evidence/runs)")
        return 0

    print(f"📁 {len(rows)} run(s) در .evidence/runs — از جدید به قدیم:\n")
    for r in rows[:30]:
        print(f"  {r['run_id']:36s} {r['type']:12s} "
              f"{str(r['actions']):>4s} ac  {r['intent']}")
    print(
        "\n💡 ساخت Spec از هر اجرا:  "
        "python main.py to-spec <run_id>"
    )
    print(  "   جدیدترین اجرا:        "
            "python main.py to-spec --last")
    return 0


# =====================================================================
# doctor — چک سلامت
# =====================================================================

def cmd_doctor(args):
    print("🩺 agentic-qa doctor")
    print("=" * 56)
    ok = True

    # 1) python
    print(f"  python          : {sys.version.split()[0]}")

    # 2) .env / config
    env_path = os.path.join(config.PROJECT_ROOT, ".env")
    print(f"  .env            : "
          + ("✓ found" if os.path.exists(env_path)
             else "✗ not found (copy .env.example → .env)"))
    print(f"  AI endpoint     : {config.AI_BASE_URL}")
    print(f"  AI model        : {config.AI_MODEL}")

    # 3) AI ping
    try:
        from engine.ai_client import AIClient
        reply = AIClient().ping()
        print(f"  AI reachable    : ✓ ({reply[:40]})")
    except Exception as e:                              # noqa: BLE001
        ok = False
        print(f"  AI reachable    : ✗ ({str(e)[:90]})")

    # 4) node / npx / global mcp
    import shutil
    node = shutil.which("node")
    print(f"  node            : "
          + (f"✓ {node}" if node else "✗ NOT FOUND — install Node.js"))
    if not node:
        ok = False

    npx = shutil.which("npx")
    global_bin = None
    for _bin in config.MCP_GLOBAL_BINS:
        _found = shutil.which(_bin)
        if _found:
            global_bin = _found
            break
    if global_bin:
        print(f"  MCP global      : ✓ {global_bin}")
    else:
        print("  MCP global      : - (not installed)")
        print("                    پیشنهاد: npm install -g @playwright/mcp")
        print(f"  npx fallback    : "
              + (f"✓ {npx}" if npx else "✗ NOT FOUND")
              + ("" if npx else " — install Node.js"))
        if not npx:
            ok = False

    # 5) MCP سرور واقعاً بالا می‌آید؟
    if args.full and (node or npx or global_bin):
        try:
            from engine.mcp_client import PlaywrightMCPBrowser
            browser = PlaywrightMCPBrowser()
            browser.start()
            sample = ", ".join(sorted(browser.tools.keys())[:6])
            browser.close()
            print(f"  MCP handshake   : ✓ "
                  f"({len(browser.tools)} tools, e.g. {sample}…)")
        except Exception as e:                          # noqa: BLE001
            ok = False
            print(f"  MCP handshake   : ✗ ({str(e)[:120]})")

    # 6) skills / rules / steering
    from engine.skill_loader import SkillLoader
    skills = SkillLoader().available()
    print(f"  skills          : {len(skills)} loaded "
          + ("✓" if len(skills) >= 5 else "✗ too few"))

    rules = [f for f in ("safety.yaml", "execution.yaml", "evidence.yaml",
                         "validation.yaml", "security.yaml")
             if os.path.exists(os.path.join(config.RULES_DIR, f))]
    print(f"  rules           : {len(rules)}/5 yaml files")

    secrets = os.path.join(config.STEERING_DIR, "secrets.yaml")
    print(f"  steering secrets: "
          + ("✓ found" if os.path.exists(secrets)
             else "- optional (for {secret:...} placeholders)"))

    print("=" * 56)
    print("  " + ("✅ همه‌چیز آماده است" if ok
                 else "⚠️ برخی موارد نیازمند اصلاح‌اند"))
    return 0 if ok else 1


# =====================================================================
# skills — دیدن skill ها
# =====================================================================

def cmd_skills(args):
    from engine.skill_loader import SkillLoader
    loader = SkillLoader()

    if args.action == "show" and args.name:
        content = loader.get(args.name)
        if not content:
            print(f"❌ skill '{args.name}' not found")
            return 1
        print(content)
        return 0

    rows = loader.describe_all()
    print(f"🧩 {len(rows)} skills in {config.SKILLS_DIR}\n")
    for row in rows:
        print(f"  {row['skill']:24s} — activates: {row['activates']}")
    return 0


# =====================================================================
# parser
# =====================================================================

def build_parser():
    parser = argparse.ArgumentParser(
        prog="agentic-qa",
        description="Agentic QA — spec-driven & exploratory testing "
                    "via Playwright MCP (no hard-coded selectors)",
    )
    sub = parser.add_subparsers(dest="command")

    # run
    p_run = sub.add_parser("run", help="run a spec (spec-driven test)")
    p_run.add_argument("spec", help="path to .yaml/.json spec file")
    p_run.add_argument("--budget", type=int, default=None,
                       help="override max actions for this run")
    p_run.add_argument("--allow-destructive", action="store_true",
                       help="allow destructive action patterns "
                            "(safety.yaml)")
    p_run.set_defaults(func=cmd_run)

    # explore
    p_exp = sub.add_parser("explore", help="exploratory test session")
    p_exp.add_argument("--url", required=True, help="entry URL")
    p_exp.add_argument("--intent", default="",
                       help="mission intent (مثلاً: 'فرم ورود را تست کن')")
    p_exp.add_argument("--budget", type=int, default=60,
                       help="max actions (default 60 — complex flows with "
                            "captcha/OTP and forms need headroom)")
    p_exp.add_argument("--mission-id", default=None)
    p_exp.add_argument("--allow-destructive", action="store_true")
    p_exp.set_defaults(func=cmd_explore)

    # gen-spec
    p_gen = sub.add_parser("gen-spec", help="read project source code "
                                            "and generate specs")
    p_gen.add_argument("--source", required=True,
                       help="path to the web project source")
    p_gen.add_argument("--out", default=None,
                       help="output dir (default generated/specs)")
    p_gen.add_argument("--base-url", default=None,
                       help="base URL to bake into generated specs")
    p_gen.add_argument("--max-files", type=int, default=120)
    p_gen.set_defaults(func=cmd_gen_spec)

    # to-spec
    p_ts = sub.add_parser(
        "to-spec",
        help="از شواهد یک اجرای explorer گذشته، Spec قابل بازاجرایی "
             "بساز و ذخیره کن (بعد با 'run' اجرا شود)")
    p_ts.add_argument("run", nargs="?", default=None,
                      help="run id (مثل exploratory-1789165500) یا مسیر "
                           "پوشه اجرا — بدون مقدار: لیست اجراها")
    p_ts.add_argument("--last", action="store_true",
                      help="جدیدترین اجرا را استفاده کن")
    p_ts.add_argument("--out", default=None,
                      help="مسیر خروجی (پیش‌فرض: generated/from-run-<id>.yaml)")
    p_ts.add_argument("--polish", action="store_true",
                      help="توصیف قدم‌ها با LLM طبیعی‌تر بازنویسی شود")
    p_ts.set_defaults(func=cmd_to_spec)

    # spec (ساخت خودکار)
    p_spec = sub.add_parser(
        "spec", help="ساخت خودکار فایل Spec از URL + هدف "
                     "(قدم‌ها با LLM پیش‌نویس می‌شوند؛ بدون LLM قالب "
                     "حداقلی)")
    p_spec.add_argument("--url", required=True,
                        help="آدرس صفحه‌ی شروع (target_url)")
    p_spec.add_argument("--goal", required=True,
                        help="هدف تست به زبان آزاد "
                             "(مثلاً: 'ورود با کدملی و کپچا')")
    p_spec.add_argument("--name", default=None,
                        help="نام فایل/feature (پیش‌فرض: از هدف ساخته "
                             "می‌شود)")
    p_spec.add_argument("--out", default=None,
                        help="مسیر خروجی (پیش‌فرض: specs/<name>.yaml)")
    p_spec.add_argument("--project", default=None,
                        help="ذخیره در projects/<id>/specs (پروژه‌ی "
                             "موجود)")
    p_spec.add_argument("--max-steps", type=int, default=10,
                        help="حداکثر تعداد قدم‌های پیش‌نویس (پیش‌فرض ۱۰)")
    p_spec.add_argument("--no-ai", action="store_true",
                        help="بدون هوش مصنوعی — فقط قالب حداقلی")
    p_spec.set_defaults(func=cmd_spec)

    # panel (پنل وب — اختیاری)
    p_panel = sub.add_parser(
        "panel", help="پنل وب اختیاری — همه‌ی قابلیت‌ها از مرورگر "
                      "(پروژه‌ها، اجرای Spec، اکتشاف، پرسش کپچا/OTP، "
                      "گزارش‌ها)")
    p_panel.add_argument("--host", default=config.PANEL_HOST,
                         help=f"آدرس bind (پیش‌فرض {config.PANEL_HOST})")
    p_panel.add_argument("--port", type=int, default=config.PANEL_PORT,
                         help=f"پورت (پیش‌فرض {config.PANEL_PORT})")
    p_panel.add_argument("--no-open", action="store_true",
                         help="مرورگر خودکار باز نشود")
    p_panel.set_defaults(func=cmd_panel)

    # runs
    p_runs = sub.add_parser("runs", help="لیست اجراهای گذشته "
                                           "(.evidence/runs)")
    p_runs.set_defaults(func=cmd_runs)

    # doctor
    p_doc = sub.add_parser("doctor", help="health check")
    p_doc.add_argument("--full", action="store_true",
                       help="also test MCP server handshake (starts "
                            "browser server)")
    p_doc.set_defaults(func=cmd_doctor)

    # skills
    p_sk = sub.add_parser("skills", help="list / show skills")
    p_sk.add_argument("action", nargs="?", default="list",
                      choices=["list", "show"])
    p_sk.add_argument("name", nargs="?", default=None)
    p_sk.set_defaults(func=cmd_skills)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return 0
    try:
        return args.func(args)
    except KeyboardInterrupt:
        print("\n⛔ interrupted by user")
        return 130
    except ValueError as e:
        print(f"❌ {e}")
        return 2


if __name__ == "__main__":
    sys.exit(main())
