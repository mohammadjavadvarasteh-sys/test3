# v26.19 — Async/Loading Precision

- Scope BUSY/LOADING detection to the action semantic surface.
- Completed correlated network activity suppresses stale UI busy flags.
- `aria-busy` / `data-loading` alone are advisory; require a concrete second signal.
- Replace long blind busy waits with a short 400ms runtime verification window when no correlated request is observed.
- Dropdown selects get network correlation only when their target is actually busy.
- Model wait policy now forbids blind waits for generic loading/pending states.
- Reduced default busy network probe window from 8s to 1.5s.
