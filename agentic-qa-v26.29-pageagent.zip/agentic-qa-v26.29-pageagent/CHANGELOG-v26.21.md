# Agentic QA v26.21 — Alibaba Page-Agent Execution Model

## Goal
The browser actor now follows the same core execution shape as Alibaba Page Agent:
Live DOM → simplified indexed state → LLM reflection → one indexed action → refreshed state.

## Changes
- Removed the default hidden fast-form-fill bypass; every browser mutation is model-selected and observable.
- Tightened the model contract to one action per turn.
- Added explicit observe/reflect/action/observe protocol.
- Uses temporary live DOM indices; stale indices are never valid after state changes.
- Kept QA-specific evidence, policy, OTP/CAPTCHA, findings and verdict layers outside the Page-Agent control loop.
- Kept the in-page DOM controller and text-based interaction model; no screenshots are required for normal targeting.

## Upstream alignment
Alibaba Page Agent uses a PageController abstraction, flattened/dehydrated DOM state, indexed actions and an iterative agent loop. This version mirrors that control architecture while retaining the project's QA safety/evidence layer.
