# v25 — Micro-Goal Planner / Actor / Verify Loop

## Why
The previous Page-Agent loop was atomic at the tool level, but the LLM still
received the entire mission and could spend turns enumerating a whole form or
guessing what to do next. v25 separates planning from acting.

## Architecture
`Mission -> MicroGoalPlanner -> Actor -> Live Page-Agent State -> MicroGoalPlanner`

The planner chooses exactly one unfinished objective. The actor sees that
objective and performs one atomic browser operation. After every action the
planner is called again with the fresh Page-Agent state and the latest action
result. The browser action budget is unchanged; planner calls are observation/
planning calls and do not consume browser actions.

## Guarantees
- One micro-goal at a time.
- No multi-step plan is sent to the actor.
- Completed micro-goals are tracked to prevent immediate repetition.
- Mission-provided literal values remain immutable.
- Dropdowns must be resolved from the NEW live state after opening.
- Existing Page-Agent index grounding, scroll guard, no-effect protection,
  human checkpoint lifecycle, and zero-hardcoding rules remain intact.
- Planner failure falls back to the current micro-goal rather than inventing a
  new objective.

## Validation
- 75 regression tests pass.
- Python compileall passes.
- Page-Agent controller Node syntax check passes.
- Generic engine hardcode scan is clean.
