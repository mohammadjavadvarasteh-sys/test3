# v26.17

This release fixes premature blocking around long-running UI work.

Key behavior:
- Wait actions are treated as time-progressing observations, not immediate no-progress loops.
- If typing/selecting causes a real busy/loading surface, the engine correlates the request and re-observes the page before deciding what to do next.
- Loading detection ignores hidden/stale `pending` or text signals unless a strong live loading indicator is present.

Validation: 142/142 tests, Python compile, and JavaScript syntax checks pass.


## v26.18 Async settlement

Runtime async settlement is now observation-driven: after an action creates a live BUSY/LOADING surface, the engine polls the current Page-Agent state (and correlates network evidence when available) before asking the model for another decision. A model-selected `wait` is not a blind fixed sleep; when no async signal exists it is skipped and the agent replans immediately. Repeated waits on the same async condition are rejected, and premature non-success finishes immediately after a wait/async transition are guarded.


## v26.20
Generic UI loading/busy detection and model-exposed wait actions were removed. Network response correlation and explicit runtime cooldown recovery remain.
