# Agentic QA v26.18 — Async Settlement / Wait Loop Fix

## Goal
Stop LLM-generated wait loops around slow UI/network operations while improving action-outcome accuracy.

## Changes
- Detect BUSY/LOADING across the whole semantic page, not only the clicked target.
- After an action creates a live busy surface, the runtime polls Page-Agent state and optionally network evidence until the async operation settles, without consuming model/browser action budget.
- A model-selected `wait` is now smart: it settles an observed async operation internally instead of issuing repeated fixed sleeps.
- Repeated waits against the same live async state are rejected so the model must replan.
- `finish` is rejected while a live BUSY/LOADING surface remains visible.
- New bounded async wait configuration: `ASYNC_OPERATION_WAIT_MAX_MS` (default 12000) and `ASYNC_OPERATION_POLL_MS` (default 250).

## Design reference
The behavior follows the current Playwright MCP guidance that browser actions already wait for triggered navigation/network activity, while explicit waiting should target a concrete condition rather than blind fixed sleeps.
