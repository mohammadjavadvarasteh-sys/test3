# v13

- Added a generic runtime-derived multi-field typing guard. Related single-character textboxes are batched through one `browser_fill_form` action instead of separate model turns.
- No OTP/CAPTCHA label, field count, selector, URL, route, or site-specific workflow is hard-coded.
- Successful typing no longer instructs the agent to take a fresh snapshot merely to confirm the typed value.
- Human-paced typing no longer performs an automatic final snapshot after every field/action.
- Human batch typing performs at most one initial value snapshot for the whole batch, not one snapshot per field.
- Existing combined observation, Network/Console, recording, semantic grounding, and zero-hardcoding behavior remain intact.
