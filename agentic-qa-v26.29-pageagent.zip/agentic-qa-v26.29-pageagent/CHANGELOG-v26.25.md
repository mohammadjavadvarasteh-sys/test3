# Agentic QA v26.25 — Same-Host Trusted Provenance Fix

## Goal
v26.24 added multi-strategy URL resolution, but `open_application_link`
and `open_new_tab` still failed on the real PKI sandbox even with HTTPS
and a valid clipboard URL. The root cause was in the navigation policy:
same-host URLs were always rejected as 'guessed routes' even when the
runtime had just read them from the trusted clipboard.

## Root cause
`PolicyEngine.check_navigation()` checked trusted provenance ONLY for
external URLs (different host from the mission). For same-host URLs
(e.g. `https://sandbox.pki.partdp.ir/contract/share?token=abc`), the
policy always denied navigation unless the URL was in the observed
navigation targets set — regardless of provenance.

This meant:
1. `open_application_link` read the URL from the clipboard, built
   `provenance=clipboard_from_application` evidence, but the policy
   rejected it because the URL was on the same host and wasn't in the
   observed-href set.
2. The LLM then called `read_clipboard` (which returned the URL) and
   `open_new_tab` (which also failed because the LLM can't construct
   trusted provenance — only the runtime can).

Most SPA share links are on the SAME host as the application, just a
different path (e.g. `/contract/share?token=...`). So this bug blocked
the entire 'copy link → open in new tab' flow.

## Changes

### Policy: trusted provenance checked first for ALL URLs
`check_navigation()` now checks `is_trusted(evidence)` BEFORE the
same-host restriction. This means:
- `clipboard_from_application` provenance → approved (same-host OR external)
- `application_generated` provenance → approved (same-host OR external)
- `observed_href` provenance → approved (same-host OR external)
- Untrusted provenance + same-host → still denied ("guessed route")
- Untrusted provenance + external → still denied ("untrusted provenance")

The same-host restriction now only applies to UNTRUSTED provenance,
which is the correct behavior: the restriction exists to prevent the
LLM from guessing routes like `/admin/delete-all`, not to block
runtime-verified clipboard URLs.

### Agent: read_clipboard registers trusted evidence
When `read_clipboard` returns a URL, the runtime now:
1. Extracts the URL from the clipboard text
2. Builds `provenance=clipboard_from_application` navigation evidence
3. Registers it with the policy

This means the LLM can immediately call `open_new_tab` or `navigate`
with that URL and the policy will approve it — no need for the LLM to
construct navigation evidence (which it can't do).

### Agent: open_new_tab/navigate auto-attach clipboard evidence
When `open_new_tab` or `navigate` is called with a URL that matches
the last clipboard-read URL, the runtime auto-attaches the trusted
clipboard evidence. This closes the loop for the case where the LLM
reads the clipboard and then opens the URL in a new tab manually.

### Tests
- 6 new regression tests covering: same-host clipboard URL approval,
  same-host application-generated URL approval, same-host untrusted URL
  still denied, external clipboard URL still approved, end-to-end
  `open_application_link` with same-host share link, and
  `read_clipboard` → `open_new_tab` evidence flow.
- All 166 tests pass (160 from v26.24 + 6 new).

## Upstream alignment
The Alibaba Page Agent control loop is unchanged. The fix only corrects
the navigation policy so that runtime-verified application artifacts
(clipboard URLs, DOM-observed URLs) are trusted regardless of whether
they are on the same host as the mission. This is consistent with the
project's provenance-based (not domain-based) trust model.
