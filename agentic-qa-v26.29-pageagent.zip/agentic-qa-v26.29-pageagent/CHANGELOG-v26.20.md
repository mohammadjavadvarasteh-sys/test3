# Agentic QA v26.20 — Remove UI Loading Heuristics

## Why

Previous versions tried to infer asynchronous progress from UI attributes such as `aria-busy`, `data-loading`, loading classes, spinner descendants, and pending/loading state labels. In real component libraries these signals were frequently stale or business-state related, which caused false `wait` loops and premature blocking.

## Changes

- Removed UI `busy/loading` inference from the Page-Agent controller.
- Removed `busy` / `busyOwner` from Page-Agent element status.
- Removed loading-based runtime guards and async settle polling from the agent loop.
- Removed the `wait` tool from the model-exposed tool catalog.
- Kept `wait` internally for explicit runtime recovery such as an observed OTP resend cooldown.
- Kept network correlation for click/upload (and opt-in input/select correlation) independent of any UI loading signal.
- Kept action outcome/state transition observation after every action.
- Kept disabled semantic-owner protection and loop breakers for genuinely disabled controls.
- Removed the 120 ms post-action loading/settle poll; the action's fresh state and correlated response are authoritative.

## Result

The agent no longer waits because a UI control looks slow, has a pending class, has a stale busy flag, or contains a spinner. It decides from the actual action result, current Page-Agent state, and correlated network response.
