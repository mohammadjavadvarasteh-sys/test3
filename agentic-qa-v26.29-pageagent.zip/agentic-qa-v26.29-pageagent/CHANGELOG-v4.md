# v4 regression fixes

- Ground semantic selection in the user-authored mission goal; the model cannot redefine the requested concept to justify an option.
- Enforce a single hard action budget across browser actions and internal agent actions such as human checkpoints and findings.
- Prevent PASS when the latest browser snapshot still contains unresolved generic validation indicators.
- Downgrade any outcome whose action count exceeds the configured budget.
- Added regression tests for semantic-claim rewriting, unresolved validation, and budget outcome enforcement.
