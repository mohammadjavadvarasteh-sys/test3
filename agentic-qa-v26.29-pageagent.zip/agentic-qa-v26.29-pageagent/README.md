## v26.21 — Page-Agent execution model

This build follows Alibaba Page Agent's core loop: **observe live DOM → reflect → one indexed action → refresh state → repeat**. QA evidence/policy remains as an outer safety layer.

### v26.20 — UI loading heuristics removed

The Page-Agent runtime no longer models generic UI `loading`/`busy` state. No model `wait` tool is exposed for that purpose. Explicit runtime recovery (for example OTP resend cooldown) may still wait on an observed timer. Click/upload network correlation and action-outcome/state-transition evidence remain enabled.


The runtime now scopes loading detection to the action target, correlates completed network activity before waiting, and prevents blind model-generated waits for generic loading/pending states.

# Agentic QA v26.16

حالت‌های `pending` صرفاً به خاطر نام pending دیگر BUSY/LOADING محسوب نمی‌شوند؛ فقط سیگنال‌های صریح loading یا aria-busy مبنا هستند.

## v26.15 — Balanced speed + accuracy

- Restored more Page-Agent state/history context while keeping the actor action-oriented.
- Increased fast actor output budget to 768 tokens; added a single retry budget for malformed JSON.
- Replaced broad keyword form autofill with a high-confidence, unique-target fast path; ambiguous repeated identifiers fall back to the LLM.
- Removed redundant immediate Page-Agent state polling; a tiny settle poll is used only when the first post-action state is unchanged.
- Network correlation remains focused on clicks/uploads by default; input/select probes are opt-in to avoid per-field latency.
- Successful network response bodies are not fetched by default; failure bodies remain fully inspectable.
- See `docs/PERFORMANCE-ACCURACY-2026-10.md`.

# Agentic QA v26.15

## v26.12 disabled-surface decision
The runtime now treats a disabled interaction surface as a semantic unit, including portal-rendered dropdowns/searchboxes connected through standard ARIA ownership (`aria-controls` / `aria-owns`). When an action is blocked, prerequisite candidates are returned to the actor. Repeating the same disabled surface in the same live state is blocked by the executor, forcing a strategy change instead of an LLM loop.


### v26.10.1
Regression fix: restored `QAReActAgent._dom_action_signature()` required by the ReAct loop. The method is internal-only and is used to distinguish repeated DOM actions by tool and arguments.
# Agentic QA v26.10

- Deterministic guard prevents fabricated phone/mobile values when the mission does not contain the actual number.
- Generic semantic find aliases cover login/confirm/forgot-password/phone concepts across English/Persian UI labels.
- Exact observed control labels are preserved in action evidence; generic labels such as «تأیید» are not renamed to «Login».
- Rejected/unobserved navigation targets are not retried as guessed routes.
- Modal/current-state transitions are treated as state changes; agent is instructed to re-observe instead of repeating the previous control.

## v26.9 modal-aware semantic state

Active dialogs/modals are treated as authoritative interaction surfaces. Their controls remain visible to Page-Agent state even when a backdrop or portal overlay makes `elementFromPoint()` hit another layer. Dialog state is explicitly surfaced, and a bounded 80ms settle is used only when an active dialog exists but its interactive surface has not rendered yet. Clicks use a bounded 160ms UI settle before the normal post-action observation.

The exploratory prompt no longer encourages translated/guessed login labels or routes; action selection must use the exact currently observed role/name/context.


## v26.8 runtime behavior

Fast Actor Mode is enabled by default for `explore`. OTP timers are treated as resend cooldown evidence, not as a generic lock on OTP entry. The runtime can read an application-copied URL from the trusted clipboard path and open it in a new browser tab. CMD output is line-buffered and human checkpoints tolerate a queued Enter from slow model output.


### v26.8 disabled semantic-owner guard
Custom controls may expose a disabled state on a wrapper while keeping a child input/searchbox technically enabled. v26.8 treats disabledness as a semantic subtree property (aria-disabled, inert, fieldset, data-disabled/data-state, semantic-owner pointer-events:none/disabled class) and blocks click/input/select on descendants before execution.

## v26.11 Fast Actor
- Fast actor LLM output is constrained to a short action-oriented response; routine field filling uses a conservative local fast-path when a mission literal unambiguously matches an observed editable field.
- Fast mode keeps realistic typing off unless `AGENTIC_QA_FAST_KEEP_REALISTIC_TYPING=1` is set, so routine form entry does not incur per-key delays.
- `AGENTIC_QA_FAST_AI_MAX_TOKENS` defaults to 384.
- No site-specific selector or route was added.

### v26.13 action outcome awareness
The explorer now reports what actually changed after each action (target effect, URL/dialog/timer changes and correlated response) instead of relying on the model's assumption that a click succeeded. A bounded observation settle is used only when the first state appears unchanged.


### v26.13.1
Hotfix for the missing `hashlib` import used by settled Page-Agent state hashing.


### v26.13.2
Hotfix for pre-action Page-Agent state initialization in the normal action path.
