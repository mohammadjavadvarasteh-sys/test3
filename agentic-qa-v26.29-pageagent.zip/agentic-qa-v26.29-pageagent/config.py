# =====================================================================
# agentic-qa — config.py
# ---------------------------------------------------------------------
# تمام تنظیمات از .env خوانده می‌شود (قابل override با متغیر محیطی).
# یک فایل .env.example در پروژه هست — کپی کنید به .env و مقدار دهید.
# =====================================================================

import os
import shlex

# مسیر ریشه پروژه (پوشه‌ای که این فایل داخل آن است)
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))


# ---------------------------------------------------------------------
# بارگذاری سبک .env — بدون وابستگی خارجی
# ---------------------------------------------------------------------

def load_env(env_file: str = ".env") -> dict:
    """یک .env ساده را می‌خواند و در os.environ می‌ریزد (بدون بازنویسی مقادیر موجود)."""
    path = os.path.join(PROJECT_ROOT, env_file)
    loaded = {}
    if not os.path.exists(path):
        return loaded

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:      # env var واقعی اولویت دارد
                os.environ[key] = value
                loaded[key] = value
    return loaded


ENV_LOADED = load_env()


def _get(name: str, default: str = "") -> str:
    """مقدار از محیط (env var یا .env) — با پیشوند AGENTIC_QA_ هم قابل override."""
    return (
        os.environ.get(f"AGENTIC_QA_{name}")
        or os.environ.get(name)
        or default
    )


# ---------------------------------------------------------------------
# اتصال هوش مصنوعی — هر endpoint سازگار با OpenAI
#   مثال:  OPENAI_BASE_URL=http://localhost:3000/v1
#           OPENAI_API_KEY=sk-...
#           MODEL=gpt-oss-120b
# ---------------------------------------------------------------------

# پایه‌ی آدرس (بدون /chat/completions — خود کلاینت اضافه می‌کند)
AI_BASE_URL = _get("OPENAI_BASE_URL", "http://localhost:3000/v1").rstrip("/")

AI_API_KEY = _get("OPENAI_API_KEY", "")

AI_MODEL = _get("MODEL", "gpt-oss-120b")

# مدل سبک‌تر برای کارهای کم‌اهمیت (تولید عنوان، خلاصه و ...)
AI_MODEL_FAST = _get("MODEL_FAST", AI_MODEL)

# تایم‌اوت (ثانیه) برای هر فراخوانی LLM
AI_TIMEOUT = int(_get("AI_TIMEOUT", "180"))

AI_TEMPERATURE = float(_get("AI_TEMPERATURE", "0.1"))

# حداکثر توکن پاسخ مدل
AI_MAX_TOKENS = int(_get("AI_MAX_TOKENS", "1024"))

# Fast interactive actor mode: smaller prompts/output and less retained history.
FAST_MODE = _get("FAST_MODE", "1") not in ("0", "false", "no")
FAST_AI_MAX_TOKENS = int(_get("FAST_AI_MAX_TOKENS", "768"))
FAST_KEEP_REALISTIC_TYPING = _get("FAST_KEEP_REALISTIC_TYPING", "0") not in ("0", "false", "no")
FAST_AI_RETRIES = int(_get("FAST_AI_RETRIES", "1"))

# ---------------------------------------------------------------------
# Playwright MCP — لایه کنترل مرورگر (بدون selector)
# ---------------------------------------------------------------------

# اگر خواستید دستی سرور را اجرا کنید:
#   AGENTIC_QA_MCP_CMD="node C:/mcp/playwright-mcp/cli.js --browser chrome"
MCP_CMD_OVERRIDE = _get("MCP_CMD", "")

# آرگومان‌های اضافی سرور MCP — مثال:
#   AGENTIC_QA_MCP_ARGS="--browser chrome --viewport-size 1280,800"
#   AGENTIC_QA_MCP_ARGS="--headless"
MCP_ARGS = shlex.split(_get("MCP_ARGS", ""))

# نام باینری‌های نصب global (بعد از npm i -g @playwright/mcp).
# ⚠ نسخه‌های جدید پکیج نام باینری را عوض کرده‌اند — هر دو چک می‌شوند:
#   نسخه‌های جدید (≈0.0.30+): playwright-mcp
#   نسخه‌های قدیمی:           mcp-server-playwright
MCP_GLOBAL_BINS = [
    b.strip()
    for b in _get(
        "MCP_GLOBAL_BINS",
        "playwright-mcp, mcp-server-playwright",
    ).split(",")
    if b.strip()
]

# پکیج npx
MCP_NPX_PACKAGE = _get("MCP_NPX_PACKAGE", "@playwright/mcp@latest")

# تایم‌اوت هر فراخوانی ابزار MCP (ثانیه) — ناوبری ممکن است کند باشد
MCP_TOOL_TIMEOUT = int(_get("MCP_TOOL_TIMEOUT", "120"))

# تایم‌اوت startup (اولین اجرای npx ممکن است پکیج را دانلود کند)
MCP_STARTUP_TIMEOUT = int(_get("MCP_STARTUP_TIMEOUT", "180"))

# بعد از هر اکشن تغییردهنده (click/type/...)، اگر نتیجه‌ی خودش snapshot
# نداشت، خودکار browser_snapshot گرفته شود؟ (پیش‌فرض: بله)
MCP_AUTO_SNAPSHOT = _get("AUTO_SNAPSHOT", "1") not in ("0", "false", "no")

# تایپ واقعی مثل کاربر واقعی (پیش‌فرض: روشن)
# ⚠ کاوش در سورس MCP نشان داد slowly=true → pressSequentially با
#   delay=0 است (کاراکترها عملاً یک‌جایی ظاهر می‌شوند = حس paste).
#   برای همین تایپ انسانی «واقعی» در لایه‌ی کلاینت MCP پیاده شده:
#   کاراکتر اول با browser_type (فوکوس مطمئن + رویداد کلید) و بقیه‌ی
#   کاراکترها یکی‌یکی با browser_press_key + تأخیر تصادفی انسانی.
#   این fan-out فقط «یک اکشن منطقی» محسوب می‌شود (بدجه/بودجه اضافه
#   مصرف نمی‌کند) و در صورت خطا خودکار به fill یک‌جایی برمی‌گردد.
REALISTIC_TYPING = _get("REALISTIC_TYPING", "0") not in ("0", "false", "no")

# Page-Agent in-page typing uses the same opt-in switch, but has its own
# timing envelope so it does not multiply browser actions.
PAGE_AGENT_REALISTIC_TYPING = _get("PAGE_AGENT_REALISTIC_TYPING", "0") not in ("0", "false", "no")
PAGE_AGENT_TYPE_MIN_MS = int(_get("PAGE_AGENT_TYPE_MIN_MS", "55"))
PAGE_AGENT_TYPE_MAX_MS = int(_get("PAGE_AGENT_TYPE_MAX_MS", "125"))
PAGE_AGENT_TYPE_PAUSE_CHANCE = float(_get("PAGE_AGENT_TYPE_PAUSE_CHANCE", "0.015"))
PAGE_AGENT_TYPE_PAUSE_MIN_MS = int(_get("PAGE_AGENT_TYPE_PAUSE_MIN_MS", "140"))
PAGE_AGENT_TYPE_PAUSE_MAX_MS = int(_get("PAGE_AGENT_TYPE_PAUSE_MAX_MS", "320"))
PAGE_AGENT_TYPE_PRE_DELAY_MS = int(_get("PAGE_AGENT_TYPE_PRE_DELAY_MS", "40"))

# سقف طول متنی که کاراکتر-به-کاراکتر تایپ می‌شود (بیشترِ آن = paste)
TYPE_MAX_CHARS = int(_get("TYPE_MAX_CHARS", "120"))

# تأخیر بین کلیدها (میلی‌ثانیه) — توزیع یکنواخت + گاهی «مکث فکر»
# ⚠ این‌ها سرعت «واقعی» انسان را شبیه‌سازی می‌کنند؛ اگر باز هم
#   سریع/کند بود، همین‌ها را از .env تنظیم کنید.
TYPE_DELAY_MIN_MS = int(_get("TYPE_DELAY_MIN_MS", "20"))
TYPE_DELAY_MAX_MS = int(_get("TYPE_DELAY_MAX_MS", "60"))
TYPE_PAUSE_CHANCE = float(_get("TYPE_PAUSE_CHANCE", "0.02"))
TYPE_PAUSE_MIN_MS = int(_get("TYPE_PAUSE_MIN_MS", "120"))
TYPE_PAUSE_MAX_MS = int(_get("TYPE_PAUSE_MAX_MS", "300"))

# مکث «زمان واکنش» قبل از اولین کلید (مثل انسانی که فیلد را نگاه
# می‌کند و بعد شروع به تایپ می‌کند)
TYPE_PRE_DELAY_MIN_MS = int(_get("TYPE_PRE_DELAY_MIN_MS", "30"))
TYPE_PRE_DELAY_MAX_MS = int(_get("TYPE_PRE_DELAY_MAX_MS", "90"))

# فاصله‌ی انسانی بین فیلدهای متوالی در browser_fill_form
TYPE_FIELD_GAP_MIN_MS = int(_get("TYPE_FIELD_GAP_MIN_MS", "20"))
TYPE_FIELD_GAP_MAX_MS = int(_get("TYPE_FIELD_GAP_MAX_MS", "60"))

# ---------------------------------------------------------------------
# Observability / run recording
# ---------------------------------------------------------------------
# بررسی console/network به‌صورت هوشمند: در خطای ابزار، no-effect و
# سیگنال‌های validation/error به‌صورت خودکار جمع می‌شود. Agent همچنین
# می‌تواند ابزارهای browser_console_messages و browser_network_* را مستقیم صدا بزند.
OBSERVABILITY_ENABLED = _get("OBSERVABILITY_ENABLED", "1") not in ("0", "false", "no")
OBSERVE_ON_ERROR = _get("OBSERVE_ON_ERROR", "1") not in ("0", "false", "no")
OBSERVE_ON_NO_EFFECT = _get("OBSERVE_ON_NO_EFFECT", "1") not in ("0", "false", "no")
USE_MICRO_GOAL_PLANNER = _get("USE_MICRO_GOAL_PLANNER", "0") not in ("0", "false", "no")
OBSERVE_NETWORK_STATIC = _get("OBSERVE_NETWORK_STATIC", "0") not in ("0", "false", "no")
OBSERVE_CONSOLE_LEVEL = _get("OBSERVE_CONSOLE_LEVEL", "error")
# After a click, briefly poll MCP network traffic for an application request.
ACTION_NETWORK_PROBE_MS = int(_get("ACTION_NETWORK_PROBE_MS", "450"))
ACTION_NETWORK_POLL_MS = int(_get("ACTION_NETWORK_POLL_MS", "50"))

# ضبط مسیر اجرای مرورگر برای بازپخش تصویری. هر اکشن یک frame می‌سازد؛
# این ضبط خارج از action budget است. اگر سرعت مهم‌تر از recording است،
# AGENTIC_QA_RECORD_RUN=0 بگذارید.
RECORD_RUN = _get("RECORD_RUN", "0") not in ("0", "false", "no")

# Automatically follow a URL that the application has just copied to the clipboard
# when the mission explicitly asks to open that link in a new tab.
AUTO_FOLLOW_CLIPBOARD_LINKS = _get("AUTO_FOLLOW_CLIPBOARD_LINKS", "1") not in ("0", "false", "no")
RECORD_FPS = max(1, int(_get("RECORD_FPS", "5")))
RECORD_MAX_WIDTH = max(320, int(_get("RECORD_MAX_WIDTH", "1280")))
RECORD_MP4 = _get("RECORD_MP4", "1") not in ("0", "false", "no")
RECORD_EVERY_N_ACTIONS = max(1, int(_get("RECORD_EVERY_N_ACTIONS", "3")))

# ---------------------------------------------------------------------
# سیاست‌ها / مسیرها
# ---------------------------------------------------------------------

SKILLS_DIR = os.path.join(PROJECT_ROOT, _get("SKILLS_DIR", ".skills"))
RULES_DIR = os.path.join(PROJECT_ROOT, _get("RULES_DIR", ".rules"))
AGENTS_DIR = os.path.join(PROJECT_ROOT, _get("AGENTS_DIR", ".agents"))
STEERING_DIR = os.path.join(PROJECT_ROOT, _get("STEERING_DIR", ".steering"))
DOCS_DIR = os.path.join(PROJECT_ROOT, "docs")
EVIDENCE_DIR = os.path.join(PROJECT_ROOT, _get("EVIDENCE_DIR", ".evidence/runs"))
GENERATED_DIR = os.path.join(PROJECT_ROOT, _get("GENERATED_DIR", "generated"))

# ابزارهای MCP که به‌صورت پیش‌فرض مسدودند (اجتماع امنیت).
# browser_evaluate یعنی اجرای JS دلخواه — فقط با ALLOW_EVALUATE=1 باز می‌شود.
DENY_TOOLS = set()
ALLOW_EVALUATE = _get("ALLOW_EVALUATE", "0") in ("1", "true", "yes")
# The agent is additionally required to opt into arbitrary JS. The built-in
# controller uses browser_evaluate internally regardless; this flag only
# controls whether the LLM itself is allowed to request execute_javascript.
ALLOW_AGENT_JS = _get("ALLOW_AGENT_JS", "0") in ("1", "true", "yes")
if not ALLOW_EVALUATE:
    DENY_TOOLS.add("browser_evaluate")

# زبان خروجی spec های تولیدی: auto | fa | en
#   auto = هم‌زبان سورس (زبان label های UI تشخیص داده می‌شود)
SPEC_LANGUAGE = _get("SPEC_LANGUAGE", "auto")

# گزارش HTML تولید شود؟
HTML_REPORT = _get("HTML_REPORT", "1") not in ("0", "false", "no")

# خروجی گزارش verbos ترمینال
VERBOSE = _get("VERBOSE", "1") not in ("0", "false", "no")

# ---------------------------------------------------------------------
# پنل وب (اختیاری — python main.py panel)
# ---------------------------------------------------------------------

# آدرس bind — 127.0.0.1 فقط همین سیستم؛ 0.0.0.0 برای دسترسی از LAN
PANEL_HOST = _get("PANEL_HOST", "127.0.0.1")

# پورت پنل
PANEL_PORT = int(_get("PANEL_PORT", "8787"))

# حداکثر انتظار (ثانیه) برای پاسخ کاربر به ask_human از پنل (کپچا/OTP)
PANEL_ASK_TIMEOUT = int(_get("PANEL_ASK_TIMEOUT", "600"))

# Fast actor keeps routine field entry local; set to 0 to disable this optimization.
FAST_DIRECT_FORM_FILL = _get("FAST_DIRECT_FORM_FILL", "1") not in ("0", "false", "no")
# Balanced actor defaults: preserve enough live state/history for accuracy while keeping routine entry local.
FAST_PAGE_STATE_CHARS = int(_get("FAST_PAGE_STATE_CHARS", "9000"))
FAST_HISTORY_KEEP_FULL = int(_get("FAST_HISTORY_KEEP_FULL", "4"))
FAST_FORM_MAX_BATCH_ITEMS = int(_get("FAST_FORM_MAX_BATCH_ITEMS", "6"))
FAST_FORM_MIN_CONFIDENCE = float(_get("FAST_FORM_MIN_CONFIDENCE", "0.98"))
FAST_FORM_REQUIRE_UNIQUE_TARGET = _get("FAST_FORM_REQUIRE_UNIQUE_TARGET", "1") not in ("0", "false", "no")
# Network correlation is authoritative for clicks/submits; do not add a network probe to every keystroke.
CORRELATE_NETWORK_ON_INPUTS = _get("CORRELATE_NETWORK_ON_INPUTS", "0") not in ("0", "false", "no")
CORRELATE_NETWORK_ON_SELECT = _get("CORRELATE_NETWORK_ON_SELECT", "0") not in ("0", "false", "no")
COLLECT_SUCCESS_RESPONSE_BODY = _get("COLLECT_SUCCESS_RESPONSE_BODY", "0") not in ("0", "false", "no")
