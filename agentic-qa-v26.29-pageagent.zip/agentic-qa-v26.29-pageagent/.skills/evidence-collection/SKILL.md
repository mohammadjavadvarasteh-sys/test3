# Skill — Evidence Collection

- **Purpose:** Ensure every action/observation that could matter to a
  Verdict is captured in the shape `engine/evidence_store.py` expects.
- **Use when:** always, after every action (Constitution #1-4).
- **Strategy:** capture, at minimum: screenshot reference, structured
  observation (visible text / element states relevant to the
  requirement), timestamp, URL, and the triggering action. Redact fields
  listed in `.rules/evidence.yaml`.
- **Failure conditions:** missing required evidence fields for the verdict
  type per `.rules/evidence.yaml` → Oracle must downgrade to
  INCONCLUSIVE regardless of what Explorer believed happened.


## Runtime debugging evidence

- When an interaction fails or produces no observable state change, inspect `browser_console_messages` and `browser_network_requests`.
- Use `browser_network_request` for the exact request when status, headers or body are needed.
- Runtime observability is stored separately in `console.jsonl` and `network.jsonl` and is included in the HTML report.
- Network/console evidence is automatically redacted before persistence; secrets such as authorization/token/OTP must not be copied into findings.
- If the mission explicitly requires an API request derived from an observed request, use only observed request evidence. `browser_evaluate` is available only when the runtime safety setting explicitly enables it.

## Run recording

- The engine can capture one browser frame per executed action without consuming the action budget.
- At the end of the run it builds `run.gif`; when `ffmpeg` is installed and enabled it also builds `run.mp4`.
