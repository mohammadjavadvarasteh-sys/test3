# Skill — Authentication

- **Purpose:** Exercise login/logout/session-establishment flows.
- **Use when:** a login form, SSO button, or auth redirect is observed.
- **Do NOT use when:** Mission scope excludes auth (`scope.out` in Spec).
- **Preconditions:** test credentials referenced via Steering's secret
  store, never inlined.
- **Strategy:** valid credentials → session established; invalid → error,
  no session; empty fields → validation error. Never attempt bypass or
  brute force (Constitution #10).
- **Test categories:** valid_login, invalid_login, empty_fields, logout.
- **Allowed actions:** fill, submit, click logout.
- **Expected observations:** redirect/dashboard render, session
  cookie/token presence, error message.
- **Failure conditions:** invalid credentials produce a session; valid
  credentials rejected.
- **Recovery:** standard procedure.
- **Stopping conditions:** scenario set from the Spec exhausted.
