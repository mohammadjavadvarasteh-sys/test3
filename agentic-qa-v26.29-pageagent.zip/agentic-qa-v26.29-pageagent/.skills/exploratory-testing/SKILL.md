# Skill — Exploratory Testing

- **Purpose:** Discover features, states, and alternative paths for a
  Mission with no fully-specified click path (Level 3 freedom — see
  Constitution/Steering hierarchy).
- **Use when:** Mission `type: exploratory`, or Planner marks a
  requirement as discovery-oriented.
- **Do NOT use when:** A deterministic regression mission exists for the
  same flow — prefer that for repeat runs.
- **Preconditions:** `allowed_domains` boundary defined (Level 1 Safety
  still applies in full during exploration).
- **Strategy:** breadth-first traversal of reachable states from the
  entry point, bounded by `action_budget`; log every new state hash seen;
  flag anything resembling an edge case (error states, empty states,
  unusual permission states) as a Finding, not a Verdict — exploratory
  missions produce Findings, only Spec-linked requirements produce
  Verdicts (see `docs/architecture/overview.md`).
- **Test categories:** state_discovery, edge_case_discovery, path_discovery.
- **Allowed actions:** any non-destructive navigation/interaction inside
  the Safety boundary.
- **Expected observations:** new state signature (URL + DOM fingerprint).
- **Failure conditions:** n/a (Findings, not Verdicts) unless a Finding
  maps to an existing Spec requirement, in which case Oracle rules apply.
- **Recovery:** standard procedure.
- **Stopping conditions:** action budget exhausted, or state-space
  saturated (no new state signatures in `cycle_window` actions).
