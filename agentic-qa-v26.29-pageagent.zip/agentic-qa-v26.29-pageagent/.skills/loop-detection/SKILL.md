# Skill — Loop Detection (skill-level pointer)

Loop Detection is primarily enforced in code
(`engine/policy_engine.py::LoopDetector`), not prompt discipline
(Constitution #13). This file documents the behavioral contract so
Explorer/Recovery know what triggers it.

- **Use when:** always active during any mission execution, not
  selectively loaded.
- **Detects:**
  - same (action, target) repeated > `max_same_action_repeat`
  - same observed state hash repeated > `max_state_repetition`
  - A→B→C→A→B→C style cycles within `cycle_window` actions
  - alternating pattern (e.g. click → refresh → click → refresh)
- **On detect:** stop the current path immediately, surface
  `loop_detected` to Explorer/Recovery. Never "one more try" past this
  signal.
