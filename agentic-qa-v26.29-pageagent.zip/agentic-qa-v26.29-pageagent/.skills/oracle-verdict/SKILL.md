# Skill — Oracle / Verdict Evaluation (pointer)

Verdict logic is centralized in `engine/oracle.py` and the Oracle Agent
role (`.agents/oracle.md`) — this file exists only so it appears in
Dynamic Skill Selection listings. Do not duplicate verdict rules here;
edit `engine/oracle.py` and `.agents/oracle.md` instead.
