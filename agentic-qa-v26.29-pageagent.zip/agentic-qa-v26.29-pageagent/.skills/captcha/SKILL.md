# Skill — CAPTCHA

- **Purpose:** Recognize CAPTCHA as a hard boundary the agent must not try
  to defeat, and resolve to BLOCKED cleanly instead of looping.
- **Use when:** A CAPTCHA widget (image challenge, reCAPTCHA, hCaptcha,
  proof-of-work widget) is observed blocking the current flow.
- **Do NOT use when:** No CAPTCHA is present — don't pre-emptively load this.
- **Preconditions:** CAPTCHA widget visibly present in the DOM/screenshot.
- **Strategy:**
  ```
  max_attempts: 2
  on_failure: [inspect, refresh_if_supported, retry_once]
  if_still_blocked: verdict = BLOCKED
  ```
  The agent MUST NOT attempt to solve image/audio CAPTCHAs via guessing,
  external solving services, or brute force — this is a Constitution
  Safety violation, not just bad practice.
- **Test categories:** presence-detection only; CAPTCHA content itself is
  out of scope for functional assertions.
- **Allowed actions:** inspect, refresh (if a refresh control exists),
  retry submit once.
- **Expected observations:** CAPTCHA widget state before/after refresh.
- **Failure conditions:** n/a — this skill never produces FAIL, only
  BLOCKED or a handoff back to the flow if the CAPTCHA clears itself
  (e.g. invisible reCAPTCHA passing automatically).
- **Recovery:** loop-detection MUST be active in parallel — a CAPTCHA
  retry loop is exactly the "click → refresh → click → refresh" pattern
  Loop Detection is built to catch.
- **Stopping conditions:** `max_attempts` reached → BLOCKED immediately.
- **Examples:** login protected by reCAPTCHA v2 after 3 failed attempts →
  attempt once more, if still present → BLOCKED with
  `failure_reason: "captcha_requires_human"`.
