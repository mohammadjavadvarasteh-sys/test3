# Skill — Recovery (skill-level pointer)

The canonical Recovery procedure lives in `.agents/recovery.md` since
Recovery is also an Agent Role. This file exists so Dynamic Skill
Selection (`engine/skill_loader.py`) can activate it alongside other
skills (e.g. `captcha + recovery + loop-detection`) using the same
lookup mechanism.

- **Use when:** any action fails.
- **Strategy:** see `.agents/recovery.md`.
- **Stopping conditions:** `max_recovery_attempts` from `.rules/execution.yaml`.
