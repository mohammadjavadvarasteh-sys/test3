# Skill — File Upload

- **Purpose:** Verify upload constraints (type, size, count) against
  `.rules/validation.yaml` and the Spec.
- **Use when:** A file input or drag-and-drop upload zone is observed.
- **Do NOT use when:** n/a.
- **Preconditions:** Allowed MIME types / max size are declared in the
  Spec or `.rules/validation.yaml`; if neither declares them, treat as
  INCONCLUSIVE for constraint checks (Constitution #6 — don't invent).
- **Strategy:** representative partition, reusing `boundary-testing` and
  `negative-testing` skills:
  1. one valid file within limits
  2. one file exceeding max size
  3. one file of a disallowed MIME/extension
  4. one empty (0-byte) file
  5. one file with a misleading extension (if security scope includes it)
- **Test categories:** valid, oversized, wrong_type, empty, spoofed_extension.
- **Allowed actions:** upload, cancel, remove.
- **Expected observations:** client-side rejection message, server error,
  successful upload confirmation, progress indicator.
- **Failure conditions:** oversized/wrong-type file accepted; valid file
  rejected.
- **Recovery:** standard procedure.
- **Stopping conditions:** partition exhausted.

## Runtime upload bridge

When a live file chooser is observed and the mission provides an explicit local path, prefer the runtime `upload_file` action. The engine maps it to the official Playwright MCP `browser_file_upload` tool. Do not ask the human to manually attach a file that the runtime can access locally.

The in-page Page-Agent controller remains primary for DOM targeting; file upload is a deliberate hybrid browser capability because the page sandbox cannot manufacture a real OS FileList.
