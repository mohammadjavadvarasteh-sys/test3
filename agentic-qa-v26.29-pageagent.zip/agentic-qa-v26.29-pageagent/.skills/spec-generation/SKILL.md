# Skill — Spec Generation (source → spec)

- **Purpose:** Read a web project's SOURCE CODE (static scan, no
  execution) and produce executable, re-runnable QA Specs for its
  user-visible flows.
- **Use when:** mode `gen-spec` (command: `python main.py gen-spec
  --source <path>`), or when a feature has no Spec yet.
- **Do NOT use when:** a live app is available for exploration —
  prefer exploring first when source code is not accessible; do not
  generate specs for styling-only changes.
- **Preconditions:** source directory reachable; scanner
  (`engine/source_scanner.py`) collected files/routes/forms; a
  working LLM endpoint.
- **Strategy:**
  1. Scan (static): collect routes, forms, fields, buttons, labels,
     API calls — chunked and size-capped.
  2. Extract per chunk: features with entry points, forms and their
     OBSERVED constraints only.
  3. Plan: one YAML spec per meaningful flow (auth first), same
     language as the UI labels (Constitution-aligned: specs read like
     humans wrote them).
  4. Sanitize: strip any `selector` field (Constitution #14), default
     ids REQ-001..., attach `wait_for` only for acceptance criteria
     visible in code (labels/messages).
  5. Emit to `generated/specs/` + `INDEX.md`; flag uncertain steps
     with `review: needs-verification` instead of guessing
     (Constitution #6).
- **Test categories:** generated-auth-flows, generated-form-flows,
  generated-navigation-flows.
- **Allowed actions:** file reads, LLM analysis, YAML writing — never
  browser actions (this skill is offline).
- **Expected observations:** spec files load cleanly
  (`python main.py run <spec>` reaches the browser).
- **Failure conditions:** invented constraints (limits not present in
  code), selectors in output, hallucinated routes.
- **Recovery:** standard procedure (re-chunk, re-extract); a chunk
  that fails analysis twice is skipped, not retried forever.
- **Stopping conditions:** all chunks analyzed, or no user-visible
  behavior found.
- **Examples:**
  - React login page with `<input placeholder="شماره موبایل" required
    maxlength="11">` → step: `description: "وارد کردن شماره موبایل
    11 رقمی در فیلد شماره موبایل"`, `action: type`,
    `target_hint: "فیلد شماره موبایل"`, plus a negative case for a
    12-digit value ONLY because maxlength was in the code.
