# Skill — Form Validation

- **Purpose:** Verify input fields enforce type/format/length/required
  constraints from `.rules/validation.yaml` and the active Spec.
- **Use when:** Explorer encounters `<input>`, `<textarea>`, or
  equivalent form controls.
- **Do NOT use when:** The field is read-only/disabled, or already covered
  by a more specific skill (email → also load `email` sub-rules; file →
  use `file-upload` skill instead).
- **Preconditions:** Field is visible and enabled; its `type`/`name`/label
  is observable.
- **Strategy:** Build a **representative partition**, not exhaustive
  brute force:
  1. One valid value.
  2. One empty value (if `required`).
  3. One value violating each declared constraint (min/max length,
     format) — one case per constraint, not the cross-product.
  4. One boundary value (exactly at min/max length).
  5. Only if the field type warrants it: one whitespace-padding case,
     one Unicode case, one special-character case.
  Cap total generated cases per field at ~8. Never generate "hundreds of
  values" for one field (Constitution #12 execution budget applies).
- **Test categories:** required, format, min_length, max_length, boundary,
  whitespace, unicode, special_chars.
- **Allowed actions:** fill, clear, submit, blur.
- **Expected observations:** inline validation message, submit button
  state, server-side error on submit, aria-invalid attribute.
- **Failure conditions:** invalid value accepted silently; valid value
  rejected; no observable feedback either way (→ INCONCLUSIVE, not PASS).
- **Recovery:** standard procedure; if the form resets unexpectedly,
  treat as a `permanent` error class (do not retry blindly).
- **Stopping conditions:** partition exhausted, or action budget for this
  requirement reached.
- **Examples (email field):**
  - valid: `user@example.com`
  - invalid: `user`, `user@`, `@example.com`, `user@.`
  - whitespace: `" user@example.com"`, `"user@example.com "`
  - boundary: very long local-part, very long domain
