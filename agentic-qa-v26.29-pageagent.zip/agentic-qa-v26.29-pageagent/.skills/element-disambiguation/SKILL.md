# Skill — Element Disambiguation

- **Purpose:** Resolve interactions when MULTIPLE elements share the
  same visible name (the classic "two buttons both called ورود"
  problem) without ever falling back to positional or CSS selectors.
- **Use when:** the accessibility snapshot shows two or more elements
  with identical role+name, and the current goal requires one of them.
- **Do NOT use when:** names are unique — normal semantic addressing is
  enough; do not over-think.
- **Preconditions:** a FRESH browser_snapshot (refs are ephemeral and
  must come from the current page state, not memory).
- **Strategy:**
  1. **Ancestry first**: read the element's chain of parents in the
     accessibility tree — `button "ورود" inside dialog "پیام"` vs
     `button "ورود" inside form "ورود به سیستم"` are different
     targets. The parent region/dialog/form/menubar is the primary
     disambiguator.
  2. **Mission context second**: which step of the Spec/mission is
     running? A login-step goal wants the button in the login form;
     a dialog-confirmation goal wants the one inside the dialog.
  3. **Nearby headings/landmarks third**: the element under the
     heading "اسناد و قراردادها" region belongs to that section.
  4. **State cues**: enabled vs disabled, required vs optional, filled
     vs empty.
  5. If still genuinely unresolvable → ask_human with a question that
     names both candidates, or finish with BLOCKED and
     `failure_reason: "ambiguous_element"`.
- **Test categories:** duplicate-name click, duplicate-name typing,
  dialog-vs-page twins, menu-vs-footer twins.
- **Allowed actions:** snapshot, click/type on the chosen ref with a
  context-qualified `element` description, ask_human.
- **Expected observations:** the click lands on the intended context
  (URL/form state changes accordingly).
- **Failure conditions:** wrong twin clicked (e.g. dialog closed
  instead of form submitted) → the requirement FAILs; never silently
  retry the other twin more than once.
- **Recovery:** standard procedure; element_not_found class always
  re-snapshots before re-selecting.
- **Stopping conditions:** resolved, or two failed attempts, or human
  input obtained.
- **Examples:**
  - Two "ورود" buttons: one in `form "ورود"` (submit), one in
    `banner` (nav link). Step REQ-003 wants the form one → pick its
    ref and describe: "the ورود submit button inside the login form".
  - Four OTP textboxes with identical names: they are siblings under
    one group — address them in order with distinct refs, one
    browser_type per cell.
