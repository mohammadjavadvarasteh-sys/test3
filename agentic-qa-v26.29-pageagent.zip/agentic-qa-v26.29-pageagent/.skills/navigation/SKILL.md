# Skill — Navigation

- **Purpose:** General-purpose movement between states (menus, tabs,
  deep links) in support of other skills' goals.
- **Use when:** Explorer needs to reach a target area to begin a
  requirement-specific skill.
- **Strategy:** prefer stable selectors (role/label/text) over brittle
  ones (auto-generated CSS classes, index-based selectors).
- **Failure conditions:** n/a — navigation failures feed into Recovery,
  not directly into a Verdict.
