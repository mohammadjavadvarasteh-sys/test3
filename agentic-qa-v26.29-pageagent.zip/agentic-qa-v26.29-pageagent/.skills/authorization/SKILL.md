# Skill — Authorization

- **Purpose:** Probe role-gated views/actions strictly within
  Mission-approved scope (`.rules/security.yaml`).
- **Use when:** Mission `type: security` or explicitly includes
  authorization checks.
- **Strategy:** verify a lower-privilege actor cannot reach a
  higher-privilege view/action via direct navigation or forced browsing,
  using only credentials the Mission explicitly provides for each role.
- **Do NOT use when:** Mission doesn't provide multiple role credentials
  — do not attempt privilege escalation opportunistically.
- **Failure conditions:** lower-privilege actor reaches gated
  resource/action.
