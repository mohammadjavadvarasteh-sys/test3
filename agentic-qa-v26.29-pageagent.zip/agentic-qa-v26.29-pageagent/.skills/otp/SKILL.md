# Skill — OTP / One-Time Passcode

- **Purpose:** Handle OTP-gated flows without ever guessing a code.
- **Use when:** An OTP input, "code sent to..." message, resend/cooldown
  timer, or expiry message is observed.
- **Do NOT use when:** No OTP step exists in the flow.
- **Preconditions:** Mission/Steering states whether a real OTP retrieval
  channel (e.g. a test inbox/API) is available to the agent.
- **Strategy:**
  - If a real OTP source is available (per Mission config) → retrieve and
    submit it, budgeted like any other action.
  - If not available → do not guess, do not brute force. Resolve to
    BLOCKED with `failure_reason: "otp_unavailable"`.
  - Track: sent, expired, invalid, resend, cooldown, wrong-attempt-count,
    session-expiry-during-OTP as distinct observed states.
- **Test categories:** otp_sent, otp_expired, invalid_otp, resend_flow,
  cooldown_enforced.
- **Allowed actions:** fill (only with a retrieved real code), click resend
  (respecting cooldown), inspect.
- **Expected observations:** success transition, expiry message, cooldown
  timer value, attempt-limit message.
- **Failure conditions:** code accepted after documented expiry; resend
  ignores cooldown; no limit on wrong attempts when Spec requires one.
- **Recovery:** standard procedure; wrong-attempt retries count against
  `max_retries` like any other action — never silently expanded.
- **Stopping conditions:** OTP retrieval channel unavailable → BLOCKED
  immediately, do not attempt the flow further.
