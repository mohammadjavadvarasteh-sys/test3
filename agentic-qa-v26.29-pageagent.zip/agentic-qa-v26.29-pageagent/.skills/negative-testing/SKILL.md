# Skill — Negative Testing

- **Purpose:** Systematically try invalid/unexpected inputs and actions
  that the Spec's `negative_cases` calls out.
- **Use when:** a Spec lists `negative_cases`.
- **Strategy:** for each named negative case, derive the minimal concrete
  input from `form-validation`/`boundary-testing` and confirm graceful
  handling (visible error, no corrupted state), not just "it didn't
  crash."
- **Failure conditions:** invalid input silently accepted, or causes an
  unhandled error state (blank page, stack trace visible, app stuck).
