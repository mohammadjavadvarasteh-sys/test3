# Skill — Session Expiry

- **Purpose:** Verify behavior once a session has expired or been
  invalidated mid-flow.
- **Use when:** Spec/Steering documents a session TTL, or Recovery
  detects an unexpected auth redirect mid-mission.
- **Strategy:** if the Mission provides a way to force expiry
  (short-TTL test account, explicit invalidation endpoint), use it; if
  not, this skill remains dormant rather than waiting out a real TTL
  (that belongs in a scheduled deterministic mission, not an interactive
  agentic run).
- **Test categories:** expired_redirect, expired_api_call,
  concurrent_session_invalidation (if in scope).
- **Expected observations:** redirect to login, or a clear "session
  expired" message; no silent failure/blank state.
- **Failure conditions:** expired session still allows protected actions.
- **Recovery:** treat mid-mission expiry as `session_expired`, hand back
  to Explorer as BLOCKED for the in-flight requirement, not a crash.
