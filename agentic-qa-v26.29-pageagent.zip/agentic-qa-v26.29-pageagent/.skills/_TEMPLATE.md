# Skill — <name>

- **Purpose:**
- **Use when:**
- **Do NOT use when:**
- **Preconditions:**
- **Strategy:**
- **Test categories:**
- **Allowed actions:**
- **Expected observations:**
- **Failure conditions:**
- **Recovery:** (link to `.agents/recovery.md` procedure, note any skill-specific step)
- **Stopping conditions:**
- **Examples:**
