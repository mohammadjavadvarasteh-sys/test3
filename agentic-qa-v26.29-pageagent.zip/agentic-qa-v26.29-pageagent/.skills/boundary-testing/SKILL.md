# Skill — Boundary Value Testing

- **Purpose:** Test values exactly at declared limits (min/max length,
  size, count) from `.rules/validation.yaml` or the Spec.
- **Use when:** a numeric/length constraint is declared.
- **Strategy:** test at limit, one below, one above — 3 cases per
  constraint, not a wide sweep.
- **Failure conditions:** off-by-one acceptance/rejection.
