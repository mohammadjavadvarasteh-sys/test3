# v5 Architecture Fix

## Root cause fixed
- Same-origin host matching previously allowed unobserved/guessed routes.
- No-effect protection could be bypassed by a changed snapshot representation even when the semantic page state had not changed.
- The agent prompt did not explicitly force evidence-first recovery after a no-effect interaction.

## Architecture changes
- `SnapshotIndex` now extracts explicitly observed navigation URLs from accessibility-tree `/url:` nodes.
- `PolicyEngine` now treats same-origin as trusted only for the current observed URL or an exact observed navigation target; arbitrary same-origin paths are blocked.
- `PolicyEngine` keeps trusted external provenance behavior unchanged.
- No-effect retry protection is state-hash based, not snapshot-text-epoch based.
- A genuinely changed page state clears the no-effect block and permits a new strategy.
- Agent navigation/recovery guidance explicitly forbids guessed routes after no-effect interactions.

## Verification
- Python compileall: PASS
- Regression suite: 29/29 PASS
- No site-specific selectors, domains, routes, credentials, or product-specific rules were added.
